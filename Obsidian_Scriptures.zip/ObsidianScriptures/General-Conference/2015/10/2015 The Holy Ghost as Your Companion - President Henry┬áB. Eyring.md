President Henry B. Eyring
First Counselor in the First Presidency
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/the-holy-ghost-as-your-companion?lang=eng)

_We can, if we live worthy of it, have the blessing of the Spirit to be with us, not only now and then but always._

My dear brothers and sisters, I am grateful to be with you on this Sabbath day in the general conference of the Lord’s Church. I have felt, as you have, the Spirit, the Holy Ghost, testifying to the words of truth we have heard spoken and sung.

My purpose today is to increase your desire and your determination to claim the gift promised to each of us after we were baptized. During our confirmation we heard these words: “Receive the Holy Ghost.”1 From that moment, our lives changed forever.

We can, if we live worthy of it, have the blessing of the Spirit to be with us, not only now and then, as in such remarkable experiences as we’ve had today, but always. You know from the words of the sacrament prayer how that promise is fulfilled: “O God, the Eternal Father, we ask thee in the name of thy Son, Jesus Christ, to bless and sanctify this bread to the souls of all those who partake of it, that they may eat in remembrance of the body of thy Son, and witness unto thee, O God, the Eternal Father, that they are willing to take upon them the name of thy Son, and always remember him and keep his commandments which he has given them.”

And then comes the glorious promise: “That they may always have his Spirit to be with them” (D&C 20:77; emphasis added).

To always have the Spirit with us is to have the guidance and direction of the Holy Ghost in our daily lives. We can, for instance, be warned by the Spirit to resist the temptation to do evil.

For that reason alone, it is easy to see why the Lord’s servants have tried to increase our desire to worship God in our sacrament meetings. If we partake of the sacrament in faith, the Holy Ghost will then be able to protect us and those we love from the temptations that come with increasing intensity and frequency.

The companionship of the Holy Ghost makes what is good more attractive and temptation less compelling. That alone should be enough to make us determined to qualify for the Spirit to be with us always.

Just as the Holy Ghost strengthens us against evil, He also gives us the power to discern truth from falsehood. The truth that matters most is verified only by revelation from God. Our human reason and the use of our physical senses will not be enough. We live in a time when even the wisest will be hard-pressed to distinguish truth from clever deception.

The Lord taught His Apostle Thomas, who wanted physical evidence of the Savior’s Resurrection by touching His wounds, that revelation is safer evidence: “Jesus saith unto him, Thomas, because thou hast seen me, thou hast believed: blessed are they that have not seen, and yet have believed” (John 20:29).

The truths that mark the way home to God are verified by the Holy Ghost. We cannot go to the grove and see the Father and the Son speak to the young Joseph Smith. No physical evidence or any logical argument can establish that Elijah came as promised to confer the priesthood keys now held and exercised by a living prophet, Thomas S. Monson.

Confirmation of truth comes to a son or daughter of God who has claimed the right to receive the Holy Ghost. Since falsehoods and lies may be presented to us at any time, we need a constant influence of the Spirit of Truth to spare us moments of doubt.

While a member of the Quorum of the Twelve Apostles, George Q. Cannon urged that we make a constant quest for the Spirit to be with us. He promised, and I promise it as well, that if we pursue that course, we “will never lack for knowledge” of the truth, “never be in doubt or in darkness,” and our “faith will be strong, [our] joy … full.”2

We need that constant help from the companionship of the Holy Ghost for yet another reason. The death of a loved one may come unexpectedly. It is the witness from the Holy Ghost of the reality of a loving Heavenly Father and a resurrected Savior that gives us hope and comfort at the loss of a loved one. That testimony must be fresh when death occurs.

So, for many reasons, we need the constant companionship of the Holy Ghost. We desire it, yet we know from experience that it is not easy to maintain. We each think, say, and do things in our daily lives that can offend the Spirit. The Lord taught us that the Holy Ghost will be our constant companion when our hearts are full of charity and when virtue garnishes our thoughts unceasingly (see D&C 121:45).

For those who are struggling with the high standard needed to qualify for the gift of the Spirit’s companionship, I offer this encouragement. You have had times when you have felt the influence of the Holy Ghost. It may have happened for you today.

You can treat those moments of inspiration like the seed of faith that Alma described (see Alma 32:28). Plant each one. You can do that by acting on the prompting you felt. The most valuable inspiration will be for you to know what God would have you do. If it is to pay tithing or to visit a grieving friend, you should do it. Whatever it is, do it. When you demonstrate your willingness to obey, the Spirit will send you more impressions of what God would have you do for Him.

As you obey, the impressions from the Spirit will come more frequently, becoming closer and closer to constant companionship. Your power to choose the right will increase.

You can know when these impressions to act for Him are from the Spirit rather than from your own desires. When the impressions square with what the Savior and His living prophets and apostles have said, you can choose to obey with confidence. Then the Lord will send His Spirit to attend you.

For example, if you receive a spiritual impression to honor the Sabbath day, especially when it seems difficult, God will send His Spirit to help.

That help came to my father years ago when his work took him to Australia. He was alone on a Sunday, and he wanted to take the sacrament. He could find no information about Latter-day Saint meetings. So he started walking. He prayed at each intersection to know which way to turn. After walking and making turns for an hour, he stopped to pray again. He felt an impression to turn down a particular street. Soon he began to hear singing coming from the ground floor of an apartment building close by. He looked in at the window and saw a few people seated near a table covered with a white cloth and sacrament trays.

Now, that may not seem like much to you, but it was something wonderful to him. He knew the promise of the sacrament prayer had been fulfilled: “Always remember him and keep his commandments which he has given them; that they may always have his Spirit to be with them” (D&C 20:77).

That was only one example of a time when he prayed and then did what the Spirit told him God wanted him to do. He kept at it over the years, as you and I will. He never talked about his spirituality. He just kept on doing little things for the Lord that he was prompted to do.

Whenever some group of Latter-day Saints asked him to speak to them, he did it. It didn’t matter if it was 10 people or 50 or how tired he was. He bore his testimony of the Father, the Son, and the Holy Ghost and of the prophets whenever the Spirit urged him to do it.

His highest callings in the Church were to the Bonneville Utah Stake high council, where he weeded on the stake farm, and he taught a Sunday School class. Over the years, when he needed it, the Holy Ghost was there as his companion.

I stood next to my father in a hospital room. My mother, his wife of 41 years, lay on the bed. We had watched her for hours. We began to see the lines of pain disappear from her face. The fingers of her hands, which had been clenched into fists, relaxed. Her arms came to rest at her sides.

The pains of decades of cancer were ending. I saw on her face a look of peace. She took a few short breaths, then a gasp, and then lay still. We stood there waiting to see if another breath would come.

Finally, Dad said quietly, “A little girl has gone home.”

He shed no tears. That was because the Holy Ghost had long before given him a clear picture of who she was, where she came from, what she had become, and where she was going. The Spirit had testified to him many times of a loving Heavenly Father, of a Savior who had broken the power of death, and of the reality of the temple sealing he shared with his wife and family.

The Spirit had long before assured him that her goodness and faith had qualified her for the return to a heavenly home where she would be remembered as a wonderful child of promise and be welcomed home with honor.

For my dad, that was more than a hope. The Holy Ghost had made it a reality for him.

Now, some might say that his words and the pictures in his mind about a heavenly home were just a sweet sentiment, the clouded judgment of a husband at the moment of his loss. But he knew eternal truth the only way you can know it.

He was a scientist who searched for truth about the physical world throughout his entire adult life. He used the tools of science well enough to be honored by his peers across the world. Much of what he did in chemistry came from seeing in his mind’s eye molecules moving about and then confirming his vision by experiments in a laboratory.



But he had followed a different course to discover the truths that mattered most to him and to each of us. Only through the Holy Ghost can we see people and events as God sees them.

That gift continued in the hospital after his wife died. We gathered up my mother’s things to take home. Dad stopped to thank every nurse and doctor we met on the way out to the car. I remember I felt, with some irritation, that we should leave to be alone with our grief.

I realize now that he saw things only the Holy Ghost could have shown him. He saw those people as angels sent by God to watch over his sweetheart. They may have seen themselves as health care professionals, but Dad was thanking them for their service on behalf of the Savior.

The influence of the Holy Ghost continued with him as we arrived at the home of my parents. We talked for a few minutes in the living room. Dad excused himself to go into his nearby bedroom.

After a few minutes, he walked back into the living room. He had a pleasant smile. He walked up to us and said quietly, “I was worried that Mildred would arrive in the spirit world alone. I thought she might feel lost in the crowd.”

Then he said brightly, “I prayed just now. I know Mildred is all right. My mother was there to meet her.”

I remember smiling as he said that, imagining my grandmother, her short legs pumping, rushing through a crowd to be sure she was there to meet and embrace her daughter-in-law as she arrived.

Now, one of the reasons my father asked for and received that comfort was because he had always prayed in faith since his childhood. He was used to getting answers that came to his heart to give comfort and direction. In addition to having a habit of prayer, he knew the scriptures and the words of living prophets. So he recognized the familiar whisperings of the Spirit, which you may have felt today.

The companionship of the Spirit had more than comforted and guided him. It changed him through the Atonement of Jesus Christ. When we accept that promise of having the Spirit with us always, the Savior can grant us the purification required for eternal life, the greatest of all the gifts of God (see D&C 14:7).

You remember the Savior’s words: “Now this is the commandment: Repent, all ye ends of the earth, and come unto me and be baptized in my name, that ye may be sanctified by the reception of the Holy Ghost, that ye may stand spotless before me at the last day” (3 Nephi 27:20).

Those commandments come with this promise from the Lord:

“And now, verily, verily, I say unto thee, put your trust in that Spirit which leadeth to do good—yea, to do justly, to walk humbly, to judge righteously; and this is my Spirit.

“Verily, verily, I say unto you, I will impart unto you of my Spirit, which shall enlighten your mind, which shall fill your soul with joy” (D&C 11:12–13).

I bear you my testimony that God the Father lives, that the resurrected Jesus Christ leads His Church, that President Thomas S. Monson holds all the keys of the priesthood, and that revelation through the Holy Ghost guides and sustains The Church of Jesus Christ of Latter-day Saints and its humble members.

I further testify to you that these wonderful men who have today been speaking to us as witnesses of the Lord Jesus Christ, as members of the Quorum of the Twelve Apostles, are called of God. I know that the Spirit led President Monson to call them. And as you listened to them and their testimonies, the Holy Spirit confirmed to you what I now say to you. They are called of God. I sustain them and love them and know that the Lord loves them and will sustain them in their service. And I do it in the name of the Lord Jesus Christ, amen.

# References
1. - Handbook 2: Administering the Church (2010), 20.3.10.
2. - See George Q. Cannon, in “Minutes of a Conference,” Millennial Star, May 2, 1863, 275–76.