Elder Vern P. Stanfill
Of the Seventy
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/choose-the-light?lang=eng)

_We must choose to heed prophetic counsel, recognize and act upon spiritual promptings, be obedient to God’s commandments, and seek personal revelation._

Not long ago, my wife and I decided that we should more fully experience the beauty of an area close to our home in northwest Montana. We determined to take our bicycles to the Hiawatha Trail, a converted rail line that crosses the beautiful Rocky Mountains between Montana and Idaho. We anticipated a fun day with good friends, enjoying the natural beauty of the area.

We knew our ride along the magnificent 15-mile (24 km) trail would include trestles stretching over deep canyons and long tunnels penetrating rugged mountains. So we prepared ourselves with lights strapped to our helmets and bicycles.



Those who had gone before warned us that the tunnels were dark and that we needed really strong lights. As we gathered in front of the massive stone opening of the Taft Tunnel, a caretaker explained some of the dangers of the trail, including deep ditches along the edges, rough walls, and complete darkness. Impatiently, we pushed forward into the tunnel. After we had ridden only a few minutes, the predicted darkness engulfed us. The lights I brought proved inadequate, and the darkness soon overwhelmed them. Suddenly, I began to feel anxious, confused, and disoriented.



  ImageTaft Tunnel

I was embarrassed to admit my anxieties to my friends and family. Although an experienced cyclist, I now felt as though I had never ridden a bicycle. I struggled to stay upright as my confusion increased. Finally, after I did express my discomfort to those around me, I was able to draw closer to the more powerful light of a friend. In fact, everyone in the group began to form a tight circle around him. By staying close to him and relying for a time on his light and the collective light of the group, we pushed deeper into the darkness of the tunnel.

  ImageTaft Tunnel

After what seemed like hours, I saw a pinpoint of light. Almost immediately, I began to feel reassured that all would be well. I continued to press forward, relying on both the light of my friends and the growing pinpoint of light. My confidence gradually returned as the light grew in size and intensity. Long before reaching the end of the tunnel, I no longer needed the assistance of my friends. All anxiety disappeared as we pedaled quickly toward the light. I felt calm and reassured even before we rode into the morning full of warmth and splendor.

We live in a world in which we will experience challenges to our faith. We may feel confident that we are ready to face these challenges—only to find that our preparations have been insufficient. And just as my friend had warned me about the darkness, we are warned today. Apostolic voices urge us to prepare ourselves with the powerful light of spiritual strength.

Likewise, we might feel embarrassed, uncomfortable, or confused spiritually when we encounter a challenge to our faith. Generally, the intensity and duration of these feelings will depend upon our reaction to them. If we do nothing, doubt, pride, and eventually apostasy may drive us from the light.

I learned some important lessons from my experience in the tunnel. I’ll share just a few of them.

First, no matter how intense the darkness of doubt, we choose how long and to what extent we allow it to influence us. We must remember how much our Heavenly Father and His Son love us. They will neither abandon us, nor will They allow us to be overcome if we seek Their help. Remember Peter’s experience in the hostile waves of the Sea of Galilee. As Peter felt the cold darkness close around him, he recognized his dilemma immediately and chose in that very moment to call out for help. He did not question the Savior’s power to save him; he simply called out, “Lord, save me.”1

In our lives, the extended hand of the Savior may take the form of help from a trusted friend, leader, or loving parent. While we are struggling in the darkness, there is nothing wrong with relying temporarily upon the light of those who love us and have our best interests at heart.

When we consider thoughtfully, why would we listen to the faceless, cynical voices of those in the great and spacious buildings of our time and ignore the pleas of those who genuinely love us? These ever-present naysayers prefer to tear down rather than elevate and to ridicule rather than uplift. Their mocking words can burrow into our lives, often through split-second bursts of electronic distortions carefully and deliberately composed to destroy our faith. Is it wise to place our eternal well-being in the hands of strangers? Is it wise to claim enlightenment from those who have no light to give or who may have private agendas hidden from us? These anonymous individuals, if presented to us honestly, would never be given a moment of our time, but because they exploit social media, hidden from scrutiny, they receive undeserved credibility.

Our choice to heed those who mock sacred things will distance us from the saving and life-giving light of the Savior. John recorded: “Then spake Jesus again unto them, saying, I am the light of the world: he that followeth me shall not walk in darkness, but shall have the light of life.”2 Remember, those who truly love us can help us build our faith.

Just as I was embarrassed in the tunnel, we might feel too embarrassed to ask for help when we doubt. Perhaps we are one to whom others have looked for strength, and now we need help. When we realize that the light and the comfort the Savior can extend to us are far too precious to lose to pride, then inspired Church leaders, parents, and trusted friends can help. They stand ready to assist us in gaining spiritual assurances that will fortify us against challenges of faith.

Second, we must trust in the Lord in order to develop spiritual strength within ourselves. We cannot rely upon the light of others forever. I knew that the darkness in the tunnel would not last if I kept pedaling beside my friend and within the safety of the group. But my expectation was to be able to proceed on my own once I could see the light. The Lord teaches us, “Draw near unto me and I will draw near unto you; seek me diligently and ye shall find me; ask, and ye shall receive; knock, and it shall be opened unto you.”3 We must act, expecting that the Lord will fulfill His promise to lift us from the darkness if we draw near unto Him. The adversary, however, will try to convince us that we have never felt the influence of the Spirit and that it will be easier just to stop trying.

President Dieter F. Uchtdorf counsels us to “doubt your doubts before you doubt your faith.”4 In my home ward, a young man recently said, “There are things I have felt that cannot be explained in any other way except that they are of God.” This is spiritual integrity.

When faced with questions or tempted to doubt, we should remember the spiritual blessings and feelings that have penetrated our hearts and lives in the past and place our faith in Heavenly Father and His Son, Jesus Christ. I am reminded of the counsel given in a familiar hymn: “Doubt not the Lord nor his goodness [for] we’ve proved him in days that are past.”5 To ignore and discount past spiritual experiences will distance us from God.

Our quest for light will be enhanced by our willingness to recognize when it shines in our lives. Modern scripture defines light and gives a promise to those who accept it: “That which is of God is light; and he that receiveth light, and continueth in God, receiveth more light; and that light groweth brighter and brighter until the perfect day.”6 Just as when we kept pedaling toward the light, the more we persist, the brighter His influence becomes in our lives. Like the light at the end of the tunnel, His influence will bring us confidence, determination, comfort, and—most important—the power to know that He lives.

Third, there is no darkness so dense, so menacing, or so difficult that it cannot be overcome by light. Elder Neil L. Andersen recently taught: “As evil increases in the world, there is a compensatory spiritual power for the righteous. As the world slides from its spiritual moorings, the Lord prepares the way for those who seek Him, offering them greater assurance, greater confirmation, and greater confidence in the spiritual direction they are traveling. The gift of the Holy Ghost becomes a brighter light in the emerging twilight.”7

Brothers and sisters, we have not been left alone to be influenced by every whim and change in the world’s attitude, but we have the power to choose belief over doubt. In order to access the promised compensatory spiritual power, we must choose to heed prophetic counsel, recognize and act upon spiritual promptings, be obedient to God’s commandments, and seek personal revelation. We must choose. May we choose the light of the Savior. In the name of Jesus Christ, amen.

# References
1. - See Matthew 14:25–31.
2. - John 8:12.
3. - Doctrine and Covenants 88:63.
4. - Dieter F. Uchtdorf, “Come, Join with Us,” Ensign or Liahona, Nov. 2013, 23.
5. - “We Thank Thee, O God, for a Prophet,” Hymns, no. 19.
6. - Doctrine and Covenants 50:24.
7. - Neil L. Andersen, “A Compensatory Spiritual Power for the Righteous” (Brigham Young University Education Week devotional, Aug. 18, 2015), speeches.byu.edu.