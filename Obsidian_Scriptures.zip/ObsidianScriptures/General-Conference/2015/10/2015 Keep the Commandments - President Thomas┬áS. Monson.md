President Thomas S. Monson
President of the Church
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/keep-the-commandments?lang=eng)

_He who created us and who loves us perfectly knows just how we need to live our lives in order to obtain the greatest happiness possible._

My beloved brethren, how good it is to be with you once again. We have been inspired this evening by the words which we have heard. I pray that I too will be guided in what I say.

My message to you tonight is straightforward. It is this: keep the commandments.

God’s commandments are not given to frustrate us or to become obstacles to our happiness. Just the opposite is true. He who created us and who loves us perfectly knows just how we need to live our lives in order to obtain the greatest happiness possible. He has provided us with guidelines which, if we follow them, will see us safely through this often treacherous mortal journey. We remember the words of the familiar hymn: “Keep the commandments! In this there is safety; in this there is peace.”1

Our Heavenly Father loves us enough to say: Thou shalt not lie; thou shalt not steal; thou shalt not commit adultery; thou shalt love thy neighbor as thyself; and so on.2 We know the commandments. He understands that when we keep the commandments, our lives will be happier, more fulfilling, and less complicated. Our challenges and problems will be easier to bear, and we will receive His promised blessings. But while He gives us laws and commandments, He also allows us to choose whether to accept them or to reject them. Our decisions in this regard will determine our destiny.

I am confident that each of us has as his ultimate goal life everlasting in the presence of our Heavenly Father and His Son, Jesus Christ. It is imperative, therefore, for us to make choices throughout our lives that will lead us to this great goal. We know, however, that the adversary is committed to our failure. He and his hosts are relentless in their efforts to thwart our righteous desires. They represent a grave and constant threat to our eternal salvation unless we are also relentless in our determination and efforts to achieve our goal. The Apostle Peter warns us, “Be vigilant; because your adversary the devil, as a roaring lion, walketh about, seeking whom he may devour.”3

Although there is no time in our lives when we are exempt from temptation, you young men are at an age when you may be particularly vulnerable. Teenage years are often years of insecurity, of feeling as though you don’t measure up, of trying to find your place with your peers, and of trying to fit in. You may be tempted to lower your standards and to follow the crowd in order to be accepted by those you desire to have as friends. Please be strong, and be alert to anything that would rob you of the blessings of eternity. The choices you make here and now are forever important.

We read in 1 Corinthians: “There are … so many kinds of voices in the world.”4 We are surrounded by persuasive voices, beguiling voices, belittling voices, sophisticated voices, and confusing voices. I might add that these are loud voices. I admonish you to turn the volume down and to be influenced instead by that still, small voice which will guide you to safety. Remember that one with authority placed his hands on your head after you were baptized, confirming you a member of the Church and saying, “Receive the Holy Ghost.”5 Open your hearts, even your very souls, to the sound of that special voice which testifies of truth. As the prophet Isaiah promised, “Thine ears shall hear a word … , saying, This is the way, walk ye in it.”6 May we ever be in tune, that we might hear this comforting, guiding voice which will keep us safe.

Disregard for the commandments has opened the way for what I consider to be the plagues of our day. They include the plague of permissiveness, the plague of pornography, the plague of drugs, the plague of immorality, and the plague of abortion, to name just a few. The scriptures tell us that the adversary is “the founder of all these things.”7 We know that he is “the father of all lies, to deceive and to blind men.”8

I plead with you to avoid anything that will deprive you of your happiness here in mortality and eternal life in the world to come. With his deceptions and lies, the adversary will lead you down a slippery slope to your destruction if you allow him to do so. You will likely be on that slippery slope before you even realize that there is no way to stop. You have heard the messages of the adversary. He cunningly calls: Just this once won’t matter; everyone is doing it; don’t be old-fashioned; times have changed; it can’t hurt anyone; your life is yours to live. The adversary knows us, and he knows the temptations which will be difficult for us to ignore. How vital it is that we exercise constant vigilance in order to avoid giving in to such lies and temptations.

Great courage will be required as we remain faithful and true amid the ever-increasing pressures and insidious influences with which we are surrounded and which distort the truth, tear down the good and the decent, and attempt to substitute the man-made philosophies of the world. If the commandments had been written by man, then to change them by inclination or legislation or by any other means would be the prerogative of man. The commandments, however, were God-given. Using our agency, we can set them aside. We cannot, however, change them, just as we cannot change the consequences which come from disobeying and breaking them.

May we realize that our greatest happiness in this life will come as we follow God’s commandments and obey His laws! I love the words found in Isaiah chapter 32, verse 17: “The work of righteousness shall be peace; and the effect of righteousness quietness and assurance for ever.” Such peace, such assurance can come only through righteousness.

We cannot allow ourselves the slightest bit of leeway in dealing with sin. We cannot allow ourselves to believe that we can participate “just a little” in disobeying the commandments of God, for the sin can grab us with an iron hand from which it is excruciatingly painful to free ourselves. The addictions which can come from drugs, alcohol, pornography, and immorality are real and are nearly impossible to break without great struggle and much help.

If any of you has stumbled in his journey, I assure you that there is a way back. The process is called repentance. Although the path is difficult, your eternal salvation depends on it. What could be more worthy of your efforts? I plead with you to determine right here and now to take the steps necessary to fully repent. The sooner you do so, the sooner you will be able to experience the peace and the quietness and the assurance spoken of by Isaiah.

A short while ago I heard the testimony of a woman who, with her husband, strayed from the path of safety, breaking commandments and, in the process, nearly destroying their family. When each of them could finally see through the thick haze of addiction and recognize how unhappy their lives had become, as well as how much they were hurting their loved ones, they began to change. The repentance process felt slow and was, at times, painful, but with the help of priesthood leaders, along with help from family and loyal friends, they made their way back.

I share with you a portion of this sister’s testimony of the healing power of repentance: “How does someone go from being one of the lost sheep and gripped by [sin], to this peace and happiness we now feel? How does that happen? The answer … is because of a perfect gospel, a perfect Son and His sacrifice for me. … Where there was darkness, there is now light. Where there was despair and pain, there is joy and hope. We have been infinitely blessed by the change that can only come through repentance made possible by the Atonement of Jesus Christ.”

Our Savior died to provide you and me that blessed gift. Despite the fact that the path is difficult, the promise is real. Said the Lord to those who repent:

“Though your sins be as scarlet, they shall be as white as snow.”9

“And I will remember [them] no more.”10

Throughout our lives we will need to nurture strong testimonies by studying the scriptures and by praying and by pondering the truths of the gospel of Jesus Christ. When firmly planted, our testimonies of the gospel, of the Savior, and of our Heavenly Father will influence all that we do.

I testify that all of us are beloved sons of our Father in Heaven, sent to earth at this day and time for a purpose, and given the priesthood of God so that we can serve others and perform God’s work here upon the earth. We have been commanded to live our lives so that we remain worthy to possess that priesthood.

My brethren, may we keep the commandments! Wonderful and glorious are the rewards which are in store for us if we do. May this be our blessing, I pray in the name of Jesus Christ, our Savior and our Redeemer, amen.

# References
1. - “Keep the Commandments,” Hymns, no. 303.
2. - See Exodus 20:1–17; Matthew 22:39.
3. - 1 Peter 5:8.
4. - 1 Corinthians 14:10.
5. - See Handbook 2: Administering the Church (2010), 20.3.10.
6. - Isaiah 30:21.
7. - 2 Nephi 26:22.
8. - Moses 4:4.
9. - Isaiah 1:18.
10. - Jeremiah 31:34.