Elder Larry R. Lawrence
Of the Seventy
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/what-lack-i-yet?lang=eng)

_If we are humble and teachable, the Holy Ghost will prompt us to improve and lead us home, but we need to ask the Lord for directions along the way._

When I was a young adult, I began investigating the Church. At first I was drawn to the gospel by the examples of my Latter-day Saint friends, but eventually I was attracted to the unique doctrine. When I learned that faithful men and women could keep progressing and ultimately become like our heavenly parents, I was frankly amazed. I loved the concept; it rang true to me.

Soon after my baptism, I was studying the Sermon on the Mount, and I recognized that Jesus taught this same truth about eternal progression in the Bible. He said, “Be ye therefore perfect, even as your Father which is in heaven is perfect.”1

I have been a member of the Church now for over 40 years, and whenever I read this verse of scripture, I am reminded of our purpose here on earth. We came to learn and improve until we gradually become sanctified or perfected in Christ.

The journey of discipleship is not an easy one. It has been called a “course of steady improvement.”2 As we travel along that strait and narrow path, the Spirit continually challenges us to be better and to climb higher. The Holy Ghost makes an ideal traveling companion. If we are humble and teachable, He will take us by the hand and lead us home.

However, we need to ask the Lord for directions along the way. We have to ask some difficult questions, like “What do I need to change?” “How can I improve?” “What weakness needs strengthening?”

Let’s consider the New Testament account of the rich young ruler. He was a righteous young man who was already keeping the Ten Commandments, but he wanted to become better. His goal was eternal life.

When he met the Savior, he asked, “What lack I yet?”3

Jesus answered immediately, giving counsel that was intended specifically for the rich young man. “Jesus said unto him, If thou wilt be perfect, go and sell that thou hast, and give to the poor, and … come and follow me.”4

The young man was stunned; he had never considered such a sacrifice. He was humble enough to ask the Lord but not faithful enough to follow the divine counsel he was given. We must be willing to act when we receive an answer.

President Harold B. Lee taught, “Every one of us, if we would reach perfection, must [at] one time ask ourselves this question, ‘What lack I yet?’”5

I knew a faithful mother who humbled herself and asked, “What is keeping me from progressing?” In her case, the response from the Spirit came immediately: “Stop complaining.” This answer surprised her; she had never thought of herself as a complainer. However, the message from the Holy Ghost was very clear. In the days that followed, she became conscious of her habit of complaining. Grateful for the prompting to improve, she determined to count her blessings instead of her challenges. Within days, she felt the warm approval of the Spirit.

A humble young man who couldn’t seem to find the right young woman went to the Lord for help: “What is keeping me from being the right man?” he asked. This answer came into his mind and heart: “Clean up your language.” At that moment, he realized that several crude expressions had become part of his vocabulary, and he committed to change.

A single sister bravely asked the question: “What do I need to change?” and the Spirit whispered to her, “Don’t interrupt people when they are talking.” The Holy Ghost really does give customized counsel. He is a completely honest companion and will tell us things that no one else knows or has the courage to say.

One returned missionary found himself stressed with a very heavy schedule. He was trying to find time for work, studies, family, and a Church calling. He asked the Lord for counsel: “How can I feel at peace with all that I need to do?” The answer was not what he expected; he received the impression that he should more carefully observe the Sabbath day and keep it holy. He decided to dedicate Sunday to God’s service—to lay aside his school courses on that day and study the gospel instead. This small adjustment brought the peace and balance that he was seeking.

Years ago I read in a Church magazine the story of a girl who was living away from home and going to college. She was behind in her classes, her social life was not what she had hoped for, and she was generally unhappy. Finally one day she fell to her knees and cried out, “What can I do to improve my life?” The Holy Ghost whispered, “Get up and clean your room.” This prompting came as a complete surprise, but it was just the start she needed. After taking time to organize and put things in order, she felt the Spirit fill her room and lift her heart.

The Holy Ghost doesn’t tell us to improve everything at once. If He did, we would become discouraged and give up. The Spirit works with us at our own speed, one step at a time, or as the Lord has taught, “line upon line, precept upon precept, … and blessed are those who hearken unto my precepts, … for unto him that receiveth I will give more.”6 For example, if the Holy Ghost has been prompting you to say “thank you” more often, and you respond to that prompting, then He may feel it’s time for you to move on to something more challenging—like learning to say, “I’m sorry; that was my fault.”

  ImageSacrament, Passing and Partaking

A perfect time to ask, “What lack I yet?” is when we take the sacrament. The Apostle Paul taught that this is a time for each of us to examine ourselves.7 In this reverent atmosphere, as our thoughts are turned heavenward, the Lord can gently tell us what we need to work on next.

Like you, I have received many messages from the Spirit over the years showing me how I could improve. Let me share a few personal examples of messages that I took to heart. These promptings have included:







Don’t raise your voice.





Organize yourself; create a daily list of things to do.





Take better care of your body by eating more fruits and vegetables.





Increase your temple attendance.





Take time to ponder before you pray.





Ask your wife for her counsel.





And be patient when driving; don’t exceed the speed limit. (I’m still working on that last one.)





The atoning sacrifice of the Savior is what makes perfection or sanctification possible. We could never do it on our own, but God’s grace is sufficient to help us. As Elder David A. Bednar once observed: “Most of us clearly understand that the Atonement is for sinners. I am not so sure, however, that we know and understand that the Atonement is also for saints—for good men and women who are obedient, worthy, and conscientious and who are striving to become better.”8

  ImagePrayer. Adult. Female

I would like to suggest that each of you participate in a spiritual exercise sometime soon, perhaps even tonight while saying your prayers. Humbly ask the Lord the following question: “What is keeping me from progressing?” In other words: “What lack I yet?” Then wait quietly for a response. If you are sincere, the answer will soon become clear. It will be revelation intended just for you.

Perhaps the Spirit will tell you that you need to forgive someone. Or you may receive a message to be more selective about the movies you watch or the music you listen to. You may feel impressed to be more honest in your business dealings or more generous in your fast offerings. The possibilities are endless.

The Spirit can show us our weaknesses, but He is also able to show us our strengths. Sometimes we need to ask what we are doing right so that the Lord can lift and encourage us. When we read our patriarchal blessings, we are reminded that our Heavenly Father knows our divine potential. He rejoices every time we take a step forward. To Him, our direction is ever more important than our speed.

Be persistent, brothers and sisters, but never be discouraged. We will have to go beyond the grave before we actually reach perfection, but here in mortality we can lay the foundation. “It is our duty to be better today than we were yesterday, and better tomorrow than we are today.”9

If spiritual growth is not a priority in our lives, if we are not on a course of steady improvement, we will miss out on the important experiences that God wants to give us.

Years ago I read these words of President Spencer W. Kimball, which had a lasting impact on me. He said: “I have learned that where there is a prayerful heart, a hungering after righteousness, a forsaking of sins, and obedience to the commandments of God, the Lord pours out more and more light until there is finally power to pierce the heavenly veil. … A person of such righteousness has the priceless promise that one day he shall see the Lord’s face and know that he is.”10

It is my prayer that this ultimate experience can be ours someday as we allow the Holy Ghost to lead us home. In the name of Jesus Christ, amen.

# References
1. - Matthew 5:48.
2. - Neal A. Maxwell, “Testifying of the Great and Glorious Atonement,” Ensign, Oct. 2001, 12; Liahona, Apr. 2002, 9.
3. - Matthew 19:20.
4. - Matthew 19:21.
5. - Teachings of Presidents of the Church: Harold B. Lee (2000), 197.
6. - 2 Nephi 28:30.
7. - See 1 Corinthians 11:28.
8. - David A. Bednar, “The Atonement and the Journey of Mortality,” Ensign, Apr. 2012, 42; Liahona, Apr. 2012, 14.
9. - Joseph Fielding Smith, Doctrines of Salvation, comp. Bruce R. McConkie, 3 vols. (1954–56), 2:18.
10. - Spencer W. Kimball, “Give the Lord Your Loyalty,” Ensign, Mar. 1980, 4; Tambuli, Feb. 1981, 47.