Elder Gary E. Stevenson
Of the Quorum of the Twelve Apostles
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/plain-and-precious-truths?lang=eng)

_Heavenly Father’s generous compensation for living in perilous times is that we also live in the fulness of times._

Dear brothers and sisters, it has been many decades since a general conference has been convened that President Boyd K. Packer and Elders L. Tom Perry and Richard G. Scott were not seated immediately behind the podium and speaking at one of these sessions. Our memories of them are poignant, and I add my tribute to honor them, each so uniquely different yet so harmonized in their witness and testimony of Jesus Christ and His Atonement.

Furthermore, I, like you, find strength in and sustain President Thomas S. Monson as prophet, seer, and revelator, and I marvel at his faithful and dutiful apostolic service spanning over 50 remarkable years.

And so it was on Tuesday morning of this week, just after 9:00 a.m. as the Bishopric was beginning a meeting with the Asia Area Presidency, who are here for conference, that I was called to meet with President Monson, along with his counselors. Moments later, as I walked into the boardroom adjacent to his office, I must have looked nervous sitting across the table, as he kindly spoke to calm my nerves. He commented, noting my age, that I seemed quite young and even looked younger than my age.

Then, within a few moments, President Monson described that acting on the will of the Lord, he was extending a call to the Quorum of the Twelve to me. He asked me if I would accept this call, to which, following what I am sure was a very undignified audible gasp, in complete shock, I responded affirmatively. And then, before I could even verbalize a tsunami of indescribable emotion, most of which were feelings of inadequacy, President Monson kindly reached out to me, describing how he was called many years ago as an Apostle by President David O. McKay, at which time he too felt inadequate. He calmly instructed me, “Bishop Stevenson, the Lord will qualify those whom He calls.” These soothing words of a prophet have been a source of peace, a calm in a storm of painful self-examination and tender feelings in the ensuing agonizing hours which have passed day and night since then.

I rehearsed what I have just described to you to my sweet companion, Lesa, later that day, seated in a quiet corner on Temple Square, with a serene view of the temple and the historic Tabernacle lying before us. As we tried to comprehend and process the events of the day, we found our anchor to be our faith in Jesus Christ and our knowledge of the great plan of happiness. This leads to an expression of my deepest love for Lesa. She is the sunshine in and of my life and a remarkable daughter of God. Hers is a life punctuated by selfless service and unconditional love of all. I will strive to remain worthy of the blessing of our eternal union.

I express my deepest love to our four sons and their families, three of whom are here with their beautiful wives, the mothers of our six grandchildren; the fourth, a missionary, has special permission to stay up past missionary curfew and is viewing these proceedings live with his mission president and the mission president’s wife from their mission home in Taiwan. I love each of them and love how they love the Savior and the gospel.

I express my love to each member of my family: to my dear mother and to my father, who passed away last year, who instilled in me a testimony which seemed to dwell in me from my earliest memories. I further extend this gratitude to my brother, sisters, and their faithful spouses, as well as Lesa’s family, many of whom are actually here today. I cast this net of gratitude to numerous extended family, friends, missionaries, leaders, and teachers along the way.

I have been blessed with a close association with the members of the First Presidency, the Twelve, the Seventy, and the general auxiliary presidencies. I express my love and esteem to each of you sisters and brothers and will strive to be worthy of our continued association. The Presiding Bishopric enjoys an almost heavenly unity. I will miss my association each day with Bishop Gérald Caussé, Bishop Dean M. Davies, and the staff.

I stand before you as evidence of the words of the Lord recorded in the first section of the Doctrine and Covenants: “That the fulness of [the] gospel might be proclaimed by the weak and the simple unto the ends of the [earth], and before kings and rulers.”1 These words are preceded by the Lord’s declaration which demonstrates the love of a Father for His children: “Wherefore, I the Lord, knowing the calamity which should come upon the inhabitants of the earth, called upon my servant Joseph Smith, Jun., and spake unto him from heaven, and gave him commandments.”2

Our loving Heavenly Father and His Son, Jehovah, with a knowledge of the end from the beginning,3 opened the heavens and a new dispensation to offset the calamities that They knew would come. The Apostle Paul described the forthcoming calamities as “perilous times.”4 For me, this suggests that Heavenly Father’s generous compensation for living in perilous times is that we also live in the fulness of times.

As I agonized over my inadequacies this week, I received a distinct impression which both chastened and comforted me: to focus not on what I can’t do but rather on what I can do. I can testify of the plain and precious truths of the gospel.

These are the words which I have shared hundreds of times with both those who belong to the Church and many who are not members: “God is our [loving] Heavenly Father. We are His children. … He weeps with us when we suffer and rejoices when we do what is right. He wants to communicate with us, and we can communicate with Him through sincere prayer. …

“Heavenly Father has provided us, His children, with a way to … return to live in His presence. … Central to our [Heavenly] Father’s plan is Jesus Christ’s Atonement.”5

Heavenly Father sent His Son to the earth to atone for the sins of all mankind. Of these plain and precious truths I bear my testimony, and I do so in the name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 1:23.
2. - Doctrine and Covenants 1:17.
3. - See Abraham 2:8.
4. - 2 Timothy 3:1.
5. - Preach My Gospel: A Guide to Missionary Service (2004), 31–32.