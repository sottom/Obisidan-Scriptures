Elder Gregory A. Schwitzer
Of the Seventy
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/let-the-clarion-trumpet-sound?lang=eng)

_The world needs disciples of Christ who can communicate the gospel message with clarity and from the heart._

This past summer my wife and I had two of our young grandsons staying with us while their parents participated in a pioneer trek activity in their stake. Our daughter wanted to be sure that the boys practiced the piano while away from home. She knew that a few days with the grandparents makes it a little easier to forget about practicing. One afternoon I decided to sit with my 13-year-old grandson, Andrew, and listen to him play.

This boy is full of energy and loves the outdoors. He could easily spend all of his time hunting and fishing. While he was practicing the piano, I could tell that he would rather be fishing on a nearby river. I listened as he pounded out each chord of a familiar song. Every note he played had the same emphasis and meter, making it difficult to clearly identify the melody. I sat beside him on the bench and explained the importance of applying just a little more pressure on the melody keys and a little less on those notes that accompany the melody. We talked about the piano being more than just a mechanical miracle. It can be an extension of his own voice and feelings and become a wonderful instrument of communication. Just as a person talks and moves smoothly from one word to another, so should the melody flow as we move from one note to another.

We laughed together as he tried again and again. His dimpled-cheek smile increased as the familiar melody began to emerge from what was previously a wild set of sounds. The message became clear: “I am a child of God, and he has sent me here.”1 I asked Andrew if he could feel the difference in the message. He responded, “Yes, Grandpa, I can feel it!”

The Apostle Paul taught us about comparing communication to musical instruments when he wrote to the Corinthians:

“And even things without life giving sound, whether pipe or harp, except they give a distinction in the sounds, how shall it be known what is piped or harped?

“For if the trumpet give an uncertain sound, who shall prepare himself to the battle?”2

If ever there was a time when the world needs disciples of Christ who can communicate the message of the gospel with clarity and from the heart, it is now. We need the clarion call of the trumpet.

Christ was certainly our best example. He always demonstrated courage to stand up for what was right. His words echo through the centuries as He invites us to remember to love God and our fellowman, to keep all of God’s commandments, and to live as lights to the world. He was not afraid to speak against the earthly powers or rulers of His day, even when such were opposing His mission given to Him by His Heavenly Father. His words were not designed to confuse but to move the hearts of men. He clearly knew His Father’s will in all He said and did.

I also love the example of Peter, who confronted the men of the world with courage and clarity on the day of Pentecost. On that day people were assembled from many countries criticizing the early Saints because they heard them speak in tongues and thought they were drunken. Peter, having the Spirit rise in his soul, stood up to defend the Church and the members. He testified with these words: “Ye men of Judea, and all ye that dwell at Jerusalem, be this known unto you, and hearken to my words.”3

He then quoted from the scriptures containing the prophecies of Christ and bore this straightforward testimony: “Therefore let all the house of Israel know assuredly, that God hath made that same Jesus, whom ye have crucified, both Lord and Christ.”4

Many heard his words and felt the Spirit, and 3,000 souls joined the ranks of the early Church. This is powerful evidence that one man or woman who is willing to testify when the world seems to be going in the opposite direction can make a difference.

When we as members make the decision to stand up and powerfully witness for God’s doctrine and His Church, something changes within us. We take His countenance upon us. We become closer to His Spirit. He in turn will go before us and be on “[our] right hand and on [our] left, and [His] Spirit shall be in [our] hearts, and [His] angels round about [us], to bear [us] up.”5

True disciples of Christ are not looking to make excuses for the doctrine when it doesn’t fit the world’s current concepts. Paul was another valiant disciple, boldly proclaiming that he was “not ashamed of the gospel of Christ: for it is the power of God unto salvation to every one that believeth.”6 True disciples represent the Lord when it may not be convenient to do so. True disciples desire to inspire the hearts of men, not just impress them.

Often it is not convenient or comfortable to stand up for Christ. I am sure that was the case with Paul when he was called before King Agrippa and was asked to justify himself and tell his story. Paul, without hesitating, proclaimed his belief with such power that this intimidating king admitted he was “almost” persuaded to be a Christian.

Paul’s response witnessed of his desire for people to understand absolutely what he had to say. He told King Agrippa that it was his desire that all who heard him would not “almost” be Christians but rather would “altogether” become disciples of Christ.7 Those who speak with clarity can bring this to pass.

Over the many years that I have studied the story of Lehi’s dream in the Book of Mormon,8 I have always thought of the great and spacious building as a place where only the most rebellious reside. The building was filled with people mocking and pointing at the faithful who had held on to the iron rod, which represents the word of God, and had made their way to the tree of life, which represents the love of God. Some could not bear up under the pressure of the people mocking them and wandered off. Others decided to join the mockers in the building. Did they not have the courage to speak boldly against the criticisms or messages of the world?

As I watch the current world moving away from God, I think this building is growing in size. Many find themselves today wandering the halls of the great and spacious building, not realizing that they are actually becoming part of its culture. They often succumb to the temptations and the messages. We eventually find them mocking or chiming in with those who criticize or mock.

For years I thought the mocking crowd was making fun of the way the faithful live their lives, but the voices from the building today have changed their tone and approach. Those who mock often try to drown out the simple message of the gospel by attacking some aspect of the Church’s history or offering pointed criticism of a prophet or other leader. They are also attacking the very heart of our doctrine and the laws of God, given since the Creation of the earth. We, as disciples of Jesus Christ and members of His Church, must never let go of that iron rod. We must let the clarion trumpet sound from our own souls.

The simple message is that God is our loving Heavenly Father and Jesus Christ is His Son. The gospel is restored in these latter days through living prophets, and the evidence is the Book of Mormon. The path of happiness is through the basic family unit as originally organized and revealed by our Heavenly Father. This is the familiar melody of the message that many can recognize because they have heard it from their premortal life.

It is time for us, as Latter-day Saints, to stand up and testify. It is time for the notes of the melody of the gospel to rise above the noise of the world. I add my testimony to the message of the Savior and Redeemer of this world. He lives! His gospel is restored, and the blessings of happiness and peace can be secured in this life by living His commandments and walking in His path. This is my testimony in the name of Jesus Christ, amen.

# References
1. - “I Am a Child of God,” Hymns, no. 301.
2. - 1 Corinthians 14:7–8.
3. - Acts 2:14.
4. - Acts 2:36.
5. - Doctrine and Covenants 84:88.
6. - Romans 1:16.
7. - See Acts 26:26–30.
8. - See 1 Nephi 8.