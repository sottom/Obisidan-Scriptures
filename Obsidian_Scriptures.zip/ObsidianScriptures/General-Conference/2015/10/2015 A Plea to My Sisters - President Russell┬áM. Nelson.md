President Russell M. Nelson
President of the Quorum of the Twelve Apostles
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/a-plea-to-my-sisters?lang=eng)

_We need your strength, your conversion, your conviction, your ability to lead, your wisdom, and your voices._

Dear Elders Rasband, Stevenson, and Renlund, we, your Brethren, welcome you to the Quorum of the Twelve Apostles. We thank God for the revelations that He gives to His prophet, President Thomas S. Monson.

Brothers and sisters, when we met in general conference six months ago, none of us anticipated the coming changes that would tug at the heartstrings of the entire Church. Elder L. Tom Perry delivered a powerful message about the irreplaceable role that marriage and family occupy in the Lord’s plan. We were stunned when just a few days later, we learned of the cancer that would soon take him from us.

Though President Boyd K. Packer’s health had been declining, he continued to “soldier on” in the work of the Lord. He was frail last April, yet he was determined to declare his witness as long as he had breath. Then, just 34 days after Elder Perry’s passing, President Packer also stepped across the veil.

We missed Elder Richard G. Scott at our last general conference, but we’ve reflected upon the powerful witness of the Savior he had borne in many previous conferences. And just 12 days ago, Elder Scott was called home and reunited with his beloved Jeanene.

I had the privilege of being with all of these Brethren during their final days, including joining members of President Packer’s and Elder Scott’s immediate families just before their passing. It has been difficult for me to believe that these three treasured friends, these magnificent servants of the Lord, are gone. I miss them more than I can say.

As I’ve reflected on this unexpected turn of events, one of the impressions that has lingered with me is that which I observed in these surviving wives. Etched in my mind are the serene images of Sister Donna Smith Packer and Sister Barbara Dayton Perry at their husbands’ bedsides, both women filled with love, truth, and pure faith.

As Sister Packer sat next to her husband in his final hours, she radiated that peace that passes all understanding.1 Though she realized that her beloved companion of almost 70 years would soon depart, she showed the tranquility of a faith-filled woman. She seemed angelic, just as she was in this photo of them at the dedication of the Brigham City Utah Temple.

  ImagePacker, Boyd K. Biography

I saw that same kind of love and faith emanating from Sister Perry. Her devotion to both her husband and the Lord was obvious, and it moved me deeply.

  ImagePerry, L. Tom. Biography

Through their husbands’ final hours and continuing to the present day, these stalwart women have shown the strength and courage that covenant-keeping women always demonstrate.2 It would be impossible to measure the influence that such women have, not only on families but also on the Lord’s Church, as wives, mothers, and grandmothers; as sisters and aunts; as teachers and leaders; and especially as exemplars and devout defenders of the faith.3

This has been true in every gospel dispensation since the days of Adam and Eve. Yet the women of this dispensation are distinct from the women of any other because this dispensation is distinct from any other.4 This distinction brings both privileges and responsibilities.

  ImageKimball, Spencer W.

Thirty-six years ago, in 1979, President Spencer W. Kimball made a profound prophecy about the impact that covenant-keeping women would have on the future of the Lord’s Church. He prophesied: “Much of the major growth that is coming to the Church in the last days will come because many of the good women of the world … will be drawn to the Church in large numbers. This will happen to the degree that the women of the Church reflect righteousness and articulateness in their lives and to the degree that the women of the Church are seen as distinct and different—in happy ways—from the women of the world.”5

My dear sisters, you who are our vital associates during this winding-up scene, the day that President Kimball foresaw is today. You are the women he foresaw! Your virtue, light, love, knowledge, courage, character, faith, and righteous lives will draw good women of the world, along with their families, to the Church in unprecedented numbers!6

We, your brethren, need your strength, your conversion, your conviction, your ability to lead, your wisdom, and your voices. The kingdom of God is not and cannot be complete without women who make sacred covenants and then keep them, women who can speak with the power and authority of God!7

President Packer declared:

“We need women who are organized and women who can organize. We need women with executive ability who can plan and direct and administer; women who can teach, women who can speak out. …

“We need women with the gift of discernment who can view the trends in the world and detect those that, however popular, are shallow or dangerous.”8

Today, let me add that we need women who know how to make important things happen by their faith and who are courageous defenders of morality and families in a sin-sick world. We need women who are devoted to shepherding God’s children along the covenant path toward exaltation; women who know how to receive personal revelation, who understand the power and peace of the temple endowment; women who know how to call upon the powers of heaven to protect and strengthen children and families; women who teach fearlessly.

Throughout my life, I have been blessed by such women. My departed wife, Dantzel, was such a woman. I will always be grateful for the life-changing influence she had on me in all aspects of my life, including my pioneering efforts in open-heart surgery.

Fifty-eight years ago I was asked to operate upon a little girl, gravely ill from congenital heart disease. Her older brother had previously died of a similar condition. Her parents pleaded for help. I was not optimistic about the outcome but vowed to do all in my power to save her life. Despite my best efforts, the child died. Later, the same parents brought another daughter to me, then just 16 months old, also born with a malformed heart. Again, at their request, I performed an operation. This child also died. This third heartbreaking loss in one family literally undid me.

I went home grief stricken. I threw myself upon our living room floor and cried all night long. Dantzel stayed by my side, listening as I repeatedly declared that I would never perform another heart operation. Then, around 5:00 in the morning, Dantzel looked at me and lovingly asked, “Are you finished crying? Then get dressed. Go back to the lab. Go to work! You need to learn more. If you quit now, others will have to painfully learn what you already know.”

Oh, how I needed my wife’s vision, grit, and love! I went back to work and learned more. If it weren’t for Dantzel’s inspired prodding, I would not have pursued open-heart surgery and would not have been prepared to do the operation in 1972 that saved the life of President Spencer W. Kimball.9

Sisters, do you realize the breadth and scope of your influence when you speak those things that come to your heart and mind as directed by the Spirit? A superb stake president told me of a stake council meeting in which they were wrestling with a difficult challenge. At one point, he realized that the stake Primary president had not spoken, so he asked if she had any impressions. “Well, actually I have,” she said and then proceeded to share a thought that changed the entire direction of the meeting. The stake president continued, “As she spoke, the Spirit testified to me that she had given voice to the revelation we had been seeking as a council.”

My dear sisters, whatever your calling, whatever your circumstances, we need your impressions, your insights, and your inspiration. We need you to speak up and speak out in ward and stake councils. We need each married sister to speak as “a contributing and full partner”10 as you unite with your husband in governing your family. Married or single, you sisters possess distinctive capabilities and special intuition you have received as gifts from God. We brethren cannot duplicate your unique influence.

We know that the culminating act of all creation was the creation of woman!11 We need your strength!

Attacks against the Church, its doctrine, and our way of life are going to increase. Because of this, we need women who have a bedrock understanding of the doctrine of Christ and who will use that understanding to teach and help raise a sin-resistant generation.12 We need women who can detect deception in all of its forms. We need women who know how to access the power that God makes available to covenant keepers and who express their beliefs with confidence and charity. We need women who have the courage and vision of our Mother Eve.

My dear sisters, nothing is more crucial to your eternal life than your own conversion. It is converted, covenant-keeping women—women like my dear wife Wendy—whose righteous lives will increasingly stand out in a deteriorating world and who will thus be seen as different and distinct in the happiest of ways.

So today I plead with my sisters of The Church of Jesus Christ of Latter-day Saints to step forward! Take your rightful and needful place in your home, in your community, and in the kingdom of God—more than you ever have before. I plead with you to fulfill President Kimball’s prophecy. And I promise you in the name of Jesus Christ that as you do so, the Holy Ghost will magnify your influence in an unprecedented way!

I bear witness of the reality of the Lord Jesus Christ and of His redeeming, atoning, and sanctifying power. And as one of His Apostles, I thank you, my dear sisters, and bless you to rise to your full stature, to fulfill the measure of your creation, as we walk arm in arm in this sacred work. Together we will help prepare the world for the Second Coming of the Lord. Of this I testify, as your brother, in the name of Jesus Christ, amen.

# References
1. - See Philippians 4:7.
2. - This includes tears—in keeping the commandment to weep for those we love when they graduate from this life (see Doctrine and Covenants 42:45).
3. - See Rebekah’s influence on Isaac and their son Jacob in Genesis 27:46; 28:1–4.
4. - See Joseph Fielding Smith, Answers to Gospel Questions, comp. Joseph Fielding Smith Jr., 5 vols. (1957–66), 4:166. Note: All previous dispensations were limited to a small segment of the world and were terminated by apostasy. In contrast, this dispensation will not be limited in location or time. It will fill the world and merge with the Second Coming of the Lord.
5. - Teachings of Presidents of the Church: Spencer W. Kimball (2006), 222–23.
6. - When I was born, there were fewer than 600,000 members of the Church. Today there are more than 15 million. That number will continue to increase.
7. - President Joseph Fielding Smith told sisters of the Relief Society, “You can speak with authority, because the Lord has placed authority upon you.” He also said that the Relief Society has “been given power and authority to do a great many things. The work which they do is done by divine authority” (“Relief Society—an Aid to the Priesthood,” Relief Society Magazine, Jan. 1959, 4, 5). These quotations were also cited by Elder Dallin H. Oaks in a conference address, “The Keys and Authority of the Priesthood,” Ensign or Liahona, May 2014, 51.
8. - Boyd K. Packer, “The Relief Society,” Ensign, Nov. 1978, 8; see also M. Russell Ballard, Counseling with Our Councils: Learning to Minister Together in the Church and in the Family (1997), 93.
9. - See Spencer J. Condie, Russell M. Nelson: Father, Surgeon, Apostle (2003), 146, 153–56. Note: In 1964 President Kimball set me apart as a stake president and blessed me that the mortality rates would decline in my pioneering efforts with operations on the aortic valve. Little did either of us then know that eight years later, I would be doing an operation on President Kimball that included replacement of his incompetent aortic valve.
10. - “When we speak of marriage as a partnership, let us speak of marriage as a full partnership. We do not want our LDS women to be silent partners or limited partners in that eternal assignment! Please be a contributing and full partner” (Spencer W. Kimball, “Privileges and Responsibilities of Sisters,” Ensign, Nov. 1978, 106).
11. - “All the purposes of the world and all that was in the world would be brought to naught without woman—a keystone in the priesthood arch of creation” (Russell M. Nelson, “Lessons from Eve,” Ensign, Nov. 1987, 87). “Eve became God’s final creation, the grand summation of all of the marvelous work that had gone before” (Gordon B. Hinckley, “The Women in Our Lives,” Ensign or Liahona, Nov. 2004, 83).
12. - See Russell M. Nelson, “Children of the Covenant,” Ensign, May 1995, 33.