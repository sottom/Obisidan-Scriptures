President Henry B. Eyring
First Counselor in the First Presidency
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/you-are-not-alone-in-the-work?lang=eng)

_As you move from one priesthood service to another, you will see the Lord is in the work with you._

My beloved brethren, we are grateful that the Lord has called Elder Ronald A. Rasband, Elder Gary E. Stevenson, and Elder Dale G. Renlund as Apostles of the Lord Jesus Christ. Our hearts, our prayers, and our faith sustain them.

We know of their great capacity. Yet they will need reassurance in their calls, as we all do, that the Lord is with them in His work. The newest deacon needs that confidence, as does the most experienced high priest who receives a new call.

That confidence grows as you come to see that He called you through His servants. My encouragement is to help you know that when you do your part, the Lord adds His power to your efforts.

Any calling we receive in the Lord’s kingdom requires more than our human judgment and our personal powers. Those calls require help from the Lord, which will come. Even the new deacon will learn that is true, and he will go on learning over the years.

One of my grandsons is here tonight in his first priesthood session. He was ordained a deacon six days ago. He may expect that his first performance of a priesthood duty will be passing the sacrament next Sunday. My prayer is that he will see that moment as it really is.

He may think that his work for the Lord is to pass the sacrament tray to people seated in the sacrament meeting. But the Lord’s purpose is not simply to have people partake of bread and water. It is to have them keep a covenant that will move them along the path to eternal life. And for that to happen, the Lord must give a spiritual experience to the person to whom the deacon offers the tray.

I have seen that happen once in a care center when a deacon leaned forward to pass the tray to a white-haired lady. She looked at the bread as if it were precious. I have never forgotten her smile as she partook and then reached up to pat the deacon’s head, saying quite loudly, “Oh, thank you!”

That deacon was simply performing his priesthood duty. Yet the Lord then multiplied the deacon’s act. It was evident that the sister remembered the Savior as she expressed sincere gratitude for a deacon’s service. She was reassured as he served the sacrament to her that she would have the Spirit to be with her. She was not alone that day in the care center. Neither was the deacon alone in his modest service.

A young teacher in the Aaronic Priesthood may not sense, as he goes to teach a family, that he is a partner with the Lord in His work. I remember still the simple testimony of a young home-teaching companion who came into our home. The Spirit confirmed his words to me and to my family. He may not remember that day, but I do.

The Lord will magnify the efforts of a young man again when he is called to become a priest. The first baptism he performs, for instance, may be of a young person he does not know. He may be worried about whether he will say the right words and perform the ordinance correctly.

But the Lord, whose servant he is, will magnify his calling. The person he baptizes has chosen to move along the path to eternal life. The Lord will do His greater part. He did it for me once when the boy I baptized, tears streaming down his face, said in my ear, “I’m clean. I’m clean.”

As you move from one priesthood service to another, you will see the Lord is in the work with you. I learned this from meeting an elders quorum president in a stake conference years ago. In the conference there were more than 40 names presented of men who were to receive the Melchizedek Priesthood.

The stake president leaned over to me and whispered, “Those men were all less-active prospective elders.” In amazement, I asked the president what his program was to rescue these men.

He pointed to a young man in the back of the chapel. He said, “There he is. Most of these men have been brought back because of that elders quorum president.” He was on the back row, dressed casually, his legs stretched out with his battered boots crossed in front of him.

I asked the stake president to introduce me to him after the meeting. When we met, I told the young man I was surprised by what he had done and asked him how he did it. He shrugged his shoulders. He obviously didn’t think he deserved any credit.

Then he said softly, “I know every inactive guy in this town. Most of them have pickup trucks. I have a truck too. I wash my pickup where they wash theirs. In time, they become my friends.

“Then I wait until something goes wrong in their lives. It always does. They tell me about it. I listen and I don’t find fault. Then, when they say, ‘There is something wrong in my life. There just has to be something better than this,’ I tell them what is missing and where they can find it. Sometimes they believe me, and when they do, I take them with me.”

You can see why he was modest. It was because he knew he had done his small part and the Lord was doing the rest. It was the Lord who had touched the hearts of those men in their troubles. It was the Lord who had given them the feeling that there must be something better for them and a hope that they could find it.

The young man, who—like you—was a servant of the Lord, simply believed that if he did his small part, the Lord would help those men along the path to home and to the happiness only He could give them. This man also knew the Lord had called him as elders quorum president because he would do his part.

There will be times in your service when you won’t have the remarkable and visible success of that young elders quorum president. That is the time when you will need to be confident that the Lord, knowing you would do your part in the work, called you through His authorized servants. Having faith in the call from the Lord’s servants was crucial in the missionary service of my great-grandfather Henry Eyring.

He was baptized on March 11, 1855, in St. Louis, Missouri. Erastus Snow ordained him to the office of a priest shortly thereafter. The president of the St. Louis Stake, John H. Hart, called him to serve a mission to the Cherokee Nation on October 6.1 He was ordained an elder on October 11. He left on horseback for the Cherokee Mission on October 24. He was 20 years old and a convert of only seven months.

If any priesthood holder had a reason to feel unqualified or unprepared, it was Henry Eyring. The only reason he could have had the courage to go was that he knew in his heart that God had called him through His authorized servants. It was the source of his courage. That must be the source of our courage to persevere, whatever our callings in the priesthood.

After Elder Eyring had served for three difficult years and upon the death of the mission president, Henry was nominated and sustained as president of the mission in a meeting held on October 6, 1858. He was surprised and as shocked as a new deacon would be. He wrote, “It was quite unexpected to me to be called to that responsible office but as it was the will of the brethren I cheerfully accepted, feeling at the same time my great weakness and lack of experience.”2

The now-President Eyring traveled to the Cherokee, Creek, and Choctaw Nations in 1859. Through his efforts, the Lord “added,” as Henry recorded, “a number to the church.” He organized two branches but noted that “very few are alive in the cause.”3

A year later, Henry was faced with the difficult reality that the political leaders among the people he was serving no longer permitted the Latter-day Saint missionaries to do their work. As he pondered what he should do, he recalled the instruction from his previous mission president indicating that he should prolong his mission until 1859.4

In October of that year, Henry wrote to President Brigham Young for direction, but he did not receive a reply to his question. Henry recorded, “Not being able to hear anything from the Presidency of the Church, I called upon the Lord in prayer, asking him to reveal to me his mind and will in regard to my remaining longer or going up to Zion.”

He continued: “The following dream was given to me in answer to my prayer. I dreamt I had arrived in [Salt Lake] City and immediately went to [President Brigham] Young’s office, where I found him. I said to him: ‘[President] Young I have left my mission, have come of my own accord, but if there is anything wrong in this, I am willing to return and finish my mission.’ [In the dream the prophet] replied: ‘You have stayed long enough, it is all right.’”

Henry wrote in his journal, “Having had dreams before which were literally fulfilled I had faith to believe, that this also would be and consequently commenced at once to prepare for a start.”

He arrived in Salt Lake City on August 29, 1860, having walked most of the way. Two days later, he walked into the office of President Brigham Young.5

Henry described the experience in these words: “[I] called upon [President] Young, who received [me] very kindly. I said to him, ‘[President] Young I have come without being sent for, if I have done wrong, I am willing to return and finish my mission.’ [Brigham Young] answered: ‘It is all right, we have been looking for you.’”

Henry described his joy, saying, “Thus my dream was literally fulfilled.”6

His joy came from a confirmation that the Lord had been working with and watching over him. He learned what is true for all of us—that the Lord’s servants are inspired to know the Lord’s will. And Henry Eyring had confirmed what I know as well: that the prophet, as the president of the priesthood, is inspired of God to watch over and care for the Lord’s servants and to call them.

Whatever your calling in the priesthood, you may have at times felt Heavenly Father was unaware of you. You can pray to know His will, and with the honest desire to do whatever He asks you to do, you will receive an answer.

Heavenly Father will allow you to feel that He knows you, that He appreciates your service, and that you are becoming worthy of the greeting from the Lord you want so much to hear: “Well done, good and faithful servant; thou hast been faithful over a few things, I will make thee ruler over many things: enter thou into the joy of thy lord.”7

It is my prayer that every priesthood holder will reach out in faith to rescue every soul for whom he is responsible. God will add His power to His servant’s efforts. Hearts of people will be touched to make the choices that will bring them along the gospel path toward happiness and away from sorrow.

It is my prayer as well that every priesthood holder will feel the loving and watchful care of Heavenly Father, of the Savior, and of the prophet of God in his calling in the priesthood.

I bear you my special witness that we are in the service of the resurrected Lord Jesus Christ. I testify that He has called you and me into His service knowing our capacities and the help we will need. He will bless our efforts beyond our fondest expectations as we give our all in His service. I testify that God’s prophet, who is the president of all the priesthood in the earth, is inspired of God.

I am grateful for the examples of faithful priesthood holders everywhere. Heavenly Father and the Savior are grateful that you do your part. They know you, They watch over you, and They love you. In the name of Jesus Christ, amen.

# References
1. - See “Minutes of the Conference,” St. Louis Luminary, Oct. 13, 1855, 187.
2. - Henry Eyring letter to Brigham Young, Oct. 7, 1858, Brigham Young Office Files, Church History Library, Salt Lake City.
3. - Henry Eyring report to Church Historian’s Office, Aug. 1860, Missionary Reports, Church History Library, Salt Lake City.
4. - See Henry Eyring letter to Brigham Young, Oct. 9, 1859, Brigham Young Office Files, Church History Library, Salt Lake City.
5. - See President’s Office Journals, Aug. 31, 1860, vol. D, 137, Brigham Young Office Files, Church History Library, Salt Lake City.
6. - Henry Eyring reminiscences, 1896, typescript, 27–28, Church History Library, Salt Lake City.
7. - Matthew 25:23.