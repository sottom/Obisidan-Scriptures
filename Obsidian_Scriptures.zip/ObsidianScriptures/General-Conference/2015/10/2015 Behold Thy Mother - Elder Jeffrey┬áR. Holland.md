Elder Jeffrey R. Holland
Of the Quorum of the Twelve Apostles
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/behold-thy-mother?lang=eng)

_No love in mortality comes closer to approximating the pure love of Jesus Christ than the selfless love a devoted mother has for her child._

May I join with all of you in welcoming Elder Ronald A. Rasband, Elder Gary E. Stevenson, and Elder Dale G. Renlund and their wives to the sweetest association they could possibly imagine.

Prophesying of the Savior’s Atonement, Isaiah wrote, “He hath borne our griefs, and carried our sorrows.”1 A majestic latter-day vision emphasized that “[Jesus] came into the world … to bear the sins of the world.”2 Both ancient and modern scripture testify that “he redeemed them, and bore them, and carried them all the days of old.”3 A favorite hymn pleads with us to “hear your great Deliv’rer’s voice!”4

Bear, borne, carry, deliver. These are powerful, heartening messianic words. They convey help and hope for safe movement from where we are to where we need to be—but cannot get without assistance. These words also connote burden, struggle, and fatigue—words most appropriate in describing the mission of Him who, at unspeakable cost, lifts us up when we have fallen, carries us forward when strength is gone, delivers us safely home when safety seems far beyond our reach. “My Father sent me,” He said, “that I might be lifted up upon the cross; … that as I have been lifted up … even so should men be lifted up … to … me.”5



But can you hear in this language another arena of human endeavor in which we use words like bear and borne, carry and lift, labor and deliver? As Jesus said to John while in the very act of Atonement, so He says to us all, “Behold thy mother!”6

Today I declare from this pulpit what has been said here before: that no love in mortality comes closer to approximating the pure love of Jesus Christ than the selfless love a devoted mother has for her child. When Isaiah, speaking messianically, wanted to convey Jehovah’s love, he invoked the image of a mother’s devotion. “Can a woman forget her sucking child?” he asks. How absurd, he implies, though not as absurd as thinking Christ will ever forget us.7

This kind of resolute love “suffereth long, and is kind, … seeketh not her own, … but … beareth all things, believeth all things, hopeth all things, endureth all things.”8 Most encouraging of all, such fidelity “never faileth.”9 “For the mountains shall depart and the hills be removed,” Jehovah said, “but my kindness shall not depart from thee.”10 So too say our mothers.

You see, it is not only that they bear us, but they continue bearing with us. It is not only the prenatal carrying but the lifelong carrying that makes mothering such a staggering feat. Of course, there are heartbreaking exceptions, but most mothers know intuitively, instinctively that this is a sacred trust of the highest order. The weight of that realization, especially on young maternal shoulders, can be very daunting.

A wonderful young mother recently wrote to me: “How is it that a human being can love a child so deeply that you willingly give up a major portion of your freedom for it? How can mortal love be so strong that you voluntarily subject yourself to responsibility, vulnerability, anxiety, and heartache and just keep coming back for more of the same? What kind of mortal love can make you feel, once you have a child, that your life is never, ever your own again? Maternal love has to be divine. There is no other explanation for it. What mothers do is an essential element of Christ’s work. Knowing that should be enough to tell us the impact of such love will range between unbearable and transcendent, over and over again, until with the safety and salvation of the very last child on earth, we can [then] say with Jesus, ‘[Father!] I have finished the work which thou gavest me to do.’11”

With the elegance of that letter echoing in our minds, let me share three experiences reflecting the majestic influence of mothers, witnessed in my ministry in just the past few weeks:

My first account is a cautionary one, reminding us that not every maternal effort has a storybook ending, at least not immediately. That reminder stems from my conversation with a beloved friend of more than 50 years who was dying away from this Church he knew in his heart to be true. No matter how much I tried to comfort him, I could not seem to bring him peace. Finally he leveled with me. “Jeff,” he said, “however painful it is going to be for me to stand before God, I cannot bear the thought of standing before my mother. The gospel and her children meant everything to her. I know I have broken her heart, and that is breaking mine.”

Now, I am absolutely certain that upon his passing, his mother received my friend with open, loving arms; that is what parents do. But the cautionary portion of this story is that children can break their mothers’ heart. Here too we see another comparison with the divine. I need not remind us that Jesus died of a broken heart, one weary and worn out from bearing the sins of the world. So in any moment of temptation, may we “behold [our] mother” as well as our Savior and spare them both the sorrow of our sinning.

Secondly, I speak of a young man who entered the mission field worthily but by his own choice returned home early due to same-sex attraction and some trauma he experienced in that regard. He was still worthy, but his faith was at crisis level, his emotional burden grew ever heavier, and his spiritual pain was more and more profound. He was by turns hurt, confused, angry, and desolate.

His mission president, his stake president, his bishop spent countless hours searching and weeping and blessing him as they held on to him, but much of his wound was so personal that he kept at least parts of it beyond their reach. The beloved father in this story poured his entire soul into helping this child, but his very demanding employment circumstance meant that often the long, dark nights of the soul were faced by just this boy and his mother. Day and night, first for weeks, then for months that turned into years, they sought healing together. Through periods of bitterness (mostly his but sometimes hers) and unending fear (mostly hers but sometimes his), she bore—there’s that beautiful, burdensome word again—she bore to her son her testimony of God’s power, of His Church, but especially of His love for this child. In the same breath she testified of her own uncompromised, undying love for him as well. To bring together those two absolutely crucial, essential pillars of her very existence—the gospel of Jesus Christ and her family—she poured out her soul in prayer endlessly. She fasted and wept, she wept and fasted, and then she listened and listened as this son repeatedly told her of how his heart was breaking. Thus she carried him—again—only this time it was not for nine months. This time she thought that laboring through the battered landscape of his despair would take forever.

But with the grace of God, her own tenacity, and the help of scores of Church leaders, friends, family members, and professionals, this importuning mother has seen her son come home to the promised land. Sadly we acknowledge that such a blessing does not, or at least has not yet, come to all parents who anguish over a wide variety of their children’s circumstances, but here there was hope. And, I must say, this son’s sexual orientation did not somehow miraculously change—no one assumed it would. But little by little, his heart changed.

He started back to church. He chose to partake of the sacrament willingly and worthily. He again obtained a temple recommend and accepted a call to serve as an early-morning seminary teacher, where he was wonderfully successful. And now, after five years, he has, at his own request and with the Church’s considerable assistance, reentered the mission field to complete his service to the Lord. I have wept over the courage, integrity, and determination of this young man and his family to work things out and to help him keep his faith. He knows he owes much to many, but he knows he owes the most to two messianic figures in his life, two who bore him and carried him, labored with him and delivered him—his Savior, the Lord Jesus Christ, and his determined, redemptive, absolutely saintly mother.

Lastly, this from the rededication of the Mexico City Mexico Temple just three weeks ago. It was there with President Henry B. Eyring that we saw our beloved friend Lisa Tuttle Pieper stand in that moving dedicatory service. But she stood with some difficulty because with one arm she was holding up her beloved but severely challenged daughter, Dora, while with the other she was trying to manipulate Dora’s dysfunctional right hand so this limited but eternally precious daughter of God could wave a white handkerchief and, with groans intelligible only to herself and the angels of heaven, cry out, “Hosanna, hosanna, hosanna to God and the Lamb.”12

To all of our mothers everywhere, past, present, or future, I say, “Thank you. Thank you for giving birth, for shaping souls, for forming character, and for demonstrating the pure love of Christ.” To Mother Eve, to Sarah, Rebekah, and Rachel, to Mary of Nazareth, and to a Mother in Heaven, I say, “Thank you for your crucial role in fulfilling the purposes of eternity.” To all mothers in every circumstance, including those who struggle—and all will—I say, “Be peaceful. Believe in God and yourself. You are doing better than you think you are. In fact, you are saviors on Mount Zion,13 and like the Master you follow, your love ‘never faileth.’14” I can pay no higher tribute to anyone. In the name of Jesus Christ, amen.

# References
1. - Isaiah 53:4.
2. - Doctrine and Covenants 76:41.
3. - Doctrine and Covenants 133:53; see also Isaiah 63:9.
4. - “Israel, Israel, God Is Calling,” Hymns, no. 7.
5. - 3 Nephi 27:14.
6. - John 19:27.
7. - See Isaiah 49:15.
8. - Moroni 7:45; see also 1 Corinthians 13:4–7.
9. - Moroni 7:46; see also 1 Corinthians 13:8.
10. - 3 Nephi 22:10; see also Isaiah 54:10.
11. - John 17:4.
12. - See History of the Church, 2:427–28.
13. - See Obadiah 1:21.
14. - Moroni 7:46; see also 1 Corinthians 13:8.