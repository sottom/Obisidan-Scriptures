Elder M. Russell Ballard
Of the Quorum of the Twelve Apostles
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/god-is-at-the-helm?lang=eng)

_Commandments and covenants are priceless truths and doctrines found in the Old Ship Zion, where God is at the helm._

In last October’s general conference, I invited listeners to follow Brigham Young’s counsel to stay on the Old Ship Zion, which is The Church of Jesus Christ of Latter-day Saints, and to hold on with both hands.1 Since then, I am happy to know that some of my family and others were listening and have asked me this question: “What’s in the Old Ship Zion that we should hang on to?” I reminded them of what President Brigham Young said: “We are on the old ship Zion. … [God] is at the helm and will stay there. … He dictates, guides and directs. If the people will have implicit confidence in their God, never forsake their covenants nor their God, He will guide us right.”2

Clearly, our Heavenly Father and the Lord Jesus Christ have outfitted the Old Ship Zion with clear and simple eternal truths that will help us stay the course through the troubled waters of mortal life. Here are just a few.

The Church of Jesus Christ has always been led by living prophets and apostles. Though mortal and subject to human imperfection, the Lord’s servants are inspired to help us avoid obstacles that are spiritually life threatening and to help us pass safely through mortality to our final, ultimate, heavenly destination.

During my nearly 40 years of close association, I have been a personal witness as both quiet inspiration and profound revelation have moved to action the prophets and apostles, the other General Authorities, and the auxiliary leaders. While neither perfect nor infallible, these good men and women have been perfectly dedicated to leading the work of the Lord forward as He has directed.

And make no mistake about it: the Lord directs His Church through living prophets and apostles. This is the way He has always done His work. Indeed, the Savior taught, “Verily, verily, I say unto you, He that receiveth whomsoever I send receiveth me.”3 We cannot separate Christ from His servants. Without His first Apostles, we would not have an eyewitness account of many of His teachings, His ministry, His suffering in the Garden of Gethsemane, and His death on the cross. Without their testimonies, we would not have an apostolic witness of the empty tomb and the Resurrection.

He commanded those first Apostles:

“Go ye therefore, and teach all nations, baptizing them in the name of the Father, and of the Son, and of the Holy Ghost:

“Teaching them to observe all things whatsoever I have commanded you.”4

This commission was renewed in our own day when the Lord called Joseph Smith to restore the Church, with ordained Apostles to declare His gospel one last time before He will come again.



It has always been a challenge for the world to accept living prophets and apostles, but it is so essential to do so in order to fully understand the Atonement and the teachings of Jesus Christ and to receive a fulness of the blessings of the priesthood that are given to those He has called.

Too many people think Church leaders and members should be perfect or nearly perfect. They forget that the Lord’s grace is sufficient to accomplish His work through mortals. Our leaders have the best intentions, but sometimes we make mistakes. This is not unique to Church relationships, as the same thing occurs in our relationships among friends, neighbors, and workplace associates and even between spouses and in families.

Looking for human weakness in others is rather easy. However, we make a serious mistake by noticing only the human nature of one another and then failing to see God’s hand working through those He has called.

Focusing on how the Lord inspires His chosen leaders and how He moves the Saints to do remarkable and extraordinary things despite their humanity is one way that we hold on to the gospel of Jesus Christ and stay safely aboard the Old Ship Zion.

A second truth is the doctrine of the plan of salvation. Through the Prophet Joseph Smith, God gave the Book of Mormon, the Doctrine and Covenants, and many additional teachings to the Church. These include a knowledge of the plan of salvation, which is a map of where we came from, our purpose here on earth, and where we are going when we die. The plan also provides us with a unique, eternal perspective that we are God’s spirit children. By understanding who our Heavenly Father is and our relationship to Him and to His Beloved Son, Jesus Christ, we will accept Their commandments and make covenants with Them that will lead us back into Their eternal presence.

Every time I hold a newborn child, I find myself wondering: “Who are you, little one? What will you become through the Atonement of Christ?”

We ask similarly reflective questions when someone we love dies: “Where are they? What are they seeing and experiencing? Does life continue? What will be the nature of our most cherished relationships in the great world of the spirits of the dead?”

In that world, our family has two granddaughters, Sara and Emily, and a grandson, Nathan. With each grandchild’s passing, we as a family held on to the gospel truths with both hands. Our questions were answered with comfort and assurance through the Atonement of the Savior. Although we miss our grandchildren, we know they live, and we know we will see them again. How grateful we are for this spiritual understanding in times of personal and familial turbulence.

Another key truth in the Church is that Heavenly Father created Adam and Eve for a lofty purpose. It was their charge—and, subsequently, the charge of their posterity—to create mortal bodies for God’s spirit children so they could experience mortality. By this process, Heavenly Father sends His spirit children to earth to learn and grow through the experiences of earth life. Because He loves His children, God sends heavenly messengers and Apostles to teach them about Jesus Christ’s central role as our Savior.

Through the centuries, prophets have fulfilled their duty when they have warned people of the dangers before them. The Lord’s Apostles are duty bound to watch, warn, and reach out to help those seeking answers to life’s questions.

Twenty years ago, the First Presidency and the Quorum of the Twelve Apostles issued “The Family: A Proclamation to the World.” In that inspired document, we concluded with the following: “We warn that individuals who violate covenants of chastity, who abuse spouse or offspring, or who fail to fulfill family responsibilities will one day stand accountable before God. Further, we warn that the disintegration of the family will bring upon individuals, communities, and nations the calamities foretold by ancient and modern prophets.”5

As Apostles, we reaffirm this solemn warning again today. Please remember that commandments and covenants are priceless truths and doctrines found in the Old Ship Zion, where God is at the helm.

Another important doctrine that we should cling to is to observe the Sabbath day. This helps us remain unspotted from the world, provides us with physical rest, and gives each of us the spiritual refreshment of worshipping the Father and the Son every Sunday.6 When we delight in the Sabbath day, it is a sign of our love for Them.7

As part of our efforts to make the Sabbath a delight, we have asked local leaders and Church members to remember that sacrament meeting is the Lord’s and should be rooted and grounded in His teachings. The presentation of the ordinance of the sacrament is when we renew our covenants and reconfirm our love for the Savior and remember His sacrifice and His Atonement.

This same spirit of worship should permeate our monthly fast and testimony meetings. This sacrament meeting is for members to briefly express gratitude, love, and appreciation for our Heavenly Father, Jesus Christ, and the restored gospel and to bear personal witness of these things. Fast and testimony meeting is a time to share brief inspirational thoughts and bear solemn testimony. It is not a time to give a speech.

Young children should practice sharing their testimonies in Primary and with their parents in family home evening gatherings until they understand the important meaning of a testimony.

The recent emphasis of making the Sabbath a delight is a direct result of inspiration from the Lord through the leaders of the Church. Ward council members should assist the bishopric several weeks in advance by reviewing music and topics that have been recommended for each sacrament meeting.

All of us are blessed when the Sabbath is filled with love for the Lord at home and at church. When our children are taught in the ways of the Lord, they learn to feel and to respond to His Spirit. We will all desire to attend each Sunday to partake of the sacrament when we feel the Spirit of the Lord. And all, young and old, who are carrying heavy burdens will feel the spiritual uplift and comfort that comes from a Sabbath day of devoted contemplation of our Heavenly Father and the Lord Jesus Christ.

Thankfully, Christ is always near, waiting and willing to help us when we pray for help and are willing to repent and come unto Him.

Now, as we ponder just these few truths that exist within the Old Ship Zion, let us stay on board and remember that, by definition, a ship is a vehicle, and the purpose of a vehicle is to take us to a destination.

Our ship’s destination is the full blessings of the gospel, the kingdom of heaven, the celestial glory, and the presence of God!

God’s plan is in place. He is at the helm, and His great and powerful ship flows toward salvation and exaltation. Remember that we cannot get there by jumping out of the boat and trying to swim there by ourselves.



Exaltation is the goal of this mortal journey, and no one gets there without the means of the gospel of Jesus Christ: His Atonement, the ordinances, and the guiding doctrine and principles that are found in the Church.

It is the Church wherein we learn the works of God and accept the grace of the Lord Jesus Christ that saves us. It is within the Church that we form the commitments and covenants of eternal families that become our passport to exaltation. It is the Church that is powered by the priesthood to propel us through the unpredictable waters of mortality.

Let us be grateful for the beautiful Old Ship Zion, for without it we are cast adrift, alone and powerless, swept along without rudder or oar, swirling with the strong currents of the adversary’s wind and waves.

Hold tight, brothers and sisters, and sail on within the glorious ship, The Church of Jesus Christ of Latter-day Saints, and we will reach our eternal destination. This is my testimony and prayer for all of us in the name of Him for whom the Old Ship Zion is named, even our Lord and Savior, Jesus Christ, amen.

# References
1. - See M. Russell Ballard, “Stay in the Boat and Hold On!” Ensign or Liahona, Nov. 2014, 89–92.
2. - Brigham Young, “Remarks,” Deseret News, Nov. 18, 1857, 291.
3. - John 13:20.
4. - Matthew 28:19–20.
5. - “The Family: A Proclamation to the World,” Ensign or Liahona, Nov. 2010, 129.
6. - See Doctrine and Covenants 59:9–23.
7. - See Isaiah 58:13–14.