Elder Richard J. Maynes
Of the Presidency of the Seventy
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/the-joy-of-living-a-christ-centered-life?lang=eng)

_Our lives must be centered with exactness in Christ if we are to find true joy and peace in this life._

The world in which we live is putting great pressure on good people everywhere to lower or even abandon their standards of righteous living. However, despite the evils and temptations that surround us each day, we can and will find true joy today in living a Christ-centered life.

Centering our lives in Jesus Christ and His gospel will bring stability and happiness to our lives, as the following examples illustrate.

Elder Taiichi Aoba of the Seventy, who resides in a small mountain village in Shikoku, Japan, was asked to teach a class at a youth conference. “Stand Ye in Holy Places” was selected as the theme of the conference. After considering the theme and what to teach, Elder Aoba decided to use his vocation as a teaching tool. His work is making pottery.



Elder Aoba relates that his classroom of youth really sprang to life when they saw how he was able to almost magically transform the shape of the clay in his hands to plates, bowls, and cups. After his demonstration, he asked them if any of them would like to give it a try. They all raised their hands.

Elder Aoba had several of the youth come forward to try out their new interest. They assumed, after watching him, that this would be quite simple. However, none of them were successful in their attempts to make even a simple bowl. They proclaimed: “I can’t do this!” “Why is this so hard?” “This is so difficult.” These comments took place as the clay flew all around the room.



He asked the youth why they were having such difficulty making pottery. They responded with various answers: “I don’t have any experience,” “I have never been trained,” or “I have no talent.” Based on the result, what they said was all true; however, the most important reason for their failure was due to the clay not being centered on the wheel. The youth thought that they had placed the clay in the center, but from a professional’s perspective, it wasn’t in the exact center. He then told them, “Let’s try this one more time.”

  ImageStill Stand in the Center

This time, Elder Aoba placed the clay in the exact center of the wheel and then started to turn the wheel, making a hole in the middle of the clay. Several of the youth tried again. This time everyone started clapping when they said: “Wow, it’s not shaking,” “I can do this,” or “I did it!” Of course, the shapes weren’t perfect, but the outcome was totally different from the first attempt. The reason for their success was because the clay was perfectly centered on the wheel.

The world in which we live is similar to the potter’s spinning wheel, and the speed of that wheel is increasing. Like the clay on the potter’s wheel, we must be centered as well. Our core, the center of our lives, must be Jesus Christ and His gospel. Living a Christ-centered life means we learn about Jesus Christ and His gospel and then we follow His example and keep His commandments with exactness.

The ancient prophet Isaiah stated, “But now, O Lord, thou art our father; we are the clay, and thou our potter; and we all are the work of thy hand.”1

If our lives are centered in Jesus Christ, He can successfully mold us into who we need to be in order to return to His and Heavenly Father’s presence in the celestial kingdom. The joy we experience in this life will be in direct proportion to how well our lives are centered on the teachings, example, and atoning sacrifice of Jesus Christ.

Brothers and sisters, I was born into a multigenerational Latter-day Saint family, so the blessings and joy of having the gospel of Jesus Christ as the basis of our family culture was woven into our everyday life. It wasn’t until my full-time mission as a young man that I realized the incredibly positive impact the fulness of the gospel of Jesus Christ has on those who have never previously experienced its blessings in their lives. This verse in Matthew reflects the process that people who are converted to the gospel of Jesus Christ experience: “The kingdom of heaven is like treasure hidden in a field, which a man found and covered up; then in his joy he goes and sells all that he has and buys that field.”2

Let me share with you an example from the Book of Mormon that illustrates what one convert was willing to pay in order to receive the joy associated with finding the treasure spoken of by Jesus in the parable of the treasure hidden in the field.

Remember in the book of Alma chapter 20, Ammon and Lamoni were traveling to the city of Middoni for the purpose of finding and delivering Ammon’s brother Aaron out of prison. During their journey they encountered Lamoni’s father, who was the Lamanite king over all the land.

The king was very upset that his son Lamoni was traveling with Ammon, a Nephite missionary, whom he considered an enemy. He felt that his son should have attended a great feast he had sponsored for his sons and his people. The Lamanite king was so upset that he commanded his son Lamoni to slay Ammon with his sword. When Lamoni refused, the king drew his own sword to slay his son for disobedience; however, Ammon interceded to save Lamoni’s life. He ultimately overpowered the king and could have killed him.

This is what the king said to Ammon after finding himself in this life-and-death situation: “If thou wilt spare me I will grant unto thee whatsoever thou wilt ask, even to half of the kingdom.”3

So the king was willing to pay the price of one-half his kingdom in order to spare his own life. The king must have been astonished when Ammon requested only that he release his brother Aaron and his associates from prison and that the king’s son Lamoni retain his kingdom.

Later on, due to this encounter, Ammon’s brother Aaron was released from the Middoni prison. After his release he was inspired to travel to where the Lamanite king ruled over the land. Aaron was introduced to the king and had the privilege of teaching him the principles of the gospel of Jesus Christ, including the great plan of redemption. The teachings of Aaron inspired the king deeply.

The king’s response to Aaron’s teachings is found in verse 15 of Alma chapter 22: “And it came to pass that after Aaron had expounded these things unto him, the king said: What shall I do that I may have this eternal life of which thou hast spoken? Yea, what shall I do that I may be born of God, having this wicked spirit rooted out of my breast, and receive his Spirit, that I may be filled with joy, that I may not be cast off at the last day? Behold, said he, I will give up all that I possess, yea, I will forsake my kingdom, that I may receive this great joy.”

Amazingly enough, in contrast to giving up one-half his kingdom to spare his life, the Lamanite king was now willing to give up his entire kingdom that he might receive the joy that comes from understanding, accepting, and living the gospel of Jesus Christ.

My wife, Nancy, is also a convert to the Church. She has mentioned to me many times over the years the joy she has felt in her life since finding, accepting, and living the gospel of Jesus Christ. What follows is a reflection from Sister Maynes on her experience:

“As a young adult in my early 20s, I was at a point in my life when I knew I needed to change something in order to be a happier person. I felt like I was adrift with no real purpose and direction, and I didn’t know where to go to find it. I had always known that Heavenly Father existed and occasionally throughout my life had said prayers, feeling that He listened.

“As I began my search, I attended several different churches but would always fall back into the same feelings and discouragement. I feel very blessed because my prayer for direction and purpose in life was ultimately answered, and the fulness of the gospel of Jesus Christ was brought into my life. For the first time I felt like I had a purpose, and the plan of happiness brought real joy into my life.”

Another experience from the Book of Mormon clearly illustrates how living a Christ-centered life can fill us with great happiness even when we are surrounded with incredible hardships.

After the prophet Lehi and his family left Jerusalem in 600 b.c., they wandered approximately eight years in the wilderness until they finally arrived in a land they called Bountiful, which was near the seashore. Nephi describes their life of tribulation in the wilderness this way: “We had suffered many afflictions and much difficulty, … even so much that we cannot write them all.”4

While living in Bountiful, Nephi was charged by the Lord with the responsibility to build the ship which would take them across the sea to the promised land. After they arrived in the promised land, great conflicts continued to arise between the people who centered their lives in Christ and the nonbelievers, who followed the examples of Laman and Lemuel. Ultimately, the risk of violence between the two groups was so great that Nephi and those who followed the teachings of the Lord separated themselves and fled into the wilderness for safety. At this point in time, some 30 years after Lehi and his family left Jerusalem, Nephi makes a well-documented and somewhat surprising statement, especially after recording in the scriptures the many afflictions and tribulations they had faced for so long. These are his words: “And it came to pass that we [did live] after the manner of happiness.”5 Despite their hardships, they were able to live after the manner of happiness because they were centered in Christ and His gospel.

Brothers and sisters, like the clay on the potter’s wheel, our lives must be centered with exactness in Christ if we are to find true joy and peace in this life. The examples of the Lamanite king; my wife, Nancy; and the Nephite people all support this true principle.

I bear you my witness today that we too can find that peace, that happiness, that true joy if we choose to live Christ-centered lives, in the name of Jesus Christ, amen.

# References
1. - Isaiah 64:8.
2. - Matthew 13:44 (Revised Standard Version).
3. - Alma 20:23.
4. - 1 Nephi 17:6.
5. - 2 Nephi 5:27.