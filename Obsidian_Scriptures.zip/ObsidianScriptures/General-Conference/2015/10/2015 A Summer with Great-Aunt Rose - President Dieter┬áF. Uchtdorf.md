President Dieter F. Uchtdorf
Second Counselor in the First Presidency
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/a-summer-with-great-aunt-rose?lang=eng)

_As you walk along your own bright path of discipleship, I pray that faith will fortify every footstep along your way._

My beloved sisters and dear friends, I am delighted to be with you today, and I am grateful to be in the presence of our dear prophet, President Thomas S. Monson. President, we love you. We are saddened by the loss of our three precious friends and true Apostles of the Lord. We miss President Packer, Elder Perry, and Elder Scott; we love them. We pray for their families and friends.

I always look forward to this session of conference—the beautiful music and the counsel from our inspired sisters bring the Spirit in great abundance. I am a better person after being in your company.

As I pondered what I should say to you today, my thoughts turned to the way the Savior taught. It is interesting how He was able to teach the most sublime truths using simple stories. His parables invited His disciples to embrace truths not just with their minds but also with their hearts and to connect eternal principles with their everyday lives.1 Our dear President Monson is also a master at teaching with personal experiences that touch the heart.2

Today, I too will give my message by expressing my thoughts and feelings in the form of a story. I invite you to listen with the Spirit. The Holy Ghost will help you to find the message for you in this parable.





Great-Aunt Rose



The story is about a girl named Eva. There are two important things you should know about Eva. One is that she was 11 years old in this story. And the other is that she absolutely, positively did not want to go and live with her great-aunt Rose. Not at all. No way.

But Eva’s mother was going to have surgery that required a lengthy recovery. So Eva’s parents were sending her to spend the summer with Great-Aunt Rose.

In Eva’s mind, there were a thousand reasons why this was a bad idea. For one thing, it would mean being away from her mother. It would also mean leaving her family and friends. And besides, she didn’t even know Great-Aunt Rose. She was quite comfortable, thank you very much, right where she was.

But no amount of arguing or eye-rolling could change the decision. So Eva packed up a suitcase and took the long drive with her father to Great-Aunt Rose’s house.

From the moment Eva stepped inside the house, she hated it.

Everything was so old! Every inch was packed with old books, strange-colored bottles, and plastic bins spilling over with beads, bows, and buttons.

Great-Aunt Rose lived there alone; she had never married. The only other inhabitant was a gray cat who liked to find the highest point in every room and perch there, staring like a hungry tiger at everything below.

Even the house itself seemed lonely. It was out in the countryside, where the houses are far apart. No one Eva’s age lived within half a mile. That made Eva feel lonely too.

At first she didn’t pay much attention to Great-Aunt Rose. She mostly thought about her mother. Sometimes, she would stay awake at night, praying with all her soul that her mother would be well. And though it didn’t happen right away, Eva began to feel that God was watching over her mother.

Word finally came that the operation was a success, and now all that was left for Eva to do was to endure till the end of summer. But oh, how she hated enduring!

With her mind now at ease about her mother, Eva began to notice Great-Aunt Rose a little more. She was a large woman—everything about her was large: her voice, her smile, her personality. It wasn’t easy for her to get around, but she always sang and laughed while she worked, and the sound of her laughter filled the house. Every night she sat down on her overstuffed sofa, pulled out her scriptures, and read out loud. And as she read, she sometimes made comments like “Oh, he shouldn’t have done that!” or “What wouldn’t I give to have been there!” or “Isn’t that the most beautiful thing you’ve ever heard!” And every evening as the two of them knelt by Eva’s bed to pray, Great-Aunt Rose would say the most beautiful prayers, thanking her Heavenly Father for the blue jays and the spruce trees, the sunsets and the stars, and the “wonder of being alive.” It sounded to Eva as though Rose knew God as a friend.

Over time, Eva made a surprising discovery: Great-Aunt Rose was quite possibly the happiest person she had ever known!

But how could that be?

What did she have to be happy about?

She had never married, she had no children, she had no one to keep her company except that creepy cat, and she had a hard time doing simple things like tying her shoes and walking up stairs.

When she went to town, she wore embarrassingly big, bright hats. But people didn’t laugh at her. Instead, they crowded around her, wanting to talk to her. Rose had been a schoolteacher, and it wasn’t uncommon for former students—now grown up with children of their own—to stop and chat. They thanked her for being a good influence in their lives. They often laughed. Sometimes they even cried.

As the summer progressed, Eva spent more and more time with Rose. They went on long walks, and Eva learned the difference between sparrows and finches. She picked wild elderberries and made marmalade from oranges. She learned about her great-great-grandmother who left her beloved homeland, sailed across an ocean, and walked across the plains to be with the Saints.

Soon Eva made another startling discovery: not only was Great-Aunt Rose one of the happiest persons she knew, but Eva herself was happier whenever she was around her.

The days of summer were passing more quickly now. Before Eva knew it, Great-Aunt Rose said it would soon be time for Eva to return home. Though Eva had been looking forward to that moment since the day she arrived, she wasn’t quite sure how to feel about it now. She realized she was actually going to miss this strange old house with the stalker cat and her beloved great-aunt Rose.

The day before her father arrived to pick her up, Eva asked the question she had been wondering about for weeks: “Aunt Rose, why are you so happy?”

Aunt Rose looked at her carefully and then guided her to a painting that hung in the front room. It had been a gift from a talented dear friend.

“What do you see there?” she asked.

  ImageJoy in the Journey

Eva had noticed the painting before, but she hadn’t really looked at it closely. A girl in pioneer dress skipped along a bright blue path. The grass and trees were a vibrant green. Eva said, “It’s a painting of a girl. Looks like she’s skipping.”

“Yes, it is a pioneer girl skipping along happily,” Aunt Rose said. “I imagine there were many dark and dreary days for the pioneers. Their life was so hard—we can’t even imagine. But in this painting, everything is bright and hopeful. This girl has a spring in her step, and she is moving forward and upward.”

Eva was silent, so Great-Aunt Rose continued: “There is enough that doesn’t go right in life, so anyone can work themselves into a puddle of pessimism and a mess of melancholy. But I know people who, even when things don’t work out, focus on the wonders and miracles of life. These folks are the happiest people I know.”

“But,” Eva said, “you can’t just flip a switch and go from sad to happy.”

“No, perhaps not,” Aunt Rose smiled gently, “but God didn’t design us to be sad. He created us to have joy!3 So if we trust Him, He will help us to notice the good, bright, hopeful things of life. And sure enough, the world will become brighter. No, it doesn’t happen instantly, but honestly, how many good things do? Seems to me that the best things, like homemade bread or orange marmalade, take patience and work.”

Eva thought about it a moment and said, “Maybe it’s not so simple for people who don’t have everything perfect in their lives.”

“Dear Eva, do you really think that my life is perfect?” Aunt Rose sat with Eva on the overstuffed sofa. “There was a time when I was so discouraged I didn’t want to go on.”

“You?” Eva asked.

Aunt Rose nodded. “There were so many things I wished for in my life.” As she spoke, a sadness entered her voice that Eva had never heard before. “Most of them never happened. It was one heartbreak after another. One day I realized that it would never be the way I had hoped for. That was a depressing day. I was ready to give up and be miserable.”

“So what did you do?”

“Nothing for a time. I was just angry. I was an absolute monster to be around.” Then she laughed a little, but it was not her usual big, room-filling laugh. “‘It’s not fair’ was the song I sang over and over in my head. But eventually I discovered something that turned my whole life around.”

“What was it?”

“Faith,” Aunt Rose smiled. “I discovered faith. And faith led to hope. And faith and hope gave me confidence that one day everything would make sense, that because of the Savior, all the wrongs would be made right. After that, I saw that the path before me wasn’t as dreary and dusty as I had thought. I began to notice the bright blues, the verdant greens, and the fiery reds, and I decided I had a choice—I could hang my head and drag my feet on the dusty road of self-pity, or I could have a little faith, put on a bright dress, slip on my dancing shoes, and skip down the path of life, singing as I went.” Now her voice was skipping along like the girl in the painting.

Aunt Rose reached over to the end table and pulled her well-worn scriptures onto her lap. “I don’t think I was clinically depressed—I’m not sure you can talk yourself out of that. But I sure had talked myself into being miserable! Yes, I had some dark days, but all my brooding and worrying wasn’t going to change that—it was only making things worse. Faith in the Savior taught me that no matter what happened in the past, my story could have a happy ending.”

“How do you know that?” Eva asked.

Aunt Rose turned a page in her Bible and said, “It says it right here:

“‘God … will dwell with them, and they shall be his people, and God himself shall be with them, and be their God.

“‘And God shall wipe away all tears from their eyes; and there shall be no more death, neither sorrow, nor crying, neither shall there be any more pain: for the former things are passed away.’”4

Great-Aunt Rose looked at Eva. Her smile was wide as she whispered, with a slight quiver in her voice, “Isn’t that the most beautiful thing you’ve ever heard?”

It really did sound beautiful, Eva thought.

Aunt Rose turned a few pages and pointed to a verse for Eva to read: “Eye hath not seen, nor ear heard, neither have entered into the heart of man, the things which God hath prepared for them that love him.”5

“With such a glorious future,” Aunt Rose said, “why get swallowed up in past or present things that don’t go quite the way we planned?”



Eva furrowed her brow. “But wait a minute,” she said. “Are you saying that being happy means just looking forward to happiness in the future? Is all our happiness in eternity? Can’t some of it happen now?”

“Oh, of course it can!” Aunt Rose exclaimed. “Dear child, now is part of eternity. It doesn’t only begin after we die! Faith and hope will open your eyes to the happiness that is placed before you.

“I know a poem that says, ‘Forever—is composed of Nows.’6 I didn’t want my forever to be composed of dark and fearful ‘Nows.’ And I didn’t want to live in the gloom of a bunker, gritting my teeth, closing my eyes, and resentfully enduring to the bitter end. Faith gave me the hope I needed to live joyfully now!”

“So what did you do then?” Eva asked.

“I exercised faith in God’s promises by filling my life with meaningful things. I went to school. I got an education. That led me to a career that I loved.”

Eva thought about this for a moment and said, “But surely being busy isn’t what made you happy. There are a lot of busy people who aren’t happy.”

“How can you be so wise for someone so young?” Aunt Rose asked. “You’re absolutely right. And most of those busy, unhappy people have forgotten the one thing that matters most in all the world—the thing Jesus said is the heart of His gospel.”

“And what is that?” Eva asked.

“It is love—the pure love of Christ,” Rose said. “You see, everything else in the gospel—all the shoulds and the musts and the thou shalts—lead to love. When we love God, we want to serve Him. We want to be like Him. When we love our neighbors, we stop thinking so much about our own problems and help others to solve theirs.”7

“And that is what makes us happy?” Eva asked.

Great-Aunt Rose nodded and smiled, her eyes filling with tears. “Yes, my dear. That is what makes us happy.”







Never the Same



The next day Eva hugged her great-aunt Rose and thanked her for everything she had done. She returned home to her family and her friends and her house and her neighborhood.

But she was never quite the same.

As Eva grew older, she often thought of the words of her great-aunt Rose. Eva eventually married, raised children, and lived a long and wonderful life.

And one day, as she was standing in her own home, admiring a painting of a girl in pioneer dress skipping down a bright blue path, she realized that somehow she had reached the same age her great-aunt Rose was during that remarkable summer.

  ImageJoy in the Journey

When she realized this, she felt a special prayer swell within her heart. And Eva felt grateful for her life, for her family, for the restored gospel of Jesus Christ, and for that summer so long ago when Great-Aunt Rose8 taught her about faith, hope, and love.9







A Blessing



My beloved sisters, my dear friends in Christ, I hope and pray that something in this story has touched your heart and inspired your soul. I know that God lives and that He loves each and every one of you.

As you walk along your own bright path of discipleship, I pray that faith will fortify every footstep along your way; that hope will open your eyes to the glories Heavenly Father has in store for you; and that love for God and all His children will fill your hearts. As an Apostle of the Lord, I leave this as my testimony and blessing in the name of Jesus Christ, amen.

# References
1. - See, for example, Matthew 13:24–30; 18:23–35; 20:1–16; 22:1–14; 25; Luke 10:25–37; 15:11–32.
2. - See, for example, Thomas S. Monson, “Guided Safely Home,” Ensign or Liahona, Nov. 2014, 67–69; “Love—the Essence of the Gospel,” Ensign or Liahona, May 2014, 91–94; “We Never Walk Alone,” Ensign or Liahona, Nov. 2013, 121–24; “Obedience Brings Blessings,” Ensign or Liahona, May 2013, 89–92.
3. - See 2 Nephi 2:25.
4. - Revelation 21:3–4.
5. - 1 Corinthians 2:9.
6. - “Forever—is composed of Nows,” in Final Harvest: Emily Dickinson’s Poems, sel. Thomas H. Johnson (1961), 158; see also poetryfoundation.org/poem/182912.
7. - See Luke 9:24.
8. - “Often the prickly thorn produces tender roses” (Ovid, Epistulae ex ponto, book 2, epistle 2, line 34; “Saepe creat molles aspera spina rosas”).
9. - See Moroni 7:42.