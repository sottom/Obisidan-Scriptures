

10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/womens-session?lang=eng)



# References
