Elder Koichi Aoyagi
Emeritus Member of the Seventy
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/hold-on-thy-way?lang=eng)

_Put God first, regardless of the trials you face. Love God. Have faith in Christ, and entrust yourself to Him in all things._

On March 11, 2011, I was standing on a platform in the Tokyo Shinagawa train station to visit the Japan Kobe Mission. At approximately 2:46 p.m., a 9.0-magnitude massive earthquake struck. I was not able to stand because of the intense shaking, and I held tightly to a stair rail. Lights on nearby ceilings began falling to the floor. All of Tokyo was in a panic.

Fortunately, I was not injured, and four hours later, I was relieved to learn that my entire family was safe.

On television there was a stream of terrifying, shocking footage. A massive tsunami surged into the Sendai mission area—sweeping away everything in its path: cars, houses, factories, and fields. I was stunned by the tragic images, and I wept. And I fervently prayed that our Heavenly Father’s protection and assistance would be upon all the people living in this region that I so dearly love.

Later, it was confirmed that all the missionaries and Church members were safe. However, many members were affected, losing their family members, homes, and household possessions. Nearly 20,000 people perished, communities were destroyed, and many people were forced to leave their homes as a result of a nuclear power plant accident.

Disasters such as this are wreaking havoc in many parts of the world today, causing much loss of life. We are warned that disasters, wars, and countless difficulties in the world will occur.

When trials such as these suddenly come upon us, we may question, “Why do these things happen to me?” or “Why do I have to suffer?”

For a long period after I converted to the gospel, I didn’t have a clear answer to the question “Why am I given trials?” I understood the part of the plan of salvation that says we will be tested. However, in reality, when it came to this question, I did not have a conviction that was powerful enough to adequately answer it. But there came a time in my life when I too experienced a major trial.

When I was 30 years old, I was visiting the Nagoya mission as part of my work. After the meeting, the mission president kindly arranged for the elders to drive me to the airport. However, as we reached the intersection at the bottom of a long hill, a large truck came barreling down from behind us at great speed. It rammed into the rear of our car and propelled it forward more than 70 feet (20 m). The terrifying part of all of this was there was no driver. The rear of our car was compacted to half its original size. Fortunately, both the elders and I survived.

However, on the following day, I began experiencing pain in my neck and shoulders and developed a severe headache. From that day, I couldn’t sleep and I was forced to live each day with both physical and mental pain. I prayed to God to please heal my pain, but these symptoms lingered on for about 10 years.

At this time, feelings of doubt also began creeping into my mind, and I wondered, “Why do I have to suffer this much pain?” However, even though the kind of healing I sought was not granted, I strove to be faithful in keeping God’s commandments. I continued to pray that I would be able to resolve the questions I had about my trials.

There came a time when I found myself struggling with a few additional personal issues, and I was agitated because I did not know how to cope with this new trial. I was praying for an answer. But I didn’t receive an answer right away. So I went and talked with a trusted Church leader.

As we were talking, with love in his voice, he said, “Brother Aoyagi, isn’t your purpose for being on this earth to experience this trial? Isn’t it to accept all the trials of this life for what they are and then leave the rest up to the Lord? Don’t you think that this problem will be resolved when we are resurrected?”

When I heard these words, I felt the Spirit of the Lord very strongly. I had heard this doctrine countless times, but the eyes of my understanding had never been opened to the extent they were at this time. I understood this was the answer that I had been seeking from the Lord in my prayers. I was able to clearly comprehend our Heavenly Father’s plan of salvation and understand anew this important principle.

In Abraham, the Lord God declared, “And we will prove them herewith, to see if they will do all things whatsoever the Lord their God shall command them.”1

The principle is that the God who created the heavens and the earth knows the grand design of this earth, that He has dominion over all things in the heavens and the earth, and that in order to bring to pass the plan of salvation, He provides us with many different experiences—including some trials—while we are on this earth.

And the Lord said the following to Joseph Smith:

“Know thou, my son, that all these things shall give thee experience, and shall be for thy good. …

“Therefore, hold on thy way … , for God shall be with you forever and ever.”2

The trials of this earth—including illness and death—are a part of the plan of salvation and are inevitable experiences. It is necessary for us to “hold on [our] way” and accept our trials with faith.

However, the purpose of our lives is not merely to endure trials. Heavenly Father sent His Beloved Son, Jesus Christ, as our Savior and Redeemer so we could overcome the trials we face on this earth; in other words, He makes our weak things become strong,3 He atones for our sins and our imperfections, and He makes it possible for us to obtain immortality and eternal life.

President Henry B. Eyring stated: “The test a loving God has set before us is not to see if we can endure difficulty. It is to see if we can endure it well. We pass the test by showing that we remembered Him and the commandments He gave us.”4

“Hold on thy way” is a key choice during times of trial. Turn your heart to God, especially when you face trials. Humbly obey the commandments of God. Show faith to reconcile your wishes with the will of God.

Let’s now consider that rear-end collision in Nagoya. I could have died in that accident. Nevertheless, through the Lord’s grace, I miraculously survived. And I know that my sufferings were for my learning and for my growth.5 Heavenly Father schooled me to temper my impatience, to develop empathy, and to comfort those who are suffering. When I realized this, my heart was filled with feelings of thankfulness toward my Heavenly Father for this trial.

Put God first, regardless of the trials you face. Love God. Have faith in Christ, and entrust yourself to Him in all things. Moroni makes the following promise to such people: “And if ye shall deny yourselves of all ungodliness, and love God with all your might, mind and strength, then is his grace sufficient for you, that by his grace ye may be perfect in Christ.”6

I sincerely testify that God the Father and His Beloved Son, Jesus Christ, live and that God’s promises to those who “hold on [their] way” and love Him will be fulfilled even in the midst of trials, in the sacred name of Jesus Christ, amen.

# References
1. - Abraham 3:25.
2. - Doctrine and Covenants 122:7, 9; emphasis added.
3. - See Ether 12:27.
4. - Henry B. Eyring, “In the Strength of the Lord,” Ensign or Liahona, May 2004, 17.
5. - See Hebrews 12:7–9.
6. - Moroni 10:32.