Elder Hugo Montoya
Of the Seventy
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/tested-and-tempted-but-helped?lang=eng)

_We can help each other as children of our Heavenly Father in our trials and temptations._

During the course of life, we are tested and tempted. We also have the opportunity to exercise agency and to help one another. These truths are part of the wonderful and perfect plan of our Heavenly Father.

President John Taylor taught: “I heard the Prophet Joseph say, in speaking to the Twelve on one occasion: ‘You will have all kinds of trials to pass through. And it is quite as necessary for you to be tried as it was for Abraham and other men of God, and (said he) God will feel after you, and He will take hold of you and wrench your very heart strings.’”1

Once we reach the age of accountability, trials and temptations are universal. Sometimes they can become heavy burdens, but they also give us strength and growth as we successfully overcome them.

Fortunately, these burdens are not to be carried alone. Alma taught, “Ye are desirous to come into the fold of God, and to be called his people, and are willing to bear one another’s burdens, that they may be light.”2 These words indicate that we have the responsibility to help each other. That responsibility can come from a Church calling, an assignment, or a friendship or as part of our divine duty as parents, spouses, or family members—or simply from being part of God’s family.

I will illustrate four ways our burdens are lightened as we help each other.





The Savior said, “Whosoever shall compel thee to go a mile, go with him twain.”3 For example, we are asked to attend the temple regularly, as our individual circumstances allow. Attending the temple requires sacrifice of time and resources, especially for those who must travel a great distance. Nevertheless, this sacrifice could be considered part of the first mile.

We begin walking the second mile when we understand the words “find, take, teach,”4 when we search for and prepare the names of our ancestors for temple ordinances, when we help in indexing, when we serve as temple workers, and when we look for ways to help others have meaningful temple experiences.

While I was serving as an Area Seventy, one of the stakes in my coordinating council participated in a large temple excursion. The temple the members attended is small, and unfortunately there were several members who, despite making the long 12-hour journey, were not able to enter the temple because it had exceeded the daily capacity.

A few days after this trip, I visited this stake and asked the president if I could talk with some of the members who were unable to attend the temple that day. One of the brothers I visited told me: “Elder, do not worry. I was at the house of the Lord. I sat on a bench in the garden and pondered in my mind the ordinances. Then I was given the opportunity to enter, but instead I allowed another brother, who had come to the temple for the first time to be sealed to his wife, to take my place. They then had the opportunity to attend two sessions that day. The Lord knows me, and He has blessed me, and we are fine.”





Smile. This small action can help those who are overwhelmed or burdened. During the priesthood session of this past April general conference, I was seated on the stand as one of the five newly called General Authorities. We were sitting where the sisters of the auxiliary presidencies are now seated. I was feeling very nervous and overwhelmed with my new call.

When we were singing the intermediate hymn, I felt a strong impression that someone was watching me. I thought to myself: “There are more than 20,000 people in this building, and most of them are facing this way. Of course someone is watching you.”

While I continued singing, I again felt the strong impression that someone was watching me. I looked over to the row where the Twelve Apostles were sitting and saw that President Russell M. Nelson was turned all the way around in his seat, looking at where we were seated. I caught his eye, and he gave me a big smile. That smile brought peace to my overwhelmed heart.

After His Resurrection, Jesus Christ visited His other sheep. He called and ordained twelve disciples, and with that authority, they ministered to the people. The Lord Jesus Christ Himself stood among them. The Lord asked them to kneel and pray. I am not sure if the newly called and ordained twelve disciples were overwhelmed with their calling, but the scripture says, “It came to pass that Jesus blessed them as they did pray unto him; and his countenance did smile upon them, and the light of his countenance did shine upon them.”5 During the last general conference, a smile lightened my burdens in an immediate and extraordinary way.





Express feelings of compassion to others. If you are a priesthood holder, please use your power on behalf of the children of God, giving blessings to them. Express words of consolation and comfort to people who are suffering or experiencing afflictions.





The cornerstone of God’s plan is the Atonement of the Lord Jesus Christ. At least once a week, we should meditate as President Joseph F. Smith did on “the great and wonderful love made manifest by the Father and the Son in the coming of the Redeemer into the world.”6 Inviting others to come to church and to worthily partake of the sacrament will allow more of Heavenly Father’s children to reflect on the Atonement. And if we are not worthy, we can repent. Remember that the Son of the Highest descended below all and took upon Him our offenses, sins, transgressions, sicknesses, pains, afflictions, and loneliness. The scripture teaches us that Christ “ascended up on high, as also he descended below all things, in that he comprehended all things.”7





It does not matter what our personal struggles are—whether they are disease or prolonged loneliness or suffering the temptations and tests of the adversary—the Good Shepherd is there. He calls us by name and says, “Come unto me, all ye that labour and are heavy laden, and I will give you rest.”8

I want to summarize the four points:

First—go the second mile.

Second—please smile. Your smile will help others.

Third—express compassion.

Fourth—invite others to come to church.



I bear my testimony of the Savior. Jesus is the Christ, the Son of the living God, and He lives. I know that He sustains, with all His might and power, the Father’s plan. I know that President Thomas S. Monson is a living prophet. He holds all the keys to successfully carry out God’s work on the earth. I know that we can help each other as children of our Heavenly Father in our trials and temptations. In the name of Jesus Christ, amen.

# References
1. - John Taylor, in Teachings of Presidents of the Church: Joseph Smith (2007), 231.
2. - Mosiah 18:8.
3. - Matthew 5:41.
4. - See Quentin L. Cook, “Our Father’s Plan Is about Families” (address given at RootsTech 2015 family history conference, Feb. 14, 2015), lds.org/topics/family-history/fdd/plan-about-families-full; see also lds.org/media-library/video/2015-07-01-find-take-teach.
5. - 3 Nephi 19:25; emphasis added.
6. - Doctrine and Covenants 138:3.
7. - Doctrine and Covenants 88:6.
8. - Matthew 11:28.