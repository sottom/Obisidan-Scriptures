Presented by President Henry B. Eyring
First Counselor in the First Presidency
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/the-sustaining-of-church-officers?lang=eng)

Brothers and sisters, President Monson has asked that I now present to you the General Authorities, Area Seventies, and general auxiliary presidencies of the Church for your sustaining vote.

It is proposed that we sustain Thomas Spencer Monson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Henry Bennion Eyring as First Counselor in the First Presidency; and Dieter Friedrich Uchtdorf as Second Counselor in the First Presidency.

Those in favor may manifest it.

Those opposed, if any, may manifest it.

The vote has been noted.

It is proposed that we sustain Russell M. Nelson as President of the Quorum of the Twelve Apostles and the following as members of that quorum: Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, Robert D. Hales, Jeffrey R. Holland, David A. Bednar, Quentin L. Cook, D. Todd Christofferson, Neil L. Andersen, and, as new members of the Quorum of the Twelve, Ronald A. Rasband, Gary E. Stevenson, and Dale G. Renlund.

Those in favor, please signify by the uplifted hand.

Any opposed may so indicate.

The vote has been noted.

It is proposed that we sustain the counselors in the First Presidency and the Quorum of the Twelve Apostles as prophets, seers, and revelators.

All in favor, please manifest it.

Contrary, if there be any, by the same sign.

The vote has been noted.

With their calls to serve as members of the Quorum of the Twelve, we hereby release Ronald A. Rasband as a member of the Presidency of the Seventy and Elder Rasband and Elder Dale G. Renlund as members of the First Quorum of the Seventy.

Those who wish to join in a vote of appreciation may so indicate.

It is proposed that we release with appreciation for their devoted service Elder Don R. Clarke as a member of the First Quorum of the Seventy and Elders Koichi Aoyagi and Bruce A. Carlson as members of the Second Quorum of the Seventy and designate them as emeritus General Authorities.



Those who wish to join with us in expressing gratitude for their excellent service, please manifest it.

We also extend a release to Serhii A. Kovalov as an Area Seventy.

Those who wish to join us in expressing appreciation for his service, please so signify.

At this time we note the releases of Brother John S. Tanner as first counselor in the Sunday School general presidency and Brother Devin G. Durrant as second counselor in the Sunday School general presidency. As previously announced, Brother Tanner has been appointed to serve as president of BYU–Hawaii.

All who wish to join us in expressing appreciation to these brethren for their service and devotion, please manifest it.

Brother Devin G. Durrant has now been called to serve as first counselor in the Sunday School general presidency and Brother Brian K. Ashton to serve as second counselor in the Sunday School general presidency.

All in favor, please manifest it.

Those opposed, if any.

It is proposed that we sustain the other General Authorities, Area Seventies, and general auxiliary presidencies as presently constituted.

All in favor, please manifest it.

Those opposed, if any.

The voting has been noted. We invite those who have opposed any of the proposals to contact their stake presidents.

Brothers and sisters, we appreciate your faith and prayers in behalf of the leaders of the Church.

We now ask the new members of the Quorum of the Twelve Apostles to take their places on the stand. They will have the opportunity to address us tomorrow morning.

# References
