Elder Dale G. Renlund
Of the Quorum of the Twelve Apostles
10-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/10/through-gods-eyes?lang=eng)

_To effectively serve others, we must see them through a parent’s eyes, through Heavenly Father’s eyes._

My dear brothers and sisters, thank you for sustaining me yesterday as a member of the Quorum of the Twelve Apostles. It is hard to express how much that means to me. I was especially grateful for the sustaining vote of the two extraordinary women in my life: my wife, Ruth, and our dear, dear, dear daughter, Ashley.

My call gives ample evidence to the truthfulness of the Lord’s statement early in this dispensation: “That the fulness of my gospel might be proclaimed by the weak and the simple unto the ends of the world.”1 I am one of those weak and simple. Decades ago, when I was called to be the bishop of a ward in the eastern United States, my brother, slightly older and much wiser than I, called me on the phone. He said, “You need to know that the Lord hasn’t called you because of anything you have done. In your case, it is probably in spite of what you have done. The Lord has called you for what He needs to do through you, and that will happen only if you do it His way.” I recognize that this wisdom from an older brother applies even more today.

Something wonderful happens in a missionary’s service when he or she realizes that the calling is not about him or her; rather, it is about the Lord, His work, and Heavenly Father’s children. I feel the same is true for an Apostle. This calling is not about me. It’s about the Lord, His work, and Heavenly Father’s children. No matter what the assignment or calling is in the Church, to serve capably, one must serve knowing that everyone we serve “is a beloved spirit son or daughter of heavenly parents, and, as such, … has a divine nature and destiny.”2

In my past profession, I was a cardiologist specializing in heart failure and transplantation, with many patients who were critically ill. My wife jokingly says that it was a bad prognostic sign to become one of my patients. All teasing aside, I saw many people die, and I developed a kind of emotional distance when things went poorly. That way, feelings of sadness and disappointment were tempered.

In 1986 a young man named Chad developed heart failure and received a heart transplant. He did very well for a decade and a half. Chad did all he could to stay healthy and live as normal a life as possible. He served a mission, worked, and was a devoted son to his parents. The last few years of his life, though, were challenging, and he was in and out of the hospital frequently.

One evening, he was brought to the hospital’s emergency department in full cardiac arrest. My associates and I worked for a long time to restore his circulation. Finally, it became clear that Chad could not be revived. We stopped our futile efforts, and I declared him dead. Although sad and disappointed, I maintained a professional attitude. I thought to myself, “Chad has had good care. He has had many more years of life than he otherwise would have had.” That emotional distance soon shattered as his parents came into the emergency room bay and saw their deceased son lying on a stretcher. In that moment, I saw Chad through his mother’s and father’s eyes. I saw the great hopes and expectations they had had for him, the desire they had had that he would live just a little bit longer and a little bit better. With this realization, I began to weep. In an ironic reversal of roles and in an act of kindness I will never forget, Chad’s parents comforted me.

I now realize that in the Church, to effectively serve others we must see them through a parent’s eyes, through Heavenly Father’s eyes. Only then can we begin to comprehend the true worth of a soul. Only then can we sense the love that Heavenly Father has for all of His children. Only then can we sense the Savior’s caring concern for them. We cannot completely fulfill our covenant obligation to mourn with those who mourn and comfort those who stand in need of comfort unless we see them through God’s eyes.3 This expanded perspective will open our hearts to the disappointments, fears, and heartaches of others. But Heavenly Father will aid and comfort us, just as Chad’s parents comforted me years ago. We need to have eyes that see, ears that hear, and hearts that know and feel if we are to accomplish the rescue so frequently encouraged by President Thomas S. Monson.4

Only when we see through Heavenly Father’s eyes can we be filled with “the pure love of Christ.”5 Every day we should plead with God for this love. Mormon admonished, “Wherefore, my beloved brethren, pray unto the Father with all the energy of heart, that ye may be filled with this love, which he hath bestowed upon all who are true followers of his Son, Jesus Christ.”6

With all my heart I want to be a true follower of Jesus Christ.7 I love Him. I adore Him. I witness of His living reality. I witness that He is the Anointed One, the Messiah. I am a witness of His incomparable mercy, compassion, and love. I add my testimony to that of the Apostles who, in the year 2000, stated “that Jesus is the Living Christ, the immortal Son of God. … He is the light, the life, and the hope of the world.”8

I testify that on a day in 1820 in a grove in upstate New York, the risen Lord appeared, along with God, our Heavenly Father, to the Prophet Joseph Smith, just as Joseph Smith said They did. Priesthood keys are on earth today to enable saving and exalting ordinances. I know it. In the name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 1:23.
2. - “The Family: A Proclamation to the World,” Ensign or Liahona, Nov. 2010, 129; it was first read by President Gordon B. Hinckley as part of his message at the general Relief Society meeting held on September 23, 1995, in Salt Lake City, Utah.
3. - See Mosiah 18:8–10.
4. - See, for example, Thomas S. Monson, “To the Rescue,” Ensign, May 2001, 48–50; Liahona, July 2001, 57–60; “Our Responsibility to Rescue,” Ensign or Liahona, Oct. 2013, 4–5. President Monson reiterated these concepts in his message to General Authorities on September 30, 2015, reminding those assembled that he was reemphasizing the message he gave to General Authorities and Area Seventies in training meetings at the April 2009 general conference.
5. - Moroni 7:47.
6. - Moroni 7:48.
7. - See Doctrine and Covenants 18:27–28:
“And the Twelve shall be my disciples, and they shall take upon them my name; and the Twelve are they who shall desire to take upon them my name with full purpose of heart.
“And if they desire to take upon them my name with full purpose of heart, they are called to go into all the world to preach my gospel unto every creature.”
8. - “The Living Christ: The Testimony of the Apostles,” Ensign or Liahona, Apr. 2000, 3. In citing this here, I figuratively add my signature to the document, witnessing to the selfsame testimony provided by those Apostles.