President Thomas S. Monson
President of the Church
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/the-priesthood-a-sacred-gift?lang=eng)

_Each of us has been entrusted with one of the most precious gifts ever bestowed upon mankind._

One of my most vivid memories is attending priesthood meeting as a newly ordained deacon and singing during the opening hymn, “Come, all ye sons of God who have received the priesthood.”1 Tonight, to all assembled here in the Conference Center and, indeed, throughout the world, I echo the spirit of that special hymn and say to you: Come, all ye sons of God who have received the priesthood, let us consider our callings; let us reflect on our responsibilities; let us determine our duty; and let us follow Jesus Christ, our Lord. While we may differ in age, in custom, or in nationality, we are united as one in our priesthood callings.

To each of us, the restoration of the Aaronic Priesthood to Oliver Cowdery and Joseph Smith by John the Baptist is most significant. Likewise, the restoration of the Melchizedek Priesthood to Joseph and Oliver by Peter, James, and John is a cherished event.

Let us take most seriously the callings, the responsibilities, and the duties which come with the priesthood we hold.

I felt a great responsibility when I was called to be secretary of my deacons quorum. I prepared most conscientiously the records I kept, for I wanted to do the very best I knew how to do in that calling. I took great pride in my work. Doing all I can, to the very best of my ability, has been my goal in any position I have ever held.

I hope each young man who has been ordained to the Aaronic Priesthood is given a spiritual awareness of the sacredness of his ordained calling, as well as opportunities to magnify that calling. I received such an opportunity as a deacon when the bishopric asked that I take the sacrament to a shut-in who lived about a mile from our chapel. That special Sunday morning, as I knocked on Brother Wright’s door and heard his feeble voice call, “Come in,” I entered not only his humble cottage but also a room filled with the Spirit of the Lord. I approached Brother Wright’s bedside and carefully placed a piece of the bread to his lips. I then held the cup of water, that he might drink. As I departed, I saw tears in his eyes as he said, “God bless you, my boy.” And God did bless me—with an appreciation for the sacred emblems of the sacrament and for the priesthood which I held.

No deacon, teacher, or priest from our ward will ever forget the memorable visits we made to Clarkston, Utah, to the gravesite of Martin Harris, one of the Three Witnesses of the Book of Mormon. As we surrounded the tall granite shaft which marks his grave, and as one of the quorum leaders read to us those penetrating words from “The Testimony of Three Witnesses,” found at the beginning of the Book of Mormon, we developed a love for that sacred record and for the truths found therein.

During those years our objective was to become as the sons of Mosiah. Of them it was said:

“They had waxed strong in the knowledge of the truth; for they were men of a sound understanding and they had searched the scriptures diligently, that they might know the word of God.

“But this is not all; they had given themselves to much prayer, and fasting; therefore they had the spirit of prophecy, and the spirit of revelation, and when they taught, they taught with power and authority of God.”2

I cannot think of a more worthy goal for a young man to have than to be described as were the valiant and righteous sons of Mosiah.

As I approached my 18th birthday and prepared to enter the mandatory military service required of young men during World War II, I was recommended to receive the Melchizedek Priesthood, but first I needed to telephone my stake president, Paul C. Child, for an interview. He was one who loved and understood the holy scriptures, and it was his intent that all others should similarly love and understand them. Having heard from some of my friends of his rather detailed and searching interviews, I desired minimum exposure of my scriptural knowledge; therefore, when I called him I suggested we meet the following Sunday at a time I knew was just an hour before his sacrament meeting time.

His response: “Oh, Brother Monson, that would not provide us sufficient time to peruse the scriptures.” He then suggested a time three hours before his sacrament meeting, and he instructed me to bring with me my personally marked and referenced set of scriptures.

When I arrived at his home on Sunday, I was greeted warmly, and then the interview began. President Child said, “Brother Monson, you hold the Aaronic Priesthood. Have you ever had angels minister to you?” I replied that I had not. When he asked if I knew I was entitled to such, I again replied that I had not known.

He instructed, “Brother Monson, repeat from memory the 13th section of the Doctrine and Covenants.”

I began, “‘Upon you my fellow servants, in the name of Messiah I confer the Priesthood of Aaron, which holds the keys of the ministering of angels—’”

“Stop,” President Child directed. Then, in a calm, kindly tone, he counseled, “Brother Monson, never forget that as a holder of the Aaronic Priesthood you are entitled to the ministering of angels.”

It was almost as though an angel were in the room that day. I have never forgotten the interview. I yet feel the spirit of that solemn occasion as we together read of the responsibilities, the duties, and the blessings of the Aaronic Priesthood and the Melchizedek Priesthood—blessings which come not only to us but also to our families and to others we will have the privilege to serve.

I was ordained an elder, and on the day of my departure for active duty with the navy, a member of my ward bishopric joined my family and friends at the train station to bid me farewell. Just before train time, he placed in my hand a small volume titled Missionary Handbook. I laughed and commented that I wasn’t going on a mission.

He answered, “Take it anyway. It may come in handy.”

It did. I needed a hard, rectangular object to place in the bottom of my seabag so that my clothing would stay more firm and would thus be less wrinkled. The Missionary Handbook was just what I needed, and it served well in my seabag for 12 weeks.

The night before our Christmas leave, our thoughts were of home. The barracks were quiet, but then the silence was broken by my buddy in the adjoining bunk—a Mormon boy, Leland Merrill—who began to moan in pain. I inquired concerning the reason, and he said he felt really sick. He did not want to go to the base dispensary, for he knew that doing such would prevent his going home the following day.

He seemed to grow worse as the hours passed. Finally, knowing that I was an elder, he asked me to give him a priesthood blessing.

I had never before given a priesthood blessing, I had never received a blessing, and I had never witnessed a blessing being given. As I prayed silently for help, I remembered the Missionary Handbook in the bottom of my seabag. I quickly emptied the bag and took the book to the night-light. There I read how one blesses the sick. With many curious sailors looking on, I proceeded with the blessing. Before I could put everything back into my bag, Leland Merrill was sleeping like a child. He awakened the following morning feeling fine. The gratitude each of us felt for the power of the priesthood was immense.

The years have brought me more opportunities to provide blessings to those in need than I could possibly count. Each opportunity has found me deeply grateful that God has entrusted to me this sacred gift. I revere the priesthood. I have witnessed its power time and time again. I have seen its strength. I have marveled at the miracles it has wrought.

Brethren, each of us has been entrusted with one of the most precious gifts ever bestowed upon mankind. As we honor our priesthood and live our lives so that we are at all times worthy, the blessings of the priesthood will flow through us. I love the words found in the Doctrine and Covenants, section 121, verse 45, which tell us what we must do to be worthy: “Let thy bowels … be full of charity towards all men, and to the household of faith, and let virtue garnish thy thoughts unceasingly; then shall thy confidence wax strong in the presence of God; and the doctrine of the priesthood shall distil upon thy soul as the dews from heaven.”

As bearers of the priesthood of God, we are engaged in the work of the Lord Jesus Christ. We have answered His call; we are on His errand. Let us learn of Him. Let us follow in His footsteps. Let us live by His precepts. By so doing, we will be prepared for any service He calls us to perform. This is His work. This is His Church. Indeed, He is our captain, the King of Glory, even the Son of God. I testify that He lives and bear this witness in His holy name, the name of Jesus Christ, amen.

# References
1. - “Come, All Ye Sons of God,” Hymns, no. 322.
2. - Alma 17:2–3.