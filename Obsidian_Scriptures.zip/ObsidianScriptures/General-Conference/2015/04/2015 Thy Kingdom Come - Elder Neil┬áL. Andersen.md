Elder Neil L. Andersen
Of the Quorum of the Twelve Apostles
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/thy-kingdom-come?lang=eng)

_The thought of His coming stirs my soul. It will be breathtaking! The scope and grandeur, the vastness and magnificence, will exceed anything mortal eyes have ever seen or experienced._

As we were singing, I was deeply moved with the thought that at this very moment hundreds of thousands, perhaps millions, of believing Saints in more than 150 countries, amazingly in 75 different languages,1 together we were raising our voices to God, singing:





Come, O thou King of Kings!

We’ve waited long for thee,

With healing in thy wings,

To set thy people free.2





“Come, O thou King of Kings!”3 We are a very large worldwide family of believers, disciples of the Lord Jesus Christ.

We have taken His name upon us, and each week as we partake of the sacrament, we pledge that we will remember Him and keep His commandments. We are far from perfect, but we are not casual in our faith. We believe in Him. We worship Him. We follow Him. We deeply love Him. His cause is the greatest cause in all the world.

We live, brothers and sisters, in the days preceding the Lord’s Second Coming, a time long anticipated by believers through the ages. We live in days of wars and rumors of wars, days of natural disasters, days when the world is pulled by confusion and commotion.

But we also live in the glorious time of the Restoration, when the gospel is being taken to all the world—a time when the Lord has promised that He “will raise up … a pure people”4 and arm them “with righteousness and with the power of God.”5

We rejoice in these days and pray that we will be able to courageously face our struggles and uncertainties. The difficulties of some are more severe than those of others, but no one is immune. Elder Neal A. Maxwell once said to me, “If everything is going perfectly for you right now, just wait.”



Although the Lord reassures us again and again that we “need not fear,”6 keeping a clear perspective and seeing beyond this world is not always easy when we are in the midst of trials.

President Thomas S. Monson taught me an important lesson about keeping an eternal point of view.

Eighteen years ago while traveling on a train in Switzerland with President Monson, I asked him about his heavy responsibilities. His response strengthened my faith. “In the First Presidency,” he said, “we do everything we can to move this work forward. But this is the Lord’s work, and He directs it. He is at the helm. We marvel as we watch Him open doors we cannot open and perform miracles we can scarcely imagine.”7

Brothers and sisters, seeing and believing the Lord’s miracles in establishing His kingdom on earth can help us see and believe that the Lord’s hand is at work in our own lives as well.

The Lord declared, “I am able to do mine own work.”8 We each try to do our part, but He is the grand architect. Under the direction of His Father, He created this world. “All things were made by him; and without him was not any thing made that was made.”9 As we are spiritually awake and alert, we see His hand across the world and we see His hand in our own personal lives.

Let me share an example.

In 1831, with only 600 members of the Church, the Lord declared, “The keys of the kingdom of God are committed unto man on the earth, and from thence shall the gospel roll forth unto the ends of the earth, as the stone which is cut out of the mountain without hands shall roll forth, until it has filled the whole earth.”10

The prophet Nephi foresaw that in our day there would be “few” members of the Church when compared to the population of the earth but that they would be “upon all the face of the earth.”11

Three beautiful examples of the Lord’s hand in establishing His kingdom are the temples announced today by President Monson. Only a few decades ago, who could have imagined temples in Haiti, Thailand, and the Ivory Coast?

The location of a temple is not a convenient geographical decision. It comes by revelation from the Lord to His prophet, signifying a great work to be done and acknowledging the righteousness of the Saints who will treasure and care for His house through generations.12

  ImageThomas S. Monson with Black Family

  ImageApril 2015 General Conference

My wife, Kathy, and I visited Haiti just two years ago. High on the mountain overlooking Port-au-Prince, we joined with Haitian Saints in commemorating the dedication of the country by then-Elder Thomas S. Monson only 30 years earlier. None of us will ever forget the devastating Haitian earthquake of 2010. With faithful members and a courageous band of missionaries made up almost exclusively of Haitians, the Church in this island nation has continued to grow and strengthen. It lifts my faith to visualize these righteous Saints of God, clothed in white, having the power of the holy priesthood to direct and perform the sacred ordinances in the Lord’s house.

  ImageApril 2015 General Conference

  ImageApril 2015 General Conference

Who could imagine a house of the Lord in the beautiful city of Bangkok? Christians are only 1 percent of this principally Buddhist country. As in Haiti we also find in Bangkok that the Lord has gathered the elect of the earth. While there a few months ago, we met Sathit and Juthamas Kaivaivatana and their devoted children. Sathit joined the Church when he was 17 and served a mission in his native land. Later he met Juthamas at the institute, and they were sealed in the Manila Philippines Temple. In 1993 the Kaivaivatanas were hit by a truck whose driver had fallen asleep, and Sathit was paralyzed from his chest down. Their faith has never wavered. Sathit is an admired teacher at the International School Bangkok. He serves as the stake president of the Thailand Bangkok North Stake. We see God’s miracles in His wondrous work and in our own personal lives.

  ImageApril 2015 General Conference

The miracle of the Church in the Ivory Coast cannot be told without the names of two couples: Philippe and Annelies Assard and Lucien and Agathe Affoue. They joined the Church as young married couples, one in Germany and one in France. In the 1980s, Philippe and Lucien felt drawn back to their native African country for the purpose of building the kingdom of God. For Sister Assard, who is German, to leave her family and allow Brother Assard to leave his work as an accomplished mechanical engineer required unusual faith. The two couples met each other for the first time in the Ivory Coast and started a Sunday School. That was 30 years ago. There are now eight stakes and 27,000 members in this beautiful African country. The Affoues continue to serve nobly as do the Assards, who recently completed a mission to the Accra Ghana Temple.

Can you see the hand of God moving His work forward? Can you see the hand of God in the lives of the missionaries in Haiti or the Kaivaivatanas in Thailand? Can you see the hand of God in the lives of the Assards and the Affoues? Can you see the hand of God in your own life?

“And in nothing doth man offend God … save those who confess not his hand in all things.”13

God’s miracles are not happening just in Haiti, Thailand, or the Ivory Coast. Look around you.14 “God is mindful of every people … ; yea, he numbereth his people, and his … mercy [is] over all the earth.”15

Sometimes we can see the hand of the Lord in the lives of others but wonder, “How can I more clearly see His hand in my own life?”

The Savior said:

“Doubt not.”16

“Be not afraid.”17

“Not … one [sparrow] shall … fall [to] the ground without your Father [knowing]. …

“Fear … not therefore, [for] ye are of more value than many sparrows.”18

Remember the young man who cried out to the prophet Elisha as they were surrounded by enemies: “Alas, [what] shall we do?”19

Elisha answered:

“Fear not: for they that be with us are more than they that be with them.

“[Then] Elisha prayed, … Lord, … open his eyes, that he may see. And the Lord [did open] the eyes of the young man; and he [did see that] the mountain was full of horses and chariots of fire.”20

As you keep the commandments and pray in faith to see the Lord’s hand in your life, I promise you that He will open your spiritual eyes even wider, and you will see more clearly that you are not alone.

The scriptures teach that we are to “[stand] steadfastly in the faith of that which is to come.”21 What is to come? The Savior prayed:

“Our Father which art in heaven, Hallowed be thy name.

“Thy kingdom come. Thy will be done in earth, as it is in heaven.”22

We all just sang “Come, O Thou King of Kings.”

Our faith grows as we anticipate the glorious day of the Savior’s return to the earth. The thought of His coming stirs my soul. It will be breathtaking! The scope and grandeur, the vastness and magnificence, will exceed anything mortal eyes have ever seen or experienced.

In that day He will not come “wrapped in swaddling clothes, lying in a manger,”23 but He will appear “in the clouds of heaven, clothed with power and great glory; with all the holy angels.”24 We will hear “the voice of the archangel, and … the trump of God.”25 The sun and the moon will be transformed, and “stars [will] be hurled from their places.”26 You and I, or those who follow us, “the saints … from [every quarter] of the earth,”27 “shall be quickened and … caught up to meet him,”28 and those who have died in righteousness, they too will “be caught up to meet him in the midst … of heaven.”29

Then, a seemingly impossible experience: “All flesh,” the Lord says, “shall see me together.”30 How will it happen? We do not know. But I testify it will happen—exactly as prophesied. We will kneel in reverence, “and the Lord shall utter his voice, and all the ends of the earth shall hear it.”31 “It shall be … as the voice of many waters, and as the voice of a great thunder.”32 “[Then] the Lord, … the Savior, shall stand in the midst of his people.”33

There will be unforgettable reunions with the angels of heaven and the Saints upon the earth.34 But most important, as Isaiah declares, “All the ends of the earth shall see the salvation of our God,”35 and He “shall reign over all flesh.”36

In that day the skeptics will be silent, “for every ear shall hear … , and every knee shall bow, and every tongue shall confess”37 that Jesus is the Christ, the Son of God, the Savior and Redeemer of the world.

Today is Easter. We rejoice with Christians all over the world in His glorious Resurrection and in our own promised resurrection. May we prepare for His coming by rehearsing these glorious events over and over in our own minds and with those we love, and may His prayer be our prayer: “Thy kingdom come. Thy will be done in earth, as it is in heaven.”38 I testify that He lives. “Come, O thou King of Kings.” In the name of Jesus Christ, amen.

# References
1. - While general conference overall is translated into 94 languages, not all languages are transmitted simultaneously, nor for all sessions. For the Sunday afternoon session of this general conference, 75 languages were transmitted live.
2. - “Come, O Thou King of Kings,” Hymns, no. 59.
3. - On Tuesday, March 31, 2015, the First Presidency’s office sent me an email explaining that I would speak on Sunday afternoon, April 5, immediately following the congregational hymn “Come, O Thou King of Kings.” The text of this great Restoration hymn, written by Parley P. Pratt, is a humble plea to the Savior to return to the earth. It embodied the message of my conference talk perhaps more powerfully than any other hymn we sing. I was deeply moved by the significance of believing Saints everywhere joining together on Easter Sunday, raising our voices to God and in unison singing, “Come, O thou King of Kings! We’ve waited long for thee.” Realizing that I personally had no input on the music selection for general conference, I wondered if those responsible for the music had read my conference talk entitled “Thy Kingdom Come” and then chosen this hymn about the Second Coming of the Savior. I later learned that the Tabernacle Choir directors had recommended the hymn to the First Presidency in early March, weeks prior to my talk being sent to the First Presidency for translation. The last time that “Come, O Thou King of Kings” was sung as a congregational hymn in general conference was October 2002. We each try to do our part, but He is the grand architect.
4. - Doctrine and Covenants 100:16.
5. - 1 Nephi 14:14.
6. - Doctrine and Covenants 10:55.
7. - Personal experience, May 1997.
8. - 2 Nephi 27:20.
9. - John 1:3.
10. - Doctrine and Covenants 65:2.
11. - 1 Nephi 14:12.
12. - In the fall of 2001, while living in Brazil, I enthusiastically shared with President James E. Faust of the First Presidency many impressive facts about the Saints living in the city of Curitiba, hoping he would pass the information on to President Gordon B. Hinckley. President Faust stopped me midsentence. “Neil,” he said, “we don’t lobby the President. The decision of where to build a temple is between the Lord and His prophet.” The Curitiba Brazil Temple was dedicated in 2008.
13. - Doctrine and Covenants 59:21.
14. - One of the great miracles of the Lord’s hand is the movement of His kingdom across the United States into cities and towns in every state. Here is one example. In May 2006 I was assigned to a stake conference in Denton, Texas. I stayed in the home of the stake president, President Vaughn A Andrus. Sister Andrus told me of the early Church in Denton, beginning with her parents, John and Margaret Porter. There was only a Sunday School in the beginning. But the Porters shared the gospel with the Ragsdales, who in turn shared it with the Nobles and the Martinos. The missionaries, of course, added their important contribution. Many families joined the Church. Others from the west moved to Denton. Today, where there was a small branch, there are now four stakes, and one of the Martinos’ sons, Elder James B. Martino, who joined the Church when he was 17, serves as a General Authority of the Church.
15. - Alma 26:37.
16. - Matthew 21:21.
17. - Mark 5:36.
18. - Matthew 10:29, 31.
19. - 2 Kings 6:15.
20. - 2 Kings 6:16–17.
21. - Mosiah 4:11.
22. - Matthew 6:9–10; see also Doctrine and Covenants 65:6.
23. - Luke 2:12.
24. - Doctrine and Covenants 45:44.
25. - 1 Thessalonians 4:16.
26. - Doctrine and Covenants 133:49.
27. - Doctrine and Covenants 45:46.
28. - Doctrine and Covenants 88:96.
29. - Doctrine and Covenants 88:97.
30. - Doctrine and Covenants 101:23.
31. - Doctrine and Covenants 45:49.
32. - Doctrine and Covenants 133:22.
33. - Doctrine and Covenants 133:25.
34. - See Moses 7:63.
35. - Isaiah 52:10.
36. - Doctrine and Covenants 133:25.
37. - Doctrine and Covenants 88:104.
38. - Matthew 6:10.