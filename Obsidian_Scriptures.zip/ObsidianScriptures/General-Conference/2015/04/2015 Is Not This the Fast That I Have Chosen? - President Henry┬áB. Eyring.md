President Henry B. Eyring
First Counselor in the First Presidency
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/is-not-this-the-fast-that-i-have-chosen?lang=eng)

_Your fast offering will do more than help feed and clothe bodies. It will heal and change hearts._

My dear brothers and sisters, it is a joy for me to extend my love to you in this general conference of The Church of Jesus Christ of Latter-day Saints. That joy comes from the witness of the Spirit that the love of the Savior reaches out to each of you and to all of Heavenly Father’s children. Our Heavenly Father wishes to bless His children spiritually and temporally. He understands each of their needs, their pains, and their hopes.

When we offer succor to anyone, the Savior feels it as if we reached out to succor Him.

He told us that was true when He described a future moment we all will have when we see Him after our life in this world is complete. A picture in my mind of that day has grown more vivid in the days that I have prayed and fasted to know what to say this morning. The Lord’s description of that future interview was given to His disciples, and it describes what we want with all our hearts to be true for us as well:

“Then shall the King say unto them on his right hand, Come, ye blessed of my Father, inherit the kingdom prepared for you from the foundation of the world:

“For I was an hungred, and ye gave me meat: I was thirsty, and ye gave me drink: I was a stranger, and ye took me in:

“Naked, and ye clothed me: I was sick, and ye visited me: I was in prison, and ye came unto me.

“Then shall the righteous answer him, saying, Lord, when saw we thee an hungred, and fed thee? or thirsty, and gave thee drink?

“When saw we thee a stranger, and took thee in? or naked, and clothed thee?

“Or when saw we thee sick, or in prison, and came unto thee?

“And the King shall answer and say unto them, Verily I say unto you, Inasmuch as ye have done it unto one of the least of these my brethren, ye have done it unto me.”1

You and I want that warm welcome from the Savior. But how can we deserve it? There are more hungry, homeless, and lonely children of Heavenly Father than we can possibly reach. And the numbers grow ever farther from our reach.

So the Lord has given us something that we each can do. It is a commandment so simple that a child can understand it. It is a commandment with a wonderful promise for those in need and for us.

It is the law of the fast. The words in the book of Isaiah are the Lord’s description of the commandment and the blessing available to those of us in His Church:



“Is not this the fast that I have chosen? to loose the bands of wickedness, to undo the heavy burdens, and to let the oppressed go free, and that ye break every yoke?

“Is it not to deal thy bread to the hungry, and that thou bring the poor that are cast out to thy house? when thou seest the naked, that thou cover him; and that thou hide not thyself from thine own flesh?

“Then shall thy light break forth as the morning, and thine health shall spring forth speedily: and thy righteousness shall go before thee; the glory of the Lord shall be thy rearward.

“Then shalt thou call, and the Lord shall answer; thou shalt cry, and he shall say, Here I am. If thou take away from the midst of thee the yoke, the putting forth of the finger, and speaking vanity;

“And if thou draw out thy soul to the hungry, and satisfy the afflicted soul; then shall thy light rise in obscurity, and thy darkness be as the noonday:

“And the Lord shall guide thee continually, and satisfy thy soul in drought, and make fat thy bones: and thou shalt be like a watered garden, and like a spring of water, whose waters fail not.”2

So the Lord has given us a simple commandment with a marvelous promise. In the Church today we are offered the opportunity to fast once a month and give a generous fast offering through our bishop or branch president for the benefit of the poor and the needy. Some of what you give will be used to help those around you, perhaps someone in your own family. The Lord’s servants will pray and fast for the revelation to know whom to help and what help to give. That which is not needed to help people in your local Church unit will become available to bless other Church members across the world who are in need.

The commandment to fast for the poor has many blessings attached to it. President Spencer W. Kimball called failing to follow that law a sin of omission with a heavy cost. He wrote: “Rich promises are made by the Lord to those who fast and assist the needy. … Inspiration and spiritual guidance will come with righteousness and closeness to our Heavenly Father. To omit to do this righteous act of fasting would deprive us of these blessings.”3

I received one of those blessings just a few weeks ago. Since general conference falls on a weekend that would normally include the fast and testimony meeting, I fasted and prayed to know how I should still obey the commandment to care for those in need.

On a Saturday, still fasting, I woke at 6:00 and prayed again. I felt impressed to look at the world news. There I read this report:

Tropical Cyclone Pam destroyed many homes as it made a direct hit on Port Vila, the capital of Vanuatu. It killed at least six people in Vanuatu, the first confirmed from one of the most powerful storms ever to make landfall.

“Hardly a tree stood straight [as the cyclone] bellowed across” the Pacific island nation.4

World Vision’s emergency assessment team planned to view damage after the storm died down.

They advised residents to seek shelter in sturdy buildings such as universities and schools.

And then they said: “‘The strongest thing they’ve got is cement churches,’ said Inga Mepham [from] CARE International. … ‘Some of them don’t have that. It’s hard to find a structure that you’d think would be able to withstand a Category 5 (storm).’”5

When I read that, I remembered visiting little homes on Vanuatu. I could picture in my mind the people huddled in homes being destroyed by winds. And then I remembered the warm welcome to me of the people of Vanuatu. I thought of them and their neighbors fleeing to the safety of our cement chapel.

Then I pictured the bishop and the Relief Society president walking among them, giving comfort, blankets, food to eat, and water to drink. I could picture the frightened children huddled together.

They are so far away from the home where I read that report, and yet I knew what the Lord would be doing through His servants. I knew that what made it possible for them to succor those children of Heavenly Father was fast offerings, given freely by the Lord’s disciples who were far away from them but close to the Lord.

So I didn’t wait for Sunday. I took a fast offering to my bishop that morning. I know that my offering may be used by the bishop and Relief Society president to help someone in my neighborhood. My small offering may not be needed near where my family and I live, but the local surplus could reach even as far as Vanuatu.

Other storms and tragedies will come across the world to people the Lord loves and whose sorrows He feels. Part of your fast offering and mine this month will be used to help someone, somewhere, whose relief the Lord will feel as if it were His own.

Your fast offering will do more than help feed and clothe bodies. It will heal and change hearts. The fruit of a free-will offering may be the desire in the heart of the recipient to reach out to others in need. That happens across the world.

It happened in the life of Sister Abie Turay, who lives in Sierra Leone. A civil war began in 1991. It ravaged the country for years. Sierra Leone was already one of the poorest countries in the world. “During the war, it was unclear who [controlled] the country—banks … closed, government offices were shuttered, police forces [were ineffective against rebel forces], … and there was chaos, killing and sorrow. Tens of thousands of people lost their lives and more than two million people were forced from their homes to avoid the slaughter.”6

Even in such times, The Church of Jesus Christ of Latter-day Saints grew.

One of the first branches was organized in the city where Sister Turay lived. Her husband was the first branch president. He served as a district president during the civil war.

“When guests visit Sister Turay’s home [now], she loves to show them two [treasures] from the war: a blue-and-white striped shirt [she got] from a bale of used clothing [given by members of the Church] and a blanket, now worn and riddled with holes.”7

She says, “This shirt is the first … clothing I [received]. … I used to wear it to go to work—it was so good. [It made me feel so beautiful.] I didn’t have other clothes.

“During the war, this blanket kept us warm, me and my children. When the rebels [would] come to attack us, this is the only thing I [could] lay [my] hands on [as we fled to the bush to hide]. So we [would] take the blanket with us. It would keep us warm and keep the mosquitos away from us.”8

“Sister Turay speaks of her gratitude for a mission president who would make his way into the war-torn country with [money] in his pocket.” Those funds, from the fast-offering donations of people like you, allowed the Saints to buy food that most Sierra Leoneans could not afford.9

Sister Turay, speaking of those who were generous enough to donate for them to survive, says, “When I think [of] the people who did this … I feel that [they were] sent by God, because ordinary human beings made this kind gesture for [us].”10

A visitor from the United States sat with Abie not long ago. During his time with her, he found his eyes “drawn to a set of scriptures that were on the table.” He could tell that they were a treasure, “well-marked with notes in the columns. The pages were [worn;] some were torn. The cover was detached from the binding.”

He held the scriptures in his “hand and gently turned the pages. As [he did, he found a] yellow copy of a tithing donation slip. [He] could see that, in a country where [a dollar was worth its] weight in gold, Abie Turay had paid one dollar as her tithing, one dollar to the missionary fund, and one dollar as a fast offering for those who, in her words, were ‘truly poor.’”

The visitor closed Sister Turay’s scriptures and thought, as he stood with this faithful African mother, that he was on sacred ground.11

Just as the receipt of the blessing of your fast offering and mine can change hearts, so does fasting for the good of another. Even a child can feel it.

Many children, and some adults, may for personal reasons find a 24-hour fast difficult. It can be, in the words of Isaiah, felt that the fast has “afflicted [their] soul.” Wise parents recognize that possibility and so are careful to follow the counsel of President Joseph F. Smith: “Better to teach them the principle, and let them observe it when they are old enough to choose intelligently.”12

I saw the blessing in that counsel recently. One of my grandsons had found a 24-hour fast beyond his powers of endurance. But his wise parents still placed the principle in his heart. One of his school friends recently lost a young cousin to accidental death. My grandson asked his mother on fast day, at about the time he had always felt the fast was too hard to continue, whether it would make his grieving friend feel better if he continued his fast.

His question was the confirmation of President Joseph F. Smith’s counsel. My grandson had come to the point where he not only understood the principle of the fast, but it had also been planted in his heart. He had come to feel that his fasting and prayers would lead to a blessing from God for someone in need. If he lives the principle often enough, it will bring the wonderful effects in his own life, as promised by the Lord. He will have the spiritual blessing of power to receive inspiration and greater capacity to resist temptation.

We do not know all the reasons why Jesus Christ went into the wilderness to fast and to pray. But we know at least one of the effects: the Savior completely resisted Satan’s temptations to misuse His divine power.

The brief time we fast every month and the small amount we offer for the poor may give us only a small part of the change in our natures to have no more desire to do evil. But there is a great promise, even as we do all that we reasonably can to pray, to fast, and to donate for those in need:

“Then shall thy light break forth as the morning, and thine health shall spring forth speedily: and thy righteousness shall go before thee; the glory of the Lord shall be thy rearward.

“Then shalt thou call, and the Lord shall answer; thou shalt cry, and he shall say, Here I am.”13

I pray that we will claim those great blessings for ourselves and for our families.

I bear my witness that Jesus is the Christ, that in His Church we are invited to help Him as He cares for the poor in His way, and that He promises everlasting blessings will come from our helping Him. In the sacred name of Jesus Christ, amen.

# References
1. - Matthew 25:34–40.
2. - Isaiah 58:6–11.
3. - Spencer W. Kimball, The Miracle of Forgiveness (1969), 98.
4. - See Steve Almasy, Ben Brumfield, and Laura Smith-Spark, “Cleanup Begins in Vanuatu after Cyclone Batters Islands,” Mar. 14, 2015, edition.cnn.com.
5. - See Sean Morris, Steve Almasy, and Laura Smith-Spark, “‘Unbelievable Destruction’ Reported in Tropical Cyclone Pam’s Wake,” Mar. 14, 2015, edition.cnn.com.
6. - Peter F. Evans, “Sister Abie Turay’s Story,” unpublished manuscript.
7. - Peter F. Evans, “Sister Abie Turay’s Story.”
8. - Abie Turay, quoted in Peter F. Evans, “Sister Abie Turay’s Story.”
9. - Peter F. Evans, “Sister Abie Turay’s Story.”
10. - Abie Turay, quoted in Peter F. Evans, “Sister Abie Turay’s Story.”
11. - Peter F. Evans, “Sister Abie Turay’s Story”; a video about Sister Turay, “We Did Not Stand Alone,” is available at lds.org/media-library.
12. - Joseph F. Smith, “Editor’s Table,” Improvement Era, Dec. 1903, 149.
13. - Isaiah 58:8–9.