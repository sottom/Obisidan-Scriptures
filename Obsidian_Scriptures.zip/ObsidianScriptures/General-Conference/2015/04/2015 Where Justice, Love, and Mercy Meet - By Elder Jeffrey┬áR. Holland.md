By Elder Jeffrey R. Holland
Of the Quorum of the Twelve Apostles
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/where-justice-love-and-mercy-meet?lang=eng)

_Jesus Christ suffered, died, and rose from death in order that He could lift us to eternal life._

Without safety ropes, harnesses, or climbing gear of any kind, two brothers—Jimmy, age 14, and John, age 19 (though those aren’t their real names)—attempted to scale a sheer canyon wall in Snow Canyon State Park in my native southern Utah. Near the top of their laborious climb, they discovered that a protruding ledge denied them their final few feet of ascent. They could not get over it, but neither could they now retreat from it. They were stranded. After careful maneuvering, John found enough footing to boost his younger brother to safety on top of the ledge. But there was no way to lift himself. The more he strained to find finger or foot leverage, the more his muscles began to cramp. Panic started to sweep over him, and he began to fear for his life.

Unable to hold on much longer, John decided his only option was to try to jump vertically in an effort to grab the top of the overhanging ledge. If successful, he might, by his considerable arm strength, pull himself to safety.

In his own words, he said:

“Prior to my jump I told Jimmy to go search for a tree branch strong enough to extend down to me, although I knew there was nothing of the kind on this rocky summit. It was only a desperate ruse. If my jump failed, the least I could do was make certain my little brother did not see me falling to my death.

“Giving him enough time to be out of sight, I said my last prayer—that I wanted my family to know I loved them and that Jimmy could make it home safely on his own—then I leapt. There was enough adrenaline in my spring that the jump extended my arms above the ledge almost to my elbows. But as I slapped my hands down on the surface, I felt nothing but loose sand on flat stone. I can still remember the gritty sensation of hanging there with nothing to hold on to—no lip, no ridge, nothing to grab or grasp. I felt my fingers begin to recede slowly over the sandy surface. I knew my life was over.

“But then suddenly, like a lightning strike in a summer storm, two hands shot out from somewhere above the edge of the cliff, grabbing my wrists with a strength and determination that belied their size. My faithful little brother had not gone looking for any fictitious tree branch. Guessing exactly what I was planning to do, he had never moved an inch. He had simply waited—silently, almost breathlessly—knowing full well I would be foolish enough to try to make that jump. When I did, he grabbed me, held me, and refused to let me fall. Those strong brotherly arms saved my life that day as I dangled helplessly above what would surely have been certain death.”1

My beloved brothers and sisters, today is Easter Sunday. Although we should always remember (we promise in our weekly sacramental prayers that we will), nevertheless this is the most sacred day of the year for special remembrance of brotherly hands and determined arms that reached into the abyss of death to save us from our fallings and our failings, from our sorrows and our sins. Against the background of this story reported by John and Jimmy’s family, I express my gratitude for the Atonement and Resurrection of the Lord Jesus Christ and acknowledge events in the divine plan of God that led up to and give meaning to “the love Jesus offers [us].”2

In our increasingly secular society, it is as uncommon as it is unfashionable to speak of Adam and Eve or the Garden of Eden or of a “fortunate fall” into mortality. Nevertheless, the simple truth is that we cannot fully comprehend the Atonement and Resurrection of Christ and we will not adequately appreciate the unique purpose of His birth or His death—in other words, there is no way to truly celebrate Christmas or Easter—without understanding that there was an actual Adam and Eve who fell from an actual Eden, with all the consequences that fall carried with it.

I do not know the details of what happened on this planet before that, but I do know these two were created under the divine hand of God, that for a time they lived alone in a paradisiacal setting where there was neither human death nor future family, and that through a sequence of choices they transgressed a commandment of God which required that they leave their garden setting but which allowed them to have children before facing physical death.3 To add further sorrow and complexity to their circumstance, their transgression had spiritual consequences as well, cutting them off from the presence of God forever. Because we were then born into that fallen world and because we too would transgress the laws of God, we also were sentenced to the same penalties that Adam and Eve faced.

What a plight! The entire human race in free fall—every man, woman, and child in it physically tumbling toward permanent death, spiritually plunging toward eternal anguish. Is that what life was meant to be? Is this the grand finale of the human experience? Are we all just hanging in a cold canyon somewhere in an indifferent universe, each of us searching for a toehold, each of us seeking for something to grip—with nothing but the feeling of sand sliding under our fingers, nothing to save us, nothing to hold on to, much less anything to hold on to us? Is our only purpose in life an empty existential exercise—simply to leap as high as we can, hang on for our prescribed three score years and ten, then fail and fall, and keep falling forever?

The answer to those questions is an unequivocal and eternal no! With prophets ancient and modern, I testify that “all things have been done in the wisdom of him who knoweth all things.”4 Thus, from the moment those first parents stepped out of the Garden of Eden, the God and Father of us all, anticipating Adam and Eve’s decision, dispatched the very angels of heaven to declare to them—and down through time to us—that this entire sequence was designed for our eternal happiness. It was part of His divine plan, which provided for a Savior, the very Son of God Himself—another “Adam,” the Apostle Paul would call Him5—who would come in the meridian of time to atone for the first Adam’s transgression. That Atonement would achieve complete victory over physical death, unconditionally granting resurrection to every person who has been born or ever will be born into this world. Mercifully it would also provide forgiveness for the personal sins of all, from Adam to the end of the world, conditioned upon repentance and obedience to divine commandments.

As one of His ordained witnesses, I declare this Easter morning that Jesus of Nazareth was and is that Savior of the world, the “last Adam,”6 the Author and Finisher of our faith, the Alpha and Omega of eternal life. “For as in Adam all die, even so in Christ shall all be made alive,”7 Paul declared. And from the prophet-patriarch Lehi: “Adam fell that men might be. … And the Messiah cometh in the fulness of time, that he may redeem the children of men from the fall.”8 Most thoroughly of all, the Book of Mormon prophet Jacob taught as part of a two-day sermon on the Atonement of Jesus Christ that “the resurrection must … come … by reason of the fall.”9

So today we celebrate the gift of victory over every fall we have ever experienced, every sorrow we have ever known, every discouragement we have ever had, every fear we have ever faced—to say nothing of our resurrection from death and forgiveness for our sins. That victory is available to us because of events that transpired on a weekend precisely like this nearly two millennia ago in Jerusalem.

Beginning in the spiritual anguish of the Garden of Gethsemane, moving to the Crucifixion on a cross at Calvary, and concluding on a beautiful Sunday morning inside a donated tomb, a sinless, pure, and holy man, the very Son of God Himself, did what no other deceased person had ever done nor ever could do. Under His own power, He rose from death, never to have His body separated from His spirit again. Of His own volition, He shed the burial linen with which He had been bound, carefully putting the burial napkin that had been placed over His face “in a place by itself,”10 the scripture says.

That first Easter sequence of Atonement and Resurrection constitutes the most consequential moment, the most generous gift, the most excruciating pain, and the most majestic manifestation of pure love ever to be demonstrated in the history of this world. Jesus Christ, the Only Begotten Son of God, suffered, died, and rose from death in order that He could, like lightning in a summer storm, grasp us as we fall, hold us with His might, and through our obedience to His commandments, lift us to eternal life.

This Easter I thank Him and the Father, who gave Him to us, that Jesus still stands triumphant over death, although He stands on wounded feet. This Easter I thank Him and the Father, who gave Him to us, that He still extends unending grace, although He extends it with pierced palms and scarred wrists. This Easter I thank Him and the Father, who gave Him to us, that we can sing before a sweat-stained garden, a nail-driven cross, and a gloriously empty tomb:





How great, how glorious, how complete

Redemption’s grand design,

Where justice, love, and mercy meet

In harmony divine!11





In the sacred name of the resurrected Lord Jesus Christ, amen.

# References
1. - Correspondence in the possession of Jeffrey R. Holland.
2. - “I Stand All Amazed,” Hymns, no. 193.
3. - See 2 Nephi 2:19–29, especially verses 20–23; Moses 5:10–11.
4. - 2 Nephi 2:24.
5. - See 1 Corinthians 15:45.
6. - 1 Corinthians 15:45.
7. - 1 Corinthians 15:22.
8. - 2 Nephi 2:25–26.
9. - 2 Nephi 9:6.
10. - John 20:7.
11. - “How Great the Wisdom and the Love,” Hymns, no. 195.