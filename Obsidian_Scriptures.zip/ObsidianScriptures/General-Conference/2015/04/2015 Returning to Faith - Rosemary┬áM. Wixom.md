Rosemary M. Wixom
Primary General President
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/returning-to-faith?lang=eng)

_Every one of us can strengthen our faith in Jesus Christ on our individual journey and find joy._

On this Easter morning, President Monson, we are so grateful to hear the voice of our living prophet. We value your words, including your counsel “Find joy in the journey”1 and “The future is as bright as your faith.”2

This year Primary children are sharing the joy and the brightness of their faith in Jesus Christ when they sing the song “I Know That My Savior Loves Me.” They sing the truth “I know He lives! … My heart I give to Him.”3 Like Primary children, every one of us can strengthen our faith in Jesus Christ on our individual journey and find joy.

In a recent Sunday Relief Society meeting, I listened to a young mother share part of her journey of conversion. She had grown up in the Church, with parents who taught her the gospel. She attended Primary, Young Women, and seminary. She loved to learn and discover truths. Her constant quest was to know why. Elder Russell M. Nelson has said, “The Lord can only teach an inquiring mind.”4 And this young woman was teachable.



After high school she attended a university, was sealed in the temple to a returned missionary, and was blessed with beautiful children.

With the spirit of inquiry, this mother continued to ask questions. But as the questions grew harder, so did the answers. And sometimes there were no answers—or no answers that brought peace. Eventually, as she sought to find answers, more and more questions arose, and she began to question some of the very foundations of her faith.

During this confusing time, some of those around her said, “Just lean on my faith.” But she thought, “I can’t. You don’t understand; you’re not grappling with these issues.” She explained, “I was willing to extend courtesy to those without doubts if they would extend courtesy to me.” And many did.

She said, “My parents knew my heart and allowed me space. They chose to love me while I was trying to figure it out for myself.” Likewise, this young mother’s bishop often met with her and spoke of his confidence in her.

Ward members also did not hesitate to give love, and she felt included. Her ward was not a place to put on a perfect face; it was a place of nurture.

“It was interesting,” she remembers. “During this time I felt a real connection to my grandparents who had died. They were pulling for me and urging me to keep trying. I felt they were saying, ‘Focus on what you know.’”

In spite of her substantial support system, she became less active. She said, “I did not separate myself from the Church because of bad behavior, spiritual apathy, looking for an excuse not to live the commandments, or searching for an easy out. I felt I needed the answer to the question ‘What do I really believe?’”

About this time she read a book of the writings of Mother Teresa, who had shared similar feelings. In a 1953 letter, Mother Teresa wrote: “Please pray specially for me that I may not spoil His work and that Our Lord may show Himself—for there is such terrible darkness within me, as if everything was dead. It has been like this more or less from the time I started ‘the work.’ Ask Our Lord to give me courage.”

Archbishop Périer responded: “God guides you, dear Mother; you are not so much in the dark as you think. The path to be followed may not always be clear at once. Pray for light; do not decide too quickly, listen to what others have to say, consider their reasons. You will always find something to help you. … Guided by faith, by prayer, and by reason with a right intention, you have enough.”5

My friend thought if Mother Teresa could live her religion without all the answers and without a feeling of clarity in all things, maybe she could too. She could take one simple step forward in faith—and then another. She could focus on the truths she did believe and let those truths fill her mind and heart.

As she reflected back, she said, “My testimony had become like a pile of ashes. It had all burned down. All that remained was Jesus Christ.” She continued, “But He does not leave you when you have questions. When anyone tries to keep the commandments, the door is wide open. Prayer and scripture study became incredibly important.”

Her first step to rebuild her faith was to start with basic gospel truths. She bought a Primary songbook and began reading the words of the songs. They were treasures to her. She prayed for faith to lift the heaviness she felt.

She learned that when she came up against a statement that caused her to doubt, she “could stop, look at the whole picture, and make the gospel personal.” She said, “I would ask, ‘Is this the right path for me and my family?’ Sometimes I would ask myself, ‘What do I want for my children?’ I realized I want them to have temple marriages. That’s when belief came back to my heart.”

Elder Jeffrey R. Holland has said, “Humility, faith, and the influence of the Holy Spirit [will] always be elements of every quest for truth.”6

Though she had questions about how the Book of Mormon came to be, she could not deny the truths she knew in the Book of Mormon. She had focused on studying the New Testament to better understand the Savior. “But eventually,” she said, “I found myself back in the Book of Mormon because I loved what I felt when reading about Jesus Christ and His Atonement.”



She concluded, “You have to have your own spiritual experiences with the truths in that book,” and she was having them. She explained, “I read in Mosiah and felt completely directed: ‘Believe in God; believe that he is, and that he created all things … ; believe that he has all wisdom, and all power, both in heaven and in earth; believe that man doth not comprehend all the things which the Lord can comprehend.’7”

About this time a call came to serve as Primary pianist. “It was safe,” she said. “I wanted to have my children in Primary, and now I could be with them. And I wasn’t ready to teach yet.” As she served, she continued to feel from those around her the invitation “Come; we want you, whatever stage you are at, and we will meet you there. Give us whatever you have to offer.”

Playing the Primary songs, she often thought to herself, “Here are truths I love. I can still bear testimony. I will just say those things that I know and trust. It may not be a perfect offering of knowledge, but it will be my offering. What I focus on expands inside of me. It is beautiful to get back to the essence of the gospel and feel clarity.”

On that Sunday morning, as I listened to this young sister share the story of her journey, I was reminded that “it is upon the rock of our Redeemer” that we all must build our foundation.8 I was also reminded of the counsel of Elder Jeffrey R. Holland: “Hold fast to what you already know and stand strong until additional knowledge comes.”9

During her lesson, I came to know more fervently that answers to our sincere questions come when we earnestly seek and when we live the commandments. I was reminded that our faith can reach beyond the limits of current reason.

And, oh, how I want to be like those who surrounded this young mother, loving and supporting her. As President Dieter F. Uchtdorf said: “We are all pilgrims seeking God’s light as we journey on the path of discipleship. We do not condemn others for the amount of light they may or may not have; rather, we nourish and encourage all light until it grows clear, bright, and true.”10

When the Primary children sing “A Child’s Prayer,” they ask: “Heavenly Father, are you really there? And do you hear and answer every child’s prayer?”11

We too may wonder, “Is Heavenly Father really there?” only to rejoice—as my friend did—when the answers come in quiet, simple assurances. I testify that those simple assurances come as His will becomes ours. I testify that truth is on the earth today and His gospel is found in The Church of Jesus Christ of Latter-day Saints. In the name of Jesus Christ, amen.

# References
1. - Thomas S. Monson, “Finding Joy in the Journey,” Ensign or Liahona, Nov. 2008, 85.
2. - Thomas S. Monson, “Be of Good Cheer,” Ensign or Liahona, May 2009, 92.
3. - “I Know That My Savior Loves Me,” in I Know My Savior Lives: 2015 Outline for Sharing Time (2014), 29.
4. - Russell M. Nelson, in M. Russell Ballard, “What Came from Kirtland” (Brigham Young University fireside, Nov. 6, 1994); speeches.byu.edu.
5. - In Mother Teresa: Come Be My Light; The Private Writings of the Saint of Calcutta, ed. Brian Kolodiejchuk (2007), 149–50; punctuation standardized.
6. - Jeffrey R. Holland, “Be Not Afraid, Only Believe” (evening with Elder Jeffrey R. Holland, Feb. 6, 2015); lds.org/broadcasts.
7. - Mosiah 4:9.
8. - See Helaman 5:12.
9. - Jeffrey R. Holland, “Lord, I Believe,” Ensign or Liahona, May 2013, 94.
10. - Dieter F. Uchtdorf, “Receiving a Testimony of Light and Truth,” Ensign or Liahona, Nov. 2014, 22.
11. - “A Child’s Prayer,” Children’s Songbook, 12.