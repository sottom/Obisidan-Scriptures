By Bonnie L. Oscarson
Young Women General President
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/defenders-of-the-family-proclamation?lang=eng)

_Let us help build the kingdom of God by standing up boldly and being defenders of marriage, parenthood, and the home._

What a privilege and joy to be a part of this marvelous assembly of girls and women. How blessed we are as women to be joined together this evening in unity and in love.



I recently read the story of Marie Madeline Cardon, who, with her family, received the message of the restored gospel of Jesus Christ from the first missionaries called to serve in Italy in 1850. She was a young woman of 17 or 18 years of age when they were baptized. One Sunday, while the family was holding a worship service in their home high in the Alps of northern Italy, an angry mob of men, including some of the local ministers, gathered around the house and began shouting, yelling, and calling for the missionaries to be brought outside. I don’t think they were anxious to be taught the gospel—they intended bodily harm. It was young Marie who marched out of the house to confront the mob.

They continued their vicious yells and demands for the missionaries to be brought out. Marie raised her Bible up in her hand and commanded them to depart. She told them that the elders were under her protection and that they could not harm one hair of their heads. Listen to her own words: “All stood aghast. … God was with me. He placed those words in my mouth, or I could not have spoken them. All was calm, instantly. That strong ferocious body of men stood helpless before a weak, trembling, yet fearless girl.” The ministers asked the mob to leave, which they did quietly in shame, fear, and remorse. The small flock completed their meeting in peace.1

Can’t you just picture that brave young woman, the same age as many of you, standing up to a mob and defending her newly found beliefs with courage and conviction?

Sisters, few of us will ever have to face an angry mob, but there is a war going on in this world in which our most cherished and basic doctrines are under attack. I am speaking specifically of the doctrine of the family. The sanctity of the home and the essential purposes of the family are being questioned, criticized, and assaulted on every front.

When President Gordon B. Hinckley first read “The Family: A Proclamation to the World” 20 years ago this year, we were grateful for and valued the clarity, simplicity, and truth of this revelatory document. Little did we realize then how very desperately we would need these basic declarations in today’s world as the criteria by which we could judge each new wind of worldly dogma coming at us from the media, the Internet, scholars, TV and films, and even legislators. The proclamation on the family has become our benchmark for judging the philosophies of the world, and I testify that the principles set forth within this statement are as true today as they were when they were given to us by a prophet of God nearly 20 years ago.

May I point out something obvious? Life rarely goes exactly according to plan for anyone, and we are very aware that not all women are experiencing what the proclamation describes. It is still important to understand and teach the Lord’s pattern and strive for the realization of that pattern the best we can.

Each of us has a part to play in the plan, and each of us is equally valued in the eyes of the Lord. We should remember that a loving Heavenly Father is aware of our righteous desires and will honor His promises that nothing will be withheld from those who faithfully keep their covenants. Heavenly Father has a mission and plan for each of us, but He also has His own timetable. One of the hardest challenges in this life is to have faith in the Lord’s timing. It’s a good idea to have an alternative plan in mind, which helps us to be covenant-keeping, charitable, and righteous women who build the kingdom of God no matter which way our lives go. We need to teach our daughters to aim for the ideal but plan for contingencies.

During this 20th anniversary year of the family proclamation, I would like to issue a challenge for all of us as women of the Church to be defenders of “The Family: A Proclamation to the World.” Just as Marie Madeline Cardon courageously defended the missionaries and her newly found beliefs, we need to boldly defend the Lord’s revealed doctrines describing marriage, families, the divine roles of men and women, and the importance of homes as sacred places—even when the world is shouting in our ears that these principles are outdated, limiting, or no longer relevant. Everyone, no matter what their marital circumstance or number of children, can be defenders of the Lord’s plan described in the family proclamation. If it is the Lord’s plan, it should also be our plan!

There are three principles taught in the proclamation which I think are especially in need of steadfast defenders. The first is marriage between a man and a woman. We are taught in the scriptures, “Nevertheless neither is the man without the woman, neither the woman without the man, in the Lord.”2 For anyone to attain the fulness of priesthood blessings, there must be a husband and a wife sealed in the house of the Lord, working together in righteousness and remaining faithful to their covenants. This is the Lord’s plan for His children, and no amount of public discourse or criticism will change what the Lord has declared. We need to continue to model righteous marriages, seek for that blessing in our lives, and have faith if it is slow in coming. Let us be defenders of marriage as the Lord has ordained it while continuing to show love and compassion for those with differing views.

The next principle which calls for our defending voices is elevating the divine roles of mothers and fathers. We eagerly teach our children to aim high in this life. We want to make sure that our daughters know that they have the potential to achieve and be whatever they can imagine. We hope they will love learning, be educated, talented, and maybe even become the next Marie Curie or Eliza R. Snow.

Do we also teach our sons and daughters there is no greater honor, no more elevated title, and no more important role in this life than that of mother or father? I would hope that as we encourage our children to reach for the very best in this life that we also teach them to honor and exalt the roles that mothers and fathers play in Heavenly Father’s plan.

Our youngest daughter, Abby, saw a unique opportunity to stand as a defender of the role of mother. One day she got a notice from her children’s school that they were having Career Day presentations at the school. Parents were invited to send in an application if they wanted to come to school to teach the children about their jobs, and Abby felt impressed to apply to come and speak about motherhood. She didn’t hear back from the school, and when Career Day was getting close, she finally called the school, thinking they may have lost her application. The organizers scrambled around and found two teachers who agreed to have Abby come talk to their classes at the end of Career Day.

In her very fun presentation to the children, Abby taught them, among other things, that as a mother she needed to be somewhat of an expert in medicine, psychology, religion, teaching, music, literature, art, finance, decorating, hair styling, chauffeuring, sports, culinary arts, and so much more. The children were impressed. She finished by having the children remember their mothers by writing thank-you notes expressing gratitude for the many loving acts of service they received daily. Abby felt that the children saw their mothers in a whole new light and that being a mother or father was something of great worth. She applied to share again this year at Career Day and was invited to present to six classes.

  ImageGeneral Women's Session April 2015

Abby has said of her experience: “I feel like it could be easy in this world for a child to get the sense that being a parent is a secondary job or even sometimes a necessary inconvenience. I want every child to feel like they are the most important priority to their parent, and maybe telling them how important being a parent is to me will help them realize all that their parents do for them and why.”

Our beloved prophet, President Thomas S. Monson, is a wonderful example of honoring women and motherhood, especially his own mother. In reference to our earthly mothers, he has said: “May each of us treasure this truth; one cannot forget mother and remember God. One cannot remember mother and forget God. Why? Because these two sacred persons, God and [our earthly] mother, partners in creation, in love, in sacrifice, in service, are as one.”3



The last principle we need to stand and defend is the sanctity of the home. We need to take a term which is sometimes spoken of with derision and elevate it. It is the term homemaker. All of us—women, men, youth, and children, single or married—can work at being homemakers. We should “make our homes” places of order, refuge, holiness, and safety. Our homes should be places where the Spirit of the Lord is felt in rich abundance and where the scriptures and the gospel are studied, taught, and lived. What a difference it would make in the world if all people would see themselves as makers of righteous homes. Let us defend the home as a place which is second only to the temple in holiness.

Sisters, I am grateful to be a woman in these latter days. We have opportunities and possibilities which no other generation of women has had in the world. Let us help build the kingdom of God by standing up boldly and being defenders of marriage, parenthood, and the home. The Lord needs us to be brave, steadfast, and immovable warriors who will defend His plan and teach the upcoming generations His truths.

I bear witness that Heavenly Father lives and loves each of us. His Son, Jesus Christ, is our Savior and Redeemer. I leave this testimony with you in the name of Jesus Christ, amen.

# References
1. - See Marie Madeline Cardon Guild, “Marie Madeline Cardon Guild: An Autobiography,” cardonfamilies.org/Histories/MarieMadelineCardonGuild.html; see also Marie C. Guild autobiography, circa 1909, Church History Library, Salt Lake City, Utah.
2. - 1 Corinthians 11:11.
3. - Thomas S. Monson, “Behold Thy Mother,” Ensign, Jan. 1974, 32.