Elder David A. Bednar
Of the Quorum of the Twelve Apostles
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/therefore-they-hushed-their-fears?lang=eng)

_Unlike worldly fear that creates alarm and anxiety, godly fear is a source of peace, assurance, and confidence._

I remember vividly an experience I had as a small boy. One day while playing with my friends, I accidentally broke a window in a store near our home. As the glass shattered and the security alarm blared, a paralyzing fear filled my heart and mind. I realized immediately I was doomed to spend the remainder of my life in prison. My parents eventually coaxed me out from a hiding place under my bed and helped me to make amends with the store owner. Fortunately, my jail sentence was commuted.

The fear I felt that day was overwhelming and real. You undoubtedly have experienced much greater feelings of dread after learning about a personal health challenge, discovering a family member in difficulty or danger, or observing disturbing world events. In such instances, the distressing emotion of fear arises because of impending danger, uncertainty, or pain and through experiences that are unexpected, sometimes sudden, and likely to produce a negative outcome.

In our daily lives, endless reports of criminal violence, famine, wars, corruption, terrorism, declining values, disease, and the destructive forces of nature can engender fear and apprehension. Surely we live in the season foretold by the Lord: “And in that day … the whole earth shall be in commotion, and men’s hearts shall fail them” (D&C 45:26).

My purpose is to describe how fear is dispelled through a correct knowledge of and faith in the Lord Jesus Christ. I earnestly pray the Holy Ghost will bless each of us as we consider together this important topic.





Mortal Fear



Upon hearing the voice of God after partaking of the forbidden fruit, Adam and Eve hid themselves in the Garden of Eden. God called unto Adam and asked, “Where art thou? And [Adam answered], I heard thy voice … , and I was afraid” (Genesis 3:9–10). Notably, one of the first effects of the Fall was for Adam and Eve to experience fear. This potent emotion is an important element of our mortal existence.

An example from the Book of Mormon highlights the power of the knowledge of the Lord (see 2 Peter 1:2–8; Alma 23:5–6) to dispel fear and provide peace even as we confront great adversity.

In the land of Helam, Alma’s people were frightened by an advancing Lamanite army.

“But Alma went forth and stood among them, and exhorted them that they should not be frightened, but … should remember the Lord their God and he would deliver them.

“Therefore they hushed their fears” (Mosiah 23:27–28).

Notice Alma did not hush the people’s fears. Rather, Alma counseled the believers to remember the Lord and the deliverance only He could bestow (see 2 Nephi 2:8). And knowledge of the Savior’s protecting watchcare enabled the people to hush their own fears.

Correct knowledge of and faith in the Lord empower us to hush our fears because Jesus Christ is the only source of enduring peace. He declared, “Learn of me, and listen to my words; walk in the meekness of my Spirit, and you shall have peace in me” (D&C 19:23).

The Master also explained, “He who doeth the works of righteousness shall receive his reward, even peace in this world, and eternal life in the world to come” (D&C 59:23).

Trust and confidence in Christ and a ready reliance on His merits, mercy, and grace lead to hope, through His Atonement, in the Resurrection and eternal life (see Moroni 7:41). Such faith and hope invite into our lives the sweet peace of conscience for which we all yearn. The power of the Atonement makes repentance possible and quells the despair caused by sin; it also strengthens us to see, do, and become good in ways that we could never recognize or accomplish with our limited mortal capacity. Truly, one of the great blessings of devoted discipleship is “the peace of God, which passeth all understanding” (Philippians 4:7).

The peace Christ gives allows us to view mortality through the precious perspective of eternity and supplies a spiritual settledness (see Colossians 1:23) that helps us maintain a consistent focus on our heavenly destination. Thus, we can be blessed to hush our fears because His doctrine provides purpose and direction in all aspects of our lives. His ordinances and covenants fortify and comfort in times both good and bad. And His priesthood authority gives assurance that the things that matter most can endure both in time and in eternity.

But can we hush the fears that so easily and frequently beset us in our contemporary world? The answer to this question is an unequivocal yes. Three basic principles are central to receiving this blessing in our lives: (1) look to Christ, (2) build upon the foundation of Christ, and (3) press forward with faith in Christ.





Look to Christ



The counsel Alma gave to his son Helaman applies precisely to each of us today: “Yea, see that ye look to God and live” (Alma 37:47). We should look to and have our focus firmly fixed upon the Savior at all times and in all places.

Recall how the Lord’s Apostles were in a ship, tossed in the midst of the sea. Jesus went to them, walking on the water; but not recognizing Him, they cried out in fear.

“Jesus spake unto them, saying, Be of good cheer; it is I; be not afraid.

“And Peter answered him and said, Lord, if it be thou, bid me come unto thee on the water.

“And he said, Come” (Matthew 14:27–29).

Peter then walked on the water to Jesus.

“But when he saw the wind boisterous, he was afraid,” began to sink, and cried out, “Lord, save me.



“And immediately Jesus stretched forth his hand, and caught him, and said unto him, O thou of little faith, wherefore didst thou doubt?” (Matthew 14:30–31).

I envision Peter responding fervently and immediately to the Savior’s invitation. With his eyes fixed upon Jesus, he stepped out of the boat and miraculously walked on the water. Only when his gaze was diverted by the wind and the waves did he become afraid and begin to sink.

We can be blessed to conquer our fears and strengthen our faith as we follow the Lord’s instruction: “Look unto me in every thought; doubt not, fear not” (D&C 6:36).







Build upon the Foundation of Christ



Helaman admonished his sons, Nephi and Lehi: “Remember, remember that it is upon the rock of our Redeemer, who is Christ, the Son of God, that ye must build your foundation; that when the devil shall send forth his mighty winds, yea, his shafts in the whirlwind, yea, when all his hail and his mighty storm shall beat upon you, it shall have no power over you to drag you down to the gulf of misery and endless wo, because of the rock upon which ye are built, which is a sure foundation, a foundation whereon if men build they cannot fall” (Helaman 5:12).

Ordinances and covenants are the building blocks we use to construct our lives upon the foundation of Christ and His Atonement. We are connected securely to and with the Savior as we worthily receive ordinances and enter into covenants, faithfully remember and honor those sacred commitments, and do our best to live in accordance with the obligations we have accepted. And that bond is the source of spiritual strength and stability in all of the seasons of our lives.

We can be blessed to hush our fears as we firmly establish our desires and deeds upon the sure foundation of the Savior through our ordinances and covenants.







Press Forward with Faith in Christ



Nephi declared: “Wherefore, ye must press forward with a steadfastness in Christ, having a perfect brightness of hope, and a love of God and of all men. Wherefore, if ye shall press forward, feasting upon the word of Christ, and endure to the end, behold, thus saith the Father: Ye shall have eternal life” (2 Nephi 31:20).

The disciplined endurance described in this verse is the result of spiritual understanding and vision, persistence, patience, and God’s grace. Exercising faith in and on the holy name of Jesus Christ, meekly submitting to His will and timing in our lives, and humbly acknowledging His hand in all things yield the peaceable things of the kingdom of God that bring joy and eternal life (see D&C 42:61). Even as we encounter difficulties and face the uncertainties of the future, we can cheerfully persevere and live a “peaceable life in all godliness and honesty” (1 Timothy 2:2).

We can be blessed to hush our fears as we receive the fortitude that comes from learning and living gospel principles and resolutely pressing forward on the covenant pathway.









The Fear of the Lord



Different from but related to the fears we often experience is what the scriptures describe as “godly fear” (Hebrews 12:28) or “the fear of the Lord” (Job 28:28; Proverbs 16:6; Isaiah 11:2–3). Unlike worldly fear that creates alarm and anxiety, godly fear is a source of peace, assurance, and confidence.

But how can anything associated with fear be edifying or spiritually helpful?

The righteous fear I am attempting to describe encompasses a deep feeling of reverence, respect, and awe for the Lord Jesus Christ (see Psalm 33:8; 96:4), obedience to His commandments (see Deuteronomy 5:29; 8:6; 10:12; 13:4; Psalm 112:1), and anticipation of the Final Judgment and justice at His hand. Thus, godly fear grows out of a correct understanding of the divine nature and mission of the Lord Jesus Christ, a willingness to submit our will to His will, and a knowledge that every man and woman will be accountable for his or her own sins in the Day of Judgment (see D&C 101:78; Articles of Faith 1:2).

As the scriptures certify, godly fear “is the beginning of knowledge” (Proverbs 1:7), “the instruction of wisdom” (Proverbs 15:33), a “strong confidence” (Proverbs 14:26), and “a fountain of life” (Proverbs 14:27).

Please note that godly fear is linked inextricably to an understanding of the Final Judgment and our individual accountability for our desires, thoughts, words, and acts (see Mosiah 4:30). The fear of the Lord is not a reluctant apprehension about coming into His presence to be judged. I do not believe we will be afraid of Him at all. Rather, it is the prospect in His presence of facing things as they really are about ourselves and having “a perfect knowledge” (2 Nephi 9:14; see also Alma 11:43) of all our rationalizations, pretenses, and self-deceptions. Ultimately, we will be left without excuse.

Every person who has lived or will yet live upon the earth “shall be brought to stand before the bar of God, to be judged of him according to [his or her] works whether they be good or whether they be evil” (Mosiah 16:10). If our desires have been for righteousness and our works good, then the judgment bar will be pleasing (see Jacob 6:13; Enos 1:27; Moroni 10:34). And at the last day we will “be rewarded unto righteousness” (Alma 41:6).

Conversely, if our desires have been for evil and our works wicked, then the judgment bar will be a cause of dread. “We shall not dare to look up to our God; and we would fain be glad if we could command the rocks and the mountains to fall upon us to hide us from his presence” (Alma 12:14). And at the last day we will “have [our] reward of evil” (Alma 41:5).

As summarized in Ecclesiastes:

“Fear God, and keep his commandments: for this is the whole duty of man.

“For God shall bring every work into judgment, with every secret thing, whether it be good, or whether it be evil” (Ecclesiastes 12:13–14).

My beloved brothers and sisters, godly fear dispels mortal fears. It even subdues the haunting concern that we never can be good enough spiritually and never will measure up to the Lord’s requirements and expectations. In truth, we cannot be good enough or measure up relying solely upon our own capacity and performance. Our works and desires alone do not and cannot save us. “After all we can do” (2 Nephi 25:23), we are made whole only through the mercy and grace available through the Savior’s infinite and eternal atoning sacrifice (see Alma 34:10, 14). Certainly, “we believe that through the Atonement of Christ, all mankind may be saved, by obedience to the laws and ordinances of the gospel” (Articles of Faith 1:3).

Godly fear is loving and trusting in Him. As we fear God more completely, we love Him more perfectly. And “perfect love casteth out all fear” (Moroni 8:16). I promise the bright light of godly fear will chase away the dark shadows of mortal fears (see D&C 50:25) as we look to the Savior, build upon Him as our foundation, and press forward on His covenant path with consecrated commitment.







Testimony and Promise



I love and revere the Lord. His power and peace are real. He is our Redeemer, and I witness He lives. And because of Him, our hearts need not be troubled or afraid (see John 14:27), and we will be blessed to hush our fears. I so testify in the sacred and holy name of the Lord Jesus Christ, amen.

# References
