President Thomas S. Monson
President of the Church
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/blessings-of-the-temple?lang=eng)

_As we attend the temple, there can come to us a dimension of spirituality and a feeling of peace._

My beloved brothers and sisters, how grateful I am to be with you this beautiful Easter morning when our thoughts turn to the Savior of the world. I extend my love and greetings to each of you and pray that our Heavenly Father will inspire my words.

This conference marks seven years since I was sustained as President of the Church. They have been busy years, filled not only with a few challenges but also with countless blessings. Among the most enjoyable and sacred of these blessings has been my opportunity to dedicate and rededicate temples.

Most recently, this past November it was my privilege to dedicate the beautiful new Phoenix Arizona Temple. I was joined by President Dieter F. Uchtdorf, Elder Dallin H. Oaks, Elder Richard J. Maynes, Elder Lynn G. Robbins, and Elder Kent F. Richards. On the evening prior to the dedication, a marvelous cultural celebration was held where over 4,000 of our youth from the temple district performed beautifully. The following day the temple was dedicated in three sacred and inspiring sessions.

The building of temples is a very clear indication of the growth of the Church. We currently have 144 temples in operation worldwide, with 5 being renovated and 13 more under construction. In addition, 13 temples which were previously announced are in various stages of preparation before construction begins. This year we anticipate rededicating 2 temples and dedicating 5 new temples which are scheduled for completion.

For the past two years, as we have concentrated our efforts on completing previously announced temples, we have held in abeyance plans for any additional temples. This morning, however, I am very pleased to announce three new temples which will be built in the following locations: Abidjan, Ivory Coast; Port-au-Prince, Haiti; and Bangkok, Thailand. What marvelous blessings are in store for our faithful members in these areas and, indeed, wherever temples are located throughout the world.

The process of determining needs and finding locations for additional temples is ongoing, for we desire that as many members as possible have an opportunity to attend the temple without great sacrifices of time and resources. As we have done in the past, we will keep you informed as decisions are made in this regard.

As I think of temples, my thoughts turn to the many blessings we receive therein. As we enter through the doors of the temple, we leave behind us the distractions and confusion of the world. Inside this sacred sanctuary, we find beauty and order. There is rest for our souls and a respite from the cares of our lives.

As we attend the temple, there can come to us a dimension of spirituality and a feeling of peace which will transcend any other feeling which could come into the human heart. We will grasp the true meaning of the words of the Savior when He said: “Peace I leave with you, my peace I give unto you. … Let not your heart be troubled, neither let it be afraid.”1

Such peace can permeate any heart—hearts that are troubled, hearts that are burdened down with grief, hearts that feel confusion, hearts that plead for help.

I recently learned firsthand of a young man who attended the temple with a heart pleading for help. Many months earlier he had received his call to serve in a mission in South America. However, his visa was delayed for such a lengthy period that he was reassigned to a mission in the United States. Although disappointed that he could not serve in the area of his original call, he nonetheless worked hard in his new assignment, determined to serve to the best of his ability. He became discouraged, however, because of negative experiences he had with missionaries who seemed to him to be more interested in having a good time than in sharing the gospel.

A few short months later this young man suffered a very serious health challenge which left him partially paralyzed, and so he was sent home on a medical leave.

Some months later the young man had healed completely, and his paralysis had disappeared. He was informed that he would once again be able to serve as a missionary, a blessing for which he had prayed daily. The only disappointing news was that he would return to the same mission which he had left, where he felt the behaviors and attitudes of some missionaries were less than they should be.

He had come to the temple to seek comfort and a confirmation that he could have a good experience as a missionary. His parents also had prayed that this temple visit would provide the help their son needed.

As the young man entered the celestial room following the session, he sat in a chair and began to pray for guidance from his Heavenly Father.

Another who entered the celestial room shortly afterward was a young man whose name is Landon. As he walked into the room, his gaze was immediately drawn to the young man sitting on the chair, eyes closed and obviously praying. Landon received an unmistakable prompting that he should speak with the young man. Hesitant to interrupt, however, he decided to wait. After several minutes had gone by, the young man was still praying. Landon knew he could no longer postpone the prompting. He approached the young man and gently touched his shoulder. The young man opened his eyes, startled that he had been disturbed. Landon said quietly, “I have felt impressed that I need to talk with you, although I am not certain why.”

As they began to converse, the young man poured out his heart to Landon, explaining his circumstances and ending with his desire to receive some comfort and encouragement concerning his mission. Landon, who had returned from a successful mission just a year earlier, told of his own mission experiences, the challenges and concerns he had faced, the manner in which he had turned to the Lord for help, and the blessings he had received. His words were comforting and reassuring, and his enthusiasm for his mission was contagious. Eventually, as the young man’s fears subsided, a feeling of peace came to him. He felt deep gratitude as he realized his prayer had been answered.

The two young men prayed together, and then Landon prepared to leave, happy that he had listened to the inspiration which had come to him. As he stood to go, the young man asked Landon, “Where did you serve your mission?” To this point, neither of them had mentioned to the other the name of the mission in which he had served. When Landon replied with the name of his mission, tears welled up in the eyes of the young man. Landon had served in the very mission to which the young man would be returning!

In a recent letter to me, Landon shared with me the young man’s parting words to him: “I had faith Heavenly Father would bless me, but I never could have imagined that He would send someone to help me who had served in my own mission. I know now that all will be well.”2 The humble prayer of a sincere heart had been heard and answered.

My brothers and sisters, in our lives we will have temptations; we will have trials and challenges. As we go to the temple, as we remember the covenants we make there, we will be better able to overcome those temptations and to bear our trials. In the temple we can find peace.

The blessings of the temple are priceless. One for which I am grateful every day of my life is that which my beloved wife, Frances, and I received as we knelt at a sacred altar and made covenants binding us together for all eternity. There is no blessing more precious to me than the peace and comfort I receive from the knowledge I have that she and I will be together again.

May our Heavenly Father bless us that we may have the spirit of temple worship, that we may be obedient to His commandments, and that we may follow carefully the steps of our Lord and Savior, Jesus Christ. I testify that He is our Redeemer. He is the Son of God. He it is who came forth from the grave that first Easter morning, bringing with Him the gift of everlasting life for all of God’s children. On this beautiful day, as we celebrate that momentous event, may we offer prayers of gratitude for His great and marvelous gifts to us. That this may be so, I pray humbly in His holy name, amen.

# References
1. - John 14:27.
2. - Correspondence in the possession of Thomas S. Monson.