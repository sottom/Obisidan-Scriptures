Presented by Brook P. Hales
Secretary to the First Presidency
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/statistical-report-2014?lang=eng)

The First Presidency has issued the following statistical report regarding the growth and status of the Church as of December 31, 2014.



Church Units



Stakes



3,114



Missions



406



Districts



561



Wards and Branches



29,621



Church Membership



Total Membership



15,372,337



New Children of Record



116,409



Converts Baptized



296,803



Missionaries



Full-Time Missionaries



85,147



Church-Service Missionaries



30,404



Temples



Temples Dedicated during 2014 (Fort Lauderdale Florida, Gilbert Arizona, and Phoenix Arizona)



3



Temples Rededicated (Ogden Utah)



1



Temples in Operation at Year End



144

# References
