Elder Robert D. Hales
Of the Quorum of the Twelve Apostles
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/preserving-agency-protecting-religious-freedom?lang=eng)

_The faithful use of our agency depends upon our having religious freedom._

This is Easter Sunday: a day of gratitude and remembrance honoring our Savior Jesus Christ’s Atonement and Resurrection for all mankind. We worship Him, grateful for our freedom of religion, freedom of assembly, freedom of speech, and our God-given right of agency.

As prophets foretold about these latter days in which we live, there are many confused about who we are and what we believe. Some are “false accusers … [and] despisers of those that are good.”1 Others “call evil good, and good evil; [and] put darkness for light, and light for darkness.”2

As those around us make choices about how to respond to our beliefs, we must not forget that moral agency is an essential part of God’s plan for all His children. That eternal plan, presented to us in the premortal Council in Heaven, included the gift of agency.3

In that Grand Council, Lucifer, known as Satan, used his agency to oppose God’s plan. God said: “Because … Satan rebelled against me, and sought to destroy the agency of man, which I, the Lord God, had given him, … I caused that he should be cast down.”4

He continued: “And also a third part of the hosts of heaven turned he away from me because of their agency.”5

As a result, Heavenly Father’s spirit children who chose to reject His plan and follow Lucifer lost their divine destiny.

Jesus Christ, using His agency, said:

“Here am I, send me.”6

“Thy will be done, and the glory be thine forever.”7

Jesus, who exercised His agency to sustain Heavenly Father’s plan, was identified and appointed by the Father as our Savior, foreordained to perform the atoning sacrifice for all. Similarly, our exercise of agency to keep the commandments enables us to fully understand who we are and receive all of the blessings our Heavenly Father has—including the opportunity to have a body, to progress, to experience joy, to have a family, and to inherit eternal life.

To keep the commandments, we need to know the official doctrine of the Church so we are not diverted from Christ’s leadership by the ever-changing whims of individuals.

The blessings we enjoy now are because we made the choice to follow the Savior before this life. To everyone hearing or reading these words, whoever you are and whatever your past may be, remember this: it is not too late to make that same choice again and follow Him.

Through our faith in Jesus Christ, believing in His Atonement, repenting of our sins, and being baptized, we may then receive the supernal gift of the Holy Ghost. This gift provides knowledge and understanding, guidance and strength to learn and gain a testimony, power, cleansing to overcome sin, and comfort and encouragement to be faithful in tribulation. These incomparable blessings of the Spirit increase our freedom and power to do what is right, for “where the Spirit of the Lord is, there is liberty.”8

As we walk the path of spiritual liberty in these last days, we must understand that the faithful use of our agency depends upon our having religious freedom. We already know that Satan does not want this freedom to be ours. He attempted to destroy moral agency in heaven, and now on earth he is fiercely undermining, opposing, and spreading confusion about religious freedom—what it is and why it is essential to our spiritual life and our very salvation.

There are four cornerstones of religious freedom that we as Latter-day Saints must rely upon and protect.

The first is freedom to believe. No one should be criticized, persecuted, or attacked by individuals, or governments either, for what he or she believes about God. It is very personal and very important. An early declaration of our beliefs regarding religious liberty states:

“No government can exist in peace, except such laws are framed and held inviolate as will secure to each individual the free exercise of conscience. …

“… The civil magistrate should restrain crime, but never control conscience [or] suppress the freedom of the soul.”9

This fundamental freedom of belief has since been acknowledged by the United Nations in its Universal Declaration of Human Rights and by other national and international human rights documents.10

The second cornerstone of religious liberty is the freedom to share our faith and our beliefs with others. The Lord commands us, “Ye shall teach [the gospel to] your children … when thou sittest in thine house.”11 He also said to His disciples, “Go ye into all the world, and preach the gospel to every creature.”12 As parents, full-time missionaries, and member missionaries, we rely on religious freedom in order to teach the Lord’s doctrine in our families and throughout the world.

The third cornerstone of religious liberty is the freedom to form a religious organization, a church, to worship peacefully with others. The eleventh article of faith declares, “We claim the privilege of worshiping Almighty God according to the dictates of our own conscience, and allow all men the same privilege, let them worship how, where, or what they may.” International human rights documents and many national constitutions support this principle.

The fourth cornerstone of religious liberty is the freedom to live our faith—free exercise of faith not just in the home and chapel but also in public places. The Lord commands us not only to pray privately13 but also to go forth and “let [our] light so shine before men, that they may see [our] good works, and glorify [our] Father which is in heaven.”14

Some are offended when we bring our religion into the public square, yet the same people who insist that their viewpoints and actions be tolerated in society are often very slow to give that same tolerance to religious believers who also wish their viewpoints and actions to be tolerated. The general lack of respect for religious viewpoints is quickly devolving into social and political intolerance for religious people and institutions.

As we face increased pressure to bow to secular standards, forfeit our religious liberties, and compromise our agency, consider what the Book of Mormon teaches about our responsibilities. In the book of Alma we read of Amlici, “a very cunning” and “wicked man” who sought to be king over the people and “deprive them of their rights and privileges,” which “was alarming to the people of the church.”15 They were taught by King Mosiah to raise their voices for what they felt was right.16 Therefore they “assembled themselves together throughout all the land, every man according to his mind, whether it were for or against Amlici, in separate bodies, having much dispute … one with another.”17

In these discussions, members of the Church and others had the opportunity to come together, experience the spirit of unity, and be influenced by the Holy Ghost. “And it came to pass that the voice of the people came against Amlici, that he was not made king.”18

As disciples of Jesus Christ we have a responsibility to work together with like-minded believers, to raise our voices for what is right. While members should never claim or even imply that they are speaking for the Church, we are all invited, in our capacity as citizens, to share our personal witness with conviction and love—“every man [and woman] according to his [or her own] mind.”19

Said the Prophet Joseph Smith:

“I am bold to declare before Heaven that I am just as ready to die in defending the rights of a Presbyterian, a Baptist, or a good man of any other denomination [as for a Mormon]; for the same principle which would trample upon the rights of the Latter-day Saints would trample upon the rights of the Roman Catholics, or of any other denomination who may be unpopular and too weak to defend themselves.

“It is a love of liberty which inspires my soul—civil and religious liberty to the whole of the human race.”20

Brothers and sisters, we are responsible to safeguard these sacred freedoms and rights for ourselves and our posterity. What can you and I do?

First, we can become informed. Be aware of issues in your community that could have an impact on religious liberty.

Second, in your individual capacity, join with others who share our commitment to religious freedom. Work side by side to protect religious freedom.

Third, live your life to be a good example of what you believe—in word and deed. How we live our religion is far more important than what we may say about our religion.

Our Savior’s Second Coming is drawing nearer. Let us not delay in this great cause. Remember Captain Moroni, who hoisted the title of liberty inscribed with the words “In memory of our God, our religion, and freedom, and our peace, our wives, and our children.”21 Let us remember the people’s response: exercising their agency, they “came running together” with a covenant to act.22

My beloved brothers and sisters, don’t walk! Run! Run to receive the blessings of agency by following the Holy Ghost and exercising the freedoms God has given us to do His will.

I bear my special witness on this special Easter day that Jesus Christ used His agency to do our Father’s will.

Of our Savior, we sing, “His precious blood he freely spilt; His life he freely gave.”23 And because He did, we have the priceless opportunity “to choose liberty and eternal life” through the power and blessings of His Atonement.24 May we freely choose to follow Him today and always, I pray in His holy name, even Jesus Christ, amen.

# References
1. - 2 Timothy 3:3.
2. - Isaiah 5:20.
3. - See Moses 6:56.
4. - Moses 4:3.
5. - Doctrine and Covenants 29:36.
6. - Abraham 3:27.
7. - Moses 4:2.
8. - 2 Corinthians 3:17.
9. - Doctrine and Covenants 134:2, 4.
10. - See the Universal Declaration of Human Rights, adopted by United Nations General Assembly on Dec. 10, 1948, un.org/en/documents/udhr. Article 18 states: “Everyone has the right to freedom of thought, conscience and religion; this right includes freedom to change his religion or belief, and freedom, either alone or in community with others and in public or private, to manifest his religion or belief in teaching, practice, worship and observance.” See also article 9 of Europe’s Convention for the Protection of Human Rights and Fundamental Freedoms, ratified on Sept. 3, 1953, conventions.coe.int/treaty/en/treaties/html/005.htm.
11. - Deuteronomy 11:19.
12. - Mark 16:15.
13. - See Matthew 6:6.
14. - Matthew 5:16.
15. - See Alma 2:1–4.
16. - See Mosiah 29:25–26.
17. - Alma 2:5; emphasis added.
18. - Alma 2:7.
19. - Alma 2:5.
20. - Teachings of Presidents of the Church: Joseph Smith (2007), 345.
21. - Alma 46:12.
22. - Alma 46:21.
23. - “How Great the Wisdom and the Love,” Hymns, no. 195.
24. - 2 Nephi 2:27.