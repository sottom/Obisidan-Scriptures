Elder L. Tom Perry
Of the Quorum of the Twelve Apostles
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/why-marriage-and-family-matter-everywhere-in-the-world?lang=eng)

_Family is the center of life and is the key to eternal happiness._

Last November, I had the privilege of being invited—along with President Henry B. Eyring and Bishop Gérald Caussé—to attend a colloquium on marriage and family at the Vatican in Rome, Italy. In attendance were religious representatives from 14 different faiths and from six of the seven continents, all of whom had been invited to express their beliefs on what is happening to the family in today’s world.



Pope Francis opened the first session of the assembly with this statement: “We now live in a culture of the temporary, in which more and more people are simply giving up on marriage as a public commitment. This revolution in manners and morals has often flown the flag of freedom, but in fact it has brought spiritual and material devastation to countless human beings, especially the poorest and most vulnerable. … It is always they who suffer the most in this crisis.”1

In referring to those of the rising generation, he said it is important that they “do not give themselves over to the poisonous [mentality] of the temporary, but rather be revolutionaries with the courage to seek true and lasting love, going against the common pattern”; this must be done.2



This was followed by three days of presentation and discussion with religious leaders addressing the subject of marriage between a man and a woman. As I listened to the widest imaginable variety of worldwide religious leaders, I heard them agree completely with each other and express support for one another’s beliefs on the sanctity of the institution of marriage and of the importance of families as the basic unit of society. I felt a powerful sense of commonality and unity with them.

There were many who saw and expressed this unity, and they did so in a variety of ways. One of my favorites was when a Muslim scholar from Iran quoted two paragraphs verbatim from our very own proclamation on the family.

During the colloquium, I observed that when various faiths and denominations and religions are united on marriage and family, they are also united on the values and loyalty and commitment which are naturally associated with family units. It was remarkable for me to see how marriage and family-centered priorities cut across and superseded any political, economic, or religious differences. When it comes to love of spouse and hopes, worries, and dreams for children, we are all the same.

  Image

It was marvelous to be in meetings with worldwide presenters as they universally addressed their feelings of the importance of marriage between a man and a woman. Each of their addresses was followed by testimonies from other religious leaders. President Henry B. Eyring gave a final testimony at the colloquium. He bore powerful witness to the beauty of a committed marriage and to our belief in the promised blessing of eternal families.

President Eyring’s testimony was a fitting benediction to those three special days.

Now, you may be asking, “If the majority felt that similarity of family priority and beliefs, if all of those faiths and religions essentially agreed on what marriage should be, and if they all agreed on the value that should be placed on homes and family relationships, then how are we any different? How does The Church of Jesus Christ of Latter-day Saints distinguish and differentiate itself from the rest of the world?”

Here is the answer: while it was wonderful to see and feel that we have so much in common with the rest of the world in regard to our families, only we have the eternal perspective of the restored gospel.

What the restored gospel brings to the discussion on marriage and family is so large and so relevant that it cannot be overstated: we make the subject eternal! We take the commitment and the sanctity of marriage to a greater level because of our belief and understanding that families go back to before this earth was and that they can go forward into eternity.

This doctrine is taught so simply, powerfully, and beautifully by Ruth Gardner’s text for the Primary song “Families Can Be Together Forever.” Pause for just a moment and think about Primary children all over the world singing these words in their native tongue, at the top of their lungs, with an enthusiasm that only love of family can evoke:







Families can be together forever

Through Heavenly Father’s plan.

I always want to be with my own family,

And the Lord has shown me how I can.3





The entire theology of our restored gospel centers on families and on the new and everlasting covenant of marriage. In The Church of Jesus Christ of Latter-day Saints, we believe in a premortal life where we all lived as literal spirit children of God our Heavenly Father. We believe that we were, and still are, members of His family.

We believe that marriage and family ties can continue beyond the grave—that marriages performed by those who have the proper authority in His temples will continue to be valid in the world to come. Our marriage ceremonies eliminate the words “till death do us part” and instead say, “for time and for all eternity.”

We also believe that strong traditional families are not only the basic units of a stable society, a stable economy, and a stable culture of values—but that they are also the basic units of eternity and of the kingdom and government of God.

We believe that the organization and government of heaven will be built around families and extended families.

It is because of our belief that marriages and families are eternal that we, as a church, want to be a leader and a participant in worldwide movements to strengthen them. We know that it is not only those who are actively religious who share common values and priorities of lasting marriages and strong family relationships. A great number of secular people have concluded that a committed marriage and family lifestyle is the most sensible, the most economical, and the happiest way to live.

No one has ever come up with a more efficient way to raise the next generation than a household of married parents with children.

Why should marriage and family matter—everywhere? Public opinion polls show that marriage is still the ideal and the hope among the majority of every age group—even among the millennial generation, where we hear so much about chosen singleness, personal freedom, and cohabitation instead of marriage. The fact is that strong majorities worldwide still want to have children and to create strong families.

Once we are married and once we have children, the true commonality among all mankind becomes even more evident. As “family people”—no matter where we live or what our religious beliefs may be—we share many of the same struggles, the same adjustments, and the same hopes, worries, and dreams for our children.

As New York Times columnist David Brooks said: “People are not better off when they are given maximum personal freedom to do what they want. They’re better off when they are enshrouded in commitments that transcend personal choice—commitments to family, God, craft and country.”4

One problem is that much of the media and entertainment that the world shares does not reflect the priorities and values of the majority. For whatever reasons, too much of our television, movies, music, and Internet present a classic case of a minority masquerading as a majority. Immorality and amorality, ranging from graphic violence to recreational sex, is portrayed as the norm and can cause those who have mainstream values to feel like we are out of date or from a bygone era. In such a media and Internet-dominated world, it has never been harder to raise responsible children and to keep marriages and families together.

Despite what much of media and entertainment outlets may suggest, however, and despite the very real decline in the marriage and family orientation of some, the solid majority of mankind still believes that marriage should be between one man and one woman. They believe in fidelity within marriage, and they believe in the marriage vows of “in sickness and in health” and “till death do us part.”

We need to remind ourselves once in a while, as I was reminded in Rome, of the wonderfully reassuring and comforting fact that marriage and family are still the aspiration and ideal of most people and that we are not alone in those beliefs. It has never been more of a challenge to find a practical balance between employment, families, and personal needs than it is in our day. As a church, we want to assist in all that we can to create and support strong marriages and families.

That is why the Church actively participates in and provides leadership to various coalitions and ecumenical efforts to strengthen the family. It is why we share our family-focused values in the media and on social media. It is why we share our genealogical and extended family records with all nations.

We want our voice to be heard against all of the counterfeit and alternative lifestyles that try to replace the family organization that God Himself established. We also want our voice to be heard in sustaining the joy and fulfillment that traditional families bring. We must continue to project that voice throughout the world in declaring why marriage and family are so important, why marriage and family really do matter, and why they always will.

My brothers and sisters, the restored gospel centers on marriage and family. It is also on marriage and family where we can unite most with other faiths. It is around marriage and family where we will find our greatest commonality with the rest of the world. It is around marriage and family that The Church of Jesus Christ of Latter-day Saints has the greatest opportunity to be a light on the hill.

Let me close by bearing witness (and my nine decades on this earth fully qualify me to say this) that the older I get, the more I realize that family is the center of life and is the key to eternal happiness.

I give thanks for my wife, for my children, for my grandchildren and my great-grandchildren, and for all of the cousins and in-laws and extended family who make my own life so rich and, yes, even eternal. Of this eternal truth I bear my strongest and most sacred witness in the name of Jesus Christ, amen.

# References
1. - Pope Francis, address at Humanum: An International Interreligious Colloquium on the Complementarity of Man and Woman, Nov. 17, 2014, humanum.it/en/videos; see also zenit.org/en/articles/pope-francis-address-at-opening-of-colloquium-on-complementarity-of-man-and-woman.
2. - Pope Francis, Colloquium on the Complementarity of Man and Woman.
3. - “Families Can Be Together Forever,” Hymns, no. 300.
4. - David Brooks, “The Age of Possibility,” New York Times, Nov. 16, 2012, A35, nytimes.com/2012/11/16/opinion/brooks-the-age-of-possibility.html.