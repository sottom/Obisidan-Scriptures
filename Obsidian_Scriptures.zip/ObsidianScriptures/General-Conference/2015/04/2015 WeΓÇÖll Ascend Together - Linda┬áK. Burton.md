Linda K. Burton
Relief Society General President
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/well-ascend-together?lang=eng)

_As covenant-keeping women and men, we need to lift each other and help each other become the people the Lord would have us become._

Next to the inspiring talks, music, and prayers that always touch our hearts during general conference, I have been told by many sisters that what they love most is watching the First Presidency and Quorum of the Twelve as they exit this podium with their eternal companions. And don’t we all enjoy hearing the Brethren tenderly express their love for them?



Speaking about his wife, Donna, President Boyd K. Packer said, “Because of the office I hold, I have a solemn obligation to tell the truth: She’s perfect.”1



“She is the sunshine of my life,”2 said President Dieter F. Uchtdorf of his wife, Harriet.

  ImageApril 2015 General Conference

President Henry B. Eyring, referring to his wife, Kathleen, said, “She [is] a person who has always made me want to be the very best that I can be.”3

  ImagePresident and Sister Monson

And President Thomas S. Monson, speaking of his beloved Frances, said, “She was the love of my life, my trusted confidant, and my closest friend. To say that I miss her does not begin to convey the depth of my feelings.”4

I too would like to express my love for my beloved companion, Craig. He is a precious gift to me! Referring to my husband, a cherished and sacred phrase in my patriarchal blessing promises that my life and the lives of my children will “be well in his keeping.” It is clear to me that Craig is the fulfillment of that promise. Borrowing from the words of Mark Twain, I say that “life without [Craig] would not be life.”5 I love him, heart and soul!





Divine Roles and Responsibilities



Today I wish to honor husbands, fathers, brothers, sons, and uncles who know who they are and who are doing their best to fulfill their God-given roles as described in the family proclamation, including righteously presiding and providing for and protecting their families. Please know that I am painfully aware that the topics of fatherhood, motherhood, and marriage can be troubling for many. I know that some Church members feel that their homes will never reach what they perceive to be the ideal. Many are hurting because of neglect, abuse, addictions, and incorrect traditions and culture. I do not condone the actions of men or women who have willfully or even ignorantly caused pain, anguish, and despair in their homes. But today I am speaking of something else.

I am convinced that a husband is never more attractive to his wife than when he is serving in his God-given roles as a worthy priesthood holder—most important in the home. I love and believe these words from President Packer to worthy husbands and fathers: “You have the power of the priesthood directly from the Lord to protect your home. There will be times when all that stands as a shield between your family and the adversary’s mischief will be that power.”6







Spiritual Leaders and Teachers in the Home



Earlier this year I attended the funeral of an extraordinary ordinary man—my husband’s uncle Don. One of Uncle Don’s sons shared an experience he had as a small child, shortly after his parents had purchased their first home. Because there were five small children to feed and clothe, there was not enough money to fence the yard. Taking seriously one of his divine roles as the protector of his family, Uncle Don drove a few small wooden stakes into the ground, took some string, and tied the string from stake to stake all around the yard. He then called his children to him. He showed them the stakes and string and explained to them that if they would stay on the inside of that makeshift fence, they would be safe.

One day the visiting teachers watched in disbelief as they approached the house and saw five little children standing obediently at the edge of the string, looking longingly at a ball that had bounced beyond their boundaries and out into the street. One little child ran to get their daddy, who, in response, ran and retrieved the ball.

Later in the funeral, the oldest son tearfully expressed that all he had ever hoped in this life was to be like his beloved father.

  ImageApril 2015 General Conference

President Ezra Taft Benson said:

“Oh, husbands and fathers in Israel, you can do so much for the salvation and exaltation of your families! …

“Remember your sacred calling as a father in Israel—your most important calling in time and eternity—a calling from which you will never be released.”

  ImageApril 2015 General Conference

“You must help create a home where the Spirit of the Lord can abide.”7

How applicable those prophetic words are today.

It must be difficult, at best, for covenant men to live in a world that not only demeans their divine roles and responsibilities but also sends false messages about what it means to be a “real man.” One false message is “It’s all about me.” On the other end of the scale is the degrading and mocking message that husbands and fathers are no longer needed. I plead with you not to listen to Satan’s lies! He has forfeited that sacred privilege of ever becoming a husband or father. Because he is jealous of those who have the sacred roles he will never fill, he is intent on making “all men … miserable like unto himself”!8







Lifting and Helping in Our Complementary Roles



Brothers and sisters, we need each other! As covenant-keeping women and men, we need to lift each other and help each other become the people the Lord would have us become. And we need to work together to lift the rising generation and help them reach their divine potential as heirs of eternal life. We could do as Elder Robert D. Hales and his wife, Mary, have done and follow the proverb “Thee lift me and I’ll lift thee, and we’ll ascend together.”9

We know from the scriptures that “it is not good that … man should be alone.” That is why our Heavenly Father made “an help meet for him.”10 The phrase help meet means “a helper suited to, worthy of, or corresponding to him.”11 For example, our two hands are similar to each other but not exactly the same. In fact, they are exact opposites, but they complement each other and are suited to each other. Working together, they are stronger.12

In a chapter about families, the Church handbook contains this statement: “The nature of male and female spirits is such that they complete each other.”13 Please note that it does not say “compete with each other” but “complete each other”! We are here to help, lift, and rejoice with each other as we try to become our very best selves. Sister Barbara B. Smith wisely taught, “There is so much more of happiness to be had when we can rejoice in another’s successes and not just in our own.”14 When we seek to “complete” rather than “compete,” it is so much easier to cheer each other on!

When I was a young mother of several small children, at the end of days filled with diapering, dish washing, and disciplining, no one sang more emphatically the Primary song “I’m so glad when daddy comes home.”15 I’m sad to admit, however, I was not always cheerful when Craig seemed to bounce through the door after a hard day of work. He always greeted each of us with a hug and kiss and turned many difficult and sometimes disastrous days into delightful daddy times. I wish I had been a little less preoccupied with the endless list of to-dos still to be done and had more wisely focused, like he did, on things that mattered most. I would have stopped more often and enjoyed sacred family time and would have thanked him more often for blessing our lives!







Let Us Oft Speak Kind Words to Each Other



Not long ago, a faithful sister in the Church shared with me a deep concern she had been praying about for some time. Her concern was for some of the sisters in her ward. She told me how it hurt her heart to observe that they sometimes spoke disrespectfully to their husbands and about their husbands, even in front of their children. She then told me how as a young woman she had earnestly desired and prayed to find and marry a worthy priesthood holder and build a happy home with him. She had grown up in a home where her mother had “ruled the roost” and her father had cowered to her mother’s demands in order to keep peace at home. She felt that there was a better way. She had not seen it modeled in the home she grew up in, but as she prayed fervently for guidance, the Lord blessed her to know how to create a home with her husband where the Spirit would be warmly welcomed. I have been in that home and can testify it is a holy place!

Sisters and brothers, how often do we intentionally “speak kind words to each other”?16

We might test ourselves by asking a few questions. With a little adaptation, these questions can apply to most of us, whether we are married or single, whatever our home situation might be.





When was the last time I sincerely praised my companion, either alone or in the presence of our children?





When was the last time I thanked, expressed love for, or earnestly pleaded in faith for him or her in prayer?





When was the last time I stopped myself from saying something I knew could be hurtful?





When was the last time I apologized and humbly asked for forgiveness—without adding the words “but if only you had” or “but if only you hadn’t”?





When was the last time I chose to be happy rather than demanding to be “right”?





Now, if any of these questions lead you to squirm or feel a tinge of guilt, remember that Elder David A. Bednar has taught that “guilt is to our spirit what pain is to our body—a warning of danger and a protection from additional damage.”17

I invite each of us to heed Elder Jeffrey R. Holland’s heartfelt plea: “Brothers and sisters, in this long eternal quest to be more like our Savior, may we try to be ‘perfect’ men and women in at least this one way now—by offending not in word, or more positively put, by speaking with a new tongue, the tongue of angels.”18

As I have prepared for this opportunity today, the Spirit has taught me, and I have committed to speak words of kindness more often to my cherished companion and about him, to lift the men in my family and express gratitude for the ways they fulfill their divine and complementary roles. And I have committed to follow the proverb “Thee lift me and I’ll lift thee, and we’ll ascend together.”

Will you join me in seeking the help of the Holy Ghost to teach us how we can better lift each other in our complementary roles as covenant sons and daughters of our loving heavenly parents?

I know that through the enabling power of the Atonement of Jesus Christ and our faith in Him, we can do it. I pray we will put our trust in Him to help us help each other live happily and eternally as we ascend together, in the name of Jesus Christ, amen.

# References
1. - Boyd K. Packer, in “Donna Smith Packer Receives Family History Certificate from BYU,” news.byu.edu/archive12-jun-packer.aspx.
2. - Dieter F. Uchtdorf, in Jeffrey R. Holland, “Elder Dieter F. Uchtdorf: On to New Horizons,” Ensign, Mar. 2005, 12; Liahona, Mar. 2005, 10.
3. - Henry B. Eyring, in Gerald N. Lund, “Elder Henry B. Eyring: Molded by ‘Defining Influences,’” Ensign, Sept. 1995, 14; Liahona, Apr. 1996, 31.
4. - Thomas S. Monson, “I Will Not Fail Thee, nor Forsake Thee,” Ensign or Liahona, Nov. 2013, 85.
5. - Mark Twain, Eve’s Diary (1905), 107.
6. - Boyd K. Packer, “The Power of the Priesthood,” Ensign or Liahona, May 2010, 9.
7. - Ezra Taft Benson, “To the Fathers in Israel,” Ensign, Nov. 1987, 51, 50.
8. - 2 Nephi 2:27.
9. - See Robert D. Hales, “Strengthening Families: Our Sacred Duty,” Ensign, May 1999, 34; Liahona, July 1999, 40; see also LaRene Gaunt, “Elder Robert D. Hales: ‘Return with Honor,’” Ensign, July 1994, 51; Liahona, Apr. 1995, 31.
10. - Genesis 2:18.
11. - Genesis 2:18, footnote b.
12. - See Bruce K. Satterfield, “The Family under Siege: The Role of Man and Woman” (presentation given at Ricks College Education Week, June 7, 2001), 4; emp.byui.edu/SATTERFIELDB/PDF/RoleManWoman2.pdf.
13. - Handbook 2: Administering the Church (2010), 1.3.1.
14. - Barbara B. Smith, “Hearts So Similar,” Ensign, May 1982, 97.
15. - “Daddy’s Homecoming,” Children’s Songbook, 210.
16. - “Let Us Oft Speak Kind Words,” Hymns, no. 232.
17. - David A. Bednar, “We Believe in Being Chaste,” Ensign or Liahona, May 2013, 44.
18. - Jeffrey R. Holland, “The Tongue of Angels,” Ensign or Liahona, May 2007, 18.