Elder Dallin H. Oaks
Of the Quorum of the Twelve Apostles
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/the-parable-of-the-sower?lang=eng)

_It is up to each of us to set the priorities and to do the things that make our soil good and our harvest plentiful._

Subjects for general conference talks are assigned—not by mortal authority but by the impressions of the Spirit. Many subjects would address the mortal concerns we all share. But just as Jesus did not teach how to overcome the mortal challenges or political oppression of His day, He usually inspires His modern servants to speak about what we must do to reform our personal lives to prepare us to return to our heavenly home. On this Easter weekend I have felt impressed to talk about the precious and timeless teachings in one of the parables of Jesus.

The parable of the sower is one of a small number of parables reported in all three of the synoptic Gospels. It is also one of an even smaller group of parables Jesus explained to His disciples. The seed that was sown was “the word of the kingdom” (Matthew 13:19), “the word” (Mark 4:14), or “the word of God” (Luke 8:11)—the teachings of the Master and His servants.

The different soils on which the seeds fell represent different ways in which mortals receive and follow these teachings. Thus the seeds that “fell by the way side” (Mark 4:4) have not reached mortal soil where they might possibly grow. They are like teachings that fall upon a heart hardened or unprepared. I will say nothing more of these. My message concerns those of us who have committed to be followers of Christ. What do we do with the Savior’s teachings as we live our lives?

The parable of the sower warns us of circumstances and attitudes that can keep anyone who has received the seed of the gospel message from bringing forth a goodly harvest.





I. Stony Ground, No Root



Some seed “fell on stony ground, where it had not much earth; and immediately it sprang up, because it had no depth of earth: but when the sun was up, it was scorched; and because it had no root, it withered away” (Mark 4:5–6).

Jesus explained that this describes those “who, when they have heard the word, immediately receive it with gladness,” but because they “have no root in themselves, … when affliction or persecution ariseth for the word’s sake, immediately they are offended” (Mark 4:16–17).

What causes hearers to “have no root in themselves”? This is the circumstance of new members who are merely converted to the missionaries or to the many attractive characteristics of the Church or to the many great fruits of Church membership. Not being rooted in the word, they can be scorched and wither away when opposition arises. But even those raised in the Church—long-term members—can slip into a condition where they have no root in themselves. I have known some of these—members without firm and lasting conversion to the gospel of Jesus Christ. If we are not rooted in the teachings of the gospel and regular in its practices, any one of us can develop a stony heart, which is stony ground for spiritual seeds.

Spiritual food is necessary for spiritual survival, especially in a world that is moving away from belief in God and the absolutes of right and wrong. In an age dominated by the Internet, which magnifies messages that menace faith, we must increase our exposure to spiritual truth in order to strengthen our faith and stay rooted in the gospel.

Young people, if that teaching seems too general, here is a specific example. If the emblems of the sacrament are being passed and you are texting or whispering or playing video games or doing anything else to deny yourself essential spiritual food, you are severing your spiritual roots and moving yourself toward stony ground. You are making yourself vulnerable to withering away when you encounter tribulation like isolation, intimidation, or ridicule. And that applies to adults also.

Another potential destroyer of spiritual roots—accelerated by current technology but not unique to it—is the keyhole view of the gospel or the Church. This limited view focuses on a particular doctrine or practice or perceived deficiency in a leader and ignores the grand panorama of the gospel plan and the personal and communal fruits of its harvest. President Gordon B. Hinckley gave a vivid description of one aspect of this keyhole view. He told a BYU audience about political commentators “aflame with indignation” at a then-recent news event. “With studied art they poured out the sour vinegar of invective and anger. … Surely,” he concluded, “this is the age and place of the gifted pickle sucker.”1 In contrast, to be securely rooted in the gospel, we must be moderate and measured in criticism and seek always for the broader view of the majestic work of God.







II. Thorns: The Cares of This World and the Deceitfulness of Riches



Jesus taught that “some fell among thorns, and the thorns grew up, and choked it, and it yielded no fruit” (Mark 4:7). He explained that these are “such as hear the word, and the cares of this world, and the deceitfulness of riches, and the lusts of other things entering in, choke the word, and it becometh unfruitful” (Mark 4:18–19). This is surely a warning to be heeded by all of us.

I will speak first of the deceitfulness of riches. Wherever we are in our spiritual journey—whatever our state of conversion—we are all tempted by this. When attitudes or priorities are fixed on the acquisition, use, or possession of property, we call that materialism. So much has been said and written about materialism that little needs to be added here.2 Those who believe in what has been called the theology of prosperity are suffering from the deceitfulness of riches. The possession of wealth or significant income is not a mark of heavenly favor, and their absence is not evidence of heavenly disfavor. When Jesus told a faithful follower that he could inherit eternal life if he would only give all that he had to the poor (see Mark 10:17–24), He was not identifying an evil in the possession of riches but an evil in that follower’s attitude toward them. As we are all aware, Jesus praised the good Samaritan, who used the same coinage to serve his fellowman that Judas used to betray his Savior. The root of all evil is not money but the love of money (see 1 Timothy 6:10).

The Book of Mormon tells of a time when the Church of God “began to fail in its progress” (Alma 4:10) because “the people of the church began to … set their hearts upon riches and upon the vain things of the world” (Alma 4:8). Whoever has an abundance of material things is in jeopardy of being spiritually “sedated” by riches and other things of the world.3 That is a suitable introduction to the next of the Savior’s teachings.

The most subtle thorns to choke out the effect of the gospel word in our lives are the worldly forces that Jesus called the “cares and riches and pleasures of this life” (Luke 8:14). These are too numerous to recite. Some examples will suffice.

On one occasion Jesus rebuked His chief Apostle, saying to Peter, “Thou art an offence unto me: for thou savourest not the things that be of God, but those that be of men” (Matthew 16:23; see also D&C 3:6–7; 58:39). Savoring the things of men means putting the cares of this world ahead of the things of God in our actions, our priorities, and our thinking.

We surrender to the “pleasures of this life” (1) when we are addicted, which impairs God’s precious gift of agency; (2) when we are beguiled by trivial distractions, which draw us away from things of eternal importance; and (3) when we have an entitlement mentality, which impairs the personal growth necessary to qualify us for our eternal destiny.

We are overcome by the “cares … of this life” when we are paralyzed by fear of the future, which hinders our going forward in faith, trusting in God and His promises. Twenty-five years ago my esteemed BYU teacher Hugh W. Nibley spoke of the dangers of surrendering to the cares of the world. He was asked in an interview whether world conditions and our duty to spread the gospel made it desirable to seek some way to “be accommodating of the world in what we do in the Church.”4

His reply: “That’s been the whole story of the Church, hasn’t it? You have to be willing to offend here, you have to be willing to take the risk. That’s where the faith comes in. … Our commitment is supposed to be a test, it’s supposed to be hard, it’s supposed to be impractical in the terms of this world.”5

This gospel priority was affirmed on the BYU campus just a few months ago by an esteemed Catholic leader, Charles J. Chaput, the archbishop of Philadelphia. Speaking of “concerns that the LDS and Catholic communities share,” such as “about marriage and family, the nature of our sexuality, the sanctity of human life, and the urgency of religious liberty,” he said this:

“I want to stress again the importance of really living what we claim to believe. That needs to be a priority—not just in our personal and family lives but in our churches, our political choices, our business dealings, our treatment of the poor; in other words, in everything we do.”

“Here’s why that’s important,” he continued. “Learn from the Catholic experience. We Catholics believe that our vocation is to be leaven in society. But there’s a fine line between being leaven in society, and being digested by society.”6

The Savior’s warning against having the cares of this world choke out the word of God in our lives surely challenges us to keep our priorities fixed—our hearts set—on the commandments of God and the leadership of His Church.

The Savior’s examples could cause us to think of this parable as the parable of the soils. The suitability of the soil depends upon the heart of each one of us who is exposed to the gospel seed. In susceptibility to spiritual teachings, some hearts are hardened and unprepared, some hearts are stony from disuse, and some hearts are set upon the things of the world.







III. Fell into Good Ground and Brought Forth Fruit



The parable of the sower ends with the Savior’s description of the seed that “fell into good ground, and brought forth fruit” in various measures (Matthew 13:8). How can we prepare ourselves to be that good ground and to have that good harvest?

Jesus explained that “the good ground are they, which in an honest and good heart, having heard the word, keep it, and bring forth fruit with patience” (Luke 8:15). We have the seed of the gospel word. It is up to each of us to set the priorities and to do the things that make our soil good and our harvest plentiful. We must seek to be firmly rooted and converted to the gospel of Jesus Christ (see Colossians 2:6–7). We achieve this conversion by praying, by scripture reading, by serving, and by regularly partaking of the sacrament to always have His Spirit to be with us. We must also seek that mighty change of heart (see Alma 5:12–14) that replaces evil desires and selfish concerns with the love of God and the desire to serve Him and His children.

I testify of the truth of these things, and I testify of our Savior, Jesus Christ, whose teachings point the way and whose Atonement makes it all possible, in the name of Jesus Christ, amen.

# References
1. - Gordon B. Hinckley, “Let Not Your Heart Be Troubled” (Brigham Young University devotional, Oct. 29, 1974), 1; speeches.byu.edu.
2. - See, for example, Dallin H. Oaks, “Materialism,” chapter 5 in Pure in Heart (1988), 73–87.
3. - I am indebted to Elder Neal A. Maxwell for this memorable image (see “These Are Your Days,” Ensign, Oct. 2004, 26).
4. - James P. Bell, in “Hugh Nibley, in Black and White,” BYU Today, May 1990, 37.
5. - Hugh Nibley, in “Hugh Nibley, in Black and White,” 37–38.
6. - Charles J. Chaput, “The Great Charter at 800: Why It Still Matters,” First Things, Jan. 23, 2015, firstthings.com/web-exclusives/2015/01/the-great-charter-at-800; see also Tad Walch, “At BYU, Catholic Archbishop Seeks Friends, Says U.S. Liberty Depends on Moral People,” Deseret News, Jan. 23, 2015, deseretnews.com/article/865620233/At-BYU-Catholic-archbishop-seeks-friends-says-US-liberty-depends-on-moral-people.html. Archbishop Chaput also said that “some of our best Catholic institutions have either lost or greatly softened their religious identity. … Brigham Young is an extraordinary university … because it’s a center of learning enriched by its religious identity. Never lose that” (“The Great Charter at 800”).