President Henry B. Eyring
First Counselor in the First Presidency
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/priesthood-and-personal-prayer?lang=eng)

_God can grant us power in the priesthood for whatever circumstance we may be in. It simply requires that we ask in humility._

I am grateful for the trust to speak to holders of the priesthood of God in all the earth. I feel the weight of that opportunity because I know something of the trust that the Lord has placed in you. With your acceptance of the priesthood, you have received the right to speak and to act in the name of God.

That right will become a reality only as you receive inspiration from God. Only then will you be able to speak in His name. And only then can you act in His name. You might have made the mistake of thinking, “Oh, that isn’t so difficult. I could get inspiration if I am ever asked to give a talk or if I ever need to give a priesthood blessing.” Or the young deacon or teacher might take comfort in the thought, “When I am older or when I am called as a missionary, then I will know what God would say and what God would do.”

But think of the day when you must know what God would say and what He would do. It has already come for us all—wherever you are in your calling in the priesthood. I grew up in the mission field in the eastern United States during World War II. The members of the Church lived far apart, and there was strict gas rationing. I was the only deacon in the branch. The members gave their fast-offering envelopes to the branch president when they came to fast and testimony meeting in our home.

When I was 13 years old, we moved to Utah to live in a large ward. I remember my first assignment to walk to homes to collect fast offerings. I looked at the name on one of the envelopes I was given and noticed the last name was the same as one of the Three Witnesses of the Book of Mormon. So I knocked on the door with confidence. The man opened the door, looked at me, scowled, and then barked at me to go away. I went away with my head down.

That was nearly 70 years ago, but I still remember the feeling I had that day on the doorstep that there was something I was supposed to have said or done. If only I had prayed in faith as I went out that day, I might have been inspired to stand a moment longer on that doorstep, smile, and say something like: “It is good to meet you. Thank you for what you and your family have given in the past. I look forward to seeing you next month.”

Had I said and done that, he might have been even more irritated—and even offended. But I know now how I might have felt. Rather than feeling sadness or failure as I walked away, I might have felt the soft commendation in my mind and heart: “Well done.”

All of us must speak and act in the name of God in moments when our unaided judgment will not be enough without inspiration. Those moments can come upon us when there is not time to make preparation. That has happened to me often. It did many years ago in a hospital when a father told me and my companion that the doctors had told him that his critically injured three-year-old daughter would die within minutes. As I placed my hands on the one spot on her head not covered with bandages, I had to know, as God’s servant, what He would do and say.

The words came to my mind and my lips that she would live. The doctor standing by me snorted in disgust and asked me to get out of the way. I walked out of that hospital room with a feeling of peace and love. The little girl lived and walked down the aisle into a sacrament meeting on my last day in that city. I still remember the joy and satisfaction I felt from what I had said and done in the Lord’s service for that little girl and her family.

The difference in my feelings at the hospital and the sadness I felt as I walked away from that door as a deacon came from what I had learned about the connection of prayer to priesthood power. As a deacon, I had not yet learned that the power to speak and act in God’s name requires revelation and that to have it when we need it requires praying and working in faith for the companionship of the Holy Ghost.

On the evening before I went to that door for fast offerings, I had said my prayers at bedtime. But for weeks and months before that phone call came from the hospital, I had followed a pattern of prayer and made the effort that President Joseph F. Smith taught will allow God to give us the inspiration necessary for us to have power in the priesthood. He put it simply:

“We do not have to cry unto him with many words. We do not have to weary him with long prayers. What we do need, and what we should do as Latter-day Saints, for our own good, is to go before him often, to witness unto him that we remember him and that we are willing to take upon us his name, keep his commandments, work righteousness; and that we desire his Spirit to help us.”1

And then President Smith told us what we should pray for, as his servants pledged to speak and act for God. He said: “What do you pray for? You pray that God may recognize you, that he may hear your prayers, and that he may bless you with his Spirit.”2

It is not a matter so much of which words to use, but it will take some patience. It is an approach to your Heavenly Father with the intent to be recognized by Him personally. He is the God above all, the Father of all, and yet willing to give undivided attention to one of His children. That may be why the Savior used the words “Our Father which art in heaven, Hallowed be thy name.”3

It is easier to get the proper feeling of reverence when you are kneeling or bowing your head, but it is possible to feel that you are approaching your Heavenly Father in less formal and even in silent prayer, as you will often need to do in your priesthood service. There will be noise and people around you most of your waking day. God hears your silent prayers, but you may have to learn to shut out the distractions because the moment you need the connection with God may not come in quiet times.

President Smith suggested that you will need to pray that God will recognize your call to serve Him. He already knows about your call in complete detail. He called you, and by praying to Him about your call, He will reveal more for you to know.4

I will give you an example of what a home teacher might do as he prays. You may already know that you are to:

“Visit the house of each member, exhorting them to pray vocally and in secret and attend to all family duties. …

“… Watch over the church always, and be with and strengthen them;

“And see that there is no iniquity in the church, neither hardness with each other, neither lying, backbiting, nor evil speaking;

“And see that the church meet together often, and also see that all the members do their duty.”5

Now, even for the experienced home teacher and his junior companion, that is clearly impossible without the help of the Holy Ghost. Think of the families or even individuals you have been called to serve. Human judgment and good intentions will not be enough.

So you will pray for the way to know their hearts, to know what things are amiss in the lives and the hearts of people whom you don’t know well and who are not anxious to have you know them. You will need to know what God would have you do to help them and to do it all, as nearly as you can, feeling God’s love for them.



It is because you have such important and difficult priesthood calls that President Smith suggests that when you pray, you always plead with God that He will bless you with His Spirit. You will need the Holy Ghost not once but as much as God will grant it to you for your constant companion. That is why we must always pray that God will guide us in our service to His children.

Because you cannot rise to your priesthood potential without the Spirit going with you, you are a personal target for the enemy of all happiness. If he can tempt you to sin, he can lessen your power to be led by the Spirit and so reduce your power in the priesthood. That is why President Smith said that you should always pray that God will warn and protect you from evil.6

He warns us in many ways. Warnings are part of the plan of salvation. Prophets, apostles, stake presidents, bishops, and missionaries all raise the warning voice to escape calamity through faith in Jesus Christ, repentance, and making and keeping sacred covenants.

As a priesthood holder, you are to be part of the warning voice of the Lord. But you need to heed the warning yourself. You will not survive spiritually without the protection of the companionship of the Holy Ghost in your daily life.

You must pray for it and work to have it. Only with that guide will you be able to find your way along the strait and narrow path through the mists of evil. The Holy Ghost will be your guide as He reveals truth when you study the words of prophets.

Getting that guidance will take more than casual listening and reading. You will need to pray and work in faith to put the words of truth down into your heart. You must pray that God will bless you with His Spirit, that He will lead you into all truth and show you the right way. That is how He will warn and guide you into the right path in your life and in your priesthood service.

General conference provides a great opportunity to let the Lord strengthen your power to serve in the priesthood of God. You can prepare yourself, as I’m sure you have for this conference, with prayer. You can join your faith with those who will pray in the conference. They will pray for many blessings on many people.

They will pray for the Spirit to come upon the prophet as the Lord’s mouthpiece. They will pray for the Apostles and all of the servants called by God. That includes you, from the newest deacon to the seasoned high priest, and some, both old and young, who may soon go to the spirit world, where they will hear, “Well done, thou good and faithful servant.”7

That salutation will go to some who will be surprised by it. They may never have held high office in the kingdom of God on the earth. Some may have felt that they saw little result from their labors or that some opportunities to serve were never given to them. Others may feel that their time of service was cut shorter in this life than they had hoped.

It will not be the offices held or the time served that will be weighed in the balance with the Lord. We know this from the Lord’s parable of the laborers in the vineyard, where the pay was the same regardless of how long they served or where. They will be rewarded for how they served.8

I know a man, a dear friend, whose mortal service in the vineyard ended last night at 11:00. He had been treated for cancer for years. During those years of treatment and of terrible pain and difficulty, he accepted a call to hold meetings with and be responsible for members in his ward whose children were gone from their homes; some were widows. His calling was to help them find comfort in sociality and gospel learning.

When he got the final sobering prognosis that he had only a short time to live, his bishop was away for a business trip. Two days later, he sent a message to his bishop through his high priests group leader. He said this about his assignment: “I understand the bishop is out of town, so I’m in action. I’m thinking of a meeting for our group next Monday. Two members can take us for a tour of the Conference Center. We could use some members to drive them and some Scouts to push wheelchairs. Depending upon who signs up, we may have enough oldsters to do it ourselves, but it would be good to know we have backup if needed. It could also be a good family night for the helpers to bring their families as well. Anyway let me know before I post the plan. … Thanks.”

And then he surprised the bishop with a phone call. Without reference to his own condition or his valiant efforts in his assignment, he asked, “Bishop, is there anything I could do for you?” Only the Holy Ghost could have allowed him to feel the bishop’s load when his own load was so crushing. And only the Spirit could have made it possible for him to create a plan to serve his brothers and sisters with the same precision he used in planning Scouting events when he was young.

With a prayer of faith, God can grant us power in the priesthood for whatever circumstance we may be in. It simply requires that we ask in humility for the Spirit to show us what God would have us say and do, do it, and continue to live worthy of that gift.

I bear you my testimony that God the Father lives, loves us, and hears our every prayer. I bear testimony that Jesus is the living Christ, whose Atonement makes it possible for us to be purified and so be worthy of the companionship of the Holy Ghost. I testify that with our faith and diligence, we can one day hear the words that will bring us joy: “Well done, thou good and faithful servant.”9 I pray that we will receive that wonderful benediction from the Master we serve. In the name of Jesus Christ, amen.

# References
1. - Teachings of Presidents of the Church: Joseph F. Smith (1998), 23.
2. - Teachings: Joseph F. Smith, 26.
3. - Luke 11:2.
4. - See Joseph F. Smith, Gospel Doctrine, 5th ed. (1939), 215–21.
5. - Doctrine and Covenants 20:51, 53–55.
6. - See Teachings: Joseph F. Smith, 26.
7. - Matthew 25:21.
8. - See Matthew 20:1–16.
9. - Matthew 25:21.