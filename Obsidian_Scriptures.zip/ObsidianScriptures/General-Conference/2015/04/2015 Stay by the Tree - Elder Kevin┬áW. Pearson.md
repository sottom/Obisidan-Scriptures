Elder Kevin W. Pearson
Of the Seventy
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/stay-by-the-tree?lang=eng)

_Lehi’s vision of the tree of life is a powerful parable on enduring to the end._

Shortly before President Heber J. Grant passed away, one of the Brethren visited his home. Before he left, President Grant prayed, “O God, bless me that I shall not lose my testimony and keep faithful to the end!”1 After nearly 27 years as President of the Church, this was his fervent prayer. His example is a striking reminder that no one, at any age, is immune from Satan’s influence. Two of Satan’s most powerful tools are distraction and deception.

Enduring to the end is a hallmark of true discipleship and is essential to eternal life. But when trials and challenges come our way, we are often told to simply “hang in there.” Let me be clear: to “hang in there” is not a principle of the gospel. Enduring to the end means constantly coming unto Christ and being perfected in Him.

If enduring to the end is essential to eternal life, why do we struggle to be faithful? We struggle when we are caught between competing priorities. Casual obedience and lukewarm commitment weaken faith. Enduring to the end requires total commitment to the Savior and to our covenants.

Lehi’s vision of the tree of life is a powerful parable on enduring to the end. Please prayerfully study and ponder Lehi’s dream; then liken it unto yourself. As you do, carefully consider six important principles that help us endure to the end.





1. Don’t Forget to Pray



We begin with Lehi alone “in a dark and dreary waste.”2 Each of us experiences periods of darkness and loneliness. “When life gets dark and dreary, don’t forget to pray.”3 Follow President Heber J. Grant’s example. Pray for strength to endure to the end. Ask Heavenly Father, “What more would You have me do?”







2. Come unto Christ and Be Perfected in Him



The tree of life is the central focus in Lehi’s dream. Everything points to the tree of life. The tree represents Christ, who is the clear manifestation of the love of God. The fruit is His infinite Atonement and is great evidence of God’s love. Eternal life with our loved ones is sweeter and more desirable than any other thing. To realize this gift, we must “come unto Christ, and be perfected in him.”4 He is “the way, the truth, and the life.”5 We can fill our lives with accomplishment and well-doing, but in the end, if we do not enter into sacred covenants to follow Christ and faithfully keep them, we will have utterly and completely missed the mark.







3. Press Forward with Faith



There is a path that leads to the tree of life, to Christ. It is strait and narrow, strict and exact. God’s commandments are strict but not restrictive. They protect us from spiritual and physical danger and prevent us from getting lost.

Obedience builds faith in Christ. Faith is a principle of action and power. Consistently following the Savior’s example produces spiritual power and capacity. Without the strengthening and enabling power of the Atonement, it’s impossible to stay on the path and endure.

“Press forward with a steadfastness in Christ.”6







4. The Book of Mormon Is Key to Spiritual Survival



Life’s journey is challenging. It’s easy to be distracted, wander off the path, and get lost. Tribulation is an inevitable and indispensable part of our eternal progression. When adversity comes, don’t let something you don’t fully understand unravel everything you do know. Be patient, cling to truth; understanding will come. Trials are like great mists of darkness that can blind our eyes and harden our hearts. Unless we are “continually holding fast”7 to the word of God and living it, we will become spiritually blinded rather than spiritually minded. Search the Book of Mormon and the words of the living prophets every day, every day, every day! It’s the key to spiritual survival and avoiding deception. Without it, we are spiritually lost.







5. Don’t Be Distracted and Deceived



To heed is to give careful attention. Heeding those who do not believe in Christ will not help you find Him. Searching #spaciousbuilding for knowledge will not lead you to truth. It’s not posted there. Only the Savior has “the words of eternal life.”8 Everything else is just words. The large and spacious building symbolizes the “vain imaginations and the pride”9 of the world—in other words, distraction and deception. It’s filled with well-dressed people who seem to have everything. But they mock the Savior and those who follow Him. They are “ever learning, and never able to come to the knowledge of the truth.”10 They may be politically correct, but they are spiritually lost.







6. Stay by the Tree



Lehi’s message is to stay by the tree. We stay because we are converted unto the Lord. Alma taught, “Behold, he changed their hearts; yea, he awakened them out of a deep sleep, and they awoke unto God.”11 As we yield our hearts to God, the Holy Ghost changes our very natures, we become deeply converted unto the Lord, and we no longer seek the spacious building. If we stop doing those things that bring about deepening conversion, we regress spiritually. Apostasy is the reverse of conversion.

To all missionaries past and present: Elders and sisters, you simply cannot return from your mission, do a swan dive back into Babylon, and spend endless hours scoring meaningless points on pointless video games without falling into a deep spiritual sleep. Nor can you indulge in online pornography and ignore virtue and chastity without dire spiritual consequences. If you lose the Spirit, you are lost. Don’t be distracted and deceived.



True disciples continue to awaken unto God each day in meaningful personal prayer, earnest scripture study, personal obedience, and selfless service. Stay by the tree and stay awake.

Several years ago, Sister Pearson and I were called to preside over the Washington Tacoma Mission. The call was a complete surprise. With some trepidation I met with the chairman and the CEO of the company where I was employed and informed them of my mission call. They were visibly upset with my decision to leave the firm. “When did you make this decision, and why didn’t you discuss it with us earlier?” they demanded.

In a moment of clarity, a profound answer came into my mind. I said, “I made this decision as a 19-year-old boy, when I made sacred covenants with God in the temple to follow the Savior. I’ve built my entire life on those covenants, and I fully intend to keep them now.”

Once we enter into covenants with God, there is no going back. Giving in, giving up, and giving out are not options. In the kingdom of God, there is a standard of excellence for exaltation. It requires valiant discipleship! There is no room for average or complacent disciples. Average is the enemy of excellence, and average commitment will prevent you from enduring to the end.

If you are struggling, confused, or spiritually lost, I urge you to do the one thing I know will get you back on track. Begin again to prayerfully study the Book of Mormon and live its teachings every day, every day, every day! I testify of the profound power in the Book of Mormon that will change your life and strengthen your resolve to follow Christ. The Holy Ghost will change your heart and help you see “things as they really are.”12 He will show you what you need to do next. This is Nephi’s promise to you:

“And I said unto them … whoso would hearken unto the word of God, and would hold fast unto it, they would never perish; neither could the temptations and the fiery darts of the adversary overpower them unto blindness, to lead them away to destruction.

“Wherefore, I … did exhort them … that they would give heed to the word of God and remember to keep his commandments always in all things.”13

Brothers and sisters, enduring to the end is the great test of discipleship. Our daily discipleship will determine our eternal destiny. Awaken unto God, cling to truth, keep your sacred temple covenants, and stay by the tree!

I bear witness of the resurrected, living Christ. I know that He lives. My greatest desire is that I will be true and faithful to the very end in following His magnificent example. In the sacred name of the Lord Jesus Christ, amen.

# References
1. - Quoted by John Longden, in Conference Report, Oct. 1958, 70.
2. - 1 Nephi 8:7.
3. - “Did You Think to Pray?” Hymns, no. 140.
4. - Moroni 10:32.
5. - John 14:6.
6. - 2 Nephi 31:20.
7. - 1 Nephi 8:30.
8. - John 6:68.
9. - 1 Nephi 12:18.
10. - 2 Timothy 3:7.
11. - Alma 5:7.
12. - Jacob 4:13.
13. - 1 Nephi 15:24–25.