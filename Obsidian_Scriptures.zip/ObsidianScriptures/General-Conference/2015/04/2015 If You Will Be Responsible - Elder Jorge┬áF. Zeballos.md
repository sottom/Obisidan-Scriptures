Elder Jorge F. Zeballos
Of the Seventy
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/if-you-will-be-responsible?lang=eng)

_Let us press forward by learning our duty, making correct decisions, acting according to those decisions, and accepting the will of our Father._

I was only 12 years old when the missionaries arrived for the first time to preach in the city where I was born in northern Chile. One Sunday, after I had been attending the small branch for six months, a missionary offered me the bread as he was passing the sacrament. I looked at him and softly said, “I can’t.”

“Why not?” he replied.

I told him, “Because I am not a member of the Church.”1

The missionary couldn’t believe it. His eyes were shining. I suppose he thought, “But this young man is in every single meeting! How can he not be a member of the Church?”

The following day, the missionaries were in my home, and they did everything they could to teach my whole family. But since my family was not interested, it was only my weekly Church attendance for more than six months that made the missionaries feel confident enough to continue. Finally, the great moment I had been waiting for came when they invited me to become a member of the Church of Jesus Christ. The missionaries explained to me that since I was a minor, I would need my parents’ permission. I went with the missionaries to see my father, thinking that his loving answer would be “Son, when you are of legal age, you will be able to make your own decisions.”

While the missionaries spoke with him, I prayed fervently for his heart to be touched so he would give me the permission I wanted. His answer to the missionaries was the following: “Elders, over the past six months, I have seen my son Jorge get up early every Sunday morning, put on his best clothes, and walk to church. I have seen only a good influence from the Church in his life.” Then, addressing me, he surprised me by saying, “Son, if you will be responsible for this decision, then you have my permission to be baptized.” I hugged my father, gave him a kiss, and thanked him for what he was doing. The next day I was baptized. Last week was the 47th anniversary of that important moment in my life.

What responsibility do we have as members of the Church of Jesus Christ? President Joseph Fielding Smith expressed it as follows: “We have these two great responsibilities. … First, to seek our own salvation; and, second, our duty to our fellow men.”2

These, then, are the main responsibilities that our Father has assigned to us: seeking our own salvation and that of others, with the understanding that in this statement, salvation means reaching the highest degree of glory that our Father has provided for His obedient children.3 These responsibilities that have been entrusted to us—and which we have freely accepted—must define our priorities, our desires, our decisions, and our daily conduct.

For someone who has come to understand that, because of the Atonement of Jesus Christ, exaltation is truly within reach, failing to obtain it constitutes damnation. Thus, the opposite of salvation is damnation, just like the opposite of success is failure. President Thomas S. Monson has taught us that “men cannot really long rest content with mediocrity once they see excellence is within their reach.”4 How, then, could we be content with anything short of exaltation if we know that exaltation is possible?

Allow me to share four key principles that will help us fulfill our desire to be responsible to our Father in Heaven as well as respond to His expectation that we become as He is.





1. Learning Our Duty



If we are to do God’s will, if we are to be responsible to Him, we must begin by learning, understanding, accepting, and living according to His will for us. The Lord has said, “Wherefore, now let every man learn his duty, and to act in the office in which he is appointed, in all diligence.”5 Having the desire to do what is right is not enough if we do not make sure to understand what our Father expects from us and wants us to do.

In the story of Alice in Wonderland, Alice does not know which way to go, so she asks the Cheshire Cat, “Would you tell me, please, which way I ought to go from here?”

The cat replies, “That depends a good deal on where you want to get to.”

Alice says, “I don’t much care where.”

“Then it doesn’t matter which way you go,” says the cat.6

However, we know that the path that leads to the “tree, whose fruit [is] desirable to make one happy”7—“the way, which leadeth unto life”—is narrow. It takes effort to journey along the path, and “few there be that find it.”8

Nephi teaches us that “the words of Christ will tell you all things what ye should do.”9 Then he adds that “the Holy Ghost … will show unto you all things what ye should do.”10 Thus, the sources that allow us to learn our duty are the words of Christ that we receive through ancient and modern prophets and the personal revelation that we receive through the Holy Ghost.







2. Making the Decision



Whether we have learned about the Restoration of the gospel, a particular commandment, the duties associated with serving in a calling, or the covenants we make in the temple, the choice is ours whether or not we act according to that new knowledge. Each person chooses freely for himself or herself to enter into a sacred covenant such as baptism or the temple ordinances. Because swearing oaths was a normal part of people’s religious lives in antiquity, the old law stated that “ye shall not swear by my name falsely.”11 However, in the meridian of time, the Savior taught a higher way of keeping our commitments when He said that yes meant yes and no meant no.12 A person’s word ought to be sufficient to establish his or her truthfulness and commitment toward someone else—and even more so when that someone else is our Father in Heaven. Honoring a commitment becomes the manifestation of the truthfulness and honesty of our word.







3. Acting Accordingly



After learning our duty and making the decisions that are associated with that learning and understanding, we must act accordingly.

A powerful example of the firm determination to meet His commitment with His Father comes from the Savior’s experience of having a man sick with palsy brought to Him to be healed. “When Jesus saw their faith, he said unto the sick of the palsy, Son, thy sins be forgiven thee.”13 We know that the Atonement of Jesus Christ is essential to receiving forgiveness for our sins, but during the episode of the healing of the man with palsy, that grand event had not yet taken place; the Savior’s suffering in Gethsemane and on the cross had not yet happened. However, Jesus not only blessed the man with palsy with the ability to stand up and walk, but He also granted him forgiveness for his sins, thereby giving an unequivocal sign that He would not fail, that He would fulfill the commitment He had made with His Father, and that in Gethsemane and on the cross He would do what He had promised to do.

The path that we have chosen to walk is narrow. Along the way are challenges that will require our faith in Jesus Christ and our best efforts to stay on the path and press forward. We need to repent and be obedient and patient, even if we do not understand all the circumstances that surround us. We must forgive others and live in accordance with what we have learned and with the choices we have made.







4. Willingly Accepting the Father’s Will



Discipleship requires us not only to learn our duty, make correct decisions, and act in accordance with them, but also essential is our developing the willingness and the ability to accept God’s will, even if it does not match our righteous desires or preferences.

I am impressed by and admire the attitude of the leper who came to the Lord, “beseeching him, and kneeling down to him, and saying unto him, If thou wilt, thou canst make me clean.”14 The leper did not demand anything, even though his desires might have been righteous; he was simply willing to accept the will of the Lord.

Some years ago a dear, faithful couple who are friends of mine were blessed with the arrival of a long-yearned-for son, for whom they had been praying for a long time. That home was filled with joy while our friends and their daughter, who was their only other child back then, enjoyed the company of the newly arrived little boy. One day, however, something unexpected happened: the little boy, who was only about three years old, suddenly went into a coma. As soon as I learned of the situation, I called my friend to express our support at that difficult time. But his reply was a lesson to me. He said, “If it is the Father’s will to take him to Him, then it is all right with us.” My friend’s words contained not the slightest degree of complaint, rebelliousness, or discontent. Quite the contrary, all I could feel in his words was gratitude to God for having allowed them to enjoy their little son for that brief time, as well as his total willingness to accept the Father’s will for them. A few days later, that little one was taken to his celestial mansion.

Let us press forward by learning our duty, making correct decisions, acting according to those decisions, and accepting the will of our Father.

How grateful and happy I am for the decision that my father let me make 47 years ago. Over time, I have come to understand that the condition he gave me—to be responsible for that decision—meant being responsible to my Heavenly Father and seeking my own salvation and that of my fellowmen, thereby becoming more as my Father expects and wants me to become. On this very special day, I testify that God our Father and His Beloved Son live. In the name of Jesus Christ, amen.





This address was delivered in Spanish.

# References
1. - Please note that “although the sacrament is for Church members, the bishopric should not announce that it will be passed to members only, and nothing should be done to prevent nonmembers from partaking of it” (Handbook 2: Administering the Church [2010], 20.4.1).
2. - Teachings of Presidents of the Church: Joseph Fielding Smith (2013), 294.
3. - See Doctrine and Covenants 132:21–23.
4. - Thomas S. Monson, “To the Rescue,” Ensign, May 2001, 49; Liahona, July 2001, 58.
5. - Doctrine and Covenants 107:99.
6. - Lewis Carroll, Alice’s Adventures in Wonderland (1920), 89.
7. - 1 Nephi 8:10.
8. - Matthew 7:14.
9. - 2 Nephi 32:3.
10. - 2 Nephi 32:5.
11. - Leviticus 19:12.
12. - See Matthew 5:37.
13. - Mark 2:5.
14. - Mark 1:40.