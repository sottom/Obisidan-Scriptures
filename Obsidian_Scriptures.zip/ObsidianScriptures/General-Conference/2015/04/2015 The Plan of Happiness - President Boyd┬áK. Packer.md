President Boyd K. Packer
President of the Quorum of the Twelve Apostles
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/the-plan-of-happiness?lang=eng)

_The end of all activity in the Church is to see that a man and a woman with their children are happy at home, sealed for eternity._

Many years ago, after World War II, I was attending college. There I met Donna Smith. About that time I read that two essential ingredients to a successful marriage are a cookie and a kiss. I thought that was a pretty good balance.

I attended college in the morning and then went back to Brigham City to work in my father’s auto-repair garage in the afternoon. Donna’s last morning class was home economics. I stopped by her classroom before leaving. The door had a frosted glass window, but if I stood close to the glass, she could see my shadow outside. She would slip out with a cookie and a kiss. The rest is history. We were married in the Logan Utah Temple, and that began the great adventure of our lives.

Over the years I have frequently taught an important principle: the end of all activity in the Church is to see that a man and a woman with their children are happy at home, sealed together for time and for all eternity.

In the beginning:

“The Gods went down to organize man in their own image, in the image of the Gods to form they him, male and female to form they them.

“And the Gods said: We will bless them. And the Gods said: We will cause them to be fruitful and multiply, and replenish the earth, and subdue it” (Abraham 4:27–28).

And so the cycle of human life began on this earth as “Adam knew his wife, and she bare unto him sons and daughters, and they began to multiply and to replenish the earth.

“And … the sons and daughters of Adam began to divide two and two in the land, … and they also begat sons and daughters” (Moses 5:2–3).

The commandment to multiply and replenish the earth has never been rescinded. It is essential to the plan of redemption and is the source of human happiness. Through the righteous exercise of this power, we may come close to our Father in Heaven and experience a fulness of joy, even godhood. The power of procreation is not an incidental part of the plan; it is the plan of happiness; it is the key to happiness.

The desire to mate in humankind is constant and very strong. Our happiness in mortal life, our joy and exaltation are dependent upon how we respond to these persistent, compelling physical desires. As the procreative power matures in early manhood and womanhood, very personal feelings occur, in a natural way, unlike any other physical experience.

Ideally, mating begins with romance. Though customs may vary, it flourishes with all the storybook feelings of excitement and anticipation, even sometimes rejection. There are moonlight and roses, love letters, love songs, poetry, the holding of hands, and other expressions of affection between a young man and a young woman. The world disappears around the couple, and they experience feelings of joy.

And if you suppose that the full-blown rapture of young romantic love is the sum total of the possibilities which spring from the fountains of life, you have not yet lived to see the devotion and the comfort of longtime married love. Married couples are tried by temptation, misunderstandings, financial problems, family crises, and illness, and all the while love grows stronger. Mature love has a bliss not even imagined by newlyweds.

True love requires reserving until after marriage the sharing of that affection which unlocks those sacred powers in that fountain of life. It means avoiding situations where physical desire might take control. Pure love presupposes that only after a pledge of eternal fidelity, a legal and lawful ceremony, and ideally after the sealing ordinance in the temple are those procreative powers released in God’s eye for the full expression of love. It is to be shared solely and only with that one who is your companion forever.

When entered into worthily, this process combines the most exquisite and exalted physical, emotional, and spiritual feelings associated with the word love. That part of life has no equal, no counterpart, in all human experience. It will, when covenants are made and kept, last eternally, “for therein are the keys of the holy priesthood ordained, that you may receive honor and glory” (D&C 124:34), “which glory shall be a fulness and a continuation of the seeds forever and ever” (D&C 132:19).

But romantic love is incomplete; it is a prelude. Love is nourished by the coming of children, who spring from that fountain of life entrusted to couples in marriage. Conception takes place in a wedded embrace between husband and wife. A tiny body begins to form after a pattern of magnificent complexity. A child comes forth in the miracle of birth, created in the image of its earthly father and mother. Within its mortal body is a spirit able to feel and perceive spiritual things. Dormant in that mortal body of this child is the power to beget offspring in its own image.

“The spirit and the body are the soul of man” (D&C 88:15), and there are spiritual and physical laws to obey if we are to be happy. There are eternal laws, including laws relating to this power to give life, “irrevocably decreed in heaven before the foundations of this world, upon which all blessings are predicated” (D&C 130:20). These are spiritual laws which define the moral standard for mankind (see Joseph Smith Translation, Romans 7:14–15 [in the Bible appendix]; 2 Nephi 2:5; D&C 29:34; 134:6). There are covenants which bind, seal, and safeguard and give promise of eternal blessings.

Alma admonished his son Shiblon, “See that ye bridle all your passions, that ye may be filled with love” (Alma 38:12). A bridle is used to guide, to direct, to restrain. Our passion is to be controlled. When lawfully used, the power of procreation will bless and will sanctify (see Teachings of Presidents of the Church: Joseph F. Smith [1998], 158).

Temptations are ever present. Because the adversary cannot beget life, he is jealous toward all who have that supernal power. He and those who followed him were cast out and forfeited the right to a mortal body. “He seeketh that all men might be miserable like unto himself” (2 Nephi 2:27). He will tempt, if he can, to degrade, to corrupt, and, if possible, to destroy this gift by which we may, if we are worthy, have eternal increase (see D&C 132:28–31).

If we pollute our fountains of life or lead others to transgress, there will be penalties more “exquisite” and “hard to bear” (D&C 19:15) than all the physical pleasure could ever be worth.

Alma told his son Corianton, “Know ye not, my son, that these things are an abomination in the sight of the Lord; yea, most abominable above all sins save it be the shedding of innocent blood or denying the Holy Ghost?” (Alma 39:5). We cannot escape the consequences when we transgress.

The only legitimate, authorized expression of the powers of procreation is between husband and wife, a man and a woman, who have been legally and lawfully married. Anything other than this violates the commandments of God. Do not yield to the awful temptations of the adversary, for every debt of transgression must be paid “till thou hast paid the uttermost farthing” (Matthew 5:26).

Nowhere is the generosity and mercy of God more manifest than in repentance.

Our physical bodies, when harmed, are able to repair themselves, sometimes with the help of a physician. If the damage is extensive, however, often a scar will remain as a reminder of the injury.

With our spiritual bodies it is another matter. Our spirits are damaged when we make mistakes and commit sins. But unlike the case of our mortal bodies, when the repentance process is complete, no scars remain because of the Atonement of Jesus Christ. The promise is: “Behold, he who has repented of his sins, the same is forgiven, and I, the Lord, remember them no more” (D&C 58:42).

When we speak of marriage and family life, there inevitably comes to mind, “What about the exceptions?” Some are born with limitations and cannot beget children. Some innocents have their marriage wrecked because of the infidelity of their spouse. Others do not marry and live in single worthiness.

For now I offer this comfort: God is our Father! All the love and generosity manifest in the ideal earthly father is magnified in Him who is our Father and our God beyond the capacity of the mortal mind to comprehend. His judgments are just; His mercy without limit; His power to compensate beyond any earthly comparison. “If in this life only we have hope in Christ, we are of all men most miserable” (1 Corinthians 15:19).

Reverently now I use the word temple. I envision a sealing room and an altar with a young couple kneeling there. This sacred temple ordinance is much more than a wedding, for this marriage can be sealed by the Holy Spirit of Promise, and the scriptures declare that we “shall inherit thrones, kingdoms, principalities, and powers, dominions” (D&C 132:19). I see the joy that awaits those who accept this supernal gift and use it worthily.

Sister Donna Smith Packer and I have been side by side in marriage for nearly 70 years. When it comes to my wife, the mother of our children, I am without words. The feeling is so deep and the gratitude so powerful that I am left almost without expression. The greatest reward we have received in this life, and the life to come, is our children and our grandchildren. Toward the end of our mortal days together, I am grateful for each moment I am with her side by side and for the promise the Lord has given that there will be no end.

I bear witness that Jesus is the Christ and the Son of the living God. He stands at the head of the Church. Through His Atonement and the power of the priesthood, families which are begun in mortality can be together through the eternities. The Atonement, which can reclaim each one of us, bears no scars. That means that no matter what we have done or where we have been or how something happened, if we truly repent, He has promised that He would atone. And when He atoned, that settled that. There are so many of us who are thrashing around, as it were, with feelings of guilt, not knowing quite how to escape. You escape by accepting the Atonement of Christ, and all that was heartache can turn to beauty and love and eternity.

I am so grateful for the blessings of the Lord Jesus Christ, for the power of procreation, for the power of redemption, for the Atonement—the Atonement which can wash clean every stain no matter how difficult or how long or how many times repeated. The Atonement can put you free again to move forward, cleanly and worthily, to pursue that path that you have chosen in life.

I bear witness that God lives, that Jesus is the Christ, that the Atonement is not a general thing that is for the whole Church. The Atonement is individual, and if you have something that is bothering you—sometimes so long ago you can hardly remember it—put the Atonement to work. It will clean it up, and you, as does He, will remember your sins no more. In the name of Jesus Christ, amen.

# References
