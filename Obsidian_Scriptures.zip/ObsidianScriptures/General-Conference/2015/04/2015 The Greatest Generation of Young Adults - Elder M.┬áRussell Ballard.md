Elder M. Russell Ballard
Of the Quorum of the Twelve Apostles
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/the-greatest-generation-of-young-adults?lang=eng)

_What we need now is the greatest generation of young adults in the history of the Church. We need your whole heart and soul._

One of the great pleasures I enjoy as I travel throughout the world is the opportunity to meet and greet our missionaries. These great elders and sisters radiate the Light of Christ, and I am always inspired by their love for the Lord Jesus Christ and their devoted service to Him. Every time I shake hands with them and feel of their remarkable spirit and faith, I say to myself, “These wonderful sons and daughters of ours are truly a miracle!”

During the October 2002 general priesthood meeting, I challenged bishops, parents, and prospective missionaries to “raise the bar” for full-time missionary service.

I then said that “what we need … is the greatest generation of missionaries in the history of the Church. We need worthy, qualified, spiritually energized missionaries. …

“… We need your whole heart and soul. We need vibrant, thinking, passionate missionaries who know how to listen to and respond to the whisperings of the Holy Spirit.”1

In many ways the world today is more challenging than it was 13 years ago. Our young men and young women have many more distractions to sidetrack them in their preparations for both a mission and a future happy life. Technology has expanded, and almost everyone has access to handheld devices that can capture the attention of the human family of God for both great good and unconscionable ill.

Tonight I speak to missionaries now serving, future missionaries, returned missionaries, and all young adult men in the Church. I pray you will understand and thoughtfully consider what I have to say to you as you journey through these exciting and exacting years of your life.

In the early days of the Church, missionaries were interviewed by a General Authority before they went on their missions. These days you are interviewed to serve as missionaries by your bishops and stake presidents, and most of you will go through your entire lives without being interviewed by a General Authority. That is simply a reflection of the reality in a worldwide church of more than 15 million members. I know I speak for my brethren when I tell you that we wish it were possible for us to know all of you personally and to be able to tell you that we love you and that we support you.

Fortunately the Lord has provided ways for us to reach out to you. For example, a member of the Quorum of the Twelve assigns every missionary to his or her mission. Although this is done without a traditional face-to-face interview, technology and revelation combine to provide an experience that is remarkably intimate and personal. Let me tell you how this happens.

Your photograph comes up on a computer screen, together with key information provided by your bishop and stake president. When your picture appears, we look into your eyes and review your answers to the missionary recommendation questions. For that brief moment, it seems as if you are present and responding to us directly.

As we look at your photograph, we trust that you have cleared in every way the “raised bar” required today to be a faithful, successful missionary. Then, by the power of the Spirit of the Lord and under the direction of President Thomas S. Monson, we assign you to one of the Church’s 406 worldwide missions.

No, it isn’t the same as a personal, face-to-face interview. But it’s close.

Videoconferencing is another way that helps us reach out to Church leaders and members who live far away from Church headquarters.

With that in mind, I would like those of you preparing to serve missions, those who have returned, and all of you young adults to spend a few minutes with me as though we were having a personal video chat right now. Please look at me for a few minutes as though you and I were the only ones in the room, wherever you are tonight.

For my part, I will imagine that I am looking into your eyes and listening carefully to your responses to a few questions that I believe will tell me a lot about the depth of your testimony and your devotion to God. If I may paraphrase what I said to missionaries 13 years ago, what we need now is the greatest generation of young adults in the history of the Church. We need your whole heart and soul. We need vibrant, thinking, passionate young adults who know how to listen and respond to the whisperings of the Holy Spirit as you make your way through the daily trials and temptations of being a young, contemporary Latter-day Saint.

In other words, it’s time to raise the bar not only for missionaries but also for returned missionaries and for your entire generation. To that end, please ponder in your heart your answers to these questions:





Do you search the scriptures regularly?





Do you kneel in prayer to talk with your Heavenly Father each morning and each night?





Do you fast and donate a fast offering each month—even if you are a poor, struggling student who can’t afford to donate much?





Do you think deeply about the Savior and His atoning sacrifice for you when you are asked to prepare, bless, pass, or partake of the sacrament?





Do you attend your meetings and strive to keep the Sabbath day holy?





Are you honest at home, school, church, and work?





Are you mentally and spiritually clean? Do you avoid viewing pornography or looking at websites, magazines, movies, or apps, including Tinder and Snapchat photos, that would embarrass you if your parents, Church leaders, or the Savior Himself saw you?





Are you careful with your time—avoiding inappropriate technology and social media, including video games, which can dull your spiritual sensitivity?





Is there anything in your life you need to change and fix, beginning tonight?





Thank you for this short personal visit. I hope you answered each one of these questions honestly and thoughtfully. If you find yourself lacking in any of these simple principles, then I urge you to courageously repent and bring your life back in line with gospel standards of righteous discipleship.

Now, brethren, may I offer additional counsel that will help you get your testimony of the gospel deep in your hearts and your souls?

I remind you returned missionaries that your preparation for life and for a family should be continuous. “RM” doesn’t mean “retired Mormon”! As a returned missionary, you “should be anxiously engaged in a good cause, and do many things of [your] own free will, and bring to pass much righteousness.”2

Please use the skills you learned on your mission to bless the lives of people around you every day. Do not shift your focus from serving others to focusing exclusively on school, work, or social activities. Instead, balance your life with spiritual experiences that remind and prepare you for continued, daily ministering to others.

During your missions you learned the importance of visiting people in their homes. I would hope that all of our young adults, whether or not you served full-time missions, understand the importance of visiting with people who are lonely, sick, or discouraged—not only as an assignment but also because of the genuine love you have for Heavenly Father and His children.

Those of you in high school preparing for missions, I encourage you to participate in and graduate from seminary. You young adults should enroll in an institute of religion.3 If you are attending a Church school, consistently include a class each semester in religious education. During this important season of preparation for a mission, eternal marriage, and life as an adult, you must continue to find ways to learn and grow and receive inspiration and guidance through the Holy Ghost. A careful, prayerful study of the gospel through seminary, institute, or religious education classes can assist you in that goal.

Whether you attend a Church school or not, whether you attend college or not, do not think that you are too busy to study the gospel. Seminary, institute, or religion classes will provide balance to your life and add to your secular education by giving you another opportunity to spend time studying the scriptures and the teachings of the prophets and apostles. There are four outstanding new courses that I would encourage every young adult to look into and to attend.4

And don’t forget that classes and activities offered at your local institute or through your young single adult ward or stake will also be a place where you can be with other young men and young women and lift and inspire one another as you learn and grow spiritually and socialize together. Brethren, if you will set aside your cell phone and actually look around a little, you may even find your future companion at the institute.

Which leads me to another bit of counsel that I’m sure you knew was coming: You single adults need to date and marry. Please stop delaying! I know some of you fear family formation. However, if you marry the right person at the right time and in the right place, you need not fear. In fact, many problems you encounter will be avoided if you are “anxiously engaged” in righteous dating, courting, and marriage. Don’t text her! Use your own voice to introduce yourself to the righteous daughters of God who are all around you. To actually hear a human voice will shock her—perhaps into saying yes.

Now, brethren, I testify to you that the Lord Jesus Christ can help us fix anything that needs fixing in our lives through His atoning sacrifice.

This evening, as we prepare to celebrate Easter Sunday tomorrow, please pause with me to remember the gift of Christ’s Atonement. Remember that our Heavenly Father and our Savior, Jesus Christ, know you best and love you the most.



Through the Atonement, the Redeemer took upon Himself our troubles, pains, and sins. The Savior of the world came to understand each of us individually by experiencing our dashed hopes, challenges, and tragedies through His suffering in Gethsemane and on the cross.5 He died as one final act of love for us and was buried in a new tomb on that fateful night.

On Sunday morning, Jesus rose from the dead—promising new life for each of us. The risen Lord then commissioned His disciples to teach everyone to have faith in Christ, repent of sin, be baptized, receive the gift of the Holy Ghost, and endure to the end. Brethren, we know that God our Father and His Beloved Son appeared to the Prophet Joseph Smith and restored through him the fulness of the everlasting gospel of Jesus Christ.

Be strong, brethren. Keep the commandments of God. The Lord Jesus Christ promises that all things we desire to do in righteousness will be ours. Church leaders are counting on you. We need every one of you young adults to prepare to marry, to serve, and to lead in the days ahead, for which I humbly pray in the name of the Lord Jesus Christ, amen.

# References
1. - M. Russell Ballard, “The Greatest Generation of Missionaries,” Ensign or Liahona, Nov. 2002, 47.
2. - Doctrine and Covenants 58:27.
3. - See First Presidency letter, Apr. 21, 2011.
4. - See “New Religion Classes to Be Offered at Church Universities and Institutes of Religion,” lds.org/topics/education/new-religion-classes.
5. - See Mosiah 3:5–13.