Presented by President Dieter F. Uchtdorf
Second Counselor in the First Presidency
04-2015
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2015/04/the-sustaining-of-church-officers?lang=eng)

Brothers and sisters, it is proposed that we sustain Thomas Spencer Monson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Henry Bennion Eyring as First Counselor in the First Presidency; and Dieter Friedrich Uchtdorf as Second Counselor in the First Presidency.

Those in favor may manifest it.

Those opposed, if any, may manifest it.

The vote has been noted.

It is proposed that we sustain Boyd Kenneth Packer as President of the Quorum of the Twelve Apostles and the following as members of that quorum: Boyd K. Packer, L. Tom Perry, Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, Richard G. Scott, Robert D. Hales, Jeffrey R. Holland, David A. Bednar, Quentin L. Cook, D. Todd Christofferson, and Neil L. Andersen.

Those in favor, please manifest it.

Any opposed may so indicate.

Thank you. The vote has been noted.

It is proposed that we sustain the counselors in the First Presidency and the Quorum of the Twelve Apostles as prophets, seers, and revelators.

All in favor, please manifest it.

Contrary, if there be any, by the same sign.

The vote has been noted.

It is proposed that we release the following as Area Seventies, effective on May 1, 2015: Juan C. Avila, Philip K. Bussey, René J. Cabrera, Renato Capelletti, Paul D. M. Christensen, Samuel W. Clark, Rogério G. R. Cruz, George R. Donaldson, Ini B. Ekong, Christian H. Fingerle, Craig G. Fisher, Jerryl L. Garns, M. Keith Giddens, Allen D. Haynie, Jui Chang Juan, George M. Keele, Von G. Keetch, Katsumi Kusume, German Laboriel, J. Christopher Lansing, Gustavo Lopez, Dmitry V. Marchenko, Peter F. Meurs, T. Jackson Mkhabela, Hugo Montoya, Valentín F. Nuñez, Hee Keun Oh, Jeffery E. Olson, R. Ingvar Olsson, Norbert K. Ounleu, Robert N. Packer, Nathaniel R. Payne, Cesar A. Perez Jr., Michael J. Reall, Edson D. G. Ribeiro, Brad K. Risenmay, Walter C. Selden, Mozart B. Soares, Carlos Solis, Norland Souza, Vern P. Stanfill, T. Marama Tarati, Kouzou Tashiro, Ruben D. Torres, Omar Villalobos, Jack D. Ward, Alan J. Webb, Gerardo J. Wilhelm, and Jim L. Wright.

Those who wish to join us in expressing appreciation for their excellent service, please manifest it.

It is proposed that we release with heartfelt gratitude Brothers David L. Beck, Larry M. Gibson, and Randall L. Ridd as the Young Men general presidency. We likewise extend releases to all members of the Young Men general board.

At this time we also extend releases to Sister Jean A. Stevens as first counselor in the Primary general presidency and Sister Cheryl A. Esplin as second counselor in the Primary general presidency.

All who wish to join us in expressing appreciation to these brothers and sisters for their remarkable service and devotion, please manifest it.

It is proposed that we sustain as new members of the First Quorum of the Seventy Kim B. Clark, Von G. Keetch, Allen D. Haynie, Hugo Montoya, and Vern P. Stanfill.

All in favor, please manifest it.

Those opposed, by the same sign.

It is proposed that we sustain the following as new Area Seventies: Nelson Ardila, Jose M. Batalla, Lawrence P. Blunck, Bradford C. Bowen, Mark A. Bragg, Sergio Luis Carboni, Armando Carreón, S. Marc Clay Jr., Z. Dominique Dekaye, Osvaldo R. Dias, Michael M. Dudley, Mark P. Durham, James E. Evanson, Paschoal F. Fortunato, Patricio M. Giuffra, Daniel P. Hall, Toru Hayashi, Paul F. Hintze, J. K. Chukwuemeka Igwe, Seung Hoon Koo, Ming-Shun Kuan, Johnny L. Leota, Carlo M. Lezano, Joel Martinez, J. Vaun McArthur, Kyle S. McKay, Helamán Montejo, A. Fabio Moscoso, Michael R. Murray, Norman R. Nemrow, S. Mark Palmer, Ferdinand P. Pangan, Jairus C. Perez, Steven M. Petersen, Wolfgang Pilz, Jay D. Pimentel, John C. Pingree Jr., Edvaldo B. Pinto Jr., Evan A. Schmutz, K. David Scott, Paul H. Sinclair, Benjamin T. Sinjoux, Rulon F. Stacey, David L. Stapleton, Karl M. Tilleman, William R. Titera, Seiji Tokuzawa, Carlos R. Toledo, Cesar E. Villar, Juan Pablo Villar, David T. Warner, Gary K. Wilde, and Robert K. William.

All in favor, please manifest it.

Those opposed, if any.

It is proposed that we sustain Cheryl A. Esplin to now serve as first counselor in the Primary general presidency and Mary R. Durham to serve as second counselor.

It is also proposed that we sustain Brother Stephen W. Owen as Young Men general president, with Douglas Dee Holmes as first counselor and Monte Joseph Brough as second counselor.

Those in favor, please manifest it.

Any opposed may so signify.

President Monson, the voting has been noted. We invite those who opposed any of the proposals to contact their stake presidents. My dear brothers and sisters, we thank you for your faith and prayers in behalf of the leaders of the Church.

We invite the new General Authorities and the new general auxiliary presidency members to now take their seats on the rostrum.

# References
