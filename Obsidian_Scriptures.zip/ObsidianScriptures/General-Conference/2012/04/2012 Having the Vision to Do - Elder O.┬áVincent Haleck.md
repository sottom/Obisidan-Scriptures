Elder O. Vincent Haleck
Of the Seventy
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/having-the-vision-to-do?lang=eng)

_If we are to prosper rather than perish, we must gain a vision of ourselves as the Savior sees us._

Like all good parents, my own parents desired a bright future for their children. My father was not a member, and because of unusual circumstances that existed at that time, my parents determined that my brothers and sisters and I should leave our island home of American Samoa, in the South Pacific, and travel to the United States in order to go to school.

The decision to be separated from us was a difficult one for my parents, especially my mother. They knew that there would be unknown challenges as we were put into new surroundings. However, with faith and determination, they pressed forward with their plan.

Because of her Latter-day Saint upbringing, my mother was familiar with the principles of fasting and prayer, and both of my parents felt that they needed the blessings of heaven to help their children. In that spirit they began to set aside a day every week to fast and pray for us. Their vision was to prepare their children for a bright future. They acted on this vision as they exercised their faith by seeking the Lord’s blessings. Through fasting and prayer, they received the assurance, comfort, and peace that all would be well.

How do we, amidst the challenges of our lives, gain the vision necessary to do those things that will bring us closer to the Savior? Speaking of vision, the book of Proverbs teaches this truth: “Where there is no vision, the people perish” (Proverbs 29:18). If we are to prosper rather than perish, we must gain a vision of ourselves as the Savior sees us.

The Savior saw more in those humble fishermen whom He called to follow Him than they initially saw in themselves; He saw a vision of who they could become. He knew of their goodness and potential, and He acted to call them. They were not experienced at first, but as they followed, they saw His example, felt His teachings, and became His disciples. There was a time when some of His disciples departed from Him because the things that they heard were hard for them. Aware that others might also depart, Jesus inquired of the Twelve, “Will ye also go away?” (John 6:67). Peter’s response reflects how he had changed and had caught the vision of who the Savior was. “To whom shall we go? thou hast the words of eternal life” (John 6:68), he responded.

With that vision these faithful and devoted disciples were able to do hard things as they traveled to preach the gospel and establish the Church after the Savior had departed. Eventually, some of them made the ultimate sacrifice for their testimonies.

There are other examples in the scriptures of those who caught the vision of the gospel and then went out to act upon that vision. The prophet Alma gained his vision when he heard Abinadi boldly teaching and testifying before King Noah. Alma acted on Abinadi’s teachings and went about teaching the things he had learned, baptizing many who believed on his words (see Mosiah 17:1–4; 18:1–16). While persecuting the early Saints, the Apostle Paul was converted on the road to Damascus and then acted by teaching and testifying of Christ (see Acts 9:1–6, 20–22, 29).

In our own day many young men, women, and senior couples have answered the call of a prophet of God to serve missions. With faith and courage they leave their homes and everything that is familiar to them because of their faith in the great good they can do as missionaries. As they act on their vision to serve, they bless the lives of many and, in the process, change their own lives. In the last general conference, President Thomas S. Monson thanked us for the service we give to one another and reminded us of our responsibility to be God’s hands in blessing His children here on earth (see “Until We Meet Again,” Liahona and Ensign, Nov. 2011, 108). The fulfillment of this charge has been heartwarming as members of the Church have acted upon his vision.

Before the Savior departed, understanding that we would need help, He said, “I will not leave you comfortless” (John 14:18). He taught His disciples, “The Comforter, which is the Holy Ghost, whom the Father will send in my name, he shall teach you all things, and bring all things to your remembrance, whatsoever I have said unto you” (John 14:26). This is the same Holy Ghost who can empower and motivate us to do the things that the Savior and our modern-day prophets and apostles teach.

As we put into action the teachings of our leaders, we gain a deeper understanding of our Savior’s vision for us. Throughout this conference we have received inspired counsel from prophets and apostles. Study their teachings and ponder them in your hearts while seeking the Spirit of the Holy Ghost to help you catch a vision of these teachings in your life. With that vision, exercise your faith in acting upon their counsel.

Search and study the scriptures with a mind to receiving further light and knowledge of their message to you. Ponder them in your heart and allow them to inspire you. Then act on your inspiration.

As we learned as a family, we act when we fast and pray. Alma spoke of fasting and praying as a way of receiving a surety when he said, “I have fasted and prayed many days that I might know these things of myself” (Alma 5:46). We too come to know how to handle the challenges of our lives through fasting and prayer.

We experience hard things in our lives that can sometimes diminish our vision and faith to do the things we should. We become so busy that we often feel overwhelmed and unable to do any more. While each of us is different, I humbly submit that we must focus our vision on the Savior and His teachings. What did He see in Peter, James, and John and the other Apostles that prompted Him to act to invite them to follow Him? Like His vision of them, the Savior has a great vision of who we can become. It will take the same faith and courage the first Apostles had in order for us to refocus on the things that matter most in bringing lasting happiness and great joy.

When we study the life of our Savior and His teachings, we see Him amongst the people teaching, praying, lifting, and healing. When we emulate Him and do the things we see Him do, we begin to see a vision of who we can become. You will be blessed with insight through the help of the Holy Ghost to do more good. Changes will begin to come, and you will bring a different order to your life that will bless you and your family. During His ministry among the Nephites, the Savior asked, “What manner of men ought ye to be?” He replied, “Even as I am” (3 Nephi 27:27). We need His help to become like Him, and He has shown us the way: “Therefore, ask, and ye shall receive; knock, and it shall be opened unto you; for he that asketh, receiveth; and unto him that knocketh, it shall be opened” (3 Nephi 27:29).

I know that as we gain a vision of ourselves as the Savior sees us and as we act on that vision, our lives will be blessed in unexpected ways. Because of the vision of my parents, not only was my life blessed by educational experiences, but I was placed in circumstances where I found and embraced the gospel. More important, I learned the significance of good and faithful parents. Simply put, my life was changed forever.

Just as vision led my parents to fast and pray for their children’s welfare and as the early Apostles’ vision led them to follow the Savior, that same vision is available to inspire and help us to act. Brothers and sisters, we are a people with a history of vision and the faith and courage to do. Look at where we have come and the blessings we have received! Believe that He can bless you with vision in your life and the courage to act.

I bear you my witness of the Savior and His desire for us to return to Him. To do that, we must have the faith to do—to follow Him and become like Him. Throughout various times of our lives, He holds out His hand and invites us:

“Take my yoke upon you, and learn of me; for I am meek and lowly in heart: and ye shall find rest unto your souls.

“For my yoke is easy, and my burden is light” (Matthew 11:29–30).

Just as the Savior saw great potential in His early disciples, He also sees the same in us. Let us see ourselves as the Savior sees us. I pray that we will have that vision with the faith and courage to do, in the name of Jesus Christ, amen.

# References
