Elder David A. Bednar
Of the Quorum of the Twelve Apostles
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/the-powers-of-heaven?lang=eng)

_Priesthood holders young and old need both authority and power—the necessary permission and the spiritual capacity to represent God in the work of salvation._

My beloved brethren, I am grateful we can worship together as a vast body of priesthood holders. I love and admire you for your worthiness and your influence for good throughout the world.

I invite each of you to consider how you would respond to the following question posed to the members of the Church many years ago by President David O. McKay: “If at this moment each one of you were asked to state in one sentence or phrase the most distinguishing feature of The Church of Jesus Christ of Latter-day Saints, what would be your answer?” (“The Mission of the Church and Its Members,” Improvement Era, Nov. 1956, 781).

The response President McKay gave to his own question was the “divine authority” of the priesthood. The Church of Jesus Christ of Latter-day Saints stands apart from other churches that claim their authority is derived from historical succession, the scriptures, or theological training. We make the distinctive declaration that priesthood authority has been conferred by the laying on of hands directly from heavenly messengers to the Prophet Joseph Smith.

My message focuses upon this divine priesthood and the powers of heaven. I earnestly pray for the assistance of the Spirit of the Lord as together we learn about these important truths.





Priesthood Authority and Power



The priesthood is the authority of God delegated to men on the earth to act in all things for the salvation of mankind (see Spencer W. Kimball, “The Example of Abraham,” Ensign, June 1975, 3). Priesthood is the means whereby the Lord acts through men to save souls. One of the defining features of the Church of Jesus Christ, both anciently and today, is His authority. There can be no true Church without divine authority.

Ordinary men are given the authority of the priesthood. Worthiness and willingness—not experience, expertise, or education—are the qualifications for priesthood ordination.

The pattern for obtaining priesthood authority is described in the fifth article of faith: “We believe that a man must be called of God, by prophecy, and by the laying on of hands by those who are in authority, to preach the Gospel and administer in the ordinances thereof.” Thus, a boy or a man receives the authority of the priesthood and is ordained to a specific office by one who already holds the priesthood and has been authorized by a leader with the necessary priesthood keys.

A priesthood holder is expected to exercise this sacred authority in accordance with God’s holy mind, will, and purposes. Nothing about the priesthood is self-centered. The priesthood always is used to serve, to bless, and to strengthen other people.

The higher priesthood is received by a solemn covenant that includes the obligation to act in the authority (see D&C 68:8) and the office (see D&C 107:99) that have been received. As bearers of God’s holy authority, we are agents to act and not objects to be acted upon (see 2 Nephi 2:26). The priesthood is inherently active rather than passive.

President Ezra Taft Benson taught:

“It is not enough to receive the priesthood and then sit back passively and wait until someone prods us into activity. When we receive the priesthood, we have the obligation of becoming actively and anxiously engaged in promoting the cause of righteousness in the earth, because the Lord says:

“‘… He that doeth not anything until he is commanded, and receiveth a commandment with doubtful heart, and keepeth it with slothfulness, the same is damned’ [D&C 58:29]” (So Shall Ye Reap [1960], 21).

President Spencer W. Kimball also pointedly emphasized the active nature of the priesthood: “One breaks the priesthood covenant by transgressing commandments—but also by leaving undone his duties. Accordingly, to break this covenant one needs only to do nothing” (The Miracle of Forgiveness [1969], 96).

As we do our best to fulfill our priesthood responsibilities, we can be blessed with priesthood power. The power of the priesthood is God’s power operating through men and boys like us and requires personal righteousness, faithfulness, obedience, and diligence. A boy or a man may receive priesthood authority by the laying on of hands but will have no priesthood power if he is disobedient, unworthy, or unwilling to serve.

“The rights of the priesthood are inseparably connected with the powers of heaven, and … the powers of heaven cannot be controlled nor handled only upon the principles of righteousness.

“That they may be conferred upon us, it is true; but when we undertake to cover our sins, or to gratify our pride, our vain ambition, or to exercise control or dominion or compulsion upon the souls of the children of men, in any degree of unrighteousness, behold, the heavens withdraw themselves; the Spirit of the Lord is grieved; and when it is withdrawn, Amen to the priesthood or the authority of that man” (D&C 121:36–37; emphasis added).

Brethren, for a boy or a man to receive priesthood authority but neglect to do what is necessary to qualify for priesthood power is unacceptable to the Lord. Priesthood holders young and old need both authority and power—the necessary permission and the spiritual capacity to represent God in the work of salvation.







A Lesson from My Father



I was reared in a home with a faithful mother and a wonderful father. My mom was a descendant of pioneers who sacrificed everything for the Church and kingdom of God. My dad was not a member of our Church and, as a young man, had desired to become a Catholic priest. Ultimately, he elected not to attend theological seminary and instead pursued a career as a tool and die maker.

For much of his married life, my father attended meetings of The Church of Jesus Christ of Latter-day Saints with our family. In fact, many of the people in our ward had no idea that my dad was not a member of the Church. He played on and coached our ward softball team, helped with Scout activities, and supported my mother in her various callings and responsibilities. I want to tell you about one of the great lessons I learned from my father about priesthood authority and power.



As a boy I asked my dad many times each week when he was going to be baptized. He responded lovingly but firmly each time I pestered him: “David, I am not going to join the Church for your mother, for you, or for anyone else. I will join the Church when I know it is the right thing to do.”

I believe I was in my early teenage years when the following conversation occurred with my father. We had just returned home from attending our Sunday meetings together, and I asked my dad when he was going to be baptized. He smiled and said, “You are the one always asking me about being baptized. Today I have a question for you.” I quickly and excitedly concluded that now we were making progress!

My dad continued, “David, your church teaches that the priesthood was taken from the earth anciently and has been restored by heavenly messengers to the Prophet Joseph Smith, right?” I replied that his statement was correct. Then he said, “Here is my question. Each week in priesthood meeting I listen to the bishop and the other priesthood leaders remind, beg, and plead with the men to do their home teaching and to perform their priesthood duties. If your church truly has the restored priesthood of God, why are so many of the men in your church no different about doing their religious duty than the men in my church?” My young mind immediately went completely blank. I had no adequate answer for my dad.

I believe my father was wrong to judge the validity of our Church’s claim to divine authority by the shortcomings of the men with whom he associated in our ward. But embedded in his question to me was a correct assumption that men who bear God’s holy priesthood should be different from other men. Men who hold the priesthood are not inherently better than other men, but they should act differently. Men who hold the priesthood should not only receive priesthood authority but also become worthy and faithful conduits of God’s power. “Be ye clean that bear the vessels of the Lord” (D&C 38:42).

I have never forgotten the lessons about priesthood authority and power I learned from my father, a good man not of our faith, who expected more from men who claimed to bear God’s priesthood. That Sunday afternoon conversation with my dad many years ago produced in me a desire to be a “good boy.” I did not want to be a poor example and a stumbling block to my father’s progress in learning about the restored gospel. I simply wanted to be a good boy. The Lord needs all of us as bearers of His authority to be honorable, virtuous, and good boys at all times and in all places.

You may be interested to know that a number of years later, my father was baptized. And at the appropriate times, I had the opportunity to confer upon him the Aaronic and the Melchizedek Priesthoods. One of the great experiences of my life was observing my dad receive the authority and, ultimately, the power of the priesthood.

I share with you this pointed lesson I learned from my father to emphasize a simple truth. Receiving the authority of the priesthood by the laying on of hands is an important beginning, but it is not enough. Ordination confers authority, but righteousness is required to act with power as we strive to lift souls, to teach and testify, to bless and counsel, and to advance the work of salvation.

In this momentous season of the earth’s history, you and I as bearers of the priesthood need to be righteous men and effective instruments in the hands of God. We need to rise up as men of God. You and I would do well to learn from and heed the example of Nephi, the grandson of Helaman and the first of the twelve disciples called by the Savior at the beginning of His ministry among the Nephites. “And [Nephi] did minister many things unto them. … And Nephi did minister with power and with great authority” (3 Nephi 7:17).







“Please Help My Husband Understand”



At the conclusion of the temple recommend interviews I conducted as a bishop and stake president, I often would ask the married sisters how I could best serve them and their families. The consistency of the answers I received from those faithful women was both instructive and alarming. The sisters rarely complained or criticized, but they often responded as follows: “Please help my husband understand his responsibility as a priesthood leader in our home. I am happy to take the lead in scripture study, family prayer, and family home evening, and I will continue to do so. But I wish my husband would be an equal partner and provide the strong priesthood leadership only he can give. Please help my husband learn how to become a patriarch and a priesthood leader in our home who presides and protects.”

I reflect often on the sincerity of those sisters and their request. Priesthood leaders hear similar concerns today. Many wives are pleading for husbands who have not only priesthood authority but also priesthood power. They yearn to be equally yoked with a faithful husband and priesthood companion in the work of creating a Christ-centered and gospel-focused home.

Brethren, I promise that if you and I will prayerfully ponder the pleas of these sisters, the Holy Ghost will help us to see ourselves as we really are (see D&C 93:24) and help us recognize the things we need to change and improve. And the time to act is now!







Be Examples of Righteousness



Tonight I reiterate the teachings of President Thomas S. Monson, who has invited us as priesthood holders to be “examples of righteousness.” He has reminded us repeatedly that we are on the Lord’s errand and are entitled to His help predicated upon our worthiness (see “Examples of Righteousness,” Liahona and Ensign, May 2008, 65–68). You and I hold priesthood authority that has been returned to the earth in this dispensation by heavenly messengers, even John the Baptist and Peter, James, and John. And therefore every man who receives the Melchizedek Priesthood can trace his personal line of authority directly to the Lord Jesus Christ. I hope we are grateful for this marvelous blessing. I pray we will be clean and worthy to represent the Lord as we exercise His sacred authority. May each of us qualify for priesthood power.

I testify the holy priesthood indeed has been restored to the earth in these latter days and is found in The Church of Jesus Christ of Latter-day Saints. I also witness that President Thomas S. Monson is the presiding high priest over the high priesthood of the Church (see D&C 107:9, 22, 65–66, 91–92) and the only person upon the earth who both holds and is authorized to exercise all priesthood keys. Of these truths I solemnly testify in the sacred name of the Lord Jesus Christ, amen.

# References
