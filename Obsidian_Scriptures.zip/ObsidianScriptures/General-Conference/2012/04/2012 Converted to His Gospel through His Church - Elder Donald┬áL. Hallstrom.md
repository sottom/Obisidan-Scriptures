Elder Donald L. Hallstrom
Of the Presidency of the Seventy
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/converted-to-his-gospel-through-his-church?lang=eng)

_The purpose of the Church is to help us live the gospel._

I love the gospel of Jesus Christ and The Church of Jesus Christ of Latter-day Saints. Sometimes we use the terms gospel and Church interchangeably, but they are not the same. They are, however, exquisitely interconnected, and we need both.

The gospel is the glorious plan of God in which we, as His children, are given the opportunity to receive all that the Father has (see D&C 84:38). This is called eternal life and is described as “the greatest of all the gifts of God” (D&C 14:7). A vital part of the plan is our earthly experience—a time to develop faith (see Moroni 7:26), to repent (see Mosiah 3:12), and to reconcile ourselves with God (see Jacob 4:11).

Because our mortal frailties and “opposition in all things” (2 Nephi 2:11) would make this life profoundly difficult and because we could not cleanse our own sins, a Savior was needed. When Elohim, the Eternal God and Father of all our spirits, presented His plan of salvation, there was one among us who said, “Here am I, send me” (Abraham 3:27). His name was Jehovah.

Born of a Heavenly Father, both spiritually and physically, He possessed the omnipotence to overcome the world. Born of an earthly mother, He was subject to the pain and suffering of mortality. The great Jehovah was also named Jesus and additionally was given the title of Christ, meaning the Messiah or Anointed One. His crowning achievement was the Atonement, wherein Jesus the Christ “descended below all things” (D&C 88:6), making it possible for Him to pay a redeeming ransom for each of us.

The Church was established by Jesus Christ during His earthly ministry, “built upon the foundation of the apostles and prophets” (Ephesians 2:20). In this, “the dispensation of the fulness of times” (D&C 128:18), the Lord restored what once was, specifically telling the Prophet Joseph Smith, “I will establish a church by your hand” (D&C 31:7). Jesus Christ was and is the head of His Church, represented on earth by prophets holding apostolic authority.

This is a magnificent Church. Its organization, effectiveness, and sheer goodness are respected by all who sincerely seek to understand it. The Church has programs for children, youth, men, and women. It has beautiful meetinghouses that number more than 18,000. Majestic temples—now totaling 136—dot the earth, with another 30 under construction or announced. A full-time missionary force of over 56,000, comprised of the young and less so, are serving in 150 countries. The Church’s worldwide humanitarian work is a marvelous display of the generosity of our members. Our welfare system cares for our members and promotes self-reliance in a manner unduplicated anywhere. In this Church we have selfless lay leaders and a community of Saints who are willing to serve one another in a remarkable way. There is nothing like this Church in all the world.

When I was born, our family lived in a tiny cottage on the grounds of one of the great and historic meetinghouses of the Church, the Honolulu Tabernacle. I now apologize to my dear friends in the Presiding Bishopric, who oversee the facilities of the Church, but as a boy I climbed over and under and through every inch of that property, from the bottom of the water-filled reflecting pool to the top of the inside of the imposing lighted steeple. We even swung (Tarzan-like) on the long hanging vines of the huge banyan trees that are on the site.

The Church was everything to us. We went to lots of meetings, even more than we have today. We attended Primary on Thursday afternoons. Relief Society meetings were on Tuesday mornings. Mutual for the youth was Wednesday night. Saturday was for ward activities. On Sunday, men and young men would go to priesthood meeting in the morning. Midday we would attend Sunday School. Then in the evening we returned for sacrament meeting. With comings and goings and meetings, it seemed our time was consumed with Church activities all day Sunday and most other days of the week.

As much as I loved the Church, it was during those boyhood days that, for the first time, I had a sense there was something even more. When I was five years old, a major conference was held at the tabernacle. We walked down the lane on which we lived and over a small bridge leading to the stately meetinghouse and sat on about the 10th row in the large chapel. Presiding and speaking at the meeting was David O. McKay, the President of the Church. I do not recall anything he said, but I vividly remember what I saw and what I felt. President McKay was dressed in a cream-colored suit and, with his wavy white hair, looked very regal. In the tradition of the islands, he wore a triple-thick red carnation lei. As he spoke, I felt something quite intense and very personal. I later understood that I was feeling the influence of the Holy Spirit. We sang the closing hymn.





Who’s on the Lord’s side? Who?

Now is the time to show.

We ask it fearlessly:

Who’s on the Lord’s side? Who?





(“Who’s on the Lord’s Side?” Hymns, no. 260)





With those words being sung by nearly 2,000 people but seeming to be a question posed just to me, I wanted to stand and say, “I am!”

Some have come to think of activity in the Church as the ultimate goal. Therein lies a danger. It is possible to be active in the Church and less active in the gospel. Let me stress: activity in the Church is a highly desirable goal; however, it is insufficient. Activity in the Church is an outward indication of our spiritual desire. If we attend our meetings, hold and fulfill Church responsibilities, and serve others, it is publicly observed.

By contrast, the things of the gospel are usually less visible and more difficult to measure, but they are of greater eternal importance. For example, how much faith do we really have? How repentant are we? How meaningful are the ordinances in our lives? How focused are we on our covenants?

I repeat: we need the gospel and the Church. In fact, the purpose of the Church is to help us live the gospel. We often wonder: How can someone be fully active in the Church as a youth and then not be when they are older? How can an adult who has regularly attended and served stop coming? How can a person who was disappointed by a leader or another member allow that to end their Church participation? Perhaps the reason is they were not sufficiently converted to the gospel—the things of eternity.



I suggest three fundamental ways to have the gospel be our foundation:





Deepen our understanding of Deity. A sustained knowledge of and love for the three members of the Godhead are indispensable. Mindfully pray to the Father, in the name of the Son, and seek direction from the Holy Ghost. Couple prayer with constant study and humble pondering to continually build unshakable faith in Jesus Christ. “For how knoweth a man the master … who is a stranger unto him, and is far from the thoughts and intents of his heart?” (Mosiah 5:13).





Focus on the ordinances and covenants. If there are any of the essential ordinances yet to be performed in your life, intently prepare to receive each of them. Then we need to establish the discipline to live faithful to our covenants, fully using the weekly gift of the sacrament. Many of us are not being regularly changed by its cleansing power because of our lack of reverence for this holy ordinance.





Unite the gospel with the Church. As we concentrate on the gospel, the Church will become more, not less, of a blessing in our lives. As we come to each meeting prepared to “seek learning, even by study and also by faith” (D&C 88:118), the Holy Spirit will be our teacher. If we come to be entertained, we often will be disappointed. President Spencer W. Kimball was once asked, “What do you do when you find yourself in a boring sacrament meeting?” His response: “I don’t know. I’ve never been in one” (quoted by Gene R. Cook, in Gerry Avant, “Learning Gospel Is Lifetime Pursuit,” Church News, Mar. 24, 1990, 10).





In our lives we should desire what occurred after the Lord came to the people of the New World and established His Church. The scriptures read, “And it came to pass that thus they [meaning His disciples] did go forth among all the people of Nephi, and did preach the gospel of Christ unto all people upon the face of the land; and they were converted unto the Lord, and were united unto the church of Christ, and thus the people of that generation were blessed” (3 Nephi 28:23).

The Lord wants the members of His Church to be fully converted to His gospel. This is the only sure way to have spiritual safety now and happiness forever. In the name of Jesus Christ, amen.

# References
