Elder Ulisses Soares
Of the Seventy
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/abide-in-the-lords-territory?lang=eng)

_Our daily question must be, “Do my actions place me in the Lord’s or in the enemy’s territory?”_

President Thomas S. Monson once said: “May I provide a simple formula by which you can measure the choices which confront you. It’s easy to remember: ‘You can’t be right by doing wrong; you can’t be wrong by doing right’” (“Pathways to Perfection,” Liahona, July 2002, 112; Ensign, May 2002, 100). President Monson’s formula is simple and direct. It works the same way as the Liahona given to Lehi did. If we exercise faith and are diligent in obeying the Lord’s commandments, we will easily find the correct direction to follow, especially when we face our day-to-day choices.

The Apostle Paul exhorts us about the importance of sowing in the Spirit and being aware of not sowing in the flesh. He said:

“Be not deceived; God is not mocked: for whatsoever a man soweth, that shall he also reap.

“For he that soweth to his flesh shall of the flesh reap corruption; but he that soweth to the Spirit shall of the Spirit reap life everlasting.

“And let us not be weary in well doing: for in due season we shall reap, if we faint not” (Galatians 6:7–9).

To sow in the Spirit means that all our thoughts, words, and actions must elevate us to the level of the divinity of our heavenly parents. However, the scriptures refer to the flesh as the physical or carnal nature of the natural man, which allows people to be influenced by passion, desires, appetites, and drives of the flesh instead of looking for inspiration from the Holy Ghost. If we are not careful, those influences together with the pressure of the evil in the world may conduct us to adopt vulgar and reckless behavior which may become part of our character. In order to avoid those bad influences, we have to follow what the Lord instructed the Prophet Joseph Smith about continuously sowing in the Spirit: “Wherefore, be not weary in well-doing, for ye are laying the foundation of a great work. And out of small things proceedeth that which is great” (D&C 64:33).

To enhance our spirit, it is required that we “let all bitterness, and wrath, and anger, and clamour, and evil speaking, be put away from [us], with all malice” (Ephesians 4:31) and that we “be wise in the days of [our] probation [and] strip [ourselves] of all uncleanness” (Mormon 9:28).



As we study the scriptures, we learn that the promises made by the Lord to us are conditional upon our obedience and encourage righteous living. Those promises must nourish our soul, bringing us hope by encouraging us not to give up even in the face of our daily challenges of living in a world whose ethical and moral values are becoming extinct, thus motivating people to sow in the flesh even more. But how can we be certain that our choices are helping us to sow in the Spirit and not in the flesh?

President George Albert Smith, repeating counsel from his grandfather, once said: “There is a line of demarcation well defined between the Lord’s territory and the devil’s territory. If you will stay on the Lord’s side of the line you will be under his influence and will have no desire to do wrong; but if you cross to the devil’s side of that line one inch you are in the tempter’s power and if he is successful, you will not be able to think or even reason properly because you will have lost the Spirit of the Lord” (Teachings of Presidents of the Church: George Albert Smith [2011], 191).

Therefore, our daily question must be, “Do my actions place me in the Lord’s or in the enemy’s territory?”

Mormon the prophet alerted his people about the importance of having the ability to distinguish good from evil:

“Wherefore, all things which are good cometh of God; and that which is evil cometh of the devil; for the devil is an enemy unto God, and fighteth against him continually, and inviteth and enticeth to sin, and to do that which is evil continually.

“But behold, that which is of God inviteth and enticeth to do good continually” (Moroni 7:12–13).

The Light of Christ together with the companionship of the Holy Ghost must help us determine if our manner of living is placing us in the Lord’s territory or not. If our attitudes are good, they are inspired of God, for every good thing comes from God. However, if our attitudes are bad, we are being influenced by the enemy because he persuades men to do evil.

The African people have touched my heart because of their determination and diligence to stay in the Lord’s territory. Even in adverse circumstances in life, those who accept the invitation to come unto Christ become a light to the world. A few weeks ago while visiting one of the wards in South Africa, I had the privilege to accompany two young priests, their bishop, and their stake president in a visit to less-active young men of their quorum. I was greatly impressed by the courage and humility that those two priests showed as they invited the less-active young men to return to church. While they talked to those less-active young men, I noticed that their countenances reflected the Savior’s light and at the same time filled with light all those around them. They were fulfilling their duty to “succor the weak, lift up the hands which hang down, and strengthen the feeble knees” (D&C 81:5). The attitude of those two priests placed them in the Lord’s territory, and they served as instruments in His hands as they invited others to do the same.

In Doctrine and Covenants 20:37, the Lord teaches us what it means to sow in the Spirit and what really places us in the Lord’s territory, as follows: humble ourselves before God, come forth with broken hearts and contrite spirits, witness before the Church that we have truly repented of all our sins, take upon ourselves the name of Jesus Christ, have a determination to serve Him to the end, manifest by our works that we have received the Spirit of Christ, and be received by baptism into His Church. Our disposition to fulfill these covenants prepares us to live in God’s presence as exalted beings. The remembrance of these covenants must guide our behavior in relation to our family, in our social interaction with other people, and especially in our relationship with the Savior.

Jesus Christ established the perfect behavior pattern by which we can build upon our attitudes to be able to fulfill these sacred covenants. The Savior banished from His life any influence that might take His focus away from His divine mission, especially when He was tempted by the enemy or by his followers while He ministered here on earth. Although He never sinned, He had a broken heart and a contrite spirit, full of love for our Heavenly Father and for all men. He humbled Himself before our Father in Heaven, denying His own will to fulfill what the Father had asked of Him in all things until the end. Even at that moment of extreme physical and spiritual pain, carrying the burden of the sins of all mankind on His shoulders and shedding blood through His pores, He told the Father, “Nevertheless not what I will, but what thou wilt” (Mark 14:36).

My prayer, brothers and sisters, as we think about our covenants is that we may keep ourselves strong against “the fiery darts of the adversary” (1 Nephi 15:24), following the Savior’s example so that we may sow in the Spirit and abide in the Lord’s territory. Let us remember President Monson’s formula: “You can’t be right by doing wrong; you can’t be wrong by doing right.” I say these things in the name of Jesus Christ, amen.

# References
