Presented by President Dieter F. Uchtdorf
Second Counselor in the First Presidency
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/the-sustaining-of-church-officers?lang=eng)

It is proposed that we sustain Thomas Spencer Monson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Henry Bennion Eyring as First Counselor in the First Presidency; and Dieter Friedrich Uchtdorf as Second Counselor in the First Presidency.

Those in favor may manifest it.

Those opposed, if any, may manifest it.

It is proposed that we sustain Boyd Kenneth Packer as President of the Quorum of the Twelve Apostles and the following as members of that quorum: Boyd K. Packer, L. Tom Perry, Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, Richard G. Scott, Robert D. Hales, Jeffrey R. Holland, David A. Bednar, Quentin L. Cook, D. Todd Christofferson, and Neil L. Andersen.

Those in favor, please manifest it.

Any opposed may so indicate.

It is proposed that we sustain the counselors in the First Presidency and the Twelve Apostles as prophets, seers, and revelators.

All in favor, please manifest it.

Contrary, if there be any, by the same sign.

Elder Steven E. Snow has been released as a member of the Presidency of the Quorums of the Seventy.

Those who can join with us in a vote of appreciation, please manifest it.

It is proposed that we sustain Elder Richard J. Maynes as a member of the Presidency of the Quorums of the Seventy.

All in favor, please manifest it.

Those opposed, if any.

It is proposed that we release with a vote of appreciation Elders Gérald Jean Caussé and Gary E. Stevenson as members of the First Quorum of the Seventy.

All in favor, please manifest it.

After many years of faithful and effective service, it is proposed that we release Bishops H. David Burton, Richard C. Edgley, and Keith B. McMullin as the Presiding Bishopric and designate them as emeritus General Authorities.

Those who can join with us in a vote of appreciation, please manifest it.

It is proposed that we release the following as Area Seventies effective on May 1, 2012:

Richard K. Ahadjie, Climato C. A. Almeida, Fernando J. D. Araújo, Marvin T. Brinkerhoff, Mario L. Carlos, Rafael E. Castro, David L. Cook, César A. Dávila, Mosiah S. Delgado, Luis G. Duarte, Juan A. Etchegaray, Stephen L. Fluckiger, J. Roger Fluhman, Robert C. Gay, Miguel Hidalgo, Garith C. Hill, David J. Hoare, David H. Ingram, Tetsuji Ishii, Kapumba T. Kola, Glendon Lyons, R. Bruce Merrell, Enrique J. Montoya, Daniel A. Moreno, Adesina J. Olukanni, Gamaliel Osorno, Patrick H. Price, Marcos A. Prieto, Paulo R. Puerta, Carlos F. Rivas, A. Ricardo Sant’Ana, Fabian L. Sinamban, Natã C. Tobias, Stanley Wan, Perry M. Webb, Richard W. Wheeler, and Scott D. Whiting.



Those who wish to join us in expressing our gratitude for their excellent service, please manifest it.

It is proposed that we release with a vote of sincere appreciation Sisters Julie B. Beck, Silvia H. Allred, and Barbara Thompson as the Relief Society general presidency.

We likewise extend a release to members of the Relief Society general board.

All who wish to join us in expressing appreciation to these sisters for their remarkable service and devotion, please manifest it.

It is proposed that we sustain as new members of the First Quorum of the Seventy Craig A. Cardon, Stanley G. Ellis, Larry Echo Hawk, Robert C. Gay, and Scott D. Whiting.

All in favor, please manifest it.

Those opposed, by the same sign.

It is proposed that we sustain Gary E. Stevenson as Presiding Bishop of The Church of Jesus Christ of Latter-day Saints, with Gérald Jean Caussé as First Counselor and Dean Myron Davies as Second Counselor.

Those in favor, please manifest it.

Any opposed.

It is proposed that we sustain the following as new Area Seventies:

Pedro U. Adduru, Detlef H. Adler, Angel H. Alarcon, Aley K. Auna Jr., W. Mark Bassett, Robert M. Call, Hernando Camargo, Gene R. Chidester, Joaquin E. Costa, Ralph L. Dewsnup, Ángel A. Duarte, Edward Dube, Moroni Gaona, Taylor G. Godoy, Francisco D. N. Granja, Yuriy A. Gushchin, Richard K. Hansen, Todd B. Hansen, Clifford T. Herbertson, Aniefiok Udo Inyon, Luiz M. Leal, Alejandro Lopez, L. Jean Claude Mabaya, Alvin F. Meredith III, Adonay S. Obando, Jared R. Ocampo, Adeyinka A. Ojediran, Andrew M. O’Riordan, Jesus A. Ortiz, Fred A. Parker, Siu Hong Pon, Abraham E. Quero, Robert Clare Rhien, Jorge Luis Romeu, Jorge Saldívar, Gordon H. Smith, Alin Spannaus, Moroni B. Torgan, Steven L. Toronto, and Daniel Yirenya-Tawiah.

All in favor, please signify.

Any opposed.

It is proposed that we sustain Linda Kjar Burton as general president of the Relief Society, with Carole Manzel Stephens as first counselor and Linda Sheffield Reeves as second counselor.

Those in favor, please manifest.

Any opposed may so signify.

It is proposed that we sustain the other General Authorities, Area Seventies, and general auxiliary presidencies as presently constituted.

Those in favor, please manifest it.

Any opposed may manifest it.

President Monson, insofar as I have been able to observe, the voting in the Conference Center has been unanimous in favor of the proposals made.

Thank you, brothers and sisters, for your sustaining vote and your continued faith, devotion, and prayers.

We invite the newly called General Authorities and Relief Society general presidency to come forward and take their places on the stand.

# References
