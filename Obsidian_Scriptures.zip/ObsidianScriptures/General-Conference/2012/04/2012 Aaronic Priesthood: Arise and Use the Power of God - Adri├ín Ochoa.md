Adrián Ochoa
Second Counselor in the Young Men General Presidency
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/aaronic-priesthood-arise-and-use-the-power-of-god?lang=eng)

_The priesthood needs to be exercised to accomplish any good. You are called to “arise and shine forth,” not to hide your light in darkness._

Not long ago I was in South Africa visiting a home with Thabiso, the first assistant in the priests quorum in the Kagiso Ward. Thabiso and his bishop, who presides and holds the keys for the quorum, had been praying for quorum members who were less active, seeking inspiration about whom to visit and how to help them. They felt prompted to visit the home of Tebello, and they invited me to go with them.

Once we made it past the ferocious guard dog, we found ourselves in the living room with Tebello, a calm-spirited young man who had stopped attending church because he had become busy doing other things on Sundays. He was nervous but happy to receive us and even invited his family to join him. The bishop expressed his love for the family and his desire to help them become an eternal family by being sealed in the temple. Their hearts were moved, and we could all feel the strong presence of the Holy Ghost guiding every word and every sentiment.

But it was the words of Thabiso that made the difference in the visit. It seemed to me that this young priest was speaking in the language of angels—loving words that we all could fully understand but that especially touched his friend. “I enjoyed so much talking to you all the time at church,” he said. “You always have kind words for me. And you know, our soccer team has basically disappeared now that we don’t have you. You are so good at it.”

“I am sorry,” Tebello answered. “I will come back with you guys.”

“That will be awesome,” said Thabiso. “And do you remember how we used to prepare to serve as missionaries? Can we start doing that again?”

“Yes,” repeated Tebello, “I want to come back.”

Perhaps the greatest joy I experience as a counselor in the Young Men general presidency is seeing the Aaronic Priesthood holders around the world exercising the power of the Aaronic Priesthood. But sometimes I also witness, with a sad heart, how many young men do not understand how much good they can do with the power they hold.

The priesthood is the power and authority of God Himself to act in the service of His children. Oh, if only every young man, every Aaronic Priesthood holder, could fully comprehend that his priesthood possesses the keys of the ministering of angels. If only they could understand that they have the sacred duty to help their friends find the pathway that leads to the Savior. If only they knew that Heavenly Father will give them the power to explain the truths of the restored gospel with such clarity and sincerity that others will feel the undeniable truthfulness of the words of Christ.

Dear young men of the Church, let me ask you a question that I hope you will carry in your heart for the rest of your life. What greater power can you acquire on earth than the priesthood of God? What power could possibly be greater than the capacity to assist our Heavenly Father in changing the lives of your fellowmen, to help them along the pathway of eternal happiness by being cleansed of sin and wrongdoing?

Like any other power, the priesthood needs to be exercised to accomplish any good. You are called to “arise and shine forth” (D&C 115:5), not to hide your light in darkness. Only those who are brave will be counted among the chosen. As you exercise the power of your sacred priesthood, your courage and confidence will increase. Young men, you know that you are at your best when you are in the service of God. You know that you are happiest when you are anxiously engaged in a good work. Magnify the power of your priesthood by being clean and being worthy.

I add my voice to the call Elder Jeffrey R. Holland made to you six months ago from this pulpit. “I am looking,” he said, “for men young and old who care enough about this battle between good and evil to sign on and speak up. We are at war.” He continued, “… I ask for a stronger and more devoted voice, a voice not only against evil … , but a voice for good, a voice for the gospel, a voice for God” (“We Are All Enlisted,” Liahona and Ensign, Nov. 2011, 44, 47).

Yes, Aaronic Priesthood holders, we are at war. And in this war, the best way to defend against evil is to actively promote righteousness. You cannot listen to foul words and pretend you don’t hear. You cannot watch, alone or with others, images you know are filthy and pretend you don’t see. You cannot touch any unclean thing and pretend it’s no big deal. You cannot be passive when Satan seeks to destroy that which is wholesome and pure. Instead, stand up boldly for what you know is true! When you hear or see anything that violates the Lord’s standards, remember who you are—a soldier in the army of God Himself, empowered with His holy priesthood. There is no better weapon against the enemy, the father of lies, than the truth that will come out of your mouth as you exercise the power of the priesthood. Most of your peers will respect you for your courage and your integrity. Some will not. But that doesn’t matter. You will gain the respect and trust of Heavenly Father because you used His power to accomplish His purposes.

I call on every Aaronic Priesthood quorum presidency to once again raise the title of liberty and organize and lead your battalions. Utilize your priesthood power by inviting those around you to come unto Christ through repentance and baptism. You have the mandate and power of Heavenly Father to do it.

Two years ago, while visiting Santiago, Chile, I was very much impressed by Daniel Olate, a young man who often accompanied the missionaries. I asked him to write to me, and with his permission I will read to you part of his recent e-mail: “I just turned 16, and Sunday I was ordained to the office of a priest. That same day I baptized a friend; her name is Carolina. I taught her the gospel, and she regularly attended church and even received her Personal Progress award, but her parents would not allow her to be baptized until they got to know and trust me. She wanted me to baptize her, so we had to wait for a month until Sunday, when I turned 16. I feel so good to have helped such a good person to be baptized, and I feel happy that I was the one who baptized her.”



Daniel is just one of many young men around the world who are living up to the power God has entrusted to them. Another is Luis Fernando, from Honduras, who noticed that his friend was walking a dangerous path and shared his testimony with him, literally saving his life (see “A Change of Heart,” lds.org/youth/video). Olavo, from Brazil, is another example. A true standing minister in his home (see D&C 84:111), Olavo inspired his mother to return to full activity in the Church (see “Reunited by Faith,” lds.org/youth/video). You can find some of these stories and many others like them on the Church’s youth website, youth.lds.org. By the way, the Internet, social media, and other technologies are tools the Lord has placed in your hands to help you exercise your priesthood duties and extend the influence of truth and virtue.

Dear young men, when you exercise the Aaronic Priesthood in the way I have described, you are preparing yourselves for responsibilities in your future. But you are doing much more than that. Like John the Baptist, that exemplary Aaronic Priesthood holder, you are also preparing the way of the Lord and making His paths straight. When you boldly declare the gospel of repentance and baptism, as John did, you are preparing the people for the coming of the Lord (see Matthew 3:3; D&C 65:1–3; 84:26–28). You are often told about your great potential. Well, now is the time to put that potential into action, to make use of the abilities God has given you to bless others, bring them out from obscurity and into light, and prepare the way of the Lord.

The Church has given you the Duty to God booklet as a resource to help you learn and fulfill your duties. Study it often. Get on your knees, away from technology, and seek the Lord’s guidance. And then arise and use the power of God. I promise that you will receive answers from Heavenly Father on how to conduct your own life and how to help others.

I quote the words of President Thomas S. Monson: “Never underestimate the far-reaching influence of your testimony. … You have the capacity to notice the unnoticed. When you have eyes to see, ears to hear, and hearts to feel, you can reach out and rescue others” (“Be Thou an Example,” Liahona and Ensign, May 2005, 115).

I testify to you that the power of the priesthood is real. I gained my witness exercising the priesthood myself. I have seen miracle after miracle performed by those who have the power of the Aaronic Priesthood. I have witnessed the power of the ministering of angels as faithful Aaronic Priesthood holders speak Spirit-filled words of hope, opening the heart of someone in need of light and love. In the name of Jesus Christ, our Lord, our leader, and our Savior, amen.

# References
