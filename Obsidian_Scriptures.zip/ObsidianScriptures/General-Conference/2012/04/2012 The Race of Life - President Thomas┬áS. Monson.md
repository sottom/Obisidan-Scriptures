President Thomas S. Monson
President of the Church
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/the-race-of-life?lang=eng)

_Where did we come from? Why are we here? Where do we go after this life? No longer need these universal questions remain unanswered._

My beloved brothers and sisters, this morning I wish to speak to you of eternal truths—those truths which will enrich our lives and see us safely home.

Everywhere people are in a hurry. Jet-powered aircraft speed their precious human cargo across broad continents and vast oceans so that business meetings might be attended, obligations met, vacations enjoyed, or families visited. Roadways everywhere—including freeways, thruways, and motorways—carry millions of automobiles, occupied by more millions of people, in a seemingly endless stream and for a multitude of reasons as we rush about the business of each day.

In this fast-paced life, do we ever pause for moments of meditation—even thoughts of timeless truths?

When compared to eternal verities, most of the questions and concerns of daily living are really rather trivial. What should we have for dinner? What color should we paint the living room? Should we sign Johnny up for soccer? These questions and countless others like them lose their significance when times of crisis arise, when loved ones are hurt or injured, when sickness enters the house of good health, when life’s candle dims and darkness threatens. Our thoughts become focused, and we are easily able to determine what is really important and what is merely trivial.

I recently visited with a woman who has been battling a life-threatening disease for over two years. She indicated that prior to her illness, her days were filled with activities such as cleaning her house to perfection and filling it with beautiful furnishings. She visited her hairdresser twice a week and spent money and time each month adding to her wardrobe. Her grandchildren were invited to visit infrequently, for she was always concerned that what she considered her precious possessions might be broken or otherwise ruined by tiny and careless hands.

And then she received the shocking news that her mortal life was in jeopardy and that she might have very limited time left here. She said that at the moment she heard the doctor’s diagnosis, she knew immediately that she would spend whatever time she had remaining with her family and friends and with the gospel at the center of her life, for these represented what was most precious to her.

Such moments of clarity come to all of us at one time or another, although not always through so dramatic a circumstance. We see clearly what it is that really matters in our lives and how we should be living.

Said the Savior:

“Lay not up for yourselves treasures upon earth, where moth and rust doth corrupt, and where thieves break through and steal:

“But lay up for yourselves treasures in heaven, where neither moth nor rust doth corrupt, and where thieves do not break through nor steal:

“For where your treasure is, there will your heart be also.”1

In our times of deepest reflection or greatest need, the soul of man reaches heavenward, seeking a divine response to life’s greatest questions: Where did we come from? Why are we here? Where do we go after we leave this life?

Answers to these questions are not discovered within the covers of academia’s textbooks or by checking the Internet. These questions transcend mortality. They embrace eternity.

Where did we come from? This query is inevitably thought, if not spoken, by every human being.

The Apostle Paul told the Athenians on Mars’ Hill that “we are the offspring of God.”2 Since we know that our physical bodies are the offspring of our mortal parents, we must probe for the meaning of Paul’s statement. The Lord has declared that “the spirit and the body are the soul of man.”3 Thus it is the spirit which is the offspring of God. The writer of Hebrews refers to Him as “the Father of spirits.”4 The spirits of all men are literally His “begotten sons and daughters.”5

We note that inspired poets have, for our contemplation of this subject, written moving messages and recorded transcendent thoughts. William Wordsworth penned the truth:





Our birth is but a sleep and a forgetting:

The soul that rises with us, our life’s Star,

Hath had elsewhere its setting,

And cometh from afar:

Not in entire forgetfulness,

And not in utter nakedness,

But trailing clouds of glory do we come

From God, who is our home:

Heaven lies about us in our infancy!6





Parents ponder their responsibility to teach, to inspire, and to provide guidance, direction, and example. And while parents ponder, children—and particularly youth—ask the penetrating question, why are we here? Usually it is spoken silently to the soul and phrased, why am I here?

How grateful we should be that a wise Creator fashioned an earth and placed us here, with a veil of forgetfulness of our previous existence so that we might experience a time of testing, an opportunity to prove ourselves in order to qualify for all that God has prepared for us to receive.

Clearly, one primary purpose of our existence upon the earth is to obtain a body of flesh and bones. We have also been given the gift of agency. In a thousand ways we are privileged to choose for ourselves. Here we learn from the hard taskmaster of experience. We discern between good and evil. We differentiate as to the bitter and the sweet. We discover that there are consequences attached to our actions.

By obedience to God’s commandments, we can qualify for that “house” spoken of by Jesus when He declared: “In my Father’s house are many mansions. … I go to prepare a place for you … that where I am, there ye may be also.”7

Although we come into mortality “trailing clouds of glory,” life moves relentlessly forward. Youth follows childhood, and maturity comes ever so imperceptibly. From experience we learn the need to reach heavenward for assistance as we make our way along life’s pathway.

God, our Father, and Jesus Christ, our Lord, have marked the way to perfection. They beckon us to follow eternal verities and to become perfect, as They are perfect.8

The Apostle Paul likened life to a race. To the Hebrews he urged, “Let us lay aside … the sin which doth so easily beset us, and let us run with patience the race that is set before us.”9

In our zeal, let us not overlook the sage counsel from Ecclesiastes: “The race is not to the swift, nor the battle to the strong.”10 Actually, the prize belongs to him or her who endures to the end.

When I reflect on the race of life, I remember another type of race, even from childhood days. My friends and I would take pocketknives in hand and, from the soft wood of a willow tree, fashion small toy boats. With a triangular-shaped cotton sail in place, each would launch his crude craft in the race down the relatively turbulent waters of Utah’s Provo River. We would run along the river’s bank and watch the tiny vessels sometimes bobbing violently in the swift current and at other times sailing serenely as the water deepened.

During a particular race we noted that one boat led all the rest toward the appointed finish line. Suddenly, the current carried it too close to a large whirlpool, and the boat heaved to its side and capsized. Around and around it was carried, unable to make its way back into the main current. At last it came to an uneasy rest amid the flotsam and jetsam that surrounded it, held fast by the tentacles of the grasping green moss.

The toy boats of childhood had no keel for stability, no rudder to provide direction, and no source of power. Inevitably, their destination was downstream—the path of least resistance.

Unlike toy boats, we have been provided divine attributes to guide our journey. We enter mortality not to float with the moving currents of life but with the power to think, to reason, and to achieve.

Our Heavenly Father did not launch us on our eternal voyage without providing the means whereby we could receive from Him guidance to ensure our safe return. I speak of prayer. I speak too of the whisperings from that still, small voice; and I do not overlook the holy scriptures, which contain the word of the Lord and the words of the prophets—provided to us to help us successfully cross the finish line.

At some period in our mortal mission, there appears the faltering step, the wan smile, the pain of sickness—even the fading of summer, the approach of autumn, the chill of winter, and the experience we call death.

Every thoughtful person has asked himself the question best phrased by Job of old: “If a man die, shall he live again?”11 Try as we might to put the question out of our thoughts, it always returns. Death comes to all mankind. It comes to the aged as they walk on faltering feet. Its summons is heard by those who have scarcely reached midway in life’s journey. At times it hushes the laughter of little children.

But what of an existence beyond death? Is death the end of all? Robert Blatchford, in his book God and My Neighbor, attacked with vigor accepted Christian beliefs such as God, Christ, prayer, and particularly immortality. He boldly asserted that death was the end of our existence and that no one could prove otherwise. Then a surprising thing happened. His wall of skepticism suddenly crumbled to dust. He was left exposed and undefended. Slowly he began to feel his way back to the faith he had ridiculed and abandoned. What had caused this profound change in his outlook? His wife died. With a broken heart he went into the room where lay all that was mortal of her. He looked again at the face he loved so well. Coming out, he said to a friend: “It is she, and yet it is not she. Everything is changed. Something that was there before is taken away. She is not the same. What can be gone if it be not the soul?”

Later he wrote: “Death is not what some people imagine. It is only like going into another room. In that other room we shall find … the dear women and men and the sweet children we have loved and lost.”12

My brothers and sisters, we know that death is not the end. This truth has been taught by living prophets throughout the ages. It is also found in our holy scriptures. In the Book of Mormon we read specific and comforting words:

“Now, concerning the state of the soul between death and the resurrection—Behold, it has been made known unto me by an angel, that the spirits of all men, as soon as they are departed from this mortal body, yea, the spirits of all men, whether they be good or evil, are taken home to that God who gave them life.

“And then shall it come to pass, that the spirits of those who are righteous are received into a state of happiness, which is called paradise, a state of rest, a state of peace, where they shall rest from all their troubles and from all care, and sorrow.”13

After the Savior was crucified and His body had lain in the tomb for three days, the spirit again entered. The stone was rolled away, and the resurrected Redeemer walked forth, clothed with an immortal body of flesh and bones.

The answer to Job’s question, “If a man die, shall he live again?” came when Mary and others approached the tomb and saw two men in shining garments who spoke to them: “Why seek ye the living among the dead? He is not here, but is risen.”14

As the result of Christ’s victory over the grave, we shall all be resurrected. This is the redemption of the soul. Paul wrote: “There are … celestial bodies, and bodies terrestrial: but the glory of the celestial is one, and the glory of the terrestrial is another.”15

It is the celestial glory which we seek. It is in the presence of God we desire to dwell. It is a forever family in which we want membership. Such blessings are earned through a lifetime of striving, seeking, repenting, and finally succeeding.

Where did we come from? Why are we here? Where do we go after this life? No longer need these universal questions remain unanswered. From the very depths of my soul and in all humility, I testify that those things of which I have spoken are true.

Our Heavenly Father rejoices for those who keep His commandments. He is concerned also for the lost child, the tardy teenager, the wayward youth, the delinquent parent. Tenderly the Master speaks to these and indeed to all: “Come back. Come up. Come in. Come home. Come unto me.”

In one week we will celebrate Easter. Our thoughts will turn to the Savior’s life, His death, and His Resurrection. As His special witness, I testify to you that He lives and that He awaits our triumphant return. That such a return will be ours, I pray humbly in His holy name—even Jesus Christ, our Savior and our Redeemer, amen.

# References
1. - Matthew 6:19–21.
2. - Acts 17:29.
3. - Doctrine and Covenants 88:15.
4. - Hebrews 12:9.
5. - Doctrine and Covenants 76:24.
6. - William Wordsworth, Ode: Intimations of Immortality from Recollections of Early Childhood (1884), 23–24.
7. - John 14:2–3.
8. - See Matthew 5:48; 3 Nephi 12:48.
9. - Hebrews 12:1.
10. - Ecclesiastes 9:11.
11. - Job 14:14.
12. - See Robert Blatchford, More Things in Heaven and Earth: Adventures in Quest of a Soul (1925), 11.
13. - Alma 40:11–12.
14. - Luke 24:5–6.
15. - 1 Corinthians 15:40.