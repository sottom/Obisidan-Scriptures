Elder David F. Evans
Of the Seventy
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/was-it-worth-it?lang=eng)

_The work of naturally and normally sharing the gospel with those we care about and love will be the work and joy of our lives._

During this conference and in other recent meetings,1 many of us have wondered, what can I do to help build up the Lord’s Church and see real growth where I live?

In this and every other important endeavor, our most important work is always within our own home and family.2 It is within families that the Church is established and real growth occurs.3 We are to teach our children the principles and doctrines of the gospel. We need to help them have faith in Jesus Christ and prepare them for baptism when they are eight years old.4 We must be faithful ourselves so that they can see our example of love for the Lord and His Church. This helps our children feel joy in keeping the commandments, happiness in families, and gratitude in service to others. Within our homes we should follow the pattern given by Nephi when he said:

“We labor diligently … to persuade our children … to believe in Christ, and to be reconciled to God. …

“… We talk of Christ, we rejoice in Christ, we preach of Christ, we prophesy of Christ, and we write according to our prophecies, that our children may know to what source they may look for a remission of their sins.”5

We labor diligently to bring these blessings to our children by attending church with them, holding family home evening, and reading the scriptures together. We pray daily with our family, accept callings, visit the sick and the lonely, and do other things that let our children know that we love them and that we love our Heavenly Father, His Son, and Their Church.

We talk and prophesy of Christ as we give a family home evening lesson or sit with a child and tell of our love for him or her and of our testimony of the restored gospel.

We can write of Christ by writing letters to those who are away. Missionaries serving, sons or daughters in the military, and those we love are all blessed by letters we write. Letters from home are not just quick e-mails. Real letters provide something tangible that can be held, thought about, and cherished.

We help our children rely on the Savior’s Atonement and know the forgiveness of a loving Heavenly Father by showing love and forgiveness in our own parenting. Our love and forgiveness not only draw our children closer to us but also build their faith in knowing that Heavenly Father loves them and that He will forgive them as they strive to repent and do better and be better. They trust this truth because they have experienced the same from their earthly parents.

In addition to the work we will do within our own family, Nephi taught that “we labor diligently to … persuade our … brethren, to believe in Christ, and to be reconciled to God.”6 As members of The Church of Jesus Christ of Latter-day Saints, every one of us has the blessing and responsibility of sharing the gospel. Some of those who need the gospel in their lives are not yet members of the Church. Some were once among us but need to feel again the joy they felt when they embraced the gospel at an earlier time in their lives. The Lord loves both the person who has never had the gospel and the person who is returning to Him.7 To Him and to us, it doesn’t matter. It is all one work. It is the worth of souls, whatever their condition, that is great to our Heavenly Father, His Son, and to us.8 The work of our Heavenly Father and His Son is “to bring to pass the immortality and eternal life”9 of all His children, regardless of their current circumstances. Our blessing is to help in this great work.

President Thomas S. Monson explained how we can help when he said: “Our missionary experiences have to be current. It is not enough to sit back and ponder former experiences. To be fulfilled, you have to continue to naturally and normally share the gospel.”10

The work of naturally and normally sharing the gospel with those we care about and love will be the work and joy of our lives. Let me tell you about two such experiences.

Dave Orchard grew up in Salt Lake City, where most of his friends were members of the Church. They were a great influence on him. In addition, Church leaders in his neighborhood constantly invited him to activities. His friends did the same. Even though he didn’t join the Church at that time, his growing-up years were blessed by the influence of good LDS friends and Church-sponsored activities. After he entered college, he moved away from his home, and most of his friends left on missions. He missed their influence in his life.

One of Dave’s high school friends was still home. This friend was meeting every week with his bishop in an effort to put his life in order and be able to serve as a missionary. He and Dave became roommates, and as would be both natural and normal, they talked about why he wasn’t then serving as a missionary and why he was meeting frequently with the bishop. The friend expressed his gratitude and respect for his bishop and the opportunity to repent and serve. He then asked Dave whether he would like to come to the next interview. What an invitation! But in the context of their friendship and circumstances, it was both natural and normal.

Dave agreed and was soon meeting with the bishop himself. This led to Dave’s decision to meet with the missionaries. He received a testimony that the gospel is true, and a date for his baptism was set. Dave was baptized by his bishop, and a year later, Dave Orchard and Katherine Evans were married in the temple. They have five beautiful children. Katherine is my little sister. I will be forever grateful to this good friend who, together with a good bishop, brought Dave into the Church.

As Dave spoke of his conversion and bore his testimony regarding these events, he asked the question, “So, was it worth it? Was all the effort of friends and youth leaders and my bishop, over all the years, worth the effort to have just one boy be baptized?” Pointing to Katherine and his five children, he said, “Well, at least for my wife and our five children, the answer is yes.”

Whenever the gospel is shared, it is never “just one boy.” Whenever conversion happens or someone returns to the Lord, it is a family that is saved. As Dave and Katherine’s children have grown, they have all embraced the gospel. One daughter and two sons have served as missionaries, and one just received his call to serve in the Alpine German-Speaking Mission. The two oldest have married in the temple, and the youngest is now in high school, faithful in every way. Was it worth it? Oh yes, it was worth it.

Sister Eileen Waite attended the same stake conference where Dave Orchard told of his conversion experience. Throughout the conference, all she could think of was her own family and particularly her sister, Michelle, who had long been away from the Church. Michelle was divorced and trying to raise four children. Eileen felt impressed to send her a copy of Elder M. Russell Ballard’s book Our Search for Happiness, together with her testimony, which she did. The very next week a friend told Eileen that she too had felt that she should contact Michelle. This friend also wrote Michelle a note, sharing her testimony and expressing her love. Isn’t it interesting how often the Spirit works on several people to help one in need?

Time passed. Michelle called Eileen and thanked her for the book. She said that she was beginning to recognize the spiritual void in her life. Eileen told her that she knew that the peace she was seeking could be found in the gospel. She told her that she loved her and wanted her to be happy. Michelle began to make changes in her life. Soon she met a wonderful man who was active in the Church. They married and a year later were sealed in the Ogden Utah Temple. Recently her 24-year-old son was baptized.

To the others in Michelle’s family and all others who do not yet know that this Church is true, I invite you to prayerfully consider whether the Church is true. Allow your family and friends and missionaries to help. When you know that it is true, and it is, come join with us by taking the same step in your life.

The end of this story has not yet been written, but blessings have been given to this wonderful woman and her family as those who love her acted on a prompting and in a natural and normal way shared their testimony and invited her to come back.

I have thought a lot about these two experiences. One young man who was working to put his own life in order helped another young man who was seeking the truth. One woman shared her testimony and her faith with her sister who had been away from the Church for 20 years. If we will pray and ask Heavenly Father who we can help and promise to act on the promptings He gives us letting us know how we can help, He will answer our prayers and we will become instruments in His hands to do His work. Acting in love upon the promptings given by the Spirit becomes the catalyst.11

As you have listened to these experiences of naturally and normally sharing the gospel with those you care about, many of you have had the same experience that Eileen Waite had. You have thought of someone to whom you should reach out and either invite to come back or share with him or her your feelings about the gospel of Jesus Christ. My invitation is to act, without delay, on that prompting. Talk to your friend or family member. Do it in a natural and normal way. Let them know of your love for them and for the Lord. Missionaries can help. My counsel is the same that President Monson has given so many times from this very pulpit: “Never delay a prompting.”12 As you act on the prompting and do it with love, watch as our Heavenly Father uses your willingness to act to bring about a miracle in your life and in the life of the person you care about.13

My dear brothers and sisters, we can build up His Church and see real growth as we work to bring the blessings of the gospel to our family and to those we love. This is the work of our Heavenly Father and His Son. I know that They live and that They answer prayers. As we act on those promptings, having faith in Their ability to bring about a miracle, miracles will occur and lives will change. In the name of Jesus Christ, amen.

# References
1. - See Worldwide Leadership Training Meeting, Feb. 11, 2012, LDS.org.
2. - See Teachings of Presidents of the Church: Harold B. Lee (2000), 134.
3. - See Boyd K. Packer, “Priesthood Power in the Home,” Worldwide Leadership Training Meeting, Feb. 11, 2012, LDS.org.
4. - See Doctrine and Covenants 68:25–28.
5. - 2 Nephi 25:23, 26.
6. - 2 Nephi 25:23.
7. - See Luke 15:4–7.
8. - See Doctrine and Covenants 18:10.
9. - Moses 1:39.
10. - “Status Report on Missionary Work: A Conversation with Elder Thomas S. Monson, Chairman of the Missionary Committee of the Council of the Twelve,” Ensign, Oct. 1977, 14.
11. - See Thomas S. Monson, “Anxiously Engaged,” Liahona and Ensign, Nov. 2004, 56–59; “To the Rescue,” Liahona, July 2001, 57–60; Ensign, May 2001, 48–50; “The Doorway of Love,” Liahona and Ensign, Oct. 1996, 2–7.
12. - See Ann M. Dibb, “My Father Is a Prophet” (Brigham Young University–Idaho devotional, Feb. 19, 2008), byui.edu/devotionalsandspeeches; Thomas S. Monson, “Stand in Your Appointed Place,” Liahona and Ensign, May 2003, 54–57; “Peace, Be Still,” Liahona and Ensign, Nov. 2002, 53–56; “Priesthood Power,” Liahona, Jan. 2000, 58–61; Ensign, Nov. 1999, 49–51; “The Spirit Giveth Life,” Ensign, May 1985, 68–70.
13. - In addition to President Thomas S. Monson, other prophets have taught this same principle. For example, President Spencer W. Kimball taught the importance of acting on the impressions given through the Spirit when he said: “God does notice us, and he watches over us. But it is usually through another person that he meets our needs. Therefore, it is vital that we serve each other in the kingdom” (Teachings of Presidents of the Church: Spencer W. Kimball [2006], 82).