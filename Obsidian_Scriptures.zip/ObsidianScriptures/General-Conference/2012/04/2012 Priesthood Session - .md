

04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/priesthood-session?lang=eng)



# References
