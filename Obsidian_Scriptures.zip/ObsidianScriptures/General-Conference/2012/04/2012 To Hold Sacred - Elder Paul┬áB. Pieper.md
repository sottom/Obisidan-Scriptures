Elder Paul B. Pieper
Of the Seventy
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/to-hold-sacred?lang=eng)

_Sacred things are to be treated with more care, given greater deference, and regarded with deeper reverence._

Some 1,500 years before Christ, a shepherd was drawn to a burning bush on the slopes of Mount Horeb. That divine encounter began the transformation of Moses from a shepherd to a prophet and his work from herding sheep to gathering Israel. Thirteen hundred years later, a privileged young priest in a king’s court was captivated by the witness of a condemned prophet. That encounter began Alma’s evolution from a civil servant to a servant of God. Nearly 2,000 years later, a 14-year-old boy entered the woods seeking an answer to a sincere question. Joseph Smith’s encounter in the grove placed him on the path to prophethood and a restoration.

Moses’s, Alma’s, and Joseph Smith’s lives were all changed by encounters with the divine. These experiences strengthened them to remain faithful to the Lord and His work throughout their lives despite overwhelming opposition and subsequent difficult trials.

Our experiences with the divine may not be as direct or dramatic nor our challenges as daunting. However, as with the prophets, our strength to endure faithfully depends upon recognizing, remembering, and holding sacred that which we receive from above.

Today authority, keys, and ordinances have been restored to the earth. There are also scriptures and special witnesses. Those who seek God may receive baptism for the remission of sins and confirmation “by the laying on of hands for the baptism of fire and the Holy Ghost” (D&C 20:41). With these precious restored gifts, our divine encounters will mostly involve the third member of the Godhead, the Holy Ghost.





Through a still small voice, the Spirit speaks to me

To guide me, to save me.





(“The Still Small Voice,” Children’s Songbook, 106)









Let the Holy Spirit guide;

Let him teach us what is true.

He will testify of Christ,

Light our minds with heaven’s view.





(“Let the Holy Spirit Guide,” Hymns, no. 143)





As we seek answers from God, we feel the still, small voice whisper to our spirits. These feelings—these impressions—are so natural and so subtle that we may overlook them or attribute them to reason or intuition. These individualized messages testify of God’s personal love and concern for each of His children and their personal mortal missions. Daily reflecting upon and recording the impressions that come from the Spirit serve the dual purposes of helping us (1) to recognize our personal encounters with the divine and (2) to preserve them for ourselves and our posterity. Recording them is also a formal recognition and acknowledgment of our gratitude to God, for “in nothing doth man offend God, or against none is his wrath kindled, save those who confess not his hand in all things” (D&C 59:21).

With respect to that which we receive by the Spirit, the Lord said, “Remember that that which cometh from above is sacred” (D&C 63:64). His statement is more than a reminder; it is also a definition and an explanation. Light and knowledge from heaven is sacred. It is sacred because heaven is its source.

Sacred means worthy of veneration and respect. By designating something as sacred, the Lord signals that it is of higher value and priority than other things. Sacred things are to be treated with more care, given greater deference, and regarded with deeper reverence. Sacred ranks high in the hierarchy of heavenly values.

That which is sacred to God becomes sacred to us only through the exercise of agency; each must choose to accept and hold sacred that which God has defined as sacred. He sends light and knowledge from heaven. He invites us to receive and treat it as sacred.

But “there is an opposition in all things” (2 Nephi 2:11). The opposite of sacred is profane or secular—that which is temporal or worldly. The worldly constantly competes with the sacred for our attention and priorities. Knowledge of the secular is essential for our daily temporal living. The Lord instructs us to seek learning and wisdom, to study and learn out of the best books, and to become acquainted with languages, tongues, and people (see D&C 88:118; 90:15). Therefore, the choice to place the sacred above the secular is one of relative priority, not exclusivity; “to be learned is good if [we] hearken unto the counsels of God” (2 Nephi 9:29; emphasis added).

The battle for priority between the sacred and the secular in each human heart can be illustrated by Moses’s experience at the burning bush. There Moses received his sacred calling from Jehovah to deliver the children of Israel from bondage. However, initially his worldly knowledge of the power of Egypt and the pharaoh caused him to doubt. Ultimately, Moses exercised faith in the Lord’s word, subjugating his secular knowledge and trusting in the sacred. That trust provided him power to overcome temporal trials and lead Israel out of Egypt.

After escaping from the armies of Noah only to fall into slavery at the hands of Amulon, Alma could have doubted the spiritual witness he had received while listening to Abinadi. However, he trusted the sacred and was given strength to endure and escape his temporary trials.

Joseph Smith faced a similar dilemma in the early days of translating the Book of Mormon. He knew the sacred nature of the plates and the work of translation. Yet he was persuaded by Martin Harris to give priority to the worldly concerns of friendship and finances, contrary to sacred instructions. As a result, the manuscript of the translation was lost. The Lord upbraided Joseph for delivering “that which [is] sacred, unto wickedness” (D&C 10:9) and deprived him for a time of the plates and the gift to translate. When Joseph’s priorities were properly reestablished, the sacred things were returned and the work continued.

The Book of Mormon provides other examples of the struggle to give priority to the sacred. It speaks of believers whose faith led them to the tree of life to partake of its sacred fruit, the love of God. Then the mocking of those in the great and spacious building caused the believers to shift their focus from the sacred to the secular. (See 1 Nephi 8:11, 24–28.) Later the Nephites chose pride and denied the spirit of prophecy and revelation, “making a mock of that which was sacred” (Helaman 4:12). Even some eyewitnesses of the signs and miracles associated with the Lord’s birth chose to reject sacred manifestations from heaven in favor of secular explanations (see 3 Nephi 2:1–3).

Today the struggle continues. Secular voices are growing in volume and intensity. They increasingly urge believers to abandon beliefs the world considers irrational and unreasonable. Because “we see through a glass, darkly” (1 Corinthians 13:12) and “do not know the meaning of all things” (1 Nephi 11:17), at times we may feel vulnerable and in need of greater spiritual assurances. The Lord told Oliver Cowdery:

“If you desire a further witness, cast your mind upon the night that you cried unto me in your heart, that you might know concerning the truth of these things.

“Did I not speak peace to your mind concerning the matter? What greater witness can you have than from God?” (D&C 6:22–23).

The Lord reminded Oliver and us to rely on sacred personal witnesses already received when our faith is challenged. Like Moses’s, Alma’s and Joseph’s before, these divine encounters serve as spiritual anchors to keep us safe and on course in times of trial.

The sacred cannot be selectively surrendered. Those who choose to abandon even one sacred thing will have their minds darkened (see D&C 84:54), and unless they repent, the light they have shall be taken from them (see D&C 1:33). Unanchored by the sacred, they will find themselves morally adrift on a secular sea. In contrast, those who hold sacred things sacred receive promises: “That which is of God is light; and he that receiveth light, and continueth in God, receiveth more light; and that light groweth brighter and brighter until the perfect day” (D&C 50:24).

May the Lord bless us to ever and always recognize, remember, and hold sacred that which we have received from above. I testify that as we do, we will have power to endure the trials and overcome the challenges of our day. In the name of Jesus Christ, amen.

# References
