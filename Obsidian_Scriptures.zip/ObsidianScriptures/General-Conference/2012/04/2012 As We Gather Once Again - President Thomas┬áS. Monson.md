President Thomas S. Monson
President of the Church
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/as-we-gather-once-again?lang=eng)

_Our Heavenly Father is mindful of each of us and our needs. May we be filled with His Spirit as we partake of the proceedings of this conference._

My beloved brothers and sisters, as we gather once again in a general conference of the Church, I welcome you and express my love to you. We meet each six months to strengthen one another, to extend encouragement, to provide comfort, to build faith. We are here to learn. Some of you may be seeking answers to questions and challenges you are experiencing in your life. Some are struggling with disappointments or losses. Each can be enlightened and uplifted and comforted as the Spirit of the Lord is felt.

Should there be changes which need to be made in your life, may you find the incentive and the courage to do so as you listen to the inspired words which will be spoken. May each of us resolve anew to live so that we are worthy sons and daughters of our Heavenly Father. May we continue to oppose evil wherever it is found.

How blessed we are to have come to earth at such a time as this—a marvelous time in the long history of the world. We can’t all be together under one roof, but we now have the ability to partake of the proceedings of this conference through the wonders of television, radio, cable, satellite transmission, and the Internet—even on mobile devices. We come together as one, speaking many languages, living in many lands, but all of one faith and one doctrine and one purpose.

From a small beginning 182 years ago, our presence is now felt throughout the world. This great cause in which we are engaged will continue to go forth, changing and blessing lives as it does so. No cause, no force in the entire world can stop the work of God. Despite what comes, this great cause will go forward. You recall the prophetic words of the Prophet Joseph Smith: “No unhallowed hand can stop the work from progressing; persecutions may rage, mobs may combine, armies may assemble, calumny may defame, but the truth of God will go forth boldly, nobly, and independent, till it has penetrated every continent, visited every clime, swept every country, and sounded in every ear, till the purposes of God shall be accomplished, and the Great Jehovah shall say the work is done.”1

There is much that is difficult and challenging in the world today, my brothers and sisters, but there is also much that is good and uplifting. As we declare in our thirteenth article of faith, “If there is anything virtuous, lovely, or of good report or praiseworthy, we seek after these things.” May we ever continue to do so.

I thank you for your faith and devotion to the gospel. I thank you for the love and care you show one to another. I thank you for the service you provide in your wards and branches and in your stakes and districts. It is such service that enables the Lord to accomplish many of His purposes here upon the earth.

I express my thanks to you for your kindnesses to me wherever I go. I thank you for your prayers in my behalf. I have felt those prayers and am most grateful for them.

Now, my brothers and sisters, we have come to be instructed and inspired. Many messages will be shared during the next two days. I can assure you that those men and women who will address you have sought heaven’s help and direction as they have prepared their messages. They have been inspired concerning that which they will share with us.

Our Heavenly Father is mindful of each of us and our needs. May we be filled with His Spirit as we partake of the proceedings of this conference. This is my sincere prayer in the sacred name of our Lord and Savior, Jesus Christ, amen.

# References
1. - Teachings of Presidents of the Church: Joseph Smith (2007), 444.