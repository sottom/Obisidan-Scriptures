Presented by Brook P. Hales
Secretary to the First Presidency
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/statistical-report-2011?lang=eng)

For the information of the members of the Church, the First Presidency has issued the following statistical report concerning the growth and status of the Church as of December 31, 2011.





Church Units





Stakes



2,946



Missions



340



Districts



608



Wards and Branches



28,784









Church Membership





Total Membership



14,441,346



New Children of Record during 2011



119,917



Converts Baptized during 2011



281,312









Missionaries





Full-Time Missionaries



55,410



Church-Service Missionaries



22,299









Temples





Temples Dedicated during 2011 (San Salvador El Salvador and Quetzaltenango Guatemala)



2



Temples Rededicated during 2011 (Atlanta Georgia)



1



Temples in Operation



136









Former General Church Officers and Others Who Have Passed Away since Last April General Conference



Elders Marion D. Hanks, Jack H Goaslind Jr., Monte J. Brough, Ronald E. Poelman, Keith W. Wilcox, and Harold G. Hillam, all former members of the Quorums of the Seventy; Sisters Joy F. Evans and Chieko N. Okazaki, former counselors in the Relief Society general presidency; Sister Norma Voloy Sonntag, wife of Elder Philip T. Sonntag, a former member of the Seventy; Sister Leola George, widow of Elder Lloyd P. George, a former member of the Seventy; Sister Argelia Villanueva de Alvarez, wife of Elder Lino Alvarez, also a former member of the Seventy; and Brother Wendell M. Smoot Jr., former president of the Tabernacle Choir.

# References
