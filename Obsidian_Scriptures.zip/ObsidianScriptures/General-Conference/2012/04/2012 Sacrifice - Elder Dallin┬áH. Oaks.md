Elder Dallin H. Oaks
Of the Quorum of the Twelve Apostles
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/sacrifice?lang=eng)

_Our lives of service and sacrifice are the most appropriate expressions of our commitment to serve the Master and our fellowmen._

The atoning sacrifice of Jesus Christ has been called the “most transcendent of all events from creation’s dawn to the endless ages of eternity.”1 That sacrifice is the central message of all the prophets. It was prefigured by the animal sacrifices prescribed by the law of Moses. A prophet declared that their whole meaning “point[ed] to that great and last sacrifice [of] … the Son of God, yea, infinite and eternal” (Alma 34:14). Jesus Christ endured incomprehensible suffering to make Himself a sacrifice for the sins of all. That sacrifice offered the ultimate good—the pure Lamb without blemish—for the ultimate measure of evil—the sins of the entire world. In the memorable words of Eliza R. Snow:





His precious blood he freely spilt;

His life he freely gave,

A sinless sacrifice for guilt,

A dying world to save.2





That sacrifice—the Atonement of Jesus Christ—is at the center of the plan of salvation.

The incomprehensible suffering of Jesus Christ ended sacrifice by the shedding of blood, but it did not end the importance of sacrifice in the gospel plan. Our Savior requires us to continue to offer sacrifices, but the sacrifices He now commands are that we “offer for a sacrifice unto [Him] a broken heart and a contrite spirit” (3 Nephi 9:20). He also commands each of us to love and serve one another—in effect, to offer a small imitation of His own sacrifice by making sacrifices of our own time and selfish priorities. In an inspired hymn, we sing, “Sacrifice brings forth the blessings of heaven.”3

I will speak of these mortal sacrifices our Savior asks us to make. This will not include sacrifices we are compelled to make or actions that may be motivated by personal advantage rather than service or sacrifice (see 2 Nephi 26:29).





I.



The Christian faith has a history of sacrifice, including the ultimate sacrifice. In the early years of the Christian era, Rome martyred thousands for their faith in Jesus Christ. In later centuries, as doctrinal controversies divided Christians, some groups persecuted and even put to death the members of other groups. Christians killed by other Christians are the most tragic martyrs of the Christian faith.

Many Christians have voluntarily given sacrifices motivated by faith in Christ and the desire to serve Him. Some have chosen to devote their entire adult lives to the service of the Master. This noble group includes those in the religious orders of the Catholic Church and those who have given lifelong service as Christian missionaries in various Protestant faiths. Their examples are challenging and inspiring, but most believers in Christ are neither expected nor able to devote their entire lives to religious service.







II.



For most followers of Christ, our sacrifices involve what we can do on a day-to-day basis in our ordinary personal lives. In that experience I know of no group whose members make more sacrifices than Latter-day Saints. Their sacrifices—your sacrifices, my brothers and sisters—stand in contrast to the familiar worldly quests for personal fulfillment.

My first examples are our Mormon pioneers. Their epic sacrifices of lives, family relationships, homes, and comforts are at the foundation of the restored gospel. Sarah Rich spoke for what motivated these pioneers when she described her husband, Charles, being called away on a mission: “This truly was a trying time for me as well as for my husband; but duty called us to part for a season and knowing that we [were] obeying the will of the Lord, we felt to sacrifice our own feelings in order to help establish the work … of helping to build up the Kingdom of God on earth.”4

Today the most visible strength of The Church of Jesus Christ of Latter-day Saints is the unselfish service and sacrifice of its members. Prior to the rededication of one of our temples, a Christian minister asked President Gordon B. Hinckley why it did not contain any representation of the cross, the most common symbol of the Christian faith. President Hinckley replied that the symbols of our Christian faith are “the lives of our people.”5 Truly, our lives of service and sacrifice are the most appropriate expressions of our commitment to serve the Master and our fellowmen.







III.



We have no professionally trained and salaried clergy in The Church of Jesus Christ of Latter-day Saints. As a result, the lay members who are called to lead and serve our congregations must carry the whole load of our numerous Church meetings, programs, and activities. They do this in more than 14,000 congregations just in the United States and Canada. Of course, we are not unique in having lay members of our congregations serve as teachers and lay leaders. But the amount of time donated by our members to train and minister to one another is uniquely large. Our efforts to have each family in our congregations visited by home teachers each month and to have each adult woman visited by Relief Society visiting teachers each month are examples of this. We know of no comparable service in any organization in the world.

The best-known examples of unique LDS service and sacrifice are the work of our missionaries. Currently they number more than 50,000 young men and young women and over 5,000 adult men and women. They devote from six months to two years of their lives to teaching the gospel of Jesus Christ and providing humanitarian service in more than 160 countries in the world. Their work always involves sacrifice, including the years they give to the work of the Lord and also the sacrifices made in providing funds for their support.

Those who remain at home—parents and other family members—also sacrifice by forgoing the companionship and service of the missionaries they send forth. For example, a young Brazilian received a missionary call while he was working to support his brothers and sisters after his father and mother died. A General Authority described these children’s meeting in council and remembering that their deceased parents had taught them that they should always be prepared to serve the Lord. The young man accepted his missionary call, and a 16-year-old brother took over the responsibility of working to support the family.6 Most of us know of many other examples of sacrifice to serve a mission or to support a missionary. We know of no other voluntary service and sacrifice like this in any other organization in the world.

We are frequently asked, “How do you persuade your young people and your older members to leave their schooling or their retirement to sacrifice in this way?” I have heard many give this explanation: “Knowing what my Savior did for me—His grace in suffering for my sins and in overcoming death so I can live again—I feel privileged to make the small sacrifice I am asked to make in His service. I want to share the understanding He has given me.” How do we persuade such followers of Christ to serve? As a prophet explained, “We [just] ask them.”7

Other sacrifices resulting from missionary service are the sacrifices of those who act on the teachings of the missionaries and become members of the Church. For many converts, these sacrifices are very significant, including the loss of friends and family associations.

Many years ago this conference heard of a young man who found the restored gospel while he was studying in the United States. As this man was about to return to his native land, President Gordon B. Hinckley asked him what would happen to him when he returned home as a Christian. “My family will be disappointed,” the young man answered. “They may cast me out and regard me as dead. As for my future and my career, all opportunity may be foreclosed against me.”

“Are you willing to pay so great a price for the gospel?” President Hinckley asked.

Tearfully the young man answered, “It’s true, isn’t it?” When that was affirmed, he replied, “Then what else matters?”8 That is the spirit of sacrifice among many of our new members.

Other examples of service and sacrifice appear in the lives of the faithful members who serve in our temples. Temple service is unique to Latter-day Saints, but the significance of such sacrifice should be understandable to all Christians. Latter-day Saints have no tradition of service in a monastery, but we can still understand and honor the sacrifice of those whose Christian faith motivates them to devote their lives to that religious activity.

In this conference just a year ago, President Thomas S. Monson shared an example of sacrifice in connection with temple service. A faithful Latter-day Saint father on a remote island in the Pacific did heavy physical work in a faraway place for six years to earn the money necessary to take his wife and 10 children for marriage and sealing for eternity in the New Zealand Temple. President Monson explained, “Those who understand the eternal blessings which come from the temple know that no sacrifice is too great, no price too heavy, no struggle too difficult in order to receive those blessings.”9

I am grateful for the marvelous examples of Christian love, service, and sacrifice I have seen among the Latter-day Saints. I see you performing your Church callings, often at great sacrifice of time and means. I see you serving missions at your own expense. I see you cheerfully donating your professional skills in service to your fellowmen. I see you caring for the poor through personal efforts and through supporting Church welfare and humanitarian contributions.10 All of this is affirmed in a nationwide study which concluded that active members of The Church of Jesus Christ of Latter-day Saints “volunteer and donate significantly more than the average American and are even more generous in time and money than the upper [20 percent] of religious people in America.”11

Such examples of giving to others strengthen all of us. They remind us of the Savior’s teaching:

“If any man will come after me, let him deny himself. …

“For whosoever will save his life shall lose it: and whosoever will lose his life for my sake shall find it” (Matthew 16:24–25).







IV.



Perhaps the most familiar and most important examples of unselfish service and sacrifice are performed in our families. Mothers devote themselves to the bearing and nurturing of their children. Husbands give themselves to supporting their wives and children. The sacrifices involved in the eternally important service to our families are too numerous to mention and too familiar to need mention.

I also see unselfish Latter-day Saints adopting children, including those with special needs, and seeking to provide foster children the hope and opportunities denied them by earlier circumstances. I see you caring for family members and neighbors who suffer from birth defects, mental and physical ailments, and the effects of advancing years. The Lord sees you also, and He has caused His prophets to declare that “as you sacrifice for each other and your children, the Lord will bless you.”12

I believe that Latter-day Saints who give unselfish service and sacrifice in worshipful imitation of our Savior adhere to eternal values to a greater extent than any other group of people. Latter-day Saints look on their sacrifices of time and means as a part of their schooling and qualifying for eternity. This is a truth revealed in the Lectures on Faith, which teach that “a religion that does not require the sacrifice of all things never has power sufficient to produce the faith necessary unto life and salvation. … It [is] through this sacrifice, and this only, that God has ordained that men should enjoy eternal life.”13

Just as the atoning sacrifice of Jesus Christ is at the center of the plan of salvation, we followers of Christ must make our own sacrifices to prepare for the destiny that plan provides for us.

I know that Jesus Christ is the Only Begotten Son of God the Eternal Father. I know that because of His atoning sacrifice, we have the assurance of immortality and the opportunity for eternal life. He is our Lord, our Savior, and our Redeemer, and I testify of Him in the name of Jesus Christ, amen.

# References
1. - Bruce R. McConkie, The Promised Messiah: The First Coming of Christ (1981), 218.
2. - “How Great the Wisdom and the Love,” Hymns, no. 195.
3. - “Praise to the Man,” Hymns, no. 27.
4. - Sarah Rich, in Guinevere Thomas Woolstenhulme, “I Have Seen Many Miracles,” in Richard E. Turley Jr. and Brittany A. Chapman, eds., Women of Faith in the Latter Days: Volume 1, 1775–1820 (2011), 283.
5. - Gordon B. Hinckley, “The Symbol of Our Faith,” Liahona and Ensign, Apr. 2005, 3.
6. - See Harold G. Hillam, “Sacrifice in the Service,” Ensign, Nov. 1995, 42.
7. - Gordon B. Hinckley, “The Miracle of Faith,” Liahona, July 2001, 84; Ensign, May 2001, 68.
8. - Gordon B. Hinckley, “It’s True, Isn’t It?” Tambuli, Oct. 1993, 3–4; Ensign, July 1993, 2; see also Neil L. Andersen, “It’s True, Isn’t It? Then What Else Matters?” Liahona and Ensign, May 2007, 74.
9. - Thomas S. Monson, “The Holy Temple—a Beacon to the World,” Liahona and Ensign, May 2011, 91–92.
10. - See, for example, Naomi Schaefer Riley, “What the Mormons Know about Welfare,” Wall Street Journal, Feb. 18, 2012, A11.
11. - Ram Cnaan and others, “Called to Serve: The Prosocial Behavior of Active Latter-day Saints” (draft), 16.
12. - Ezra Taft Benson, “To the Single Adult Brethren of the Church,” Ensign, May 1988, 53.
13. - Lectures on Faith (1985), 69.