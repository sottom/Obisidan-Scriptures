Elder Neil L. Andersen
Of the Quorum of the Twelve Apostles
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/what-thinks-christ-of-me?lang=eng)

_As you love Him, trust Him, believe Him, and follow Him, you will feel His love and approval._

A reporter from a leading Brazilian magazine studied the Church in preparation for a major news article.1 He examined our doctrine and visited the missionary training and humanitarian centers. He spoke with friends of the Church and with others who were not so friendly. In the interview with me, the reporter seemed honestly puzzled as he asked, “How could someone not consider you Christian?” I knew he was referring to the Church, but my mind somehow framed the question personally, and I found myself silently asking, “Does my life reflect the love and devotion I feel for the Savior?”

Jesus asked the Pharisees, “What think ye of Christ?”2 In the final assessment, our personal discipleship will not be judged by friends or foes. Rather, as Paul said, “We shall all stand before the judgment seat of Christ.”3 At that day the important question for each of us will be, “What thinks Christ of me?”

Even with His love for all mankind, Jesus reprovingly referred to some around Him as hypocrites,4 fools,5 and workers of iniquity.6 He approvingly called others children of the kingdom7 and the light of the world.8 He disapprovingly referred to some as blinded9 and unfruitful.10 He commended others as pure in heart11 and hungering after righteousness.12 He lamented that some were faithless13 and of the world,14 but others He esteemed as chosen,15 disciples,16 friends.17 And so we each ask, “What thinks Christ of me?”

President Thomas S. Monson has described our day as moving away “from that which is spiritual … [with] the winds of change [swirling] around us and the moral fiber of society [continuing] to disintegrate before our very eyes.”18 It is a time of growing disbelief in and disregard for Christ and His teachings.

In this turbulent environment, we rejoice in being disciples of Jesus Christ. We see the Lord’s hand all around us. Our destination is beautifully set before us. “This is life eternal,” Jesus prayed, “that they might know thee the only true God, and Jesus Christ, whom thou hast sent.”19 Being a disciple in these days of destiny will be a badge of honor throughout the eternities.

The messages we have heard during this conference are guideposts from the Lord on our journey of discipleship. As we have listened during the past two days, praying for spiritual guidance, and as we study and pray about these messages in the days ahead, the Lord blesses us with customized direction through the gift of the Holy Ghost. These feelings turn us even more toward God, repenting, obeying, believing, and trusting. The Savior responds to our acts of faith. “If a man [or woman] love me, he will keep my words: and my Father will love him, and we will come unto him, and make our abode with him.”20

Jesus’s call “Come, follow me”21 is not only for those prepared to compete in a spiritual Olympics. In fact, discipleship is not a competition at all but an invitation to all. Our journey of discipleship is not a dash around the track, nor is it fully comparable to a lengthy marathon. In truth, it is a lifelong migration toward a more celestial world.

His invitation is a call to daily duty. Jesus said: “If ye love me, keep my commandments.”22 “If any man will come after me, let him deny himself, and take up his cross daily, and follow me.”23 We may not be at our very best every day, but if we are trying, Jesus’s bidding is full of encouragement and hope: “Come unto me, all ye that labour and are heavy laden, and I will give you rest.”24

Wherever you now find yourself on the road of discipleship, you are on the right road, the road toward eternal life. Together we can lift and strengthen one another in the great and important days ahead. Whatever the difficulties confronting us, the weaknesses confining us, or the impossibilities surrounding us, let us have faith in the Son of God, who declared, “All things are possible to him that believeth.”25

Let me share two examples of discipleship in action. The first is from the life of President Thomas S. Monson, demonstrating the power of simple kindness and Jesus’s teaching, “He that is greatest among you shall be your servant.”26

Nearly 20 years ago, President Monson spoke in general conference about a 12-year-old young woman suffering from cancer. He told of her courage and the kindness of her friends to carry her up Mount Timpanogos in central Utah.

A few years ago I met Jami Palmer Brinton and heard the story from a different perspective—the perspective of what President Monson had done for her.

Jami met President Monson in March 1993, a day after being told that a mass above her right knee was a fast-growing bone cancer. With her father assisting, President Monson administered a priesthood blessing, promising, “Jesus will be on your right side and on your left side to buoy you up.”

“Upon leaving his office that day,” Jami said, “I unfastened a balloon tied to my wheelchair and gave it to him. ‘You’re the Best!’ it announced in bright letters.”

Through her chemotherapy treatments and limb-saving surgery, President Monson did not forget her. Jami said, “President Monson exemplified what it means to be a true disciple of Christ. [He] lifted me from sorrow to great and abiding hope.” Three years after their first meeting, Jami again sat in President Monson’s office. At the end of the meeting, he did something that Jami will never forget. So typical of President Monson’s thoughtfulness, he surprised her with the very same balloon that she had given to him three years before. “You’re the Best!” the balloon proclaimed. He had saved it, knowing she would return to his office when she was cured of cancer. Fourteen years after first meeting Jami, President Monson performed her marriage to Jason Brinton in the Salt Lake Temple.27

We can learn so much from the discipleship of President Monson. He often reminds the General Authorities to remember this simple question: “What would Jesus do?”

Jesus told the leader of the synagogue, “Be not afraid, only believe.”28 Discipleship is believing Him in seasons of peace and believing Him in seasons of difficulty, when our pain and fear are calmed only by the conviction that He loves us and keeps His promises.

I recently met a family who is a beautiful example of how we believe Him. Olgan and Soline Saintelus, from Port-au-Prince, Haiti, told me their story.

On January 12, 2010, Olgan was at work and Soline was at the church when a devastating earthquake struck Haiti. Their three children—Gancci, age five, Angie, age three, and Gansly, age one—were at home in their apartment with a friend.

Massive devastation was everywhere. As you will remember, tens of thousands lost their lives that January in Haiti. Olgan and Soline ran as fast as they could to their apartment to find the children. The three-story apartment building where the Saintelus family lived had collapsed.

The children had not escaped. No rescue efforts would be devoted to a building that was so completely destroyed.

Olgan and Soline Saintelus had both served full-time missions and had been married in the temple. They believed in the Savior and in His promises to them. Yet their hearts were broken. They wept uncontrollably.

Olgan told me that in his darkest hour he began to pray. “Heavenly Father, if it be thy will, if there could be just one of my children alive, please, please help us.” Over and over he walked around the building, praying for inspiration. The neighbors tried to comfort him and help him accept the loss of his children. Olgan continued to walk around the rubble of the collapsed building, hoping, praying. Then something quite miraculous happened. Olgan heard the almost inaudible cry of a baby. It was the cry of his baby.

For hours the neighbors frantically dug into the rubble, risking their own lives. In the dark of the night, through the piercing sounds of hammers and chisels, the rescue workers heard another sound. They stopped their pounding and listened. They couldn’t believe what they were hearing. It was the sound of a little child—and he was singing. Five-year-old Gancci later said that he knew his father would hear him if he sang. Under the weight of crushing concrete that would later result in the amputation of his arm, Gancci was singing his favorite song, “I Am a Child of God.”29

As the hours passed amid the darkness, death, and despair of so many other precious sons and daughters of God in Haiti, the Saintelus family had a miracle. Gancci, Angie, and Gansly were discovered alive under the flattened building.30

Miracles are not always so immediate. At times we thoughtfully wonder why the miracle we have so earnestly prayed for does not happen here and now. But as we trust in the Savior, promised miracles will occur. Whether in this life or the next, all will be made right. The Savior declares: “Let not your heart be troubled, neither let it be afraid.”31 “In the world ye shall have tribulation: but be of good cheer; I have overcome the world.”32

I testify that as you love Him, trust Him, believe Him, and follow Him, you will feel His love and approval. As you ask, “What thinks Christ of me?” you will know that you are His disciple; you are His friend. By His grace He will do for you what you cannot do for yourself.

We eagerly await the concluding remarks of our beloved prophet. President Thomas S. Monson was ordained an Apostle of the Lord Jesus Christ when I was 12 years old. For more than 48 years we have been blessed to hear him bear witness of Jesus Christ. I testify that he now stands as the Savior’s senior Apostle upon the earth.

With great love and admiration for the many disciples of Jesus Christ who are not members of this Church, we humbly declare that angels have returned to the earth in our day. The Church of Jesus Christ as He established it anciently has been restored, with the power, ordinances, and blessings of heaven. The Book of Mormon is another testament of Jesus Christ.

I witness that Jesus Christ is the Savior of the world. He suffered and died for our sins and rose the third day. He is resurrected. In a future day, every knee will bow and every tongue confess that He is the Christ.33 On that day, our concern will not be, “Do others consider me Christian?” At that time, our eyes will be fixed on Him, and our souls will be riveted on the question, “What thinks Christ of me?” He lives. I so testify in the name of Jesus Christ, amen.

# References
1. - See André Petry, “Entre a Fé e a Urna,” Veja, Nov. 2, 2011, 96.
2. - Matthew 22:42.
3. - Romans 14:10.
4. - See Matthew 6:2.
5. - See Matthew 23:17.
6. - See Matthew 7:23.
7. - See Matthew 13:38.
8. - See Matthew 5:14.
9. - See Matthew 15:14.
10. - See Matthew 13:22.
11. - See Matthew 5:8.
12. - See Matthew 5:6.
13. - See Matthew 17:17.
14. - See John 8:23.
15. - See John 6:70.
16. - See John 13:35.
17. - See John 15:13.
18. - Thomas S. Monson, “Stand in Holy Places,” Liahona and Ensign, Nov. 2011, 83, 86.
19. - John 17:3.
20. - John 14:23.
21. - Luke 18:22.
22. - John 14:15.
23. - Luke 9:23.
24. - Matthew 11:28.
25. - Mark 9:23.
26. - Matthew 23:11.
27. - Jami Brinton, letter to author, Jan. 27, 2012.
28. - Mark 5:36.
29. - “I Am a Child of God,” Children’s Songbook, 2–3.
30. - From a discussion with Olgan and Soline Saintelus on Feb. 10, 2012; see also Jennifer Samuels, “Family Reunited in Miami after Trauma in Haiti,” Church News, Jan. 30, 2010, 6.
31. - John 14:27.
32. - John 16:33.
33. - See Romans 14:11.