Elder Richard G. Scott
Of the Quorum of the Twelve Apostles
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/how-to-obtain-revelation-and-inspiration-for-your-personal-life?lang=eng)

_Why does the Lord want us to pray to Him and to ask? Because that is how revelation is received._

Anyone who stands at this pulpit to deliver a message feels the strength and support of members throughout the world. I’m grateful that that same support can come from a beloved companion on the other side of the veil. Thank you, Jeanene.

The Holy Ghost communicates important information that we need to guide us in our mortal journey. When it is crisp and clear and essential, it warrants the title of revelation. When it is a series of promptings we often have to guide us step by step to a worthy objective, for the purpose of this message, it is inspiration.

An example of revelation would be the direction that President Spencer W. Kimball received after his long and continued supplication to the Lord regarding providing the priesthood to all worthy men in the Church when at the time it was available to only some of them.

Another example of revelation is this guidance given to President Joseph F. Smith: “I believe we move and have our being in the presence of heavenly messengers and of heavenly beings. We are not separate from them. … We are closely related to our kindred, to our ancestors … who have preceded us into the spirit world. We can not forget them; we do not cease to love them; we always hold them in our hearts, in memory, and thus we are associated and united to them by ties that we can not break. … If this is the case with us in our finite condition, surrounded by our mortal weaknesses, … how much more certain it is … to believe that those who have been faithful, who have gone beyond … can see us better than we can see them; that they know us better than we know them. … We live in their presence, they see us, they are solicitous for our welfare, they love us now more than ever. For now they see the dangers that beset us; … their love for us and their desire for our well being must be greater than that which we feel for ourselves.”1

Relationships can be strengthened through the veil with people we know and love. That is done by our determined effort to continually do what is right. We can strengthen our relationship with the departed individual we love by recognizing that the separation is temporary and that covenants made in the temple are eternal. When consistently obeyed, such covenants assure the eternal realization of the promises inherent in them.

A very clear case of revelation in my life occurred when I was strongly prompted by the Spirit to ask Jeanene Watkins to be sealed to me in the temple.

One of the great lessons that each of us needs to learn is to ask. Why does the Lord want us to pray to Him and to ask? Because that is how revelation is received.

When I am faced with a very difficult matter, this is how I try to understand what to do. I fast. I pray to find and understand scriptures that will be helpful. That process is cyclical. I start reading a passage of scripture; I ponder what the verse means and pray for inspiration. I then ponder and pray to know if I have captured all the Lord wants me to do. Often more impressions come with increased understanding of doctrine. I have found that pattern to be a good way to learn from the scriptures.

There are some practical principles that enhance revelation. First, yielding to emotions such as anger or hurt or defensiveness will drive away the Holy Ghost. Those emotions must be eliminated, or our chance for receiving revelation is slight.



Another principle is to be cautious with humor. Loud, inappropriate laughter will offend the Spirit. A good sense of humor helps revelation; loud laughter does not. A sense of humor is an escape valve for the pressures of life.

Another enemy to revelation comes from exaggeration or loudness in what is stated. Careful, quiet speech will favor the receipt of revelation.

On the other hand, spiritual communication can be enhanced by good health practices. Exercise, reasonable amounts of sleep, and good eating habits increase our capacity to receive and understand revelation. We will live for our appointed life span. However, we can improve both the quality of our service and our well-being by making careful, appropriate choices.

It is important that our daily activities do not distract us from listening to the Spirit.

Revelation can also be given in a dream when there is an almost imperceptible transition from sleep to wakefulness. If you strive to capture the content immediately, you can record great detail, but otherwise it fades rapidly. Inspired communication in the night is generally accompanied by a sacred feeling for the entire experience. The Lord uses individuals for whom we have great respect to teach us truths in a dream because we trust them and will listen to their counsel. It is the Lord doing the teaching through the Holy Ghost. However, He may in a dream make it both easier to understand and more likely to touch our hearts by teaching us through someone we love and respect.

When it is for the Lord’s purposes, He can bring anything to our remembrance. That should not weaken our determination to record impressions of the Spirit. Inspiration carefully recorded shows God that His communications are sacred to us. Recording will also enhance our ability to recall revelation. Such recording of direction of the Spirit should be protected from loss or intrusion by others.

The scriptures give eloquent confirmation of how truth, consistently lived, opens the door to inspiration to know what to do and, where needed, to have personal capacities enhanced by divine power. The scriptures depict how an individual’s capacity to conquer difficulty, doubt, and seemingly insurmountable challenges is strengthened by the Lord in time of need. As you ponder such examples, there will come a quiet confirmation through the Holy Spirit that their experiences are true. You will come to know that similar help is available to you.

I have seen individuals encountering challenges who knew what to do when it was beyond their own experience because they trusted in the Lord and knew that He would guide them to solutions that were urgently required.

The Lord has declared: “And ye are to be taught from on high. Sanctify yourselves and ye shall be endowed with power, that ye may give even as I have spoken.”2 The words sanctify yourselves may appear puzzling. President Harold B. Lee once explained that you can replace those words with the phrase “keep my commandments.” Read that way, the counsel may seem clearer.3



One must be ever mentally and physically clean and have purity of intent so that the Lord can inspire. One who is obedient to His commandments is trusted of the Lord. That individual has access to His inspiration to know what to do and, as needed, the divine power to do it.

For spirituality to grow stronger and more available, it must be planted in a righteous environment. Haughtiness, pride, and conceit are like stony ground that will never produce spiritual fruit.

Humility is a fertile soil where spirituality grows and produces the fruit of inspiration to know what to do. It gives access to divine power to accomplish what must be done. An individual motivated by a desire for praise or recognition will not qualify to be taught by the Spirit. An individual who is arrogant or who lets his or her emotions influence decisions will not be powerfully led by the Spirit.

When we are acting as instruments in behalf of others, we are more easily inspired than when we think only of ourselves. In the process of helping others, the Lord can piggyback directions for our own benefit.

Our Heavenly Father did not put us on earth to fail but to succeed gloriously. It may seem paradoxical, but that is why recognizing answers to prayer can sometimes be very difficult. Sometimes we unwisely try to face life by depending on our own experience and capacity. It is much wiser for us to seek through prayer and divine inspiration to know what to do. Our obedience assures that when required, we can qualify for divine power to accomplish an inspired objective.

Like many of us, Oliver Cowdery did not recognize the evidence of answers to prayers already given by the Lord. To open his and our eyes, this revelation was given through Joseph Smith:

“Blessed art thou for what thou hast done; for thou hast inquired of me, and behold, as often as thou hast inquired thou hast received instruction of my Spirit. If it had not been so, thou wouldst not have come to the place where thou art at this time.

“Behold, thou knowest that thou hast inquired of me and I did enlighten thy mind; and now I tell thee these things that thou mayest know that thou hast been enlightened by the Spirit of truth.”4

If you feel that God has not answered your prayers, ponder these scriptures—then carefully look for evidence in your own life that He may have already answered you.

Two indicators that a feeling or prompting comes from God are that it produces peace in your heart and a quiet, warm feeling. As you follow the principles I have discussed, you will be prepared to recognize revelation at critical times in your own life.

The more closely you follow divine guidance, the greater will be your happiness here and for eternity—moreover, the more abundant your progress and capacity to serve. I do not understand fully how it is done, but that guidance in your life does not take away your agency. You can make the decisions you choose to make. But remember, the disposition to do right brings peace of mind and happiness.

Should choices be wrong, they can be rectified through repentance. When its conditions are fully met, the Atonement of Jesus Christ, our Savior, provides a release from the demands of justice for the errors made. It is wondrously simple and so incomparably beautiful. As you continue to live righteously, you will always be prompted to know what to do. Sometimes the discovery of what action to take may require significant effort and trust on your part. Yet you will be prompted to know what to do as you meet the conditions for such divine guidance in your life, namely, obedience to the commandments of the Lord, trust in His divine plan of happiness, and the avoidance of anything that is contrary to it.

Communication with our Father in Heaven is not a trivial matter. It is a sacred privilege. It is based upon eternal, unchanging principles. We receive help from our Father in Heaven in response to our faith, obedience, and the proper use of agency.

May the Lord inspire you to understand and use the principles that lead to personal revelation and inspiration, in the name of Jesus Christ, amen.

# References
1. - Joseph F. Smith, in Conference Report, Apr. 1916, 2–3; see also Gospel Doctrine, 5th ed. (1939), 430–31.
2. - Doctrine and Covenants 43:16.
3. - See Teachings of Presidents of the Church: Harold B. Lee (2000), 34.
4. - Doctrine and Covenants 6:14–15.