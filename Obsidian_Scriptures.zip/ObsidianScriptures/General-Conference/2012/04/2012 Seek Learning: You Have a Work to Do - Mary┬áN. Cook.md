Mary N. Cook
First Counselor in the Young Women General Presidency
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/seek-learning-you-have-a-work-to-do?lang=eng)

_Bless your children and your future home by learning as much as you can now._

My dear young women, how we love each one of you. We see you courageously arising and shining forth with light in a world where great challenges accompany great opportunities. This may cause you to wonder, what does the future hold for me? I assure you that as you are a virtuous daughter of God, your future is bright! You live at a time when the truths of the gospel have been restored, and these truths can be found in your scriptures. You received the gift of the Holy Ghost at the time of your baptism, and the Holy Ghost will teach you truth and prepare you for life’s challenges.

God gave you moral agency and the opportunity to learn while on earth, and He has a work for you to do. To accomplish this work, you have an individual responsibility to seek learning. The key to your future, your “bright ray of hope,”1 can be found in the new For the Strength of Youth booklet under the standard of education and in the Young Women value of knowledge.

“Education … will open the doors of opportunity.”2 As you follow the Lord’s admonition to “seek learning, even by study and also by faith,”3 you gain not only knowledge from your study but added light as you learn by faith.

Seek learning by studying diligently. Rarely will you be able to spend as much time dedicated to learning as you can now. President Gordon B. Hinckley wisely counseled the youth of the Church: “The pattern of study you establish during your formal schooling will in large measure affect your lifelong thirst for knowledge.”4 “You must get all of the education that you possibly can. … Sacrifice anything that is needed to be sacrificed to qualify yourselves to do the work of [this] world. … Train your minds and hands to become an influence for good as you go forward with your lives.”5

In speaking specifically to women, President Thomas S. Monson said: “Often the future is unknown; therefore, it behooves us to prepare for uncertainties. … I urge you to pursue your education and learn marketable skills so that, should such a situation arise, you are prepared to provide.”6

Young women, follow the advice of these wise and inspired prophets. Be a good student. Arise and shine forth in your schools with hard work, honesty, and integrity. If you are struggling or discouraged with your performance in school, seek help from your parents, teachers, and helpful Church members. Never give up!

Make a list of the things you want to learn; then “share your educational goals with your family, friends, and leaders so they can support and encourage you.”7 This is the pattern of Personal Progress.

With technology you are witnessing an explosion of knowledge. You are constantly bombarded by sound, video, and networking. Be selective and don’t allow this surge of information to distract you or slow your progress. Arise, young women! You determine your goals. You decide what enters your mind and heart.

Some of your most important learning will be outside of the classroom. Surround yourself with exemplary women who can teach you skills in homemaking, art, music, family history, sports, writing, or speaking. Get to know them and ask them to mentor you. When you have learned something new, teach it at Mutual or become a mentor to other young women as part of the requirements for your Honor Bee.

In addition to my wonderful mother, I’ve had many mentors in my life. I first became acquainted with the process of mentoring when I was just nine years old. My Primary teacher taught me to cross-stitch “I Will Bring the Light of the Gospel into My Home,” a picture that hung in my room during my teenage years. My teacher guided me, corrected me, and always encouraged me along the way. Other mentors followed. Two excellent seamstresses in my ward taught me sewing. With their guidance, patience, and encouragement, I entered a dress in a sewing contest when I was 14, and I actually won a prize! The process increased my thirst for knowledge and excellence in other areas as well.

Gaining knowledge now will pay huge dividends when you become a mother. “A mother’s education level has a profound influence on the educational choices of her [children].”8 A mother’s education can hold the “key to halt [the] poverty cycle.”9 Educated women “tend to: Give birth to healthier babies, have children who are healthier, be more confident, resilient and have improved reasoning and judgment.”10

We learn in “The Family: A Proclamation to the World” that “mothers are primarily responsible for the nurture of their children.”11 Providing an education for your children is part of that nurturing and is your sacred responsibility. Like the stripling warriors, who “had been taught by their mothers,”12 you will be the most important teacher your children will ever have, so choose your learning carefully. Bless your children and your future home by learning as much as you can now.

Seek learning by faith. We learn by faith as we diligently gain spiritual knowledge through prayer, scripture study, and obedience and as we seek the guidance of the Holy Ghost, who testifies of all truth. If you do your part to gain knowledge, the Holy Ghost can enlighten your mind. As you strive to keep yourself worthy, the Holy Ghost will give direction and added light to your learning.

When I was a young woman, I borrowed skis that were way too long and boots that were way too big, and a friend taught me to ski! We went on a beautiful spring day filled with bright sun, perfect snow, and cloudless, blue skies. Anxiety about the steep slopes gave way to delight as I learned. And though I tumbled quite a few times on those long skis, I got up and I kept trying. I came to love the sport!

I soon found out, however, that not all ski days and weather conditions were that ideal. On days with overcast skies, we skied in a condition called “flat light.” Flat light occurs when the light from the sun is diffused by the clouds. Looking ahead at the white snow, you find that your depth perception vanishes, and it is difficult to judge the steepness of the slope or see the moguls and bumps on the hill.

Young women, you may be looking forward to your future as I looked at that steep ski slope. You may feel at times that you are living in flat light, unable to see what lies ahead of you. Learning by faith will give you confidence and will help you navigate your way through times of uncertainty.

In the 25th chapter of Matthew, the parable of the ten virgins teaches us that spiritual preparation is vital and must be achieved individually. You will recall that all ten virgins were invited to escort the bridegroom into the wedding feast, but only the five wise virgins were prepared with oil in their lamps.

“And the foolish said unto the wise, Give us of your oil; for our lamps are gone out.

“But the wise answered, saying, Not so; lest there be not enough for us and you: but go ye rather to them that sell, and buy for yourselves.

“And while they went to buy, the bridegroom came; and they that were ready went in with him to the marriage: and the door was shut.”13

You may think it selfish that the five wise virgins did not share their oil, but it was impossible. Spiritual preparation must be acquired individually, drop by drop, and cannot be shared.

The time is now for you to diligently apply yourselves to increasing your spiritual knowledge—drop by drop—through prayer, scripture study, and obedience. The time is now to pursue your education—drop by drop. Each virtuous thought and action also adds oil to your lamps, qualifying you for the guidance of the Holy Ghost, our divine teacher.

The Holy Ghost will guide you on your journey here in mortality, even when you feel you are in flat light, uncertain of what lies ahead. You need not fear. As you stay on the path that leads to eternal life, the Holy Ghost will guide you in your decisions and in your learning.

I testify from personal experience that if you will seek learning not only by study but also by faith, you will be guided in what “the Lord … will need you to do and what you will need to know.”14

I received my patriarchal blessing as a young woman and was counseled to prepare myself with a good education and to learn early in life those virtues that go into homemaking and rearing a family. I so wanted the blessing of a family; however, that blessing wasn’t fulfilled until I was 37, when I eventually married. My husband had been widowed, so the day we were sealed in the temple, I was suddenly blessed with not only a husband but a family of four children.

Long before that, there were many days when I felt like I was skiing in flat light, asking the question, “What does the future hold for me?” I tried to follow the admonitions in my patriarchal blessing. I studied diligently to become a schoolteacher and continued my education to become an elementary school principal. I prayed to my Heavenly Father and sought the guidance of the Holy Ghost. I held fervently to the promise of prophets who assured me that if I “remain true and faithful, keep [my] covenants, serve God, and love [my] Father in Heaven and the Lord Jesus Christ, [I] will not be denied any of the eternal blessings our Heavenly Father has for His faithful children.”15

I know that my education prepared me for a life that has been nothing like I had envisioned as a young woman. I thought I was studying education to teach school and my future children, but I did not know the Lord was also preparing me to teach English in Mongolia on a mission with my husband and to teach the young women of the Church throughout the world and to teach my grandchildren the value of knowledge—all wonderful blessings I could never have imagined.

I testify that our Father in Heaven does know and love you. He has placed great trust in you and has work that only you can do. I want to assure you that you will be prepared for that great work if you seek learning by study and also by faith. Of this I testify in the name of Jesus Christ, amen.

# References
1. - Gordon B. Hinckley, “Reaching Down to Lift Another,” Liahona, Jan. 2002, 67; Ensign, Nov. 2001, 54.
2. - For the Strength of Youth (booklet, 2011), 9.
3. - Doctrine and Covenants 88:118.
4. - Gordon B. Hinckley, Way to Be! Nine Ways to Be Happy and Make Something of Your Life (2002), 28.
5. - Gordon B. Hinckley, “Seek Learning,” New Era, Sept. 2007, 2, 4.
6. - Thomas S. Monson, “If Ye Are Prepared Ye Shall Not Fear,” Liahona and Ensign, Nov. 2004, 116.
7. - For the Strength of Youth, 9.
8. - Cheryl Hanewicz and Susan R. Madsen, “The Influence of a Mother on a Daughter’s College Decision,” Utah Women and Education Project Research Snapshots, no. 3 (Jan. 2011): 1.
9. - Marjorie Cortez, “Mom’s Education Key to Halt Poverty Cycle,” Deseret News, Sept. 23, 2011, A1.
10. - Olene Walker, “More Utah Women Need to Finish College,” Salt Lake Tribune, Oct. 30, 2011, O4.
11. - “The Family: A Proclamation to the World,” Liahona and Ensign, Nov. 2010, 129.
12. - Alma 56:47.
13. - Matthew 25:8–10.
14. - Henry B. Eyring, “Education for Real Life,” Ensign, Oct. 2002, 18.
15. - M. Russell Ballard, “Preparing for the Future,” Ensign, Sept. 2011, 27.