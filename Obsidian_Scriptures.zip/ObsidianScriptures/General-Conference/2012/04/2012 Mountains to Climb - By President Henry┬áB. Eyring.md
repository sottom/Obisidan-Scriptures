By President Henry B. Eyring
First Counselor in the First Presidency
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/mountains-to-climb?lang=eng)

_If we have faith in Jesus Christ, the hardest as well as the easiest times in life can be a blessing._

I heard President Spencer W. Kimball, in a session of conference, ask that God would give him mountains to climb. He said: “There are great challenges ahead of us, giant opportunities to be met. I welcome that exciting prospect and feel to say to the Lord, humbly, ‘Give me this mountain,’ give me these challenges.”1

My heart was stirred, knowing, as I did, some of the challenges and adversity he had already faced. I felt a desire to be more like him, a valiant servant of God. So one night I prayed for a test to prove my courage. I can remember it vividly. In the evening I knelt in my bedroom with a faith that seemed almost to fill my heart to bursting.

Within a day or two my prayer was answered. The hardest trial of my life surprised and humbled me. It provided me a twofold lesson. First, I had clear proof that God heard and answered my prayer of faith. But second, I began a tutorial that still goes on to learn about why I felt with such confidence that night that a great blessing could come from adversity to more than compensate for any cost.

The adversity that hit me in that faraway day now seems tiny compared to what has come since—to me and to those I love. Many of you are now passing through physical, mental, and emotional trials that could cause you to cry out as did one great and faithful servant of God I knew well. His nurse heard him exclaim from his bed of pain, “When I have tried all my life to be good, why has this happened to me?”

You know how the Lord answered that question for the Prophet Joseph Smith in his prison cell:

“And if thou shouldst be cast into the pit, or into the hands of murderers, and the sentence of death passed upon thee; if thou be cast into the deep; if the billowing surge conspire against thee; if fierce winds become thine enemy; if the heavens gather blackness, and all the elements combine to hedge up the way; and above all, if the very jaws of hell shall gape open the mouth wide after thee, know thou, my son, that all these things shall give thee experience, and shall be for thy good.

“The Son of Man hath descended below them all. Art thou greater than he?

“Therefore, hold on thy way, and the priesthood shall remain with thee; for their bounds are set, they cannot pass. Thy days are known, and thy years shall not be numbered less; therefore, fear not what man can do, for God shall be with you forever and ever.”2

There seems to me no better answer to the question of why trials come and what we are to do than the words of the Lord Himself, who passed through trials for us more terrible than we can imagine.

You remember His words when He counseled that we should, out of faith in Him, repent:

“Therefore I command you to repent—repent, lest I smite you by the rod of my mouth, and by my wrath, and by my anger, and your sufferings be sore—how sore you know not, how exquisite you know not, yea, how hard to bear you know not.

“For behold, I, God, have suffered these things for all, that they might not suffer if they would repent;

“But if they would not repent they must suffer even as I;

“Which suffering caused myself, even God, the greatest of all, to tremble because of pain, and to bleed at every pore, and to suffer both body and spirit—and would that I might not drink the bitter cup, and shrink—

“Nevertheless, glory be to the Father, and I partook and finished my preparations unto the children of men.”3

You and I have faith that the way to rise through and above trials is to believe that there is a “balm in Gilead”4 and that the Lord has promised, “I will not … forsake thee.”5 That is what President Thomas S. Monson has taught us to help us and those we serve in what seem lonely and overwhelming trials.6

But President Monson has also wisely taught that a foundation of faith in the reality of those promises takes time to build. You may have seen the need for that foundation, as I have, at the bedside of someone ready to give up the fight to endure to the end. If the foundation of faith is not embedded in our hearts, the power to endure will crumble.



My purpose today is to describe what I know of how we can lay that unshakable foundation. I do it with great humility for two reasons. First, what I say could discourage some who are struggling in the midst of great adversity and feel their foundation of faith is crumbling. And second, I know that ever-greater tests lie before me before the end of life. Therefore, the prescription I offer you has yet to be proven in my own life through enduring to the end.

As a young man I worked with a contractor building footings and foundations for new houses. In the summer heat it was hard work to prepare the ground for the form into which we poured the cement for the footing. There were no machines. We used a pick and a shovel. Building lasting foundations for buildings was hard work in those days.

It also required patience. After we poured the footing, we waited for it to cure. Much as we wanted to keep the jobs moving, we also waited after the pour of the foundation before we took away the forms.

And even more impressive to a novice builder was what seemed to be a tedious and time-consuming process to put metal bars carefully inside the forms to give the finished foundation strength.

In a similar way, the ground must be carefully prepared for our foundation of faith to withstand the storms that will come into every life. That solid basis for a foundation of faith is personal integrity.

Our choosing the right consistently whenever the choice is placed before us creates the solid ground under our faith. It can begin in childhood since every soul is born with the free gift of the Spirit of Christ. With that Spirit we can know when we have done what is right before God and when we have done wrong in His sight.

Those choices, hundreds in most days, prepare the solid ground on which our edifice of faith is built. The metal framework around which the substance of our faith is poured is the gospel of Jesus Christ, with all its covenants, ordinances, and principles.

One of the keys to an enduring faith is to judge correctly the curing time required. That is why I was unwise to pray so soon in my life for higher mountains to climb and greater tests.

That curing does not come automatically through the passage of time, but it does take time. Getting older does not do it alone. It is serving God and others persistently with full heart and soul that turns testimony of truth into unbreakable spiritual strength.

Now, I wish to encourage those who are in the midst of hard trials, who feel their faith may be fading under the onslaught of troubles. Trouble itself can be your way to strengthen and finally gain unshakable faith. Moroni, the son of Mormon in the Book of Mormon, told us how that blessing could come to pass. He teaches the simple and sweet truth that acting on even a twig of faith allows God to grow it:

“And now, I, Moroni, would speak somewhat concerning these things; I would show unto the world that faith is things which are hoped for and not seen; wherefore, dispute not because ye see not, for ye receive no witness until after the trial of your faith.

“For it was by faith that Christ showed himself unto our fathers, after he had risen from the dead; and he showed not himself unto them until after they had faith in him; wherefore, it must needs be that some had faith in him, for he showed himself not unto the world.

“But because of the faith of men he has shown himself unto the world, and glorified the name of the Father, and prepared a way that thereby others might be partakers of the heavenly gift, that they might hope for those things which they have not seen.

“Wherefore, ye may also have hope, and be partakers of the gift, if ye will but have faith.”7

That particle of faith most precious and which you should protect and use to whatever extent you can is faith in the Lord Jesus Christ. Moroni taught the power of that faith this way: “And neither at any time hath any wrought miracles until after their faith; wherefore they first believed in the Son of God.”8

I have visited with a woman who received the miracle of sufficient strength to endure unimaginable losses with just the simple capacity to repeat endlessly the words “I know that my Redeemer lives.”9 That faith and those words of testimony were still there in the mist that obscured but did not erase memories of her childhood.

I was stunned to learn that another woman had forgiven a person who had wronged her for years. I was surprised and asked her why she had chosen to forgive and forget so many years of spiteful abuse.

She said quietly, “It was the hardest thing I have ever done, but I just knew I had to do it. So I did.” Her faith that the Savior would forgive her if she forgave others prepared her with a feeling of peace and hope as she faced death just months after she had forgiven her unrepentant adversary.

She asked me, “When I get there, how will it be in heaven?”

And I said, “I know just from what I have seen of your capacity to exercise faith and to forgive that it will be a wonderful homecoming for you.”

I have another encouragement to those who now wonder if their faith in Jesus Christ will be sufficient for them to endure well to the end. I was blessed to have known others of you who are listening now when you were younger, vibrant, gifted beyond most of those around you, yet you chose to do what the Savior would have done. Out of your abundance you found ways to help and care for those you might have ignored or looked down upon from your place in life.

When hard trials come, the faith to endure them well will be there, built as you may now notice but may have not at the time that you acted on the pure love of Christ, serving and forgiving others as the Savior would have done. You built a foundation of faith from loving as the Savior loved and serving for Him. Your faith in Him led to acts of charity that will bring you hope.

It is never too late to strengthen the foundation of faith. There is always time. With faith in the Savior, you can repent and plead for forgiveness. There is someone you can forgive. There is someone you can thank. There is someone you can serve and lift. You can do it wherever you are and however alone and deserted you may feel.

I cannot promise an end to your adversity in this life. I cannot assure you that your trials will seem to you to be only for a moment. One of the characteristics of trials in life is that they seem to make clocks slow down and then appear almost to stop.

There are reasons for that. Knowing those reasons may not give much comfort, but it can give you a feeling of patience. Those reasons come from this one fact: in Their perfect love for you, Heavenly Father and the Savior want you fitted to be with Them to live in families forever. Only those washed perfectly clean through the Atonement of Jesus Christ can be there.

My mother fought cancer for nearly 10 years. Treatments and surgeries and finally confinement to her bed were some of her trials.

I remember my father saying as he watched her take her last breath, “A little girl has gone home to rest.”

One of the speakers at her funeral was President Spencer W. Kimball. Among the tributes he paid, I remember one that went something like this: “Some of you may have thought that Mildred suffered so long and so much because of something she had done wrong that required the trials.” He then said, “No, it was that God just wanted her to be polished a little more.” I remember at the time thinking, “If a woman that good needed that much polishing, what is ahead for me?”

If we have faith in Jesus Christ, the hardest as well as the easiest times in life can be a blessing. In all conditions, we can choose the right with the guidance of the Spirit. We have the gospel of Jesus Christ to shape and guide our lives if we choose it. And with prophets revealing to us our place in the plan of salvation, we can live with perfect hope and a feeling of peace. We never need to feel that we are alone or unloved in the Lord’s service because we never are. We can feel the love of God. The Savior has promised angels on our left and our right to bear us up.10 And He always keeps His word.

I testify that God the Father lives and that His Beloved Son is our Redeemer. The Holy Ghost has confirmed truth in this conference and will again as you seek it, as you listen, and as you later study the messages of the Lord’s authorized servants, who are here. President Thomas S. Monson is the Lord’s prophet to the entire world. The Lord watches over you. God the Father lives. His Beloved Son, Jesus Christ, is our Redeemer. His love is unfailing. I so testify in the name of Jesus Christ, amen.

# References
1. - Spencer W. Kimball, “Give Me This Mountain,” Ensign, Nov. 1979, 79.
2. - Doctrine and Covenants 122:7–9.
3. - Doctrine and Covenants 19:15–19.
4. - Jeremiah 8:22.
5. - Joshua 1:5.
6. - See Thomas S. Monson, “Look to God and Live,” Ensign, May 1998, 52–54.
7. - Ether 12:6–9.
8. - Ether 12:18.
9. - “I Know That My Redeemer Lives,” Hymns, no. 136.
10. - See Doctrine and Covenants 84:88.