Elder Larry Y. Wilson
Of the Seventy
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/only-upon-the-principles-of-righteousness?lang=eng)

_Wise parents prepare their children to get along without them. They provide opportunities for growth as children acquire the spiritual maturity to exercise their agency properly._

A month or so after we were married, my wife and I were taking a long road trip in the car. She was driving, and I was trying to relax. I say trying because the highway we were traveling had a reputation for speed traps, and my wife might have had a slight tendency toward a lead foot in those days. I said, “You’re going too fast. Slow down.”

My new bride thought to herself, “Well, I’ve been driving for nearly 10 years, and other than my driver’s education teacher, no one ever told me how to drive before.” So she replied, “What gives you the right to tell me how to drive?”

Frankly, her question caught me off guard. So, doing my best to step up to my new responsibilities as a married man, I said, “I don’t know—because I’m your husband and I hold the priesthood.”

Brethren, just a quick tip: if you are ever in a similar situation, that is not the right response. And I’m happy to report, it was the one and only time I ever made that mistake.

The Doctrine and Covenants explains that the right to use the priesthood in the home or elsewhere is directly connected with righteousness in our lives: “The powers of heaven cannot be controlled nor handled only upon the principles of righteousness.”1 It goes on to say that we lose that power when we “exercise control or dominion or compulsion upon the souls of [others], in any degree of unrighteousness.”2

This scripture says we must lead by “principles of righteousness.” Such principles apply to all leaders in the Church as well as to all fathers and mothers in their homes.3 We lose our right to the Lord’s Spirit and to whatever authority we have from God when we exercise control over another person in an unrighteous manner.4 We may think such methods are for the good of the one being “controlled.” But anytime we try to compel someone to righteousness who can and should be exercising his or her own moral agency, we are acting unrighteously. When setting firm limits for another person is in order, those limits should always be administered with loving patience and in a way that teaches eternal principles.

We simply cannot force others to do the right thing. The scriptures make it clear that this is not God’s way. Compulsion builds resentment. It conveys mistrust, and it makes people feel incompetent. Learning opportunities are lost when controlling persons pridefully assume they have all the right answers for others. The scriptures say that “it is the nature and disposition of almost all men” to engage in this “unrighteous dominion,”5 so we should be aware that it’s an easy trap to fall into. Women too may exercise unrighteous dominion, though the scriptures identify the problem especially with men.

Unrighteous dominion is often accompanied by constant criticism and the withholding of approval or love. Those on the receiving end feel they can never please such leaders or parents and that they always fall short. Wise parents must weigh when children are ready to begin exercising their own agency in a particular area of their lives. But if parents hold on to all decision-making power and see it as their “right,” they severely limit the growth and development of their children.

Our children are in our homes for a limited time. If we wait until they walk out the door to turn over to them the reins of their moral agency, we have waited too long. They will not suddenly develop the ability to make wise decisions if they have never been free to make any important decisions while in our homes. Such children often either rebel against this compulsion or are crippled by an inability to make any decisions on their own.

Wise parents prepare their children to get along without them. They provide opportunities for growth as children acquire the spiritual maturity to exercise their agency properly. And yes, this means children will sometimes make mistakes and learn from them.

Our family had an experience that taught us about helping children develop their ability to make choices. Our daughter Mary was a standout soccer player growing up. One year her team made it to the championships and, wouldn’t you know it, that game was to be played on a Sunday. As a young teen, Mary had had years of teaching that the Sabbath was a day of rest and spiritual regeneration, not recreation. But she still felt pressure from her coaches and teammates to play, as well as a desire not to let her team down.

She asked us what she should do. My wife and I could easily have made this decision for her. However, we decided after prayerful consideration that in this case our daughter was ready to take spiritual responsibility for her own decision. We read some scriptures with her and encouraged Mary to pray and think about it.

After a few days she announced her decision. She would play the game on Sunday. Now what were we to do? After further discussion and receiving reassurance from the Spirit, we did as we had promised and permitted her to carry out her choice to play. After the game ended, Mary slowly walked over to her waiting mother. “Oh, Mom,” she said, “that felt awful. I never want to feel like that again. I’m never playing another game on the Sabbath day.” And she never did.

Mary had now internalized the principle of Sabbath keeping. If we had forced her not to play the game, we would have deprived her of a precious and powerful learning experience with the Spirit.

As you can see, helping children exercise their agency properly requires teaching them how to pray and receive answers to their prayers. There must also be teaching about the value and purpose of obedience as well as about all other essential principles of the gospel.6

In raising our family, we decided that our most important goal would be to help our children establish their own connection to heaven. We knew that ultimately they would need to depend on the Lord, not on us. Brigham Young said, “Were I to draw a distinction in all the duties that are required of the children of men, … I would place first and foremost the duty of seeking unto the Lord our God until we open the path of communication from heaven to earth—from God to our own souls.”7

Mary had received answers to her prayers in other, earlier situations, and so we trusted that our daughter was developing this path of communication with heaven in her life. Thus she learned something positive from her experience and was equipped to make better choices in the future. Without a link to the Spirit, children and parents alike would be able to rationalize all sorts of poor decisions in the name of exercising their agency. The promise of scripture is that “they that are wise … and have taken the Holy Spirit for their guide [are not] deceived.”8

An additional and tragic side effect of unrighteous dominion can be a loss of trust in God’s love. I have known some people who were subject to demanding and controlling leaders or parents, and they have found it hard to feel the very love from their Heavenly Father that would sustain them and motivate them along the path of righteousness.

If we are going to help those in our stewardships make the all-important link with heaven, we must be the kind of parent and leader described in Doctrine and Covenants, section 121. We must act “only by persuasion, by long-suffering, by gentleness and meekness, and by love unfeigned.”9 President Henry B. Eyring has said, “Of all the help we can give … young people, the greatest will be to let them feel our confidence that they are on the path home to God and that they can make it.”10

As we consider the principles that should guide us in the Church and at home, let me close with an illustration from the biography of President Thomas S. Monson. Ann Dibb, the Monsons’ daughter, says that to this day, when she walks in the front door of the house where she was raised, her father will say, “Oh, look who’s here. And aren’t we glad, and isn’t she beautiful?” She goes on to say: “My parents always give me some compliment; it doesn’t matter what I look like or what I’ve been doing. … When I go and visit my parents, I know I am loved, I am complimented, I am made welcome, I am home.”11

Brothers and sisters, this is the Lord’s way. Even if you’ve been mistreated in the past, I know the Lord wants you to come unto Him.12 All are loved. All are welcomed. In the name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 121:36.
2. - Doctrine and Covenants 121:37; emphasis added.
3. - See Neal A. Maxwell, “Put Off the Natural Man, and Come Off Conqueror,” Tambuli, Jan. 1991, 13–14; Ensign, Nov. 1990, 14–16.
4. - See Doctrine and Covenants 121:37.
5. - Doctrine and Covenants 121:39.
6. - See Doctrine and Covenants 68:25–29.
7. - Teachings of Presidents of the Church: Brigham Young (1997), 44.
8. - Doctrine and Covenants 45:57.
9. - Doctrine and Covenants 121:41.
10. - Henry B. Eyring, “Help Them on Their Way Home,” Liahona and Ensign, May 2010, 25.
11. - See Heidi S. Swinton, To the Rescue: The Biography of Thomas S. Monson (2010), 372.
12. - See Matthew 11:28.