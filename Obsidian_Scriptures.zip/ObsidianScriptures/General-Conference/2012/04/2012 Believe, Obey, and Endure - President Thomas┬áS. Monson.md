President Thomas S. Monson
President of the Church
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/believe-obey-and-endure?lang=eng)

_Believe that remaining strong and faithful to the truths of the gospel is of utmost importance. I testify that it is!_

My dear young sisters, the responsibility to address you is humbling. I pray for divine help, that I may be made equal to such an opportunity.

A mere 20 years ago you had not yet commenced your journey through mortality. You were still in your heavenly home. There you were among those who loved you and were concerned for your eternal well-being. Eventually, earth life became essential to your progress. Farewells were no doubt spoken, and expressions of confidence given. You gained bodies and became mortal, cut off from the presence of your Heavenly Father.

A joyous welcome, however, awaited you here on earth. Those first years were precious, special years. Satan had no power to tempt you, for you had not yet become accountable. You were innocent before God.

Soon you entered that period some have labeled “the terrible teens.” I prefer “the terrific teens.” What a time of opportunity, a season of growth, a semester of development—marked by the acquisition of knowledge and the quest for truth.

No one has described the teenage years as being easy. They are often years of insecurity, of feeling as though you just don’t measure up, of trying to find your place with your peers, of trying to fit in. This is a time when you are becoming more independent—and perhaps desire more freedom than your parents are willing to give you right now. They are also prime years when Satan will tempt you and will do his utmost to entice you from the path which will lead you back to that heavenly home from which you came and back to your loved ones there and back to your Heavenly Father.

The world around you is not equipped to provide the help you need to make it through this often-treacherous journey. So many in our society today seem to have slipped from the moorings of safety and drifted from the harbor of peace.

Permissiveness, immorality, pornography, drugs, the power of peer pressure—all these and more—cause many to be tossed about on a sea of sin and crushed on the jagged reefs of lost opportunities, forfeited blessings, and shattered dreams.



Is there a way to safety? Is there an escape from threatened destruction? The answer is a resounding yes! I counsel you to look to the lighthouse of the Lord. I have said it before; I will say it again: there is no fog so dense, no night so dark, no gale so strong, no mariner so lost but what the lighthouse of the Lord can rescue. It beckons through the storms of life. It calls, “This way to safety. This way to home.” It sends forth signals of light easily seen and never failing. If followed, those signals will guide you back to your heavenly home.

I wish to talk with you tonight about three essential signals from the Lord’s lighthouse which will help you to return to that Father who eagerly awaits your triumphant homecoming. Those three signals are believe, obey, and endure.

First, I mention a signal which is basic and essential: believe. Believe that you are a daughter of Heavenly Father, that He loves you, and that you are here for a glorious purpose—to gain your eternal salvation. Believe that remaining strong and faithful to the truths of the gospel is of utmost importance. I testify that it is!

My young friends, believe in the words you say each week as you recite the Young Women theme. Think about the meaning of those words. There is truth there. Strive always to live the values which are set forth. Believe, as your theme states, that if you accept and act upon those values, you will be prepared to strengthen your home and your family, to make and keep sacred covenants, to receive the ordinances of the temple, and to eventually enjoy the blessings of exaltation. These are beautiful gospel truths, and by following them, you will be happier throughout your life here and hereafter than you will be if you disregard them.

Most of you were taught the truths of the gospel from the time you were a toddler. You were taught by loving parents and caring teachers. The truths they imparted to you helped you gain a testimony; you believed what you were taught. Although that testimony can continue to be fed spiritually and to grow as you study, as you pray for guidance, and as you attend your Church meetings each week, it is up to you to keep that testimony alive. Satan will try with all his might to destroy it. Throughout your entire life you will need to nurture it. As with the flame of a brightly burning fire, your testimony—if not continually fed—will fade to glowing embers and then cool completely. You must not let this happen.

Besides attending your Sunday meetings and your weeknight activities, when you have the chance to be involved in seminary, whether in the early morning or in released-time classes, take advantage of that opportunity. Many of you are attending seminary now. As with anything in life, much of what you take from your seminary experience depends on your attitude and your willingness to be taught. May your attitude be one of humility and a desire to learn. How grateful I am for the opportunity I had as a teenager to attend early-morning seminary, for it played a vital role in my development and the development of my testimony. Seminary can change lives.

Some years ago I was on a board of directors with a fine man who had been extremely successful in life. I was impressed with his integrity and his loyalty to the Church. I learned that he had gained a testimony and had joined the Church because of seminary. When he married, his wife had been a lifelong member of the Church. He belonged to no church. Through the years and despite her efforts, he showed no interest in attending church with his wife and children. And then he began driving two of his daughters to early-morning seminary. He would remain in the car while they had their class, and then he would drive them to school. One day it was raining, and one of his daughters said, “Come in, Dad. You can sit in the hall.” He accepted the invitation. The door to the classroom was open, and he began to listen. His heart was touched. For the rest of that school year, he attended seminary with his daughters, which led eventually to his membership and a lifetime of activity in the Church. Let seminary help build and strengthen your testimony.

There will be times when you will face challenges which might jeopardize your testimony, or you may neglect it as you pursue other interests. I plead with you to keep it strong. It is your responsibility, and yours alone, to keep its flame burning brightly. Effort is required, but it is effort you will never, ever regret. I’m reminded of the words of a song written by Julie de Azevedo Hanks. Referring to her testimony, she wrote:





Through the winds of change

Encircled by the clouds of pain

I guard it with my life

I need the warmth—I need the light

Though the storm will rage

I stand against the pounding rain

I remain

A keeper of the flame.1





May you believe and then may you keep the flame of your testimony burning brightly, come what may.

Next, young women, may you obey. Obey your parents. Obey the laws of God. They are given to us by a loving Heavenly Father. When they are obeyed, our lives will be more fulfilling, less complicated. Our challenges and problems will be easier to bear. We will receive the Lord’s promised blessings. He has said, “The Lord requireth the heart and a willing mind; and the willing and obedient shall eat the good of the land of Zion in these last days.”2

You have but one life to live. Keep it as free from trouble as you can. You will be tempted, sometimes by individuals you had thought friends.

Some years ago I spoke to a Mia Maid adviser who told me of an experience she had with one of the young women in her class. This young woman had been tempted time and time again to leave the pathway of truth and follow the detour of sin. Through the constant persuasion of some of her friends at school, she had finally agreed to follow such a detour. The plan was set: she would tell her parents she was going to her activity night for Young Women. She planned, however, to be there only long enough for her girlfriends and their dates to pick her up. They would then attend a party where alcoholic beverages would be consumed and where the behavior would be in complete violation of what this young woman knew was right.

The teacher had prayed for inspiration in helping all her girls but especially this particular young woman, who seemed so uncertain about her commitment to the gospel. The teacher had received inspiration that night to abandon what she had previously planned and to speak to the girls about remaining morally clean. As she began sharing her thoughts and feelings, the young woman in question checked her watch often to make sure she didn’t miss her rendezvous with her friends. However, as the discussion progressed, her heart was touched, her conscience awakened, and her determination renewed. When it came, she ignored the repeated sound of the automobile horn summoning her. She remained throughout the evening with her teacher and the other girls in the class. The temptation to detour from God’s approved way had been averted. Satan had been frustrated. The young woman remained after the others had left in order to thank her teacher for the lesson and to let her know how it had helped her avoid what might have been a tragic outcome. A teacher’s prayer had been answered.



I subsequently learned that because she had made her decision not to go with her friends that night—some of the most popular girls and boys at school—the young woman was shunned by them and for many months had no friends at school. They couldn’t accept that she was unwilling to do the things they did. It was an extremely difficult and lonely period for her, but she remained steadfast and eventually gained friends who shared her standards. Now, several years later, she has a temple marriage and four beautiful children. How different her life could have been. Our decisions determine our destiny.

Precious young women, make every decision you contemplate pass this test: “What does it do to me? What does it do for me?” And let your code of conduct emphasize not “What will others think?” but rather “What will I think of myself?” Be influenced by that still, small voice. Remember that one with authority placed his hands on your head at the time of your confirmation and said, “Receive the Holy Ghost.” Open your hearts, even your very souls, to the sound of that special voice which testifies of truth. As the prophet Isaiah promised, “Thine ears shall hear a word … saying, This is the way, walk ye in it.”3

The tenor of our times is permissiveness. Magazines and television shows portray the stars of the movie screen, the heroes of the athletic field—those whom many young people long to emulate—as disregarding the laws of God and flaunting sinful practices, seemingly with no ill effect. Don’t you believe it! There is a time of reckoning—even a balancing of the ledger. Every Cinderella has her midnight—if not in this life, then in the next. Judgment Day will come for all. Are you prepared? Are you pleased with your own performance?

If any has stumbled in her journey, I promise you that there is a way back. The process is called repentance. Our Savior died to provide you and me that blessed gift. Though the path is difficult, the promise is real. Said the Lord: “Though your sins be as scarlet, they shall be as white as snow.”4 “And I will remember [them] no more.”5

My beloved young sisters, you have the precious gift of agency. I plead with you to choose to obey.

Finally, may you endure. What does it mean to endure? I love this definition: to withstand with courage. Courage may be necessary for you to believe; it will at times be necessary as you obey. It will most certainly be required as you endure until that day when you will leave this mortal existence.

I have spoken over the years with many individuals who have told me, “I have so many problems, such real concerns. I’m overwhelmed with the challenges of life. What can I do?” I have offered to them, and I now offer to you, this specific suggestion: seek heavenly guidance one day at a time. Life by the yard is hard; by the inch it’s a cinch. Each of us can be true for just one day—and then one more and then one more after that—until we’ve lived a lifetime guided by the Spirit, a lifetime close to the Lord, a lifetime of good deeds and righteousness. The Savior promised, “Look unto me, and endure to the end, and ye shall live; for unto him that endureth to the end will I give eternal life.”6

For this purpose have you come into mortality, my young friends. There is nothing more important than the goal you strive to attain—even eternal life in the kingdom of your Father.

You are precious, precious daughters of our Heavenly Father sent to earth at this day and time for a purpose. You have been withheld until this very hour. Wonderful, glorious things are in store for you if you will only believe, obey, and endure. May this be your blessing, I pray in the name of Jesus Christ, our Savior, amen.

# References
1. - Julie de Azevedo Hanks, “Keeper of the Flame,” Treasure the Truth (compact disc, 1997).
2. - Doctrine and Covenants 64:34.
3. - Isaiah 30:21.
4. - Isaiah 1:18.
5. - Jeremiah 31:34.
6. - 3 Nephi 15:9.