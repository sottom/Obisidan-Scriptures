President Thomas S. Monson
President of the Church
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/willing-and-worthy-to-serve?lang=eng)

_Miracles are everywhere to be found when the priesthood is understood, its power is honored and used properly, and faith is exerted._

My beloved brethren, how good it is to meet with you once again. Whenever I attend the general priesthood meeting, I reflect on the teachings of some of God’s noble leaders who have spoken in the general priesthood meetings of the Church. Many have passed to their eternal reward, and yet from the brilliance of their minds, from the depths of their souls, and from the warmth of their hearts, they have given us inspired direction. I share with you tonight some of their teachings concerning the priesthood.

From the Prophet Joseph Smith: “Priesthood is an everlasting principle, and existed with God from eternity, and will to eternity, without beginning of days or end of years.”1

From the words of President Wilford Woodruff, we learn: “The Holy Priesthood is the channel through which God communicates and deals with man upon the earth; and the heavenly messengers that have visited the earth to communicate with man are men who held and honored the priesthood while in the flesh; and everything that God has caused to be done for the salvation of man, from the coming of man upon the earth to the redemption of the world, has been and will be by virtue of the everlasting priesthood.”2

President Joseph F. Smith further clarified: “The priesthood … is … the power of God delegated to man by which man can act in the earth for the salvation of the human family, in the name of the Father and the Son and the Holy Ghost, and act legitimately; not assuming that authority, nor borrowing it from generations that are dead and gone, but authority that has been given in this day in which we live by ministering angels and spirits from above, direct from the presence of Almighty God.”3

And finally from President John Taylor: “What is priesthood? … It is the government of God, whether on the earth or in the heavens, for it is by that power, agency, or principle that all things are governed on the earth and in the heavens, and by that power that all things are upheld and sustained. It governs all things—it directs all things—it sustains all things—and has to do with all things that God and truth are associated with.”4

How blessed we are to be here in these last days, when the priesthood of God is upon the earth. How privileged we are to bear that priesthood. The priesthood is not so much a gift as it is a commission to serve, a privilege to lift, and an opportunity to bless the lives of others.

With these opportunities come responsibilities and duties. I love and cherish the noble word duty and all that it implies.

In one capacity or another, in one setting or another, I have been attending priesthood meetings for the past 72 years—since I was ordained a deacon at the age of 12. Time certainly marches on. Duty keeps cadence with that march. Duty does not dim nor diminish. Catastrophic conflicts come and go, but the war waged for the souls of men continues without abatement. Like a clarion call comes the word of the Lord to you, to me, and to priesthood holders everywhere: “Wherefore, now let every man learn his duty, and to act in the office in which he is appointed, in all diligence.”5

The call of duty came to Adam, to Noah, to Abraham, to Moses, to Samuel, to David. It came to the Prophet Joseph Smith and to each of his successors. The call of duty came to the boy Nephi when he was instructed by the Lord, through his father Lehi, to return to Jerusalem with his brothers to obtain the brass plates from Laban. Nephi’s brothers murmured, saying it was a hard thing which had been asked of them. What was Nephi’s response? Said he, “I will go and do the things which the Lord hath commanded, for I know that the Lord giveth no commandments unto the children of men, save he shall prepare a way for them that they may accomplish the thing which he commandeth them.”6

When that same call comes to you and to me, what will be our response? Will we murmur, as did Laman and Lemuel, and say, “This is a hard thing required of us”?7 Or will we, with Nephi, individually declare, “I will go. I will do”? Will we be willing to serve and to obey?

At times the wisdom of God appears as being foolish or just too difficult, but one of the greatest and most valuable lessons we can learn in mortality is that when God speaks and a man obeys, that man will always be right.

When I think of the word duty and how performing our duty can enrich our lives and the lives of others, I recall the words penned by a renowned poet and author:





I slept and dreamt

That life was joy

I awoke and saw

That life was duty

I acted and behold

Duty was joy.8





Robert Louis Stevenson put it another way. Said he, “I know what pleasure is, for I have done good work.”9

As we perform our duties and exercise our priesthood, we will find true joy. We will experience the satisfaction of having completed our tasks.

We have been taught the specific duties of the priesthood which we hold, whether it be the Aaronic or the Melchizedek Priesthood. I urge you to contemplate those duties and then do all within your power to fulfill them. In order to do so, each must be worthy. Let us have ready hands, clean hands, and willing hands, that we may participate in providing what our Heavenly Father would have others receive from Him. If we are not worthy, it is possible to lose the power of the priesthood; and if we lose it, we have lost the essence of exaltation. Let us be worthy to serve.

President Harold B. Lee, one of the great teachers in the Church, said: “When one becomes a holder of the priesthood, he becomes an agent of the Lord. He should think of his calling as though he were on the Lord’s errand.”10

During World War II, in the early part of 1944, an experience involving the priesthood took place as United States marines were taking Kwajalein Atoll, part of the Marshall Islands and located in the Pacific Ocean about midway between Australia and Hawaii. What took place in this regard was related by a correspondent—not a member of the Church—who worked for a newspaper in Hawaii. In the 1944 newspaper article he wrote following the experience, he explained that he and other correspondents were in the second wave behind the marines at Kwajalein Atoll. As they advanced, they noticed a young marine floating facedown in the water, obviously badly wounded. The shallow water around him was red with his blood. And then they noticed another marine moving toward his wounded comrade. The second marine was also wounded, with his left arm hanging helplessly by his side. He lifted up the head of the one who was floating in the water in order to keep him from drowning. In a panicky voice he called for help. The correspondents looked again at the boy he was supporting and called back, “Son, there is nothing we can do for this boy.”

“Then,” wrote the correspondent, “I saw something that I had never seen before.” This boy, badly wounded himself, made his way to the shore with the seemingly lifeless body of his fellow marine. He “put the head of his companion on his knee. … What a picture that was—these two mortally wounded boys—both … clean, wonderful-looking young men, even in their distressing situation. And the one boy bowed his head over the other and said, ‘I command you, in the name of Jesus Christ and by the power of the priesthood, to remain alive until I can get medical help.’” The correspondent concluded his article: “The three of us [the two marines and I] are here in the hospital. The doctors don’t know [how they made it alive], but I know.”11

Miracles are everywhere to be found when the priesthood is understood, its power is honored and used properly, and faith is exerted. When faith replaces doubt, when selfless service eliminates selfish striving, the power of God brings to pass His purposes.

The call of duty can come quietly as we who hold the priesthood respond to the assignments we receive. President George Albert Smith, that modest but effective leader, declared, “It is your duty first of all to learn what the Lord wants and then by the power and strength of His holy Priesthood to [so] magnify your calling in the presence of your fellows … that the people will be glad to follow you.”12

Such a call of duty—a much less dramatic call but one which nonetheless helped to save a soul—came to me in 1950 when I was a newly called bishop. My responsibilities as a bishop were many and varied, and I tried to the best of my ability to do all that was required of me. The United States was engaged in a different war by then. Because many of our members were serving in the armed services, an assignment came from Church headquarters for all bishops to provide each serviceman a subscription to the Church News and the Improvement Era, the Church’s magazine at that time. In addition, each bishop was asked to write a personal, monthly letter to each serviceman from his ward. Our ward had 23 men in uniform. The priesthood quorums, with effort, supplied the funds for the subscriptions to the publications. I undertook the task, even the duty, to write 23 personal letters each month. After all these years I still have copies of many of my letters and the responses received. Tears come easily when these letters are reread. It is a joy to learn again of a soldier’s pledge to live the gospel, a sailor’s decision to keep faith with his family.

One evening I handed to a sister in the ward the stack of 23 letters for the current month. Her assignment was to handle the mailing and to maintain the constantly changing address list. She glanced at one envelope and, with a smile, asked, “Bishop, don’t you ever get discouraged? Here is another letter to Brother Bryson. This is the 17th letter you have sent to him without a reply.”

I responded, “Well, maybe this will be the month.” As it turned out, that was the month. For the first time, he responded to my letter. His reply is a keepsake, a treasure. He was serving far away on a distant shore, isolated, homesick, alone. He wrote, “Dear Bishop, I ain’t much at writin’ letters.” (I could have told him that several months earlier.) His letter continued, “Thank you for the Church News and magazines, but most of all thank you for the personal letters. I have turned over a new leaf. I have been ordained a priest in the Aaronic Priesthood. My heart is full. I am a happy man.”

Brother Bryson was no happier than was his bishop. I had learned the practical application of the adage “Do [your] duty; that is best; leave unto [the] Lord the rest.”13

Years later, while attending the Salt Lake Cottonwood Stake when James E. Faust served as its president, I related that account in an effort to encourage attention to our servicemen. After the meeting, a fine-looking young man came forward. He took my hand in his and asked, “Bishop Monson, do you remember me?”

I suddenly realized who he was. “Brother Bryson!” I exclaimed. “How are you? What are you doing in the Church?”

With warmth and obvious pride, he responded, “I’m fine. I serve in the presidency of my elders quorum. Thank you again for your concern for me and the personal letters which you sent and which I treasure.”

Brethren, the world is in need of our help. Are we doing all we should? Do we remember the words of President John Taylor: “If you do not magnify your callings, God will hold you responsible for those whom you might have saved had you done your duty”?14 There are feet to steady, hands to grasp, minds to encourage, hearts to inspire, and souls to save. The blessings of eternity await you. Yours is the privilege to be not spectators but participants on the stage of priesthood service. Let us hearken to the stirring reminder found in the Epistle of James: “Be ye doers of the word, and not hearers only, deceiving your own selves.”15

Let us learn and contemplate our duty. Let us be willing and worthy to serve. Let us in the performance of our duty follow in the footsteps of the Master. As you and I walk the pathway Jesus walked, we will discover He is more than the babe in Bethlehem, more than the carpenter’s son, more than the greatest teacher ever to live. We will come to know Him as the Son of God, our Savior and our Redeemer. When to Him came the call of duty, He answered, “Father, thy will be done, and the glory be thine forever.”16 May each of us do likewise, I pray in His holy name, the name of Jesus Christ, the Lord, amen.

# References
1. - Teachings of Presidents of the Church: Joseph Smith (2007), 104.
2. - Teachings of Presidents of the Church: Wilford Woodruff (2004), 38.
3. - Joseph F. Smith, Gospel Doctrine, 5th ed. (1939), 139–40; emphasis added.
4. - Teachings of Presidents of the Church: John Taylor (2001), 119.
5. - Doctrine and Covenants 107:99; emphasis added.
6. - 1 Nephi 3:7; see also verses 1–5.
7. - See 1 Nephi 3:5.
8. - Rabindranath Tagore, in William Jay Jacobs, Mother Teresa: Helping the Poor (1991), 42.
9. - Robert Louis Stevenson, in Elbert Hubbard II, comp., The Note Book of Elbert Hubbard: Mottoes, Epigrams, Short Essays, Passages, Orphic Sayings and Preachments (1927), 55.
10. - Stand Ye in Holy Places: Selected Sermons and Writings of President Harold B. Lee (1976), 255.
11. - In Ernest Eberhard Jr., “Giving Our Young Men the Proper Priesthood Perspective,” typescript, July 19, 1971, 4–5, Church History Library.
12. - George Albert Smith, in Conference Report, Apr. 1942, 14.
13. - Henry Wadsworth Longfellow, “The Legend Beautiful,” in The Complete Poetical Works of Longfellow (1893), 258.
14. - Teachings: John Taylor, 164.
15. - James 1:22.
16. - Moses 4:2.