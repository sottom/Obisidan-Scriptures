Elder David S. Baxter
Of the Seventy
04-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/04/faith-fortitude-fulfillment-a-message-to-single-parents?lang=eng)

_You are striving to raise your children in righteousness and truth, knowing that while you cannot change the past, you can shape the future._

My message is for the single parents in the Church, the majority of whom are single mothers—you valiant women who, through the varying circumstances of life, find yourselves raising children and running a home on your own. Perhaps you have been widowed or divorced. You may be coping with the challenges of single parenthood as a result of having taken a wrong turn outside of marriage, but you are now living within the framework of the gospel, having turned your life around. Bless you for avoiding the type of companionship that would come at the expense of virtue and discipleship. That would be far too high a price to pay.

Although you may at times have asked, why me? it is through the hardships of life that we grow toward godhood as our character is shaped in the crucible of affliction, as the events of life take place while God respects the agency of man. As Elder Neal A. Maxwell commented, we cannot do all the sums or make it all add up because “we do not have all the numbers.”1

Whatever your circumstances or the reasons for them, how wonderful you are. Day to day you face the struggles of life, doing the work that was always meant for two but doing it largely alone. You have to be father as well as mother. You run your household, watch over your family, sometimes struggle to make ends meet, and miraculously you even find the wherewithal to serve in the Church in significant ways. You nurture your children. You cry and pray with them and for them. You want the very best for them but fret every night that your best may never be good enough.

Whilst reluctant to be overly personal, I am the product of such a home. For most of my childhood and teenage years, my mother raised us on her own in poor circumstances. Money was carefully rationed. She coped with an inner loneliness, desperate at times for support and companionship. Yet despite all of this, there was a dignity about my mother, a tremendous source of determination and sheer Scottish grit.

Thankfully, her later years were more blessed than the beginning. She married a new convert, a widower; they were sealed in the London England Temple and later briefly served there as ordinance workers. They were together for almost a quarter of a century—happy, content, and fulfilled until overtaken by mortality.

There are many of you good women in the Church across the world who face similar circumstances and who demonstrate the same resilience year after year.

This is not exactly what you hoped or planned, prayed for or expected, when you started out years ago. Your journey through life has had bumps, detours, twists, and turns, mostly as the result of life in a fallen world that is meant to be a place of proving and testing.

Meanwhile, you are striving to raise your children in righteousness and truth, knowing that while you cannot change the past, you can shape the future. Along the way you will obtain compensatory blessings, even if they are not immediately apparent.

With God’s help, you need not fear for the future. Your children will grow up and call you blessed, and every single one of their many achievements will stand as a tribute to you.

Please never feel that you are in some kind of second-tier subcategory of Church membership, somehow less entitled to the Lord’s blessings than others. In the kingdom of God there are no second-class citizens.

We hope that when you attend meetings and see seemingly complete and happy families or hear someone speak of family ideals, you will feel glad to be part of a church that does focus on families and teaches of their central role in Heavenly Father’s plan for the happiness of His children; that in the midst of world calamity and moral decay, we have the doctrine, authority, ordinances, and covenants that do hold out the best hope for the world, including for the future happiness of your children and the families they will create.

In the general Relief Society meeting of September 2006, President Gordon B. Hinckley related an experience shared by a divorced single mother of seven children then ranging in ages from 7 to 16. She had gone across the street to deliver something to a neighbor. She said:

“As I turned around to walk back home, I could see my house lighted up. I could hear echoes of my children as I had walked out of the door a few minutes earlier. They were saying: ‘Mom, what are we going to have for dinner?’ ‘Can you take me to the library?’ ‘I have to get some poster paper tonight.’ Tired and weary, I looked at that house and saw the light on in each of the rooms. I thought of all of those children who were home waiting for me to come and meet their needs. My burdens felt heavier than I could bear.

“I remember looking through tears toward the sky, and I said, ‘Dear Father, I just can’t do it tonight. I’m too tired. I can’t face it. I can’t go home and take care of all those children alone. Could I just come to You and stay with You for just one night? …’

“I didn’t really hear the words of reply, but I heard them in my mind. The answer was: ‘No, little one, you can’t come to me now. … But I can come to you.’”2

Thank you, sisters, for all that you are doing to raise your family and maintain a loving home where there is goodness, peace, and opportunity.

Although you often feel alone, in truth you are never totally on your own. As you move forward in patience and in faith, Providence will move with you; heaven will bestow its needful blessings.

Your perspective and view of life will change when, rather than being cast down, you look up.

Many of you have already discovered the great, transforming truth that when you live to lift the burdens of others, your own burdens become lighter. Although circumstances may not have changed, your attitude has. You are able to face your own trials with greater acceptance, a more understanding heart, and deeper gratitude for what you have, rather than pining for what you yet lack.

You have discovered that when we extend lines of hopeful credit to those whose life accounts seem empty, our own coffers of consolation are enriched and made full; our cup truly “runneth over” (Psalm 23:5).

Through righteous living, you and your children may one day enjoy the blessings of being part of a complete, eternal family.

Members and leaders, is there more that you could do to support single-parent families without passing judgment or casting aspersions? Might you mentor young people in these families, especially providing for young men examples of what good men do and how good men live? In the absence of fathers, are you providing role models worthy of emulation?

Now, there are, of course, some single families where it is the father who is the single parent. Brethren, we also pray for you and pay tribute to you. This message is also for you.

Single parents, I testify that as you do your very best in the most difficult of human challenges, heaven will smile upon you. Truly you are not alone. Let the redemptive, loving power of Jesus Christ brighten your life now and fill you with the hope of eternal promise. Take courage. Have faith and hope. Consider the present with fortitude and look to the future with confidence. In the name of Jesus Christ, amen.

# References
1. - Neal A. Maxwell, Notwithstanding My Weakness (1981), 68.
2. - In Gordon B. Hinckley, “In the Arms of His Love,” Liahona and Ensign, Nov. 2006, 117.