Elder Neil L. Andersen
Of the Quorum of the Twelve Apostles
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/trial-of-your-faith?lang=eng)

_Like the intense fire that transforms iron into steel, as we remain faithful during the fiery trial of our faith, we are spiritually refined and strengthened._

Ten years ago as my wife, Kathy, and I were living in São Paulo, Brazil, President David Marriott was presiding over the Brazil São Paulo Interlagos Mission. He and his wife, Neill, and their sons Will, Wesley, and Trace lived near us. They had left their home, their business, and many in their family to respond to a call from the prophet to serve a mission.

President Marriott called me one afternoon. Their precious, righteous 21-year-old daughter, Georgia, a senior in violin performance at Indiana University, had been hit by a truck while riding her bicycle home after a Church meeting. On first report, Georgia was doing well. Hours later her condition dramatically worsened.

Family and friends began fasting and praying for a miracle for Georgia. Her mother flew through the night from Brazil. Arriving in Indiana the next day, she was met by her older children, who tearfully explained that they had been with Georgia as she passed away.

I watched the Marriott family at the time of this experience and in the months and years that followed. They wept, they prayed, they spoke of Georgia, they felt immense pain and sadness, but their faith did not falter. In this morning’s session, we heard of similar faith in the beautiful lives of the Bowen and Wilberger families.1

The gift of faith is a priceless spiritual endowment. “This is life eternal,” Jesus prayed, “that they might know thee the only true God, and Jesus Christ, whom thou hast sent.”2

Our faith is centered in God, our Father, and in His Son, Jesus Christ, our Savior and Redeemer. It is bolstered by our knowledge that the fulness of the gospel has been restored to the earth, that the Book of Mormon is the word of God, and that prophets and apostles today hold the keys of the priesthood. We treasure our faith, work to strengthen our faith, pray for increased faith, and do all within our power to protect and defend our faith.

The Apostle Peter identified something he called a “trial of your faith.”3 He had experienced it. Remember Jesus’s words:

“Simon, … Satan hath desired to have you, that he may sift you as wheat:

“But I have prayed for thee, that thy faith fail not.”4

Peter later encouraged others: “Think it not strange,” he said, “concerning the fiery trial which is to try you, as though some strange thing happened unto you.”5



These fiery trials are designed to make you stronger, but they have the potential to diminish or even destroy your trust in the Son of God and to weaken your resolve to keep your promises to Him. These trials are often camouflaged, making them difficult to identify. They take root in our weaknesses, our vulnerabilities, our sensitivities, or in those things that matter most to us. A real but manageable test for one can be a fiery trial for another.

How do you remain “steadfast and immovable”6 during a trial of faith? You immerse yourself in the very things that helped build your core of faith: you exercise faith in Christ, you pray, you ponder the scriptures, you repent, you keep the commandments, and you serve others.

When faced with a trial of faith—whatever you do, you don’t step away from the Church! Distancing yourself from the kingdom of God during a trial of faith is like leaving the safety of a secure storm cellar just as the tornado comes into view.

The Apostle Paul said, “Ye are no more strangers and foreigners, but fellowcitizens with the saints, and of the household of God.”7 It is within the sanctuary of the Church that we protect our faith. Meeting together with others who believe, we pray and find answers to our prayers; we worship through music, share testimony of the Savior, serve one another, and feel the Spirit of the Lord. We partake of the sacrament, receive the blessings of the priesthood, and attend the temple. The Lord declared, “In the ordinances … , the power of godliness is manifest.”8 When you are faced with a test of faith, stay within the safety and security of the household of God. There is always a place for you here. No trial is so large we can’t overcome it together.9

President Thomas S. Monson said: “The moral compass of society [has been evolving at a rapid rate]. Behaviors … once … considered inappropriate and immoral are now … viewed by … many as acceptable.”10

There are many single adults in the Church well beyond their early adult years. While finding their present life different than they had anticipated, they keep the law of chastity.11 It can be a trial of their faith. I express my deep respect and admiration for these disciples of Christ.

“God has commanded that the sacred powers of procreation are to be employed only between man and woman, lawfully wedded as husband and wife.”12 In the New Testament the Savior lifted the moral standard for His followers when He declared, “Whosoever looketh on a woman to lust after her hath committed adultery with her already in his heart.”13 He taught us not to condemn others, but He was unafraid to speak directly: “Go,” He said, “and sin no more.”14

Our family has a friend. You probably know someone like her, or perhaps you are like her. Always faithful, serves nobly in the Church, admired professionally, adored by her family, and while she anticipated marriage and children, she is single. “I made the decision,” she said, “to put my … trust in Jesus Christ. Going to the temple frequently helps me keep a more eternal focus. It reminds me I am never alone. I have faith … that no … blessing will be withheld … as I … remain faithful to my covenants, including the law of chastity.”15

Another friend served an outstanding mission, followed by rigorous academic training. He hoped to have a family. His trial of faith: feelings of same-sex attraction. He wrote me recently: “I am promised in my patriarchal blessing that I will have my own family someday. Whether that will occur in this life or the next, I do not know. But what I do know is that I don’t want to do anything that will jeopardize the blessings God has promised both me and my future posterity. … Living [the law of chastity] is a challenge, but did we not come to earth to confront challenges and to show God our love and respect for Him by keeping His commandments? I am blessed with good health, the gospel, a loving family, and loyal friends. I am grateful for my many blessings.”16

The world protests, how can you ask so much? The Lord responds:



“My thoughts are not your thoughts, neither are your ways my ways. …

“For as the heavens are higher than the earth, so are my ways higher than your ways, and my thoughts than your thoughts.”17

These two followers of Christ and tens of thousands like them have felt the Savior’s promise: “Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you. Let not your heart be troubled, neither let it be afraid.”18

Here is another trial. There have always been a few who want to discredit the Church and to destroy faith. Today they use the Internet.

Some of the information about the Church, no matter how convincing, is just not true. In 1985, I remember a colleague walking into my business office in Florida. He had a Time magazine article entitled “Challenging Mormonism’s Roots.” It spoke of a recently discovered letter, supposedly written by Martin Harris, that conflicted with Joseph Smith’s account of finding the Book of Mormon plates.19

My colleague asked if this new information would destroy the Mormon Church. The article quoted a man who said he was leaving the Church over the document. Later, others reportedly left the Church.20 I’m sure it was a trial of their faith.

A few months later, experts discovered (and the forger confessed) that the letter was a complete fraud. I remember really hoping that those who had left the Church because of this deception would find their way back.

A few question their faith when they find a statement made by a Church leader decades ago that seems incongruent with our doctrine. There is an important principle that governs the doctrine of the Church. The doctrine is taught by all 15 members of the First Presidency and Quorum of the Twelve. It is not hidden in an obscure paragraph of one talk. True principles are taught frequently and by many. Our doctrine is not difficult to find.

The leaders of the Church are honest but imperfect men. Remember the words of Moroni: “Condemn me not because of mine imperfection, neither my father … ; but rather give thanks unto God that he hath made manifest unto you our imperfections, that ye may learn to be more wise than we have been.”21

Joseph Smith said, “I never told you I was perfect; but there is no error in the revelations.”22 The miracle of God’s hand in the history and destiny of The Church of Jesus Christ of Latter-day Saints is understood only through the lens of spiritual inquiry. President Ezra Taft Benson said, “Every [person] eventually is backed up to the wall of faith, and there … must make his stand.”23 Don’t be surprised when it happens to you!

By definition, trials will be trying. There may be anguish, confusion, sleepless nights, and pillows wet with tears. But our trials need not be spiritually fatal. They need not take us from our covenants or from the household of God.

“Remember, … it is upon the rock of our Redeemer, who is Christ, the Son of God, that ye must build your foundation; that when the devil shall send forth his mighty winds, yea, his shafts in the whirlwind, yea, when all his hail and his mighty storm shall beat upon you, it shall have no power over you to drag you down to the gulf of misery and endless wo, because of the rock upon which ye are built, which is a sure foundation, a foundation whereon if men build they cannot fall.”24

Like the intense fire that transforms iron into steel, as we remain faithful during the fiery trial of our faith, we are spiritually refined and strengthened.

Elder D. Todd Christofferson explained what he learned from a personal trial: “Though I suffered then, as I look back now, I am grateful that there was not a quick solution to my problem. The fact that I was forced to turn to God for help almost daily over an extended period of years taught me truly how to pray and get answers to prayer and taught me in a very practical way to have faith in God. I came to know my Savior and my Heavenly Father in a way and to a degree that might not have happened otherwise or that might have taken me much longer to achieve. … I learned to trust in the Lord with all my heart. I learned to walk with Him day by day.”25

Peter described these experiences as “much more precious than … gold.”26 Moroni added that a witness follows “the trial of your faith.”27

I began with the story of the Marriott family. Last week Kathy and I joined them at Georgia’s grave. Ten years have passed. Family and friends spoke of the love and memories they have of Georgia. There were white helium balloons to celebrate her life. Amid tears, Georgia’s mother tenderly spoke of the increased faith and understanding she has received, and Georgia’s father quietly told me of the promised witness that has come to him.

With faith come trials of faith, bringing increased faith. The Lord’s comforting assurance to the Prophet Joseph Smith is the very same promise He makes to you in your trial of faith: “Hold on … , fear not … , for God shall be with you forever and ever.”28 Of this I bear my sacred witness in the name of Jesus Christ, amen.

# References
1. - See Shayne M. Bowen, “Because I Live, Ye Shall Live Also,” and Ann M. Dibb, “I Know It. I Live It. I Love It,” in the Saturday morning session of the October 2012 general conference.
2. - John 17:3.
3. - 1 Peter 1:7.
4. - Luke 22:31–32.
5. - 1 Peter 4:12; emphasis added.
6. - Alma 1:25.
7. - Ephesians 2:19.
8. - Doctrine and Covenants 84:20.
9. - See Mosiah 18:8–10.
10. - Thomas S. Monson, “Stand in Holy Places,” Liahona and Ensign, Nov. 2011, 82.
11. - See Ezra Taft Benson, “The Law of Chastity,” New Era, Jan. 1988, 4–7; “The Law of Chastity” in Brigham Young University 1987–88 Speeches (1988), 1–5, speeches.byu.edu; see also Gospel Principles (2009), 224–32.
12. - “The Family: A Proclamation to the World,” Liahona and Ensign, Nov. 2010, 129.
13. - Matthew 5:28.
14. - John 8:11.
15. - Personal correspondence, 2012.
16. - Personal correspondence, 2012.
17. - Isaiah 55:8–9.
18. - John 14:27.
19. - See Richard N. Ostling, “Challenging Mormonism’s Roots,” Time, May 20, 1985, 44.
20. - See Gordon B. Hinckley, “Lord, Increase Our Faith,” Ensign, Nov. 1987, 52.
21. - Mormon 9:31.
22. - Teachings of Presidents of the Church: Joseph Smith (2007), 522.
23. - Ezra Taft Benson, “The Book of Mormon Is the Word of God,” Tambuli, May 1988, 6; Ensign, May 1975, 65.
24. - Helaman 5:12.
25. - D. Todd Christofferson, “Give Us This Day Our Daily Bread” (Church Educational System fireside, Jan. 9, 2011), lds.org/broadcasts.
26. - 1 Peter 1:7; see also 1 Peter 4:13.
27. - Ether 12:6.
28. - Doctrine and Covenants 122:9; President George Q. Cannon said: “No matter how serious the trial, how deep the distress, how great the affliction, [God] will never desert us. He never has, and He never will. He cannot do it. It is not His character. He is an unchangeable being; the same yesterday, the same today, and He will be the same throughout the eternal ages to come. We have found that God. We have made Him our friend, by obeying His Gospel; and He will stand by us. We may pass through the fiery furnace; we may pass through deep waters; but we shall not be consumed nor overwhelmed. We shall emerge from all these trials and difficulties the better and purer for them, if we only trust in our God and keep His commandments” (“Remarks,” Deseret Evening News, Mar. 7, 1891, 4); see also Jeffrey R. Holland, “Come unto Me,” Ensign, Apr. 1998, 16–23.