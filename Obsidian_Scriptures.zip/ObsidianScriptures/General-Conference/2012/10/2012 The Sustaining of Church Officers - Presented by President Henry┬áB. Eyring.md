Presented by President Henry B. Eyring
First Counselor in the First Presidency
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/the-sustaining-of-church-officers?lang=eng)

It is proposed that we sustain Thomas Spencer Monson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Henry Bennion Eyring as First Counselor in the First Presidency; and Dieter Friedrich Uchtdorf as Second Counselor in the First Presidency.

Those in favor may manifest it.

Those opposed, if any, may manifest it.

It is proposed that we sustain Boyd Kenneth Packer as President of the Quorum of the Twelve Apostles and the following as members of that quorum: Boyd K. Packer, L. Tom Perry, Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, Richard G. Scott, Robert D. Hales, Jeffrey R. Holland, David A. Bednar, Quentin L. Cook, D. Todd Christofferson, and Neil L. Andersen.

Those in favor, please manifest it.

Any opposed may so indicate.

It is proposed that we sustain the counselors in the First Presidency and the Twelve Apostles as prophets, seers, and revelators.

All in favor, please manifest it.

Contrary, if there be any, by the same sign.

Elder Jay E. Jensen has been released as a member of the Presidency of the Quorums of the Seventy.

Those who can join with us in a vote of appreciation, please manifest it.

It is proposed that we sustain Elder Craig C. Christensen as a member of the Presidency of the Quorums of the Seventy.

All in favor, please manifest it.

Those opposed, if any.

It is proposed that we release with a vote of appreciation for his excellent service Elder Marlin K. Jensen as Church Historian and Recorder.

All in favor, please manifest it.

It is proposed that we sustain Elder Steven E. Snow as Church Historian and Recorder.

All in favor, please manifest it.

Any opposed.

It is proposed that we release Elders Keith K. Hilbig, Jay E. Jensen, Marlin K. Jensen, and Octaviano Tenorio as members of the First Quorum of the Seventy and designate them as emeritus General Authorities.

It is proposed that we release Elders Keith R. Edwards and Larry W. Gibbons as members of the Second Quorum of the Seventy.

Those who wish to join in expressing gratitude to these Brethren for their excellent service, please manifest it.

It is proposed that we sustain the other General Authorities, Area Seventies, and general auxiliary presidencies as presently constituted.

Those in favor, please manifest it.

Any opposed may manifest it.

Thank you, brothers and sisters, for your sustaining vote, your faith, devotion, and prayers.

# References
