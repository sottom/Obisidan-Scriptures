Elder Scott D. Whiting
Of the Seventy
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/temple-standard?lang=eng)

_The high standards of temple building employed by this Church are a type and even a symbol of how we should be living our own lives._

While recently touring the beautiful Brigham City Utah Temple, I was reminded of an experience that I had while serving as the coordinator of the open house, rededication, and cultural celebration of the historic Laie Hawaii Temple.

A few months prior to the completion of the extensive renovation work, I was invited to tour the temple with the Executive Director of the Temple Department, Elder William R. Walker, and his Temple Department associates. In addition, various members of the general contracting firm were in attendance. The purpose of the tour, in part, was to review the progress and quality of the work performed. At the time of this tour, the work was about 85 percent completed.

As we moved through the temple, I watched and listened to Elder Walker and his associates as they inspected the work and conversed with the general contractor. On occasion I observed one man running his hand along the walls as we moved from room to room. A few times after doing this, he would rub his fingers together and then approach the general contractor and say, “I feel grit on this wall. Grit is not temple standard. You will need to re-sand and buff this wall.” The contractor dutifully took notes of each observation.

As we approached an area in the temple that few eyes would ever see, the same man stopped us and directed our attention to a newly installed, beautiful leaded-glass window. This window measured about two feet (0.6 m) wide by six feet (1.8 m) tall and contained an embedded, small stained-glass geometric pattern. He pointed to a small two-inch (5 cm) colored-glass square that was part of the simple pattern and said, “That square is crooked.” I looked at the square, and to my eyes it looked evenly placed. However, upon closer inspection with a measuring device in hand, I could see there was a flaw and that this little square was indeed one-eighth of an inch (3 mm) crooked. Direction was then given to the contractor that this window would need to be replaced because it was not temple standard.

I admit that I was surprised that an entire window would need to be replaced because of such a small, barely noticeable defect. Surely, it was unlikely that anyone would ever know or even notice this window given its remote location in the temple.

As I drove home from the temple that day, I reflected on what I learned from this experience—or, rather, what I thought I learned. It wasn’t until several weeks later when I was invited to tour the now completed temple that my understanding of the prior tour experience became clearer.

As I entered the completely renovated Laie Hawaii Temple, I was overwhelmed by its beauty and quality of finish. You can appreciate my anticipation as I approached the “gritty” walls and the “flawed” window. Did the contractor re-sand and buff the walls? Was the window really replaced? As I approached the gritty walls, I was surprised to see that beautiful wallpaper now hung on all the walls. My first thought was, “So this is how the contractor addressed the grit—he covered it.” But, no, I learned that it had always been the plan to hang wallpaper on these walls. I wondered why a little hardly detectable grit mattered if wallpaper was to cover it. I then eagerly approached the area where the flawed window was located and was surprised to see a beautiful floor-to-ceiling potted plant sitting directly in front of the window. Again I thought, “So this is how the contractor addressed the crooked little square—he hid it.” As I moved closer, I pushed the plant’s leaves aside and smiled as I saw that the window had indeed been replaced. The formerly crooked little square now stood neatly and evenly in the pattern. I learned that it had always been part of the interior design to have a plant in front of this window.

Why would walls with a little grit and a window with a little asymmetry require additional work and even replacement when few human hands or eyes would ever know? Why was a contractor held to such high standards?



As I exited the temple deep in thought, I found my answer as I looked up at the refinished exterior and saw these words: “Holiness to the Lord, the House of the Lord.”

The temples of this Church are precisely as proclaimed. These sacred buildings are built for our use, and within their walls sacred and saving ordinances are performed. But there should be no doubt as to whose house it really is. By requiring exacting standards of construction down to the smallest of details, we not only show our love and respect for the Lord Jesus Christ, but we also hold out to all observers that we honor and worship Him whose house it is.

In the revelation given to the Prophet Joseph Smith to build a temple in Nauvoo, the Lord instructed:

“Come ye, with all your gold, and your silver, and your precious stones, and with all your antiquities; and with all who have knowledge of antiquities, … and bring … the precious trees of the earth;

“… And build a house to my name, for the Most High to dwell therein.”1

This follows a pattern established by King Solomon in the Old Testament when he built a temple unto the Lord using only the finest materials and workmanship.2 Today we continue to follow this pattern, with appropriate moderation, as we build the temples of the Church.

I learned that even though mortal eyes and hands may never see or feel a defect, the Lord knows the level of our efforts and whether we have done our very best. The same is true of our own personal efforts to live a life worthy of the blessings of the temple. The Lord has counseled:

“And inasmuch as my people build a house unto me in the name of the Lord, and do not suffer any unclean thing to come into it, that it be not defiled, my glory shall rest upon it;

“Yea, and my presence shall be there, for I will come into it, and all the pure in heart that shall come into it shall see God.

“But if it be defiled I will not come into it, and my glory shall not be there; for I will not come into unholy temples.”3

Like the contractor, when we become aware of elements in our own lives that are inconsistent with the teachings of the Lord, when our efforts have been less than our very best, we should move quickly to correct anything that is amiss, recognizing that we cannot hide our sins from the Lord. We need to remember that “when we undertake to cover our sins, … behold, the heavens withdraw themselves; [and] the Spirit of the Lord is grieved.”4

I also learned that the high standards of temple building employed by this Church are a type and even a symbol of how we should be living our own lives. We can apply, individually, the teachings of the Apostle Paul given to the early Church when he said:

“Know ye not that ye are the temple of God, and that the Spirit of God dwelleth in you?

“If any man defile the temple of God, him shall God destroy; for the temple of God is holy, which temple ye are.”5

We are each made of the finest materials, and we are the miraculous result of divine craftsmanship. However, as we move past the age of accountability and step onto the battlefield of sin and temptation, our own temple can become in need of renovation and repair work. Perhaps there are walls within us that are gritty and need buffing or windows of our souls that need replacement in order that we can stand in holy places. Gratefully, the temple standard that we are asked to meet is not that of perfection, although we are striving for it, but rather that we are keeping the commandments and doing our best to live as disciples of Jesus Christ. It is my prayer that we will all endeavor to live a life worthy of the blessings of the temple by doing our best, by making the necessary improvements and eliminating flaws and imperfections so that the Spirit of God may always dwell in us. In the name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 124:26–27.
2. - See 1 Kings 6–7.
3. - Doctrine and Covenants 97:15–17.
4. - Doctrine and Covenants 121:37.
5. - 1 Corinthians 3:16–17; see also verse 19.