Linda K. Burton
Relief Society General President
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/is-faith-in-the-atonement-of-jesus-christ-written-in-our-hearts?lang=eng)

_Making, keeping, and rejoicing in our covenants will be the evidence that the Atonement of Jesus Christ is truly written in our hearts._

My beloved sisters, you have been on my mind and in my heart for months as I have pondered this challenging responsibility. Though I don’t feel equal to the responsibility placed upon me, I know that the call has come from the Lord through His chosen prophet, and for now, that is enough. The scriptures teach that “whether by [the Lord’s] voice or by the voice of [His] servants, it is the same.”1

One of the precious gifts associated with this calling is the assurance that Heavenly Father loves all of His daughters. I have felt His love for each of us!

Like you, I love the scriptures! In the book of Jeremiah we find a scripture that is very dear to my heart. Jeremiah lived in a difficult time and place, but the Lord allowed him to foresee “a time of hope during the latter-day gathering of Israel”2—our day. Jeremiah prophesied:

“After those days, saith the Lord, I will put my law in their inward parts, and write it in their hearts; and will be their God, and they shall be my people. …

“… They shall all know me, from the least of them unto the greatest of them, saith the Lord: for I will forgive their iniquity, and I will remember their sin no more.”3

We are the people Jeremiah saw. Have we invited the Lord to write the law, or doctrine, in our hearts? Do we believe that the forgiveness available through the Atonement that Jeremiah refers to applies to us personally?

A few years ago, Elder Jeffrey R. Holland shared his feelings about the deep-rooted faith of pioneers who pushed toward the Salt Lake Valley even after the deaths of their children. He said, “They didn’t do that for a program, they didn’t do it for a social activity, they did it because the faith of the gospel of Jesus Christ was in their soul, it was in the marrow of their bones.”

He expressed, with tender emotion:

“That’s the only way those mothers could bury [their babies] in a breadbox and move on, saying, ‘The promised land is out there somewhere. We’re going to make it to the valley.’

“They could say that because of covenants and doctrine and faith and revelation and spirit.”

He concluded with these thought-provoking words: “If we can keep that in our families and in the Church, maybe a lot of other things start to take care of themselves. Maybe a lot of other less-needed things sort of fall out of the wagon. I’m told those handcarts could only hold so much. Just as our ancestors had to choose what they took, maybe the 21st century will drive us to decide, ‘What can we put on this handcart?’ It’s the substance of our soul; it’s the stuff right down in the marrow of our bones.”4 Or, to put it another way, it is what is written in our hearts!

As a new Relief Society presidency, we have sought the Lord earnestly to know what essential things He would have us put in our Relief Society handcart to continue moving His work forward. We have felt that Heavenly Father would first have us help His beloved daughters understand the doctrine of the Atonement of Jesus Christ. As we do so, we know our faith will increase, as will our desire to live righteously. Second, as we have considered the critical need to strengthen families and homes, we have felt that the Lord would have us encourage His beloved daughters to cheerfully cleave to their covenants. When covenants are kept, families are strengthened. Finally, we feel He would have us work in unity with the other auxiliaries and with our priesthood leaders, striving to seek out and help those in need to progress along the path. It is our fervent prayer that each of us will open our hearts and let the Lord engrave in them the doctrines of the Atonement, covenants, and unity.

How can we expect to strengthen families or help others unless we first have written in our own hearts a deep and abiding faith in Jesus Christ and His infinite Atonement? Tonight I would like to share three principles of the Atonement that, if written in our hearts, will increase our faith in Jesus Christ. It is my hope that understanding these principles will bless each of us, whether we are new to the Church or lifelong members.





Principle 1: “All that is unfair about life can be made right through the Atonement of Jesus Christ.”5



We, with you, bear witness of the Atonement of our Savior, Jesus Christ. Our testimonies, like yours, have been written in our hearts as we have faced assorted soul-stretching challenges and adversities. Without an understanding of Heavenly Father’s perfect plan of happiness and the Savior’s Atonement as the central feature of that plan, these challenges could seem unfair. We all share in the trials of life together. But in faithful hearts is written, “All that is unfair about life can be made right through the Atonement of Jesus Christ.”

Why does the Lord allow suffering and adversity to come to us in this life? Simply put, it is part of the plan for our growth and progress! We “shouted for joy”6 when we knew we would have the opportunity to come to earth to experience mortality. Elder Dallin H. Oaks taught, “Our needed conversions are often achieved more readily by suffering and adversity than by comfort and tranquillity.”7

The example of a faithful pioneer sister illustrates this truth. Mary Lois Walker was married at age 17 to John T. Morris in St. Louis, Missouri. They crossed the plains with the Saints in 1853, entering the Salt Lake Valley shortly after their first anniversary. On their journey they had suffered the privations typical of other Saints. But their sufferings and adversity did not end when they reached the Salt Lake Valley. The following year Mary, then 19, wrote: “A son was born to us. … One evening when he was two or three months old … something whispered to me, ‘You will lose that little one.’”

During the winter the baby’s health declined. “We did all we could, … but the baby grew steadily worse. … On the second of February he passed away … and so I drank the bitter cup of parting from my own flesh and blood.” But her trials were still not over. Mary’s husband was also stricken, and three weeks after losing her baby, he died.

Mary wrote: “So was I, while yet in my teens, bereft in the short period of 20 days, of my husband and my only child, in a strange land hundreds of miles from my blood kin and with a mountain of difficulty before me … and I wished that I too, might die and join my loved one[s].”

Mary continues: “One Sunday evening I was taking a walk with my friend. … I was reminded of [my husband’s] absence and my intense loneliness, and as I wept bitterly I could see, as it were in mental vision, the steep hill of life I should have to climb and felt the reality of it with great force. A deep depression settled upon me, for the enemy knows when to attack us, but our [Savior, Jesus Christ,] is mighty to save. Through … the help given of the Father, I was able to battle with all the force which seemed to be arrayed against me at this time.”8

Mary learned at the tender age of 19 that the Atonement gives us the assurance that all things that are unfair in this life can and will be made right—even the deepest sorrows.







Principle 2: There is power in the Atonement to enable us to overcome the natural man or woman and become true disciples of Jesus Christ.9



There is a way to know when we have learned a doctrine or principle of the gospel. It is when we are able to teach the doctrine or principle in a way that a child can understand it. A valuable resource to teach children to understand the Atonement is an analogy that is found in a Primary lesson. Perhaps this can help us as we teach our own children, grandchildren, or friends of other faiths who desire to understand this essential doctrine.

“A [woman] walking along a road fell into a pit so deep [she] could not climb out. No matter what [she] did, [she] could not get out by [herself]. The [woman] called for help and rejoiced when a kind passerby heard [her] and lowered a ladder down into the pit. This allowed [her] to climb out of the pit and regain [her] freedom.

“We are like the [woman] in the pit. Sinning is like falling into the pit, and we can’t get out by ourselves. Just as the kind passerby heard the [woman’s] cry for help, Heavenly Father sent his Only Begotten Son to provide the means of escape. Jesus Christ’s atonement could be compared to lowering a ladder into the pit; it gives us the means to climb out.”10 But the Savior does more than lower the ladder, He “comes down into the pit and makes it possible for us to use the ladder to escape.”11 “Just as the [woman] in the pit had to climb up the ladder, we must repent of our sins and obey the gospel principles and ordinances to climb out of our pit and make the Atonement work in our lives. Thus, after all we can do, the Atonement makes it possible for us to become worthy to return to Heavenly Father’s presence.”12



Recently I was privileged to meet a modern-day pioneer, a beloved daughter of God and recent convert to the Church in Chile. She is a single mother with two young sons. Through the power of the Atonement, she has been enabled to put her past behind her and is now earnestly striving to become a true disciple of Jesus Christ. As I think of her, a principle taught by Elder David A. Bednar comes to mind: “It is one thing to know that Jesus Christ came to earth to die for us—that is fundamental and foundational to the doctrine of Christ. But we also need to appreciate that the Lord desires, through His Atonement and by the power of the Holy Ghost, to live in us—not only to direct us but also to empower us.”13

As this Chilean sister and I discussed how to stay on the path leading to eternal life, she enthusiastically assured me that she was determined to continue on the path. She had been off the path most of her life, and she declared that there was nothing “out there” off the path that she wanted to have back in her life again. The enabling power of the Atonement is living inside of her. It is being written in her heart.

That power not only enables us to climb out of the pit but also gives us power to continue on the strait and narrow path leading back to the presence of our Heavenly Father.







Principle 3: The Atonement is the greatest evidence we have of the Father’s love for His children.



We would do well to ponder this stirring thought from Elder Oaks: “Think how it must have grieved our Heavenly Father to send His Son to endure incomprehensible suffering for our sins. That is the greatest evidence of His love for each of us!”14

That supreme act of love ought to send each of us to our knees in humble prayer to thank our Heavenly Father for loving us enough that He sent His Only Begotten and perfect Son to suffer for our sins, our heartaches, and all that seems unfair in our own individual lives.

Remember the woman President Dieter F. Uchtdorf spoke of recently? He said: “One woman who had been through years of trial and sorrow said through her tears, ‘I have come to realize that I am like an old 20-dollar bill—crumpled, torn, dirty, abused, and scarred. But I am still a 20-dollar bill. I am worth something. Even though I may not look like much and even though I have been battered and used, I am still worth the full 20 dollars.’”15

This woman knows that she is a beloved daughter of her Heavenly Father and that she was worth enough to Him to send His Son to atone for her, individually. Every sister in the Church should know what this woman knows—that she is a beloved daughter of God. How does knowing our worth to Him change how we keep our covenants? How does knowing our worth to Him affect our desire to minister to others? How does knowing our worth to Him increase our desire to help those who need to understand the Atonement as we do—way down deep? When each of us has the doctrine of the Atonement written deep in our hearts, then we will begin to become the kind of people the Lord wants us to be when He comes again. He will recognize us as His true disciples.



May the Atonement of Jesus Christ cause a “mighty change” to be wrought in our hearts.16 As we awaken to this doctrine, declared by an angel of God to be “glad tidings of great joy,”17 I promise that we will feel as King Benjamin’s people felt. After they had prayed mightily that the Atonement would be applied in their lives, “they were filled with joy”18 and were “willing to enter into a covenant with … God to do his will, and to be obedient to his commandments in all things.”19 Making, keeping, and rejoicing in our covenants will be the evidence that the Atonement of Jesus Christ is truly written in our hearts. Please remember these three principles, sisters:





“All that is unfair about life can be made right through the Atonement of Jesus Christ.”20







There is power in the Atonement to enable us to overcome the natural man or woman and become true disciples of Jesus Christ.21





The Atonement is the greatest evidence we have of the Father’s love for His children.22





“After those days, saith the Lord, I will put my law in their inward parts, and write it in their hearts; and will be their God, and they shall be my people.”23 I invite us to ask the Lord to write these principles of the Atonement in our hearts. I testify that they are true. In the name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 1:38.
2. - Old Testament: Gospel Doctrine Teacher’s Manual (2001), 198.
3. - Jeremiah 31:33–34; emphasis added.
4. - Jeffrey R. Holland, “Roundtable Discussion,” Worldwide Leadership Training Meeting, Feb. 9, 2008, 28.
5. - Preach My Gospel: A Guide to Missionary Service (2004), 52.
6. - Job 38:7.
7. - Dallin H. Oaks, “The Challenge to Become,” Liahona, Jan. 2001, 42; Ensign, Nov. 2000, 33.
8. - Autobiography of Mary Lois Walker Morris (copy in possession of Linda Kjar Burton).
9. - See David A. Bednar, “The Atonement and the Journey of Mortality,” Liahona, Apr. 2012, 12–19; Ensign, Apr. 2012, 40–47.
10. - Primary 7: New Testament (1997), 104.
11. - Joseph Fielding Smith, Doctrines of Salvation, comp. Bruce R. McConkie, 3 vols. (1954–56), 1:123.
12. - Primary 7, 104.
13. - David A. Bednar, Liahona, Apr. 2012, 14; Ensign, Apr. 2012, 42.
14. - Dallin H. Oaks, “Love and Law,” Liahona and Ensign, Nov. 2009, 26.
15. - Dieter F. Uchtdorf, “You Are My Hands,” Liahona and Ensign, May 2010, 69.
16. - See Alma 5:12–14.
17. - Mosiah 3:3.
18. - See Mosiah 4:1–3.
19. - See Mosiah 5:2–5.
20. - Preach My Gospel, 52.
21. - See David A. Bednar, Liahona, Apr. 2012, 12–19; Ensign, Apr. 2012, 40–47.
22. - See Dallin H. Oaks, Liahona and Ensign, Nov. 2009, 26.
23. - Jeremiah 31:33; emphasis added.