President Henry B. Eyring
First Counselor in the First Presidency
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/the-caregiver?lang=eng)

_You will be strengthened and yet inspired to know the limits and extent of your ability to serve._

I am grateful to be in your company tonight. The women of the Church of Jesus Christ have been moving toward becoming the society of sisters that the Prophet Joseph Smith’s mother, Lucy Mack Smith, described in these words: “We must cherish one another, watch over one another, comfort one another and gain instruction, that we may all sit down in heaven together.”1

There are three parts to that remarkable description of the qualifications to associate in a state of happiness with God. One is to care for each other. Another is to teach each other and be taught. And the third is to sit down together with God.

My purpose tonight is to help you feel the commendation and appreciation of God for what you have already done to help each other reach that lofty goal. And, second, it is to describe some of what is yet to come in your unified service.

Like the sisters of an earlier time, you have responded to the Lord’s call to go to the relief of others. In 1856 the prophet Brigham Young asked the Saints to go to the aid of handcart pioneers stranded in the mountain snows. He said in that time of need to the members in general conference: “Your faith, religion, and profession of religion, will never save one soul of you in the celestial kingdom of our God, unless you carry out just such principles as I am now teaching you. Go and bring in those people now on the plains, and attend strictly to those things which we call temporal, … otherwise your faith will be in vain.”2

Women in Utah responded by the hundreds. In their poverty they filled wagons with all they could spare and all they could gather from others to comfort those in distress. One of those valiant sisters recorded, “I never took more satisfaction and, I might say, pleasure in any labor I ever performed in my life, such a unanimity of feeling prevailed.”3

When the rescue was complete and the snows melted, that same sister recorded the question of her faithful heart: “What comes next for willing hands to do?”4

In our time, bands of valiant sisters across the earth have turned their faith into action in hundreds of places. And they ask in their hearts and prayers the same question about the future of their lives of service.

Each of you is in a unique place in your journey to eternal life. Some have years of experience, and others are early in their mortal discipleship. Each is unique in her personal history and her challenges. But all of you are sisters and beloved daughters of our Heavenly Father, who knows and watches over each of you.

What you have done remarkably well together is to cherish, watch over, and comfort each other. I was a witness of that threefold miracle just one month ago in your service to one sister. As her father, I thank you and I want to extend my thanks to God, who guided one visiting teacher.

Our daughter Elizabeth, who lives in another state and time zone from us, was at home with her three-year-old daughter. Her other child was in her first week of kindergarten. Elizabeth was six months pregnant and looking forward to the birth of her third child, which the doctors said would be another girl. Her husband, Joshua, was away at his work.

When she saw that she was passing blood and that the flow was increasing, she called her husband on the phone. He told her to call for an ambulance and that he would meet her at the hospital, which was 20 minutes from her home. Before she could place the call, she heard a knock at the front door.

At the door she was surprised to see her Relief Society visiting teaching companion. They had no appointment for that morning. Her companion had simply felt she ought to come by to see Elizabeth.

She helped her into the car. They arrived at the hospital minutes before Joshua arrived from his work. The doctors decided in less than 20 minutes to take the baby by surgery to save Elizabeth and her baby. So a tiny girl came into the world, crying loudly, 15 weeks ahead of schedule. She weighed one pound, eleven ounces (765 g). But she was alive, and so was Elizabeth.



The words of Lucy Mack Smith were in part fulfilled that day. A faithful member of the Relief Society, prompted by the Holy Ghost, watched over, cherished, and comforted her sister in God’s kingdom. She and the tens of thousands of others who have given such inspired service over the generations have not only the thanks of those they helped and their loved ones but also of the Lord.

You remember His words of appreciation to those who receive little recognition for their benevolence: “And the King shall answer and say unto them, Verily I say unto you, Inasmuch as ye have done it unto one of the least of these my brethren, ye have done it unto me.”5

But the miracle of one Relief Society sister arriving to help just in time is multiplied through the power of a unified society of sisters. Here is just a part of the message Elizabeth’s bishop sent to Elizabeth and to Joshua at the hospital hours after the baby was born: “The Relief Society president has everything under control. We are already building a future plan to assist with your girls at home so Elizabeth can travel back and forth to the hospital while the unnamed cute baby remains there. We’ve done it before, long term, and [our] people jump at the chance.”

The bishop went on to say, speaking for himself and the ward: “We’ve even come to the hospital and sat with kids in the playroom when moms didn’t want to leave them somewhere else.”

And then: “We won’t execute our plan without coordination and concurrence from you, of course. Just wanted to let you know not to worry about the things we can [and will] do.”

What they did for my daughter made it possible for her to have a precious moment when she held, for the first time, her tiny daughter.

And then the bishop closed his message to Joshua and Elizabeth with one that sisters send out of their commitment across the earth to serve others for the Master: “Keep the faith.”

With all your differences in personal circumstances and past experiences, I can tell you something of what lies ahead for you. As you keep the faith, you will find yourself invited by the Lord often to serve someone in need when it will not seem convenient. It may appear to be an unpleasant and perhaps even impossible task. When the call comes, it may seem you are not needed or that someone else could easily give the succor.

Remember that when the Lord lets us encounter someone in distress, we honor the good Samaritan for what he did not do as much as for what he did. He did not pass by on the other side even though the beaten traveler on the road was a stranger and perhaps an enemy. He did what he could for the beaten man and then put in place a specific plan for others to do more. He did that because he understood that helping may require more than what one person can do.

Lessons in that story can guide you in whatever your future holds. Those same lessons were available in your own childhood and recent experiences.

At least once, and perhaps often, you have been surprised when you encountered someone in need of care. It may have been a parent, a grandparent, a sister, or a child struck by illness or disability. Your feelings of compassion prevailed over your human desires. So you began to offer help.

Like the traveler in the scripture story of the good Samaritan, it is likely that the help needed turned into longer-term care than you could give alone. The Samaritan needed to pass the traveler to the care of the innkeeper. The Lord’s plan for serving others in need provides teams.

Bishops and Relief Society presidents always invite family members to help each other when there is a need. There are many reasons for that principle. Foremost is to provide to more people the blessing of increased love that comes from serving each other.

You have observed and felt that blessing. Whenever you have cared for someone for even a short time, you have felt love for the person you served. As the time to provide needed care grew longer, the feelings of love increased.

Since we are mortal, that increase in love may be interrupted by feelings of frustration and fatigue. That is another reason why the Lord lets us have the help of others in our service to those in need. That is why the Lord has created societies of caregivers.



A few weeks ago I was present as a young woman rose to be sustained in a sacrament meeting as the assistant coordinator of visiting teaching, a position I did not know existed. I wondered if she knew what a tribute the Lord had paid her. Because of a restless child, she had to leave the meeting before I could tell her how much the Lord would love and appreciate her for her help coordinating the efforts of His disciples.

Caring for those in need takes a team, a loving and unified society. That is what the Lord is building among you. He loves you for any part you play.

One evidence of His appreciation is that God allows you to feel increasing love for those you serve. That is a reason why you weep at the death of someone you have served for a long time. Losing the chance to care for them can feel like an even greater loss than does the temporary separation. I heard a woman—whom I have known a long time—recently, the week her husband died, bear a testimony of gratitude for the chance to serve him to the very end of his life. No tears were visible, but her happy smile was.

Even though extended and loving service to people is richly rewarded, you have learned that there are physical, emotional, and financial limits to what is possible. The person giving care long enough can become the one who needs care.

The Lord, who is the Master Nurturer of people in need, gave inspired counsel to weary caregivers in these words delivered by King Benjamin and recorded in the Book of Mormon: “For the sake of retaining a remission of your sins … I would that ye should impart of your substance to the poor, every man according to that which he hath, such as feeding the hungry, clothing the naked, visiting the sick and administering to their relief, both spiritually and temporally, according to their wants.”6

But then He goes on to warn those of you who might fail to respond to the evidence that you are pushing on too far and too long in your loving service: “And see that all these things are done in wisdom and order; for it is not requisite that a man [or any caregiver] should run faster than he has strength. And again, it is expedient that he should be diligent, that thereby he might win the prize; therefore, all things must be done in order.”7

That counsel can be hard to apply when the choice seems to be balancing a desire to do all you can to help others with the wisdom to be prudent in meeting your own needs to retain your power to serve. You may have seen others struggle with such hard choices. One example is the choice to care for a person approaching the end of life at home or in a care facility when you may be close to exhaustion.

What you know of the plan of salvation can be your guide in such heartrending choices. That is one of the reasons why Lucy Mack Smith wisely said that the sisters were to “gain instruction.”

It helps to have a sure conviction of the purpose of the Lord for every child of God in the crucible of mortal life. He taught the essence of the plan of salvation to the Prophet Joseph this way as he struggled to understand his seemingly endless trials: “And then, if thou endure it well, God shall exalt thee on high.”8



Our choice to best help someone through hard trials then becomes, “What course should I follow that will best help the person I love to ‘endure well’?” It is for us to make it more likely that he or she can exercise faith in Christ, keep a bright hope of eternal life, and practice charity, the pure love of Christ, to the end of his or her life.

I have seen sisters in the kingdom put that focus on the Savior and His purpose. Think of the times you have gone into the room where the Relief Society or the Primary or the Young Women have met.

A picture of the Savior or His words may not be evident, but you know a testimony of the reality and value of His Atonement has been felt in that hour as it has been this evening. There may not be a picture of a holy temple or the words “Families Can Be Forever,” but you can see hope in their smiles.

And you have seen, as I have, a wise visiting teacher build the confidence in a struggling sister that her service to someone else, even as she is failing, is still needed and valuable. Great Relief Society presidents find ways to let those who need care help in the care of others. They create opportunities for sisters to endure trials well as they care for each other in the pure love of Christ. That may include gentle urging of the tired giver of care to rest and accept the help of others.

The sisters make that possible by being slow to judge those going through trials. Most people carrying heavy loads begin to doubt themselves and their own worth. We lighten their loads as we are patient with their weaknesses and celebrate whatever goodness we can see in them. The Lord does that. And we could follow His example—He the greatest nurturer of all.

We speak often of the strength of the circle of sisters in the Church of Jesus Christ. We must learn to recognize that the Savior is always in the circle as we invite Him.

More and more, we will see daughters of God invite sisters into the circle with them. As sisters come into a meeting and look for a seat, they will hear the softly spoken words, “Please, come sit here with me.”

We will hear those words in that future day Lucy Mack Smith foresaw when the sisters will “sit down in heaven together.” We do not prepare for that day in a moment. It will come from days and years of caring for each other and taking the words of eternal life down deep into our hearts.

My prayer is that many of us will be together in the glorious future that lies before us. I bear you my testimony that your hope for those days will be justified. The Lord Jesus Christ, through His infinite Atonement, made it possible for each of you. Heavenly Father hears and answers your prayers of faith for guidance and for help to endure in your service for Him.

The Holy Ghost is sent to you and to those you care for. You will be strengthened and yet inspired to know the limits and extent of your ability to serve. The Spirit will comfort you when you may wonder, “Did I do enough?”

I testify that the Lord will be with you and that your way will be prepared and marked for you by Him in your service to those He loves in their needs and trials. In the sacred name of Jesus Christ, amen.

# References
1. - Lucy Mack Smith, in Daughters in My Kingdom: The History and Work of Relief Society (2011), 25.
2. - Brigham Young, in Daughters in My Kingdom, 36.
3. - Lucy Meserve Smith, in Daughters in My Kingdom, 37.
4. - Lucy Meserve Smith, in Daughters in My Kingdom, 37.
5. - Matthew 25:40.
6. - Mosiah 4:26.
7. - Mosiah 4:27.
8. - Doctrine and Covenants 121:8.