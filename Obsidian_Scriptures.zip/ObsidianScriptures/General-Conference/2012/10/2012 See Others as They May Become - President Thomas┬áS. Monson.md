President Thomas S. Monson
President of the Church
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/see-others-as-they-may-become?lang=eng)

_We must develop the capacity to see men not as they are at present but as they may become._

My dear brethren, twice each year this magnificent Conference Center is filled to capacity with the priesthood of God as we gather to hear messages of inspiration. There is a marvelous spirit which permeates the general priesthood meeting of the Church. This spirit emanates from the Conference Center and enters every building where the sons of God assemble. We have surely felt that spirit tonight.

Some years ago, before this beautiful Conference Center was built, a visitor to Temple Square in Salt Lake City attended a general conference session in the Tabernacle. He listened to the messages of the Brethren. He paid attention to the prayers. He heard the beautiful music by the Tabernacle Choir. He marveled at the grandeur of the magnificent Tabernacle organ. When the meeting had ended he was heard to say, “I would give everything I possess if I knew that what those speakers said today was true.” In essence he was saying, “I wish that I had a testimony of the gospel.”

There is absolutely nothing in this world that will provide more comfort and happiness than a testimony of the truth. Although to varying degrees, I believe every man or young man here tonight has a testimony. If you feel that you do not yet have the depth of testimony you would wish, I admonish you to work to achieve such a testimony. If it is strong and deep, labor to keep it that way. How blessed we are to have a knowledge of the truth.

My message tonight, brethren, is that there are countless individuals who have little or no testimony right now, those who could and would receive such a testimony if we would be willing to make the effort to share ours and to help them change. In some instances we can provide the incentive for change. I mention first those who are members but who are not at present fully committed to the gospel.

Many years ago, at an area conference held in Helsinki, Finland, I heard a powerful, memorable, and motivating message given in a mothers and daughters’ session. I have not forgotten that message, though nearly 40 years have passed since I heard it. Among many truths the speaker discussed, she said that a woman needs to be told she is beautiful. She needs to be told she is valued. She needs to be told she is worthwhile.

Brethren, I know that men are very much like women in this regard. We need to be told that we amount to something, that we are capable and worthwhile. We need to be given a chance to serve. For those members who have slipped from activity or who hold back and remain noncommittal, we can prayerfully seek for some way to reach them. Asking them to serve in some capacity may just be the incentive they need to return to full activity. But those leaders who could help in this regard are sometimes reluctant to do so. We need to bear in mind that people can change. They can put behind them bad habits. They can repent from transgressions. They can bear the priesthood worthily. And they can serve the Lord diligently. May I provide a few illustrations.

When I first became a member of the Quorum of the Twelve Apostles, I had the opportunity to accompany President N. Eldon Tanner, a counselor to President David O. McKay, to a stake conference in Alberta, Canada. During the meeting, the stake president read the names of four brethren who had qualified to be ordained elders. These were men whom President Tanner knew, for at one time he had lived in that area. But President Tanner knew and remembered them as they once were and did not know that they had turned their lives around and had fully qualified to become elders.

The stake president read the name of the first man and asked him to stand. President Tanner whispered to me, “Look at him. I never thought he would make it.” The stake president read the name of the second man, and he stood. President Tanner nudged me again and reported his astonishment. And so it was with all four of the brethren.



After the meeting, President Tanner and I had the opportunity to congratulate these four brethren. They had demonstrated that men can change.

During the 1940s and 1950s, an American prison warden, Clinton Duffy, was well known for his efforts to rehabilitate the men in his prison. Said one critic, “You should know that leopards don’t change their spots!”

Replied Warden Duffy, “You should know I don’t work with leopards. I work with men, and men change every day.”1

Many years ago it was my opportunity to serve as president of the Canadian Mission. There we had a branch with very limited priesthood. We always had a missionary presiding over the branch. I received a strong impression that we needed to have a member of the branch preside there.

We had one adult member in the branch who was a deacon in the Aaronic Priesthood but who didn’t attend or participate enough to be advanced in the priesthood. I felt inspired to call him as the branch president. I shall always remember the day that I had an interview with him. I told him that the Lord had inspired me to call him to be the president of the branch. After much protest on his part, and much encouragement on the part of his wife, he indicated that he would serve. I ordained him a priest.

It was the beginning of a new day for that man. His life was quickly put in order, and he assured me that he would live the commandments as he was expected to live them. In a few months he was ordained an elder. He and his wife and family eventually went to the temple and were sealed. Their children served missions and married in the house of the Lord.

Sometimes letting our brethren know they are needed and valued can help them take that step into commitment and full activity. This can be true of priesthood holders regardless of age. It is our responsibility to give them opportunities to live as they should. We can help them to overcome their shortcomings. We must develop the capacity to see men not as they are at present but as they may become when they receive testimonies of the gospel of Christ.

I once attended a meeting in Leadville, Colorado. Leadville is situated at an altitude of over 10,000 feet (3,000 m). I remember that particular meeting because of the high altitude, but I also remember it for what took place that evening. There were just a small number of priesthood holders present. As with the branch in the Canadian Mission, that branch was presided over by a missionary and always had been.

That night we had a lovely meeting, but as we were singing the closing song, the inspiration came to me that there ought to be a local branch president presiding. I turned to the mission president and asked, “Isn’t there someone here who could preside—a local man?”

He replied, “I don’t know of one.”

During the singing of that song, I looked carefully at the men who were seated on the first three rows. My attention seemed to be focused on one of the brethren. I said to the mission president, “Could he serve as the branch president?”

He replied, “I don’t know. Perhaps he could.”

I said, “President, I’ll take him into the other room and interview him. You speak after the closing song until we return.”

When the two of us walked back in the room, the mission president concluded his testimony. I presented the name of the brother to be the new branch president. From that day forward, Leadville, Colorado, had a local member leading the unit there.

The same principle, brethren, applies to those who are not yet members. We should develop the capacity to see men not as they are but as they can become when they are members of the Church, when they have a testimony of the gospel, and when their lives are in harmony with its teachings.

Back in the year 1961, a worldwide conference was held for mission presidents, and every mission president in the Church was brought to Salt Lake City for those meetings. I came to Salt Lake City from my mission in Toronto, Canada.

In one particular meeting, N. Eldon Tanner, who was then an Assistant to the Quorum of the Twelve, had just returned from his initial experience of presiding over the missions in Great Britain and western Europe. He told of a missionary who had been the most successful missionary whom he had met in all of the interviews he had conducted. He said that as he interviewed that missionary, he said to him, “I suppose that all of the people whom you baptized came into the Church by way of referrals.”

The young man answered, “No, we found them all by tracting.”

Brother Tanner asked him what was different about his approach—why he had such phenomenal success when others didn’t. The young man said that he attempted to baptize every person whom he met. He said that if he knocked on the door and saw a man smoking a cigar and dressed in old clothes and seemingly uninterested in anything—particularly religion—the missionary would picture in his own mind what that man would look like under a different set of circumstances. In his mind he would look at him as clean-shaven and wearing a white shirt and white trousers. And the missionary could see himself leading that man into the waters of baptism. He said, “When I look at someone that way, I have the capacity to bear my testimony to him in a way that can touch his heart.”

We have the responsibility to look at our friends, our associates, our neighbors this way. Again, we have the responsibility to see individuals not as they are but rather as they can become. I would plead with you to think of them in this way.

Brethren, the Lord told us something about the importance of this priesthood that we hold. He told us that we receive it with an oath and a covenant. He gave unto us the instruction that we must be faithful and true in all that we receive, and that we have the responsibility to keep this covenant even unto the end. And then all that the Father has shall be given unto us.2

Courage is the word we need to hear and hold near our hearts—courage to turn our backs on temptation, courage to lift up our voices in testimony to all whom we meet, remembering that everyone must have an opportunity to hear the message. It is not an easy thing for most to do this. But we can come to believe in the words of Paul to Timothy:

“For God hath not given us the spirit of fear; but of power, and of love, and of a sound mind.

“Be not thou therefore ashamed of the testimony of our Lord.”3

In May of 1974, I was with Brother John H. Groberg in the Tongan islands. We had an appointment to visit the king of Tonga, and we met with him in a formal session. We exchanged the normal pleasantries. However, before we left, John Groberg said something that was out of the ordinary. He said, “Your Majesty, you should really become a Mormon and your subjects as well, for then your problems and their problems would largely be solved.”

The king smiled broadly and answered, “John Groberg, perhaps you’re right.”

I thought of the Apostle Paul before Agrippa. I thought of Agrippa’s response to Paul’s testimony: “Almost thou persuadest me to be a Christian.”4 Brother Groberg had the courage to bear his testimony to a king.

Tonight there are many thousands of our number who are serving the Lord full-time as His missionaries. In response to a call, they have left behind home, family, friends, and school and have gone forward to serve. Those who don’t understand ask the question, “Why do they respond so readily and willingly give so much?”

Our missionaries could well answer in the words of Paul, that peerless missionary of an earlier day: “For though I preach the gospel, I have nothing to glory of: for necessity is laid upon me; yea, woe is unto me, if I preach not the gospel!”5

The holy scriptures contain no proclamation more relevant, no responsibility more binding, no instruction more direct than the injunction given by the resurrected Lord as He appeared in Galilee to the eleven disciples. Said He:

“All power is given unto me in heaven and in earth.

“Go ye therefore, and teach all nations, baptizing them in the name of the Father, and of the Son, and of the Holy Ghost:

“Teaching them to observe all things whatsoever I have commanded you: and, lo, I am with you alway, even unto the end of the world.”6

This divine command, coupled with its glorious promise, is our watchword today, as it was in the meridian of time. Missionary work is an identifying feature of The Church of Jesus Christ of Latter-day Saints. Always has it been; ever shall it be. As the Prophet Joseph Smith declared, “After all that has been said, the greatest and most important duty is to preach the Gospel.”7

Within two short years, all of the full-time missionaries currently serving in this royal army of God will have concluded their full-time labors and will have returned to their homes and loved ones. Their replacements are found tonight in the ranks of the Aaronic Priesthood of the Church. Young men, are you ready to respond? Are you willing to work? Are you prepared to serve?

President John Taylor summed up the requirements: “The kind of men we want as bearers of this gospel message are men who have faith in God; men who have faith in their religion; men who honor their priesthood; … men full of the Holy Ghost and the power of God[;] … men of honor, integrity, virtue and purity.”8

Brethren, to each of us comes the mandate to share the gospel of Christ. When our lives comply with God’s own standard, those within our sphere of influence will never speak the lament, “The harvest is past, the summer is ended, and we are not saved.”9

The perfect Shepherd of souls, the missionary who redeemed mankind, gave us His divine assurance:

“If it so be that you should labor all your days in crying repentance unto this people, and bring, save it be one soul unto me, how great shall be your joy with him in the kingdom of my Father!

“And now, if your joy will be great with one soul that you have brought unto me into the kingdom of my Father, how great will be your joy if you should bring many souls unto me!”10

Of Him who spoke these words, I declare my personal witness. He is the Son of God, our Redeemer, and our Savior.

I pray that we will have the courage to extend the hand of fellowship, the tenacity to try and try again, and the humility needed to seek guidance from our Father as we fulfill our mandate to share the gospel. The responsibility is upon us, brethren. In the name of Jesus Christ, amen.

# References
1. - In Bill Sands, The Seventh Step (1967), 9.
2. - See Doctrine and Covenants 84:33–39.
3. - 2 Timothy 1:7–8.
4. - Acts 26:28.
5. - 1 Corinthians 9:16.
6. - Matthew 28:18–20.
7. - Teachings of Presidents of the Church: Joseph Smith (2007), 330.
8. - Teachings of Presidents of the Church: John Taylor (2001), 73.
9. - Jeremiah 8:20.
10. - Doctrine and Covenants 18:15–16.