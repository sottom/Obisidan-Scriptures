President Thomas S. Monson
President of the Church
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/consider-the-blessings?lang=eng)

_Our Heavenly Father is aware of our needs and will help us as we call upon Him for assistance._

My beloved brothers and sisters, this conference marks 49 years since I was sustained, on October 4, 1963, as a member of the Quorum of the Twelve Apostles. Forty-nine years is a long time. In many ways, however, the time seems very short since I stood at the pulpit in the Tabernacle and gave my very first general conference address.

Much has changed since October 4, 1963. We live in a unique time in the world’s history. We are blessed with so very much. And yet it is sometimes difficult to view the problems and permissiveness around us and not become discouraged. I have found that, rather than dwelling on the negative, if we will take a step back and consider the blessings in our lives, including seemingly small, sometimes overlooked blessings, we can find greater happiness.

As I have reviewed the past 49 years, I have made some discoveries. One is that countless experiences I have had were not necessarily those one would consider extraordinary. In fact, at the time they transpired, they often seemed unremarkable and even ordinary. And yet, in retrospect, they enriched and blessed lives—not the least of which was my own. I would recommend this same exercise to you—namely, that you take an inventory of your life and look specifically for the blessings, large and small, you have received.

Reinforced constantly during my own review of the years has been my knowledge that our prayers are heard and answered. We are familiar with the truth found in 2 Nephi in the Book of Mormon: “Men are, that they might have joy.”1 I testify that much of that joy comes as we recognize that we can communicate with our Heavenly Father through prayer and that those prayers will be heard and answered—perhaps not how and when we expected they would be answered, but they will be answered and by a Heavenly Father who knows and loves us perfectly and who desires our happiness. Hasn’t He promised us, “Be thou humble; and the Lord thy God shall lead thee by the hand, and give thee answer to thy prayers”?2

For the next few minutes allotted to me, I would like to share with you just a tiny sampling of the experiences I have had wherein prayers were heard and answered and which, in retrospect, brought blessings into my life as well as the lives of others. My daily journal, kept over all these years, has helped provide some specifics which I most likely would not otherwise be able to recount.

In early 1965, I was assigned to attend stake conferences and to hold other meetings throughout the South Pacific area. This was my first visit to that part of the world, and it was a time never to be forgotten. Much that was spiritual in nature occurred during this assignment as I met with leaders, members, and missionaries.

On the weekend of Saturday and Sunday, February 20 and 21, we were in Brisbane, Australia, to hold regular conference sessions of the Brisbane Stake. During meetings on Saturday, I was introduced to the district president from an adjoining area. As I shook his hand, I had a strong impression that I needed to speak with him and to provide counsel, and so I asked him if he would accompany me to the Sunday morning session the following day so that this could be accomplished.

Following the Sunday session, we had an opportunity to visit together. We talked of his many responsibilities as district president. As we did so, I felt impressed to offer him specific suggestions concerning missionary work and how he and his members could help the full-time missionaries in their labors in his area. I later learned that this man had been praying for guidance in this regard. To him our visit was a special witness that his prayers were heard and answered. This was a seemingly unremarkable meeting but one which I am convinced was guided by the Spirit and which made a difference in that district president’s life and administration, in the lives of his members, and in the success of the missionaries there.

My brothers and sisters, the Lord’s purposes are often accomplished as we pay heed to the guidance of the Spirit. I believe that the more we act upon the inspiration and impressions which come to us, the more the Lord will entrust to us His errands.

I have learned, as I have mentioned in previous messages, never to postpone a prompting. On one occasion many years ago, I was swimming laps at the old Deseret Gym in Salt Lake City when I felt the inspiration to go to the University Hospital to visit a good friend of mine who had lost the use of his lower limbs because of a malignancy and the surgery which followed. I immediately left the pool, dressed, and was soon on my way to see this good man.

When I arrived at his room, I found that it was empty. Upon inquiry I learned I would probably find him in the swimming pool area of the hospital, an area which was used for physical therapy. Such turned out to be the case. He had guided himself there in his wheelchair and was the only occupant of the room. He was on the far side of the pool, near the deep end. I called to him, and he maneuvered his wheelchair over to greet me. We had an enjoyable visit, and I accompanied him back to his hospital room, where I gave him a blessing.

I learned later from my friend that he had been utterly despondent that day and had been contemplating taking his own life. He had prayed for relief but began to feel that his prayers had gone unanswered. He went to the pool with the thought that this would be a way to end his misery—by guiding his wheelchair into the deep end of the pool. I had arrived at a critical moment, in response to what I know was inspiration from on high.

My friend was able to live many more years—years filled with happiness and gratitude. How pleased I am to have been an instrument in the Lord’s hands on that critical day at the swimming pool.

On another occasion, as Sister Monson and I were driving home after visiting friends, I felt impressed that we should go into town—a drive of many miles—to pay a visit to an elderly widow who had once lived in our ward. Her name was Zella Thomas. At the time, she was a resident in a care center. That early afternoon we found her to be extremely frail but lying peacefully on her bed.

Zella had long been blind, but she recognized our voices immediately. She asked if I might give her a blessing, adding that she was prepared to die if the Lord wanted her to return home. There was a sweet, peaceful spirit in the room, and all of us knew that her remaining time in mortality would be brief. Zella took me by the hand and said that she had prayed fervently that I would come to see her and provide her a blessing. I told her that we had come because of direct inspiration from our Heavenly Father. I kissed her on the forehead, knowing that I perhaps would not again see her in mortality. Such proved to be the case, for she passed away the following day. To have been able to provide some comfort and peace to our sweet Zella was a blessing to her and to me.

The opportunity to be a blessing in the life of another often comes unexpectedly. On one extremely cold Saturday night during the winter of 1983–84, Sister Monson and I drove several miles to the mountain valley of Midway, Utah, where we have a home. The temperature that night was minus 24 degrees Fahrenheit (–31°C), and we wanted to make certain all was well at our home there. We checked and found that it was fine, so we left to return to Salt Lake City. We barely made it the few miles to the highway before our car stopped working. We were completely stranded. I have seldom, if ever, been as cold as we were that night.

Reluctantly we began walking toward the nearest town, the cars whizzing past us. Finally one car stopped, and a young man offered to help. We eventually found that the diesel fuel in our gas tank had thickened because of the cold, making it impossible for us to drive the car. This kind young man drove us back to our Midway home. I attempted to reimburse him for his services, but he graciously declined. He indicated that he was a Boy Scout and wanted to do a good turn. I identified myself to him, and he expressed his appreciation for the privilege to be of help. Assuming that he was about missionary age, I asked him if he had plans to serve a mission. He indicated he was not certain just what he wanted to do.

On the following Monday morning, I wrote a letter to this young man and thanked him for his kindness. In the letter I encouraged him to serve a full-time mission. I enclosed a copy of one of my books and underscored the chapters on missionary service.

About a week later the young man’s mother telephoned and advised that her son was an outstanding young man but that because of certain influences in his life, his long-held desire to serve a mission had diminished. She indicated she and his father had fasted and prayed that his heart would be changed. They had placed his name on the prayer roll of the Provo Utah Temple. They hoped that somehow, in some way, his heart would be touched for good and he would return to his desire to fill a mission and to serve the Lord faithfully. The mother wanted me to know that she looked upon the events of that cold evening as an answer to their prayers in his behalf. I said, “I agree with you.”

After several months and more communication with this young man, Sister Monson and I were overjoyed to attend his missionary farewell prior to his departure for the Canada Vancouver Mission.

Was it chance that our paths crossed on that cold December night? I do not for one moment believe so. Rather, I believe our meeting was an answer to a mother’s and father’s heartfelt prayers for the son they cherished.

Again, my brothers and sisters, our Heavenly Father is aware of our needs and will help us as we call upon Him for assistance. I believe that no concern of ours is too small or insignificant. The Lord is in the details of our lives.

I should like to conclude by relating one recent experience which had an impact on hundreds. It occurred at the cultural celebration for the Kansas City Temple, just five months ago. As with so much that happens in our lives, at the time it seemed to be just another experience where everything worked out. However, as I learned of the circumstances associated with the cultural celebration the evening before the temple was dedicated, I realized that the performance that night was not ordinary. Rather, it was quite remarkable.

As with all cultural events held in conjunction with temple dedications, the youth in the Kansas City Missouri Temple District had rehearsed the performance in separate groups in their own areas. The plan was that they would meet all together in the large rented municipal center on the Saturday morning of the performance so that they could learn when and where to enter, where they were to stand, how much space should be between them and the person next to them, how to exit the main floor, and so forth—many details which they would have to grasp during the day as those in charge put the various scenes together so that the final performance would be polished and professional.

There was just one major problem that day. The entire production was dependent on prerecorded segments that would be shown on the large screen known as a Jumbotron. These recorded segments were critical to the entire production. They not only tied it all together, but each televised segment would introduce the next performance. The video segments provided the framework on which the entire production depended. And the Jumbotron was not working.

Technicians worked frantically to solve the problem while the youth waited, hundreds of them, losing precious rehearsal time. The situation began to look impossible.

The writer and director of the celebration, Susan Cooper, later explained: “As we moved from plan A to B to Z, we knew that it wasn’t working. … As we were looking at the schedule, we knew that it was going to be beyond us, but we knew that we had one of the greatest strengths on the floor below—3,000 youth. We needed to go down and tell [them] what was happening and draw upon their faith.”3

Just an hour before the audience would begin to enter the center, 3,000 youth knelt on the floor and prayed together. They prayed that those working on the Jumbotron would be inspired to know what to do to repair it; they asked their Heavenly Father to make up for what they themselves could not do because of the shortage of time.

Said one who wrote about it afterward, “It was a prayer the youth will never forget, not because the floor was hard, but because the Spirit melted their bones.”4

It was not long before one of the technicians came to tell them that the problem had been discovered and corrected. He attributed the solution to luck, but all those youth knew better.

When we entered the municipal center that evening, we had no idea of the difficulties of the day. Only later did we learn of them. What we witnessed, however, was a beautiful, polished performance—one of the best I have seen. The youth radiated a glorious, powerful spirit which was felt by all who were present. They seemed to know just where to enter, where to stand, and how to interact with all the other performers around them. When I learned that their rehearsals had been cut short and that many of the numbers had not been rehearsed by the entire group, I was astonished. No one would have known. The Lord had indeed made up the difference.

I never cease to be amazed by how the Lord can motivate and direct the length and breadth of His kingdom and yet have time to provide inspiration concerning one individual—or one cultural celebration or one Jumbotron. The fact that He can, that He does, is a testimony to me.

My brothers and sisters, the Lord is in all of our lives. He loves us. He wants to bless us. He wants us to seek His help. As He guides us and directs us and as He hears and answers our prayers, we will find the happiness here and now that He desires for us. May we be aware of His blessings in our lives, I pray in the name of Jesus Christ, our Savior, amen.

# References
1. - 2 Nephi 2:25.
2. - Doctrine and Covenants 112:10.
3. - Susan Cooper, in Maurine Proctor, “Nothing’s Too Hard for the Lord: The Kansas City Cultural Celebration,” Meridian Magazine, May 9, 2012, ldsmag.com.
4. - Proctor, Meridian Magazine, May 9, 2012.