Elder Jeffrey R. Holland
Of the Quorum of the Twelve Apostles
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/the-first-great-commandment?lang=eng)

_We have a life of devoted discipleship to give in demonstrating our love of the Lord._

There is almost no group in history for whom I have more sympathy than I have for the eleven remaining Apostles immediately following the death of the Savior of the world. I think we sometimes forget just how inexperienced they still were and how totally dependent upon Jesus they had of necessity been. To them He had said, “Have I been so long time with you, and yet hast thou not known me … ?”1

But, of course, to them He hadn’t been with them nearly long enough. Three years isn’t long to call an entire Quorum of Twelve Apostles from a handful of new converts, purge from them the error of old ways, teach them the wonders of the gospel of Jesus Christ, and then leave them to carry on the work until they too were killed. Quite a staggering prospect for a group of newly ordained elders.

Especially the part about being left alone. Repeatedly Jesus had tried to tell them He was not going to remain physically present with them, but they either could not or would not comprehend such a wrenching thought. Mark writes:

“He taught his disciples, and said unto them, The Son of man is delivered into the hands of men, and they shall kill him; and after that he is killed, he shall rise the third day.

“But they understood not that saying, and were afraid to ask him.”2

Then, after such a short time to learn and even less time to prepare, the unthinkable happened, the unbelievable was true. Their Lord and Master, their Counselor and King, was crucified. His mortal ministry was over, and the struggling little Church He had established seemed doomed to scorn and destined for extinction. His Apostles did witness Him in His resurrected state, but that only added to their bewilderment. As they surely must have wondered, “What do we do now?” they turned for an answer to Peter, the senior Apostle.

Here I ask your indulgence as I take some nonscriptural liberty in my portrayal of this exchange. In effect, Peter said to his associates: “Brethren, it has been a glorious three years. None of us could have imagined such a few short months ago the miracles we have seen and the divinity we have enjoyed. We have talked with, prayed with, and labored with the very Son of God Himself. We have walked with Him and wept with Him, and on the night of that horrible ending, no one wept more bitterly than I. But that is over. He has finished His work, and He has risen from the tomb. He has worked out His salvation and ours. So you ask, ‘What do we do now?’ I don’t know more to tell you than to return to your former life, rejoicing. I intend to ‘go a fishing.’” And at least six of the ten other remaining Apostles said in agreement, “We also go with thee.” John, who was one of them, writes, “They went forth, and entered into a ship immediately.”3

But, alas, the fishing wasn’t very good. Their first night back on the lake, they caught nothing—not a single fish. With the first rays of dawn, they disappointedly turned toward the shore, where they saw in the distance a figure who called out to them, “Children, have you caught anything?” Glumly these Apostles-turned-again-fishermen gave the answer no fisherman wants to give. “We have caught nothing,” they muttered, and to add insult to injury, they were being called “children.”4

“Cast the net on the right side of the ship, and ye shall find,”5 the stranger calls out—and with those simple words, recognition begins to flood over them. Just three years earlier these very men had been fishing on this very sea. On that occasion too they had “toiled all the night, and [had] taken nothing,”6 the scripture says. But a fellow Galilean on the shore had called out to them to let down their nets, and they drew “a great multitude of fishes,”7 enough that their nets broke, the catch filling two boats so heavily they had begun to sink.

Now it was happening again. These “children,” as they were rightly called, eagerly lowered their net, and “they were not able to draw it for the multitude of fishes.”8 John said the obvious: “It is the Lord.”9 And over the edge of the boat, the irrepressible Peter leaped.

After a joyful reunion with the resurrected Jesus, Peter had an exchange with the Savior that I consider the crucial turning point of the apostolic ministry generally and certainly for Peter personally, moving this great rock of a man to a majestic life of devoted service and leadership. Looking at their battered little boats, their frayed nets, and a stunning pile of 153 fish, Jesus said to His senior Apostle, “Peter, do you love me more than you love all this?” Peter said, “Yea, Lord; thou knowest that I love thee.”10

The Savior responds to that reply but continues to look into the eyes of His disciple and says again, “Peter, do you love me?” Undoubtedly confused a bit by the repetition of the question, the great fisherman answers a second time, “Yea, Lord; thou knowest that I love thee.”11

The Savior again gives a brief response, but with relentless scrutiny He asks for the third time, “Peter, do you love me?” By now surely Peter is feeling truly uncomfortable. Perhaps there is in his heart the memory of only a few days earlier when he had been asked another question three times and he had answered equally emphatically—but in the negative. Or perhaps he began to wonder if he misunderstood the Master Teacher’s question. Or perhaps he was searching his heart, seeking honest confirmation of the answer he had given so readily, almost automatically. Whatever his feelings, Peter said for the third time, “Lord, … thou knowest that I love thee.”12

To which Jesus responded (and here again I acknowledge my nonscriptural elaboration), perhaps saying something like: “Then Peter, why are you here? Why are we back on this same shore, by these same nets, having this same conversation? Wasn’t it obvious then and isn’t it obvious now that if I want fish, I can get fish? What I need, Peter, are disciples—and I need them forever. I need someone to feed my sheep and save my lambs. I need someone to preach my gospel and defend my faith. I need someone who loves me, truly, truly loves me, and loves what our Father in Heaven has commissioned me to do. Ours is not a feeble message. It is not a fleeting task. It is not hapless; it is not hopeless; it is not to be consigned to the ash heap of history. It is the work of Almighty God, and it is to change the world. So, Peter, for the second and presumably the last time, I am asking you to leave all this and to go teach and testify, labor and serve loyally until the day in which they will do to you exactly what they did to me.”

Then, turning to all the Apostles, He might well have said something like: “Were you as foolhardy as the scribes and Pharisees? As Herod and Pilate? Did you, like they, think that this work could be killed simply by killing me? Did you, like they, think the cross and the nails and the tomb were the end of it all and each could blissfully go back to being whatever you were before? Children, did not my life and my love touch your hearts more deeply than this?”

My beloved brothers and sisters, I am not certain just what our experience will be on Judgment Day, but I will be very surprised if at some point in that conversation, God does not ask us exactly what Christ asked Peter: “Did you love me?” I think He will want to know if in our very mortal, very inadequate, and sometimes childish grasp of things, did we at least understand one commandment, the first and greatest commandment of them all—“Thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy strength, and with all thy mind.”13 And if at such a moment we can stammer out, “Yea, Lord, thou knowest that I love thee,” then He may remind us that the crowning characteristic of love is always loyalty.

“If ye love me, keep my commandments,”14 Jesus said. So we have neighbors to bless, children to protect, the poor to lift up, and the truth to defend. We have wrongs to make right, truths to share, and good to do. In short, we have a life of devoted discipleship to give in demonstrating our love of the Lord. We can’t quit and we can’t go back. After an encounter with the living Son of the living God, nothing is ever again to be as it was before. The Crucifixion, Atonement, and Resurrection of Jesus Christ mark the beginning of a Christian life, not the end of it. It was this truth, this reality, that allowed a handful of Galilean fishermen-turned-again-Apostles without “a single synagogue or sword”15 to leave those nets a second time and go on to shape the history of the world in which we now live.

I testify from the bottom of my heart, with the intensity of my soul, to all who can hear my voice that those apostolic keys have been restored to the earth, and they are found in The Church of Jesus Christ of Latter-day Saints. To those who have not yet joined with us in this great final cause of Christ, we say, “Please come.” To those who were once with us but have retreated, preferring to pick and choose a few cultural hors d’oeuvres from the smorgasbord of the Restoration and leave the rest of the feast, I say that I fear you face a lot of long nights and empty nets. The call is to come back, to stay true, to love God, and to lend a hand. I include in that call to fixed faithfulness every returned missionary who ever stood in a baptismal font and with arm to the square said, “Having been commissioned of Jesus Christ.”16 That commission was to have changed your convert forever, but it was surely supposed to have changed you forever as well. To the youth of the Church rising up to missions and temples and marriage, we say: “Love God and remain clean from the blood and sins of this generation. You have a monumental work to do, underscored by that marvelous announcement President Thomas S. Monson made yesterday morning. Your Father in Heaven expects your loyalty and your love at every stage of your life.”

To all within the sound of my voice, the voice of Christ comes ringing down through the halls of time, asking each one of us while there is time, “Do you love me?” And for every one of us, I answer with my honor and my soul, “Yea, Lord, we do love thee.” And having set our “hand to the plough,”17 we will never look back until this work is finished and love of God and neighbor rules the world. In the name of Jesus Christ, amen.

# References
1. - John 14:9.
2. - Mark 9:31–32.
3. - John 21:3.
4. - See John 21:5.
5. - John 21:6.
6. - Luke 5:5.
7. - Luke 5:6.
8. - John 21:6.
9. - John 21:7.
10. - John 21:15.
11. - John 21:16.
12. - John 21:17.
13. - Luke 10:27; see also Matthew 22:37–38.
14. - John 14:15.
15. - Frederic W. Farrar, The Life of Christ (1994), 656; see chapter 62 for more on the plight of this newly founded Church.
16. - Doctrine and Covenants 20:73.
17. - Luke 9:62.