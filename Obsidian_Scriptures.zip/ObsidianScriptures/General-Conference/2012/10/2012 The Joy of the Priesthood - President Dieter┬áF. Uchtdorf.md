President Dieter F. Uchtdorf
Second Counselor in the First Presidency
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/the-joy-of-the-priesthood?lang=eng)

_Let us embrace and understand the wonder and privilege of the priesthood. Let us accept and love the responsibilities we are asked to fulfill._

The Joy of Flying



Many years ago a couple of fellow airline captains and I decided to fulfill a boyhood dream of restoring an antique airplane. Together we purchased a worn-down 1938 Piper Cub and started the work of returning it to its original form. The project was a labor of love. It had special meaning for me because I had learned to fly in a similar airplane when I was a young man.

This airplane was first built only 35 years after the Wright brothers made their famous first flight. Just thinking of that makes me feel very old.

The engine did not have an electric starter; as you were priming the engine from the cockpit, someone else on the ground would grab hold of the propeller and hurl it with might until the engine would run on its own. Each engine start was a moment of excitement and bravery.

Once the plane was airborne, it became clear the Piper Cub was not built for speed. As a matter of fact, when there was a strong headwind, it seemed as though we were not moving at all. I remember flying together with my teenage son, Guido, above the autobahn in Germany, and sure enough, the cars below passed us comfortably!

But, oh, how I loved this little plane! It was the perfect way to experience the wonder and beauty of flight. You could hear, feel, smell, taste, and see what flying was all about. The Wright brothers expressed it this way: “There is [nothing] equal to that which aviators enjoy while being carried through the air on great white wings.”1

In contrast, earlier this year I had the privilege to fly in a sophisticated F-18 fighter jet with the world-famous Blue Angels, the United States Navy’s flight demonstration team. It was like taking a flight above and along memory lane because exactly 50 years before, almost to the day, I had completed my training as an air force fighter pilot.

The F-18 flight experience, of course, was totally different from the one in the Piper Cub. It showed me a more dynamic beauty of flying. It was like applying the existing laws of aerodynamics in a more perfect way. However, flying with the Blue Angels also quickly reminded me that being a jet fighter pilot is a young man’s game. To quote the Wright brothers again, “More than anything else the sensation [of flying] is one of perfect peace, mingled with an excitement that strains every nerve to the utmost.”2 In addition, flying with the Blue Angels suggested a totally different way of having “angels” round about you and bearing you up.

If you were to ask me which of these two flying experiences I enjoyed more, I’m not sure I could tell you. In some obvious ways, they were very different, to say the least. And yet in other ways, they were very much the same.

In both the Piper Cub and the F-18, I felt the excitement, beauty, and joy of flight. In both I could feel the call of the poet to “[slip] the surly bonds of Earth and [dance] the skies on laughter-silvered wings.”3







The Same Priesthood Everywhere



Now, you might ask, what do these two totally different flying experiences have to do with our meeting today or with the priesthood we are privileged to bear or with the priesthood service we all love so much?

Brethren, isn’t it true that our individual experiences of service in the priesthood may all be quite different? We could say some of you are flying in F-18 jets, while others are flying in Piper Cubs. Some of you live in wards and stakes where every position, from assistant to the high priests group leader to the deacons quorum secretary, is filled with an active priesthood holder. Yours is the privilege to participate in a ward organization that is well staffed.

Others of you live in areas of the world where there is only a small handful of Church members and priesthood holders. You may feel alone and burdened with the weight of all that needs to be done. For you it may take a lot of personal hands-on involvement to get the engine of priesthood service started. Sometimes it may even seem that your branch or ward is not moving forward at all.

However, no matter what your responsibilities or circumstances may be, you and I know there is always a special joy that comes from dedicated priesthood service.

I always loved flying, whether it was in a Piper Cub, an F-18, or any other plane. While in the Piper Cub, I did not complain about the lack of speed; while in the F-18, I did not grumble when the strain of the aerobatic maneuvers mercilessly revealed the realities of my advancing age.

Yes, there is always something imperfect in any situation. Yes, it is easy to find things to complain about.

But brethren, we are bearers of the Holy Priesthood, after the Order of the Son of God! Each of us had hands laid upon our head, and we received the priesthood of God. We have been given authority and responsibility to act in His name as His servants on earth. Whether in a large ward or a small branch, we are called upon to serve, to bless, and to act in all things for the good of everyone and everything entrusted to our care. Could there be anything more exhilarating?

Let us understand, appreciate, and feel the joy of service in the priesthood.







The Joy of the Priesthood



My love for flying influenced the direction of my entire life. But as invigorating and blissful as my experiences as a pilot were, my experiences as a member of this Church have been much deeper, more joyful, and far more profound. As I have immersed myself in Church service, I have felt God’s almighty power as well as His tender mercies.

As a pilot, I have touched the skies. As a Church member, I have felt heaven’s embrace.

Every now and then, I miss sitting in a cockpit. But serving alongside my brothers and sisters in the Church easily makes up for it. Being able to feel the sublime peace and joy that grow from being a small part of this great cause and work, I would not want to miss for anything in the world.

Today we are assembled as a vast body of the priesthood. It is our sacred joy and privilege to serve the Lord and our fellowmen, to commit the best that is within us to the noble cause of lifting others and building the kingdom of God.

We know and understand that the priesthood is the eternal power and authority of God. We can easily recite this definition from memory. However, do we truly comprehend the significance of what we’re saying? Let me repeat: the priesthood is the eternal power and authority of God.

Think of it. Through the priesthood, God created and governs the heavens and the earth.

Through this power, He redeems and exalts His children, bringing “to pass the immortality and eternal life of man.”4

The priesthood, as the Prophet Joseph Smith explained, is “the channel through which the Almighty commenced revealing His glory at the … creation of this earth, and through which He has continued to reveal Himself to the children of men to the present time, and through which He will make known His purposes to the end of time.”5

Our all-powerful Father in Heaven has entrusted priesthood authority to us—mortal beings who, by definition, are flawed and imperfect. He grants to us the authority to act in His name for the salvation of His children. By this great power we are authorized to preach the gospel, administer the ordinances of salvation, help build the kingdom of God on the earth, and bless and serve our families and our fellowmen.







Available to All



This is the sacred priesthood we bear.

The priesthood, or any responsibility within it, cannot be purchased or commanded. The use of priesthood power cannot be influenced, swayed, or compelled by position, by wealth, or by influence. It is a spiritual power that operates on heavenly law. It originates in the great Heavenly Father of us all. Its power can be controlled and directed only through principles of righteousness,6 not self-righteousness.

Christ is the source of all true priesthood authority and power on earth.7 It is His work, in which we are privileged to assist. “And no one can assist in this work except he shall be humble and full of love, having faith, hope, and charity, being temperate in all things, whatsoever shall be entrusted to his care.”8

We do not act for personal gain, but rather we seek to serve and to lift up others. We lead not by force but through “persuasion, … long-suffering, … gentleness and meekness, and by love unfeigned.”9

The priesthood of Almighty God is available to worthy men wherever they may be—no matter their ancestry, no matter how humble their circumstances, in the nearest or farthest reaches of the globe. It is available without money or any worldly price. To paraphrase the ancient prophet Isaiah, everyone who is thirsty can come to the waters, and no money is required to come and eat!10

And because of the eternal and unfathomable Atonement of our Savior, Jesus Christ, the priesthood of God can be available even if you have stumbled or have been unworthy in the past. Through the spiritually refining and cleansing process of repentance, you can “arise and shine forth”!11 Because of the boundless, forgiving love of our Savior and Redeemer, you can lift up your eyes, become clean and worthy, and develop into righteous and noble sons of God—worthy bearers of the most sacred priesthood of Almighty God.







The Wonder and Privilege of the Priesthood



I feel a certain sadness for those who do not grasp and appreciate the wonder and privilege of the priesthood. They are like passengers on an airplane who spend their time grumbling about the size of the packet of peanuts while they are soaring through the air, far above the clouds—something ancient kings would have given all they possessed to try and experience just once!

Brethren, we are blessed to be humble partakers of this great priesthood authority and power. Let us lift up our eyes and see, recognize, and accept this opportunity for what it really is.

Through righteous, loving, and dedicated priesthood service, we will be able to experience the true meaning of the revelation: “I will go before your face. I will be on your right hand and on your left, and my Spirit shall be in your hearts, and mine angels round about you, to bear you up.”12

Let us embrace and understand the wonder and privilege of the priesthood. Let us accept and love the responsibilities we are asked to fulfill—responsibilities in our homes and in our Church units, no matter how large or small they may be. Let us constantly increase in righteousness, dedication, and priesthood service. Let us find the joy of serving in the priesthood!

We can do this best by applying the principles of knowledge, obedience, and faith.

That means, first, we need to know and internalize the doctrine of the priesthood found in the revealed word of God. It is important for us to understand the covenants and commandments upon which the priesthood operates.13

Next, let us be wise and act upon this gained knowledge constantly and honorably. As we obey God’s laws, discipline our minds and bodies, and attune our actions to the patterns of righteousness taught by the prophets, we will experience the joy of priesthood service.

And finally, let us deepen our faith in our Lord, Jesus Christ. Let us take upon ourselves His name and commit each single day to walk anew in the path of discipleship. Let our works make our faith perfect.14 Through discipleship we may be perfected one step at a time by serving our family, our fellowmen, and God.

When we serve in the priesthood with all our heart, might, mind, and strength, we have a promise of sublime knowledge, peace, and spiritual gifts. As we honor the holy priesthood, God will honor us, and we will “stand blameless before [Him] at the last day.”15

That we may always have eyes to see and a heart to feel the wonder and joy of the priesthood of our great and mighty God is my prayer in the name of Jesus Christ, amen.

# References
1. - Wilbur Wright, in James Tobin, To Conquer the Air: The Wright Brothers and the Great Race for Flight (2003), 238.
2. - Wright brothers, in Tobin, To Conquer the Air, 397.
3. - John Gillespie Magee Jr., “High Flight,” in Diane Ravitch, ed., The American Reader: Words That Moved a Nation (1990), 486.
4. - Moses 1:39.
5. - Teachings of Presidents of the Church: Joseph Smith (2007), 108–9.
6. - See Doctrine and Covenants 121:36.
7. - See Hebrews 5:4–10; Doctrine and Covenants 107:3.
8. - Doctrine and Covenants 12:8.
9. - Doctrine and Covenants 121:41.
10. - See Isaiah 55:1.
11. - Doctrine and Covenants 115:5.
12. - Doctrine and Covenants 84:88.
13. - See Doctrine and Covenants 84:33–44; 121:34–46.
14. - See James 2:22.
15. - Doctrine and Covenants 4:2.