Elder Dallin H. Oaks
Of the Quorum of the Twelve Apostles
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/protect-the-children?lang=eng)

_None should resist the plea that we unite to increase our concern for the welfare and future of our children—the rising generation._

We can all remember our feelings when a little child cried out and reached up to us for help. A loving Heavenly Father gives us those feelings to impel us to help His children. Please recall those feelings as I speak about our responsibility to protect and act for the well-being of children.

I speak from the perspective of the gospel of Jesus Christ, including His plan of salvation. That is my calling. Local Church leaders have responsibility for a single jurisdiction, like a ward or stake, but an Apostle is responsible to witness to the entire world. In every nation, of every race and creed, all children are children of God.

Although I do not speak in terms of politics or public policy, like other Church leaders, I cannot speak for the welfare of children without implications for the choices being made by citizens, public officials, and workers in private organizations. We are all under the Savior’s command to love and care for each other and especially for the weak and defenseless.

Children are highly vulnerable. They have little or no power to protect or provide for themselves and little influence on so much that is vital to their well-being. Children need others to speak for them, and they need decision makers who put their well-being ahead of selfish adult interests.





I.



Worldwide, we are shocked at the millions of children victimized by evil adult crimes and selfishness.

In some war-torn countries, children are abducted to serve as soldiers in contending armies.

A United Nations report estimates that over two million children are victimized each year through prostitution and pornography.1

From the perspective of the plan of salvation, one of the most serious abuses of children is to deny them birth. This is a worldwide trend. The national birthrate in the United States is the lowest in 25 years,2 and the birthrates in most European and Asian countries have been below replacement levels for many years. This is not just a religious issue. As rising generations diminish in numbers, cultures and even nations are hollowed out and eventually disappear.

One cause of the diminishing birthrate is the practice of abortion. Worldwide, there are estimated to be more than 40 million abortions per year.3 Many laws permit or even promote abortion, but to us this is a great evil. Other abuses of children that occur during pregnancy are the fetal impairments that result from the mother’s inadequate nutrition or drug use.

There is a tragic irony in the multitude of children eliminated or injured before birth while throngs of infertile couples long for and seek babies to adopt.

Childhood abuses or neglect of children that occur after birth are more publicly visible. Worldwide, almost eight million children die before their fifth birthday, mostly from diseases both treatable and preventable.4 And the World Health Organization reports that one in four children have stunted growth, mentally and physically, because of inadequate nutrition.5 Living and traveling internationally, we Church leaders see much of this. The general presidency of the Primary report children living in conditions “beyond our imaginations.” A mother in the Philippines said: “Sometimes we do not have enough money for food, but that is all right because it gives me the opportunity to teach my children about faith. We gather and pray for relief, and the children see the Lord bless us.”6 In South Africa, a Primary worker met a little girl, lonely and sad. In faint responses to loving questions, she said she had no mother, no father, and no grandmother—only a grandfather to care for her.7 Such tragedies are common on a continent where many caregivers have died of AIDS.

Even in rich nations little children and youth are impaired by neglect. Children growing up in poverty have inferior health care and inadequate educational opportunities. They are also exposed to dangerous environments in their physical and cultural surroundings and even from the neglect of their parents. Elder Jeffrey R. Holland recently shared the experience of an LDS police officer. In an investigation he found five young children huddled together and trying to sleep without bedding on a filthy floor in a dwelling where their mother and others were drinking and partying. The apartment had no food to relieve their hunger. After tucking the children into a makeshift bed, the officer knelt and prayed for their protection. As he walked toward the door, one of them, about six, pursued him, grabbed him by the hand, and pleaded, “Will you please adopt me?”8

We remember our Savior’s teaching as He placed a little child before His followers and declared:

“And whoso shall receive one such little child in my name receiveth me.

“But whoso shall offend one of these little ones which believe in me, it were better for him that a millstone were hanged about his neck, and that he were drowned in the depth of the sea” (Matthew 18:5–6).

When we consider the dangers from which children should be protected, we should also include psychological abuse. Parents or other caregivers or teachers or peers who demean, bully, or humiliate children or youth can inflict harm more permanent than physical injury. Making a child or youth feel worthless, unloved, or unwanted can inflict serious and long-lasting injury on his or her emotional well-being and development.9 Young people struggling with any exceptional condition, including same-gender attraction, are particularly vulnerable and need loving understanding—not bullying or ostracism.10

With the help of the Lord, we can repent and change and be more loving and helpful to children—our own and those around us.







II.



There are few examples of physical or emotional threats to children as important as those arising out of their relationships with their parents or guardians. President Thomas S. Monson has spoken of what he called the “vile deeds” of child abuse, where a parent has broken or disfigured a child, physically or emotionally.11 I grieved as I had to study the shocking evidence of such cases during my service on the Utah Supreme Court.

Of utmost importance to the well-being of children is whether their parents were married, the nature and duration of the marriage, and, more broadly, the culture and expectations of marriage and child care where they live. Two scholars of the family explain: “Throughout history, marriage has first and foremost been an institution for procreation and raising children. It has provided the cultural tie that seeks to connect the father to his children by binding him to the mother of his children. Yet in recent times, children have increasingly been pushed from center stage.”12

A Harvard law professor describes the current law and attitude toward marriage and divorce: “The [current] American story about marriage, as told in the law and in much popular literature, goes something like this: marriage is a relationship that exists primarily for the fulfillment of the individual spouses. If it ceases to perform this function, no one is to blame and either spouse may terminate it at will. … Children hardly appear in the story; at most they are rather shadowy characters in the background.”13

Our Church leaders have taught that looking “upon marriage as a mere contract that may be entered into at pleasure … and severed at the first difficulty … is an evil meriting severe condemnation,” especially where “children are made to suffer.”14 And children are impacted by divorces. Over half of the divorces in a recent year involved couples with minor children.15

Many children would have had the blessing of being raised by both of their parents if only their parents had followed this inspired teaching in the family proclamation: “Husband and wife have a solemn responsibility to love and care for each other and for their children. … Parents have a sacred duty to rear their children in love and righteousness, to provide for their physical and spiritual needs, and to teach them to love and serve one another.”16 The most powerful teaching of children is by the example of their parents. Divorcing parents inevitably teach a negative lesson.

There are surely cases when a divorce is necessary for the good of the children, but those circumstances are exceptional.17 In most marital contests the contending parents should give much greater weight to the interests of the children. With the help of the Lord, they can do so. Children need the emotional and personal strength that come from being raised by two parents who are united in their marriage and their goals. As one who was raised by a widowed mother, I know firsthand that this cannot always be achieved, but it is the ideal to be sought whenever possible.

Children are the first victims of current laws permitting so-called “no-fault divorce.” From the standpoint of children, divorce is too easy. Summarizing decades of social science research, a careful scholar concluded that “the family structure that produces the best outcomes for children, on average, are two biological parents who remain married.”18 A New York Times writer noted “the striking fact that even as traditional marriage has declined in the United States … the evidence has mounted for the institution’s importance to the well-being of children.”19 That reality should give important guidance to parents and parents-to-be in their decisions involving marriage and divorce. We also need politicians, policy makers, and officials to increase their attention to what is best for children in contrast to the selfish interests of voters and vocal advocates of adult interests.

Children are also victimized by marriages that do not occur. Few measures of the welfare of our rising generation are more disturbing than the recent report that 41 percent of all births in the United States were to women who were not married.20 Unmarried mothers have massive challenges, and the evidence is clear that their children are at a significant disadvantage when compared with children raised by married parents.21

Most of the children born to unmarried mothers—58 percent—were born to couples who were cohabitating.22 Whatever we may say about these couples’ forgoing marriage, studies show that their children suffer significant comparative disadvantages.23 For children, the relative stability of marriage matters.

We should assume the same disadvantages for children raised by couples of the same gender. The social science literature is controversial and politically charged on the long-term effect of this on children, principally because, as a New York Times writer observed, “same-sex marriage is a social experiment, and like most experiments it will take time to understand its consequences.”24







III.



I have spoken for children—children everywhere. Some may reject some of these examples, but none should resist the plea that we unite to increase our concern for the welfare and future of our children—the rising generation.

We are speaking of the children of God, and with His powerful help, we can do more to help them. In this plea I address not only Latter-day Saints but also all persons of religious faith and others who have a value system that causes them to subordinate their own needs to those of others, especially to the welfare of children.25

Religious persons are also conscious of the Savior’s New Testament teaching that pure little children are our role models of humility and teachableness:

“Verily I say unto you, Except ye be converted, and become as little children, ye shall not enter into the kingdom of heaven.

“Whosoever therefore shall humble himself as this little child, the same is greatest in the kingdom of heaven” (Matthew 18:3–4).

In the Book of Mormon we read of the risen Lord teaching the Nephites that they must repent and be baptized “and become as a little child” or they could not inherit the kingdom of God (3 Nephi 11:38; see also Moroni 8:10).

I pray that we will humble ourselves as little children and reach out to protect our little children, for they are the future for us, for our Church, and for our nations. In the name of Jesus Christ, amen.

# References
1. - See UNICEF, The State of the World’s Children 2005: Childhood under Threat (2004), 26.
2. - See Haya El Nasser, “National Birthrate Lowest in 25 Years,” USA Today, July 26, 2012, A1.
3. - See Gilda Sedgh and others, “Induced Abortion: Incidence and Trends Worldwide from 1995 to 2008,” The Lancet, vol. 379, no. 9816 (Feb. 18, 2012), 625–32.
4. - See UNICEF, “Young Child Survival and Development,” http://www.unicef.org/childsurvival/index.html.
5. - See World Health Organization, World Health Statistics 2012 (2012), 109, 118.
6. - Report of Primary general presidency, Sept. 13, 2012.
7. - Report of Primary general presidency.
8. - See Jeffrey R. Holland, “Israel, Israel, God Is Calling” (Church Educational System devotional for young adults, Sept. 9, 2012), lds.org/broadcasts; see also R. Scott Lloyd, “Zion Not Only Where, but How We Live, Says Elder Holland,” Deseret News, Sept. 10, 2012, B2.
9. - See Kim Painter, “Parents Can Inflict Deep Emotional Harm,” USA Today, July 30, 2012, B8; Rachel Lowry, “Mental Abuse as Injurious as Other Forms of Child Abuse, Study Shows,” Deseret News, Aug. 5, 2012, A3.
10. - See “End the Abuses,” Deseret News, June 12, 2012, A10.
11. - Thomas S. Monson, “A Little Child Shall Lead Them,” Liahona, June 2002, 2; Ensign, May 1990, 53.
12. - W. Bradford Wilcox and Elizabeth Marquardt, eds., The State of Our Unions: Marriage in America (2011), 82.
13. - Mary Ann Glendon, Abortion and Divorce in Western Law: American Failures, European Challenges (1987), 108.
14. - David O. McKay, “Structure of the Home Threatened by Irresponsibility and Divorce,” Improvement Era, June 1969, 5.
15. - See Diana B. Elliott and Tavia Simmons, “Marital Events of Americans: 2009,” American Community Survey Reports, Aug. 2011.
16. - “The Family: A Proclamation to the World,” Liahona and Ensign, Nov. 2010, 129.
17. - See Dallin H. Oaks, “Divorce,” Liahona and Ensign, May 2007, 71.
18. - Charles Murray, Coming Apart: The State of White America, 1960–2010 (2012), 158.
19. - Ross Douthat, “Gay Parents and the Marriage Debate,” New York Times, June 11, 2012, http://douthat.blogs.nytimes.com/2012/06/11/gay-parents-and-the-marriage-debate.
20. - See Joyce A. Martin and others, “Births: Final Data for 2010,” National Vital Statistics Reports, vol. 61, no. 1 (Aug. 2012), 10.
21. - See William J. Doherty and others, Why Marriage Matters: Twenty-One Conclusions from the Social Sciences (2002); W. Bradford Wilcox and others, Why Marriage Matters: Thirty Conclusions from the Social Sciences, 3rd ed. (2011).
22. - See Martin, “Births: Final Data for 2010,” 10–11.
23. - See Wilcox, Why Marriage Matters.
24. - Douthat, “Gay Parents and the Marriage Debate.” The latest and most thorough study finds significant disadvantages reported by young adults with a parent who had same-sex relationships prior to the child’s turning age 18 (see Mark Regnerus, “How Different Are the Adult Children of Parents Who Have Same-Sex Relationships? Findings from the New Family Structures Study,” Social Science Research, vol. 41 [2012], 752–70).
25. - Latter-day Saints are especially committed to parenthood as one of the most important goals in life (see Pew Research Center’s Forum on Religion and Public Life, Mormons in America: Certain in Their Beliefs, Uncertain of Their Place in Society, Jan. 12, 2012, 10, 16, 51).