Elder Quentin L. Cook
Of the Quorum of the Twelve Apostles
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/can-ye-feel-so-now?lang=eng)

_Some in the Church believe they can’t answer Alma’s question with a resounding yes. They do not “feel so now.”_

President Monson, we love, honor, and sustain you! This historically significant announcement with respect to missionary service is inspiring. I can remember the excitement in 1960 when the age for young men serving was reduced from 20 years of age to 19. I arrived in the British Mission as a newly called 20-year-old. The first 19-year-old in our mission was Elder Jeffrey R. Holland, an incredible addition. He was a few months shy of being 20. Then over the course of a year, many more 19-year-olds arrived. They were obedient and faithful missionaries, and the work progressed. I am confident that an even greater harvest will be achieved now as righteous, committed missionaries fulfill the Savior’s commandment to preach His gospel.

In my view, those of you in the rising generation are better prepared than any previous generation. Your knowledge of the scriptures is particularly impressive. However, the challenges your generation faces as you prepare for service are similar to those faced by all members of the Church. We are all aware the culture in most of the world is not conducive to righteousness or spiritual commitment. Throughout history, Church leaders have warned the people and taught repentance. In the Book of Mormon, Alma the Younger was so concerned about unrighteousness and lack of commitment that he resigned as chief judge, the leader of the people of Nephi, and concentrated all his efforts on his prophetic calling.1

In one of the most profound verses in all of scripture, Alma proclaims, “If ye have experienced a change of heart, and if ye have felt to sing the song of redeeming love, I would ask, can ye feel so now?”2

Local leaders across the world report that when viewed as a whole, Church members, especially our youth, have never been stronger. But they almost always raise two concerns: first, the challenge of increased unrighteousness in the world and, second, the apathy and lack of commitment of some members. They seek counsel about how to help members to follow the Savior and achieve a deep and lasting conversion.

This question, “Can ye feel so now?” rings across the centuries. With all that we have received in this dispensation—including the Restoration of the fulness of the gospel of Jesus Christ, the outpouring of spiritual gifts, and the indisputable blessings of heaven—Alma’s challenge has never been more important.

Soon after Ezra Taft Benson was called as an Apostle in 1943, President George Albert Smith3 counseled, “Your mission … is to … warn the people … in as kind a way as possible that repentance will be the only panacea for the ills of this world.”4 When this statement was made, we were in the midst of the conflagration of World War II.

Today moral deterioration has escalated. One prominent writer recently said, “Everyone knows the culture is poisonous, and nobody expects that to change.”5 The constant portrayal of violence and immorality in music, entertainment, art, and other media in our day-to-day culture is unprecedented. This was dramatically described by a highly respected Baptist theologian when he stated, “The spiritual immune system of an entire civilization has been wounded.”6

It is not surprising that some in the Church believe they can’t answer Alma’s question with a resounding yes. They do not “feel so now.” They feel they are in a spiritual drought. Others are angry, hurt, or disillusioned. If these descriptions apply to you,7 it is important to evaluate why you cannot “feel so now.”

Many who are in a spiritual drought and lack commitment have not necessarily been involved in major sins or transgressions, but they have made unwise choices. Some are casual in their observance of sacred covenants. Others spend most of their time giving first-class devotion to lesser causes. Some allow intense cultural or political views to weaken their allegiance to the gospel of Jesus Christ. Some have immersed themselves in Internet materials that magnify, exaggerate, and, in some cases, invent shortcomings of early Church leaders. Then they draw incorrect conclusions that can affect testimony. Any who have made these choices can repent and be spiritually renewed.

Immersion in the scriptures is essential for spiritual nourishment.8 The word of God inspires commitment and acts as a healing balm for hurt feelings, anger, or disillusionment.9 When our commitment is diminished for any reason, part of the solution is repentance.10 Commitment and repentance are closely intertwined.

C. S. Lewis, the striving, pragmatic Christian writer, poignantly framed the issue. He asserted that Christianity tells people to repent and promises them forgiveness; but until people know and feel they need forgiveness, Christianity does not speak to them. He stated, “When you know you are sick, you will listen to the doctor.”11

The Prophet Joseph pointed out that before your baptism, you could be on neutral ground between good and evil. But “when you joined this Church you enlisted to serve God. When you did that you left the neutral ground, and you never can [go] back.” His counsel was that we must never forsake the Master.12

Alma emphasizes that through the Atonement of Jesus Christ, “the arms of mercy are extended” to those who repent.13 He then asks penetrating and ultimate questions, such as: Are we prepared to meet God? Are we keeping ourselves blameless? We should all contemplate these questions. Alma’s own experience in failing to follow his faithful father and then coming to a dramatic understanding of how much he needed forgiveness and what it meant to sing the song of redeeming love is powerful and compelling.

While anything that lessens commitment is of consequence, two relevant challenges are both prevalent and significant. The first is unkindness, violence, and domestic abuse. The second is sexual immorality and impure thoughts. These often precede and are at the root of the choice to be less committed.

How we treat those closest to us is of fundamental importance. Violence, abuse, lack of civility, and disrespect in the home are not acceptable—not acceptable for adults and not acceptable for the rising generation. My father was not active in the Church but was a remarkably good example, especially in his treatment of my mother. He used to say, “God will hold men responsible for every tear they cause their wives to shed.” This same concept is emphasized in “The Family: A Proclamation to the World.” It reads, “[Those] who abuse spouse or offspring … will one day stand accountable before God.”14 Regardless of the culture in which we are raised, and whether our parents did or did not abuse us, we must not physically, emotionally, or verbally abuse anyone else.15

The need for civility in society has never been more important. The foundation of kindness and civility begins in our homes. It is not surprising that our public discourse has declined in equal measure with the breakdown of the family. The family is the foundation for love and for maintaining spirituality. The family promotes an atmosphere where religious observance can flourish. There is indeed “beauty all around when there’s love at home.”16

Sexual immorality and impure thoughts violate the standard established by the Savior.17 We were warned at the beginning of this dispensation that sexual immorality would be perhaps the greatest challenge.18 Such conduct will, without repentance, cause a spiritual drought and loss of commitment. Movies, TV, and the Internet often convey degrading messages and images. President Dieter F. Uchtdorf and I were recently in an Amazon jungle village and observed satellite dishes even on some of the small, simply built huts. We rejoiced at the wonderful information available in this remote area. We also recognized there is virtually no place on earth that cannot be impacted by salacious, immoral, and titillating images. This is one reason why pornography has become such a plague in our day.

I recently had an insightful conversation with a 15-year-old Aaronic Priesthood holder. He helped me understand how easy it is in this Internet age for young people to almost inadvertently be exposed to impure and even pornographic images. He pointed out that for most principles the Church teaches, there is at least some recognition in society at large that violating these principles can have devastating effects on health and well-being. He mentioned cigarette smoking, drug use, and alcohol consumption by young people. But he noted that there is no corresponding outcry or even a significant warning from society at large about pornography or immorality.

My dear brothers and sisters, this young man’s analysis is correct. What is the answer? For years, prophets and apostles have taught the importance of religious observance in the home.19

Parents, the days are long past when regular, active participation in Church meetings and programs, though essential, can fulfill your sacred responsibility to teach your children to live moral, righteous lives and walk uprightly before the Lord. With President Monson’s announcement this morning, it is essential that this be faithfully accomplished in homes which are places of refuge where kindness, forgiveness, truth, and righteousness prevail. Parents must have the courage to filter or monitor Internet access, television, movies, and music. Parents must have the courage to say no, defend truth, and bear powerful testimony. Your children need to know that you have faith in the Savior, love your Heavenly Father, and sustain the leaders of the Church. Spiritual maturity must flourish in our homes. My hope is that no one will leave this conference without understanding that the moral issues of our day must be addressed in the family. Bishops and priesthood and auxiliary leaders need to support families and make sure that spiritual principles are taught. Home and visiting teachers can assist, especially with children of single parents.

The young man I mentioned earnestly asked if the Apostles knew how early in life teaching and protecting against pornography and impure thoughts should start. With emphasis, he stated that in some areas even before youth graduate from Primary is not too early.

Youth who have been exposed to immoral images at a very early age are terrified that they may have already disqualified themselves for missionary service and sacred covenants. As a result, their faith can be severely impaired. I want to assure you young people, as Alma taught, that through repentance you can qualify for all the blessings of heaven.20 That is what the Savior’s Atonement is all about. Please talk with your parents or a trusted adviser, and counsel with your bishop.

When it comes to morality, some adults believe that adherence to a single, overriding humanitarian project or principle nullifies the need to comply with the Savior’s teachings. They say to themselves that sexual misconduct is “a small thing … [if I am] a kind and charitable person.”21 Such thinking is a gross self-deception. Some young people inform me that in our current culture it is not “cool” to try too hard in many areas, including living strictly in accordance with righteous principles.22 Please do not fall into this trap.

At baptism we promise to take upon us “the name of [Jesus] Christ, having [the] determination to serve him to the end.”23 Such a covenant requires courageous effort, commitment, and integrity if we are to continue to sing the song of redeeming love and stay truly converted.

A historic example of commitment to be strong and immovable for all ages was portrayed by a British Olympian who competed in the 1924 Olympics in Paris, France.

Eric Liddell was the son of a Scottish missionary to China and a devoutly religious man. He infuriated the British leadership of the Olympics by refusing, even under enormous pressure, to run in a preliminary 100-meter race held on Sunday. Ultimately he was victorious in the 400-meter race. Liddell’s example of refusing to run on Sunday was particularly inspiring.

Depictions and memorials in his honor have referred to the inspirational words from Isaiah, “But they that wait upon the Lord shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint.”24

Liddell’s admirable conduct was very influential in our youngest son’s decision to not participate in Sunday sports and, more importantly, to separate himself from unrighteous and worldly conduct. He used the quote from Isaiah for his yearbook contribution. Eric Liddell left a powerful example of determination and commitment to principle.

As our youth follow President Monson’s counsel by preparing to serve missions, and as we all live the principles the Savior taught and prepare to meet God,25 we win a much more important race.26 We will have the Holy Ghost as our guide for spiritual direction. For any whose lives are not in order, remember, it is never too late to make the Savior’s Atonement the foundation of our faith and lives.27

In the words of Isaiah, “Though your sins be as scarlet, they shall be as white as snow; though they be red like crimson, they shall be as wool.”28

My sincere prayer is that each of us will take any necessary action to feel the Spirit now so we can sing the song of redeeming love with all our hearts. I testify of the power of the Savior’s Atonement, in the name of Jesus Christ, amen.

# References
1. - See Alma 4:15–19.
2. - Alma 5:26.
3. - George Albert Smith was then President of the Quorum of the Twelve Apostles. He would become President of the Church on May 21, 1945. (See Deseret News 2012 Church Almanac [2012], 98.)
4. - George Albert Smith, in Sheri L. Dew, Ezra Taft Benson: A Biography (1987), 184.
5. - Peggy Noonan, “The Dark Night Rises,” Wall Street Journal, July 28–29, 2012, A17.
6. - Dr. R. Albert Mohler Jr., president, The Southern Baptist Theological Seminary, presentation to religious leaders, New York City, Sept. 5, 2012.
7. - See 2 Nephi 2:27.
8. - See John 5:39; Amos 8:11; see also James E. Faust, “A Personal Relationship with the Savior,” Ensign, Nov. 1976, 58–59.
9. - See Alma 31:5.
10. - See Alma 36:23–26.
11. - C. S. Lewis, Mere Christianity (1952), 31–32. Lewis was a Fellow in English literature at Oxford University and was subsequently chair of Medieval and Renaissance English at Cambridge University.
12. - See Teachings of Presidents of the Church: Joseph Smith (2007), 324; see also Revelation 3:15–16.
13. - Alma 5:33.
14. - “The Family: A Proclamation to the World,” Liahona and Ensign, Nov. 2010, 129.
15. - See Richard G. Scott, “Removing Barriers to Happiness,” Ensign, May 1998, 85–87. Some cultural imperatives are contrary to the Savior’s teachings and can lead us astray. When I was in the South Pacific, I met a man who had investigated the Church for years. He reported he was deeply touched when a Church leader taught at a priesthood conference, “Hands which you have previously used to hit your children are to be used to bless your children.” He received the missionary lessons, was baptized, and has been a great leader.
16. - “Love at Home,” Hymns, no. 294.
17. - See Alma 39.
18. - See Ezra Taft Benson, “Cleansing the Inner Vessel,” Ensign, May 1986, 4.
19. - President Gordon B. Hinckley introduced “The Family: A Proclamation to the World” in the general Relief Society meeting in September 1995. President Thomas S. Monson presided over changing the first chapter of Handbook 2: Administering the Church (2010), “Families and the Church in God’s Plan.”
20. - See Alma 13:27–30; 41:11–15.
21. - Ross Douthat, Bad Religion: How We Became a Nation of Heretics (2012), 238; see also Alma 39:5.
22. - Do not allow a culture that is filled with violence and immorality and is critical of those who live the principles the Savior taught to disturb your faith. As the poet Wordsworth gently penned, “Feed [your mind] with lofty thoughts, that neither evil tongues, rash judgements, nor the sneers of selfish men … shall e’er prevail … or disturb [your] cheerful faith” (“Lines Composed a Few Miles above Tintern Abbey,” in The Oxford Book of English Verse, ed. Christopher Ricks [1999], 346).
23. - Moroni 6:3; emphasis added; see also Mosiah 18:13.
24. - Isaiah 40:31; see Robert L. Backman, “Day of Delight,” New Era, June 1993, 48–49.
25. - See Alma 34:32.
26. - See 1 Corinthians 9:24–27.
27. - See Helaman 5:12. Oliver Wendell Holmes Sr. counseled, “I find the great thing in this world is not so much where we stand, as in what direction we are moving: To reach the port of heaven, we must sail sometimes with the wind and sometimes against it,—but we must sail, and not drift, nor lie at anchor” (The Autocrat of the Breakfast-Table [1858], 105).
28. - Isaiah 1:18.