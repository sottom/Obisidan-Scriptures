

10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/priesthood-session?lang=eng)



# References
