Elder Richard G. Scott
Of the Quorum of the Twelve Apostles
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/the-joy-of-redeeming-the-dead?lang=eng)

_“He shall plant in the hearts of the children the promises made to the fathers, and the hearts of the children shall turn to their fathers.”_

The Lord revealed to the Prophet Joseph Smith sublime doctrine concerning the sacred ordinance of baptism. That light came when other Christian churches taught that death irrevocably, eternally, determined the destiny of the soul. They taught the baptized were rewarded with endless joy while all others faced eternal torment without hope of redemption.

The Lord’s revelation that through proper priesthood authority, baptism could be performed vicariously for the dead preserved the justice of His statement: “Except a man be born of water and of the Spirit, he cannot enter into the kingdom of God.”1 Vicarious baptism can mercifully provide this essential ordinance for all worthy deceased who did not receive it in mortality.

This glorious doctrine is another witness of the all-encompassing nature of the Atonement of Jesus Christ. He made salvation available to every repentant soul. His Atonement conquered death, and He permits the worthy deceased to receive all ordinances of salvation vicariously.

In an epistle written over 150 years ago, Joseph Smith stated: “The Saints have the privilege of being baptized for … their relatives who are dead … who have received the Gospel in the spirit, through … those who have been commissioned to preach to them.”2 Later he added, “Those Saints who neglect it in behalf of their deceased relatives, do it at the peril of their own salvation.”3

The prophet Elijah committed the keys for vicarious work to Joseph Smith in the Kirtland Temple4 to fulfill the Lord’s promise that “he shall plant in the hearts of the children the promises made to the fathers, and the hearts of the children shall turn to their fathers.”5

Through further revelation to Joseph Smith and subsequent prophets, there has come an understanding of and the provision for temple work and the family history effort that supports it. Every prophet since Joseph Smith has emphasized the imperative need to provide all ordinances for ourselves and our deceased ancestors.

Temple and family history work is one work divided into two parts. They are connected together like the ordinances of baptism and the gift of the Holy Ghost. Some members may not be able to do both works because of health or distances to temples.

President Howard W. Hunter taught:

“We must accomplish the priesthood temple ordinance work necessary for our own exaltation; then we must do the necessary work for those who did not have the opportunity to accept the gospel in life. Doing work for others is accomplished in two steps: first, by family history research to ascertain our progenitors; and second, by performing the temple ordinances to give them the same opportunities afforded to the living.

“Yet there are many members of the Church who have only limited access to the temples. They do the best they can. They pursue family history research and have the temple ordinance work done by others. Conversely, there are some members who engage in temple work but fail to do family history research on their own family lines. Although they perform a divine service in assisting others, they lose a blessing by not seeking their own kindred dead as divinely directed by latter-day prophets. …

“I have learned that those who engage in family history research and then perform the temple ordinance work for those whose names they have found will know the additional joy of receiving both halves of the blessing.”6

Father in Heaven wants each of us to receive both parts of the blessing of this vital vicarious work. He has led others to show us how to qualify. It is up to you and me to claim those blessings.

Any work you do in the temple is time well spent, but receiving ordinances vicariously for one of your own ancestors will make the time in the temple more sacred, and even greater blessings will be received. The First Presidency has declared, “Our preeminent obligation is to seek out and identify our own ancestors.”7

Do you young people want a sure way to eliminate the influence of the adversary in your life? Immerse yourself in searching for your ancestors, prepare their names for the sacred vicarious ordinances available in the temple, and then go to the temple to stand as proxy for them to receive the ordinances of baptism and the gift of the Holy Ghost. As you grow older, you will be able to participate in receiving the other ordinances as well. I can think of no greater protection from the influence of the adversary in your life.

In the Russia Rostov-na-Donu Mission the youth were invited to each index 2,000 names and then qualify at least one name from their own families for temple ordinances. Those who accomplished this goal were invited to go on a long journey to the new Kyiv Ukraine Temple. One young man shared his experience: “I was spending a lot of time playing computer games. When I started indexing, I didn’t have time to play games. At first I thought, ‘Oh no! How can that be!’ When this project was over, I even lost interest in gaming. … Genealogical work is something that we can do here on earth, and it will remain in heaven.”

Many faithful Saints have done the work of researching their family lines and are using the reserve feature of FamilySearch to hold the ordinances for their own family members to serve as proxy. The intent of reserving names is to allow a reasonable period of time for individuals to perform ordinances for ancestors and collateral lines. There are currently 12 million names and millions of corresponding ordinances that are reserved. Many names have been reserved for years. Ancestors who have been found are no doubt anxious and thrilled when their names are cleared for ordinances. They, however, may not be very happy when they have to continue to wait for their ordinances to be performed.

We encourage those of you who have a large reservation of names to share them so that members of your extended family or ward and stake can help you in completing that work. You can do this by distributing temple cards to ward and stake members willing to help or by using the FamilySearch computer system to submit the names directly to the temple. This latter option is something Cindy Blevins of Casper, Wyoming, has been doing for years.

Sister Blevins was baptized as a teenager and has been the only member of her family to join the Church. She has completed a vast amount of genealogical work. But there are far too many names for her and her immediate family to complete. Consequently, Sister Blevins has submitted the names to the temple, which, she reports, are often completed in a matter of weeks, usually at one of the two temples closest to her home. She says she likes to think that friends and neighbors in her own ward and stake may be among those helping to complete the work for her ancestors. She appreciates their doing so.

My beloved wife, Jeanene, loved doing family history research. When our children were young, she would trade babysitting time with friends so she could have a few hours every few weeks to work on researching our family lines. After our youngest child left home, she recorded in her personal journal: “I have just made a decision and I want to stand up and shout about it. Mike’s old bedroom has become my genealogy workroom. It is well equipped to organize the records and work in. My life will now focus on vital family research and temple name submissions. I am so excited and anxious to get going.”8

Another journal entry reads: “The … miracle for me occurred in the Family History office of Mel Olsen who presented me with a printout of all my known ancestral pedigrees taken from the update of the Ancestral File computerized records sent into the genealogical society. They came mostly from the records of the four generation’s program the Church called for many years ago. I had been overwhelmed with the thought of the huge task ahead of me to gather all my ancestors’ research records from family organizations to get them all in the computer for the first computerized distribution of the Ancestral File. And there they all were, beautiful, organized and laser printed and sitting there on the desk before me. I was so thrilled and so overwhelmed I just sat there stunned and then began to cry I was so happy. … For one who has doggedly, painstakingly researched for thirty years, the computerization of all these records is truly exciting. And when I think of the hundreds of thousands of people who are now or soon will be computerizing huge blocks of censuses and private research disks … I am so excited. It is truly the Lord’s work and He is directing it.”9

I have tasted enough of the fruits of this sublime work to know that the keys Elijah restored to Joseph Smith permit our hearts to be bound and each of us linked to those of our ancestors who are waiting for our help. Through our efforts in holy temples here on earth using the authority delegated by the Savior, our progenitors receive the saving ordinances that allow them to enjoy eternal happiness.

In the past, motivated by a deep conviction of the sanctity of the work, individuals have valiantly faced a challenge that seemed like single-handedly endeavoring to harvest all the grain in Nebraska. Now, many mighty combines are at work. Together we can and will accomplish the required work.

I testify that the Spirit of Elijah is touching the hearts of many of Father’s children throughout the world, causing the work for the dead to accelerate at an unprecedented pace.

But what about you? Have you prayed about your own ancestors’ work? Set aside those things in your life that don’t really matter. Decide to do something that will have eternal consequences. Perhaps you have been prompted to look for ancestors but feel you are not a genealogist. Can you see that you don’t have to be anymore? It all begins with love and a sincere desire to help those beyond the veil who can’t help themselves. Check around. There will be someone in your area who can help you have success.

This work is a spiritual work, a monumental effort of cooperation on both sides of the veil, where help is given in both directions. Anywhere you are in the world, with prayer, faith, determination, diligence, and some sacrifice, you can make a powerful contribution. Begin now. I promise you that the Lord will help you find a way. And it will make you feel wonderful. In the name of Jesus Christ, amen.

# References
1. - John 3:5.
2. - History of the Church, 4:231.
3. - Teachings of Presidents of the Church: Joseph Smith (2007), 471–72.
4. - See Doctrine and Covenants 110:13–16.
5. - Doctrine and Covenants 2:2; emphasis added.
6. - Howard W. Hunter, “A Temple-Motivated People,” Liahona, May 1995, 5–6; Ensign, Feb. 1995, 4–5.
7. - First Presidency letter, Feb. 29, 2012; emphasis added.
8. - Jeanene Watkins Scott, personal journal, Apr. 1988.
9. - Jeanene Watkins Scott, personal journal, Sept. 23, 1989.