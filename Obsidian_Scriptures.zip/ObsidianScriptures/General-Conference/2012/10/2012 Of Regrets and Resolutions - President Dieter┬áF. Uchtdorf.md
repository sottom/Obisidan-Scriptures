President Dieter F. Uchtdorf
Second Counselor in the First Presidency
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/of-regrets-and-resolutions?lang=eng)

_The more we devote ourselves to the pursuit of holiness and happiness, the less likely we will be on a path to regrets._

Of Regrets



President Monson, we love you. Thank you for the inspired and historic announcement on the building of new temples and missionary service. Because of them, I’m sure great blessings will come to us and to many future generations.

My dear brothers and sisters, my dear friends! We are all mortal. I hope this does not come as a surprise to anyone.

None of us will be on earth very long. We have a number of precious years which, in the eternal perspective, barely amount to the blink of an eye.

And then we depart. Our spirits “are taken home to that God who gave [us] life.”1 We lay our bodies down and leave behind the things of this world as we move to the next realm of our existence.

When we are young, it seems that we will live forever. We think there is a limitless supply of sunrises waiting just beyond the horizon, and the future looks to us like an unbroken road stretching endlessly before us.

However, the older we get, the more we tend to look back and marvel at how short that road really is. We wonder how the years could have passed so quickly. And we begin to think about the choices we made and the things we have done. In the process, we remember many sweet moments that give warmth to our souls and joy to our hearts. But we also remember the regrets—the things we wish we could go back and change.

A nurse who cares for the terminally ill says that she has often asked a simple question of her patients as they prepared to depart this life.

“Do you have any regrets?” she would ask.2

Being so close to that final day of mortality often gives clarity to thought and provides insight and perspective. So when these people were asked about their regrets, they opened their hearts. They reflected about what they would change if only they could turn back the clock.

As I considered what they had said, it struck me how the foundational principles of the gospel of Jesus Christ can affect our life’s direction for good, if only we will apply them.

There is nothing mysterious about the principles of the gospel. We have studied them in the scriptures, we have discussed them in Sunday School, and we have heard them from the pulpit many times. These divine principles and values are straightforward and clear; they are beautiful, profound, and powerful; and they can definitely help us to avoid future regrets.







I Wish I Had Spent More Time with the People I Love



Perhaps the most universal regret dying patients expressed was that they wished they had spent more time with the people they love.

Men in particular sang this universal lament: they “deeply regretted spending so much of their lives on the [daily] treadmill of … work.”3 Many had lost out on choice memories that come from spending time with family and friends. They missed developing a deep connection with those who meant the most to them.

Isn’t it true that we often get so busy? And, sad to say, we even wear our busyness as a badge of honor, as though being busy, by itself, was an accomplishment or sign of a superior life.

Is it?

I think of our Lord and Exemplar, Jesus Christ, and His short life among the people of Galilee and Jerusalem. I have tried to imagine Him bustling between meetings or multitasking to get a list of urgent things accomplished.

I can’t see it.

Instead I see the compassionate and caring Son of God purposefully living each day. When He interacted with those around Him, they felt important and loved. He knew the infinite value of the people He met. He blessed them, ministered to them. He lifted them up, healed them. He gave them the precious gift of His time.

In our day it is easy to merely pretend to spend time with others. With the click of a mouse, we can “connect” with thousands of “friends” without ever having to face a single one of them. Technology can be a wonderful thing, and it is very useful when we cannot be near our loved ones. My wife and I live far away from precious family members; we know how that is. However, I believe that we are not headed in the right direction, individually and as a society, when we connect with family or friends mostly by reposting humorous pictures, forwarding trivial things, or linking our loved ones to sites on the Internet. I suppose there is a place for this kind of activity, but how much time are we willing to spend on it? If we fail to give our best personal self and undivided time to those who are truly important to us, one day we will regret it.

Let us resolve to cherish those we love by spending meaningful time with them, doing things together, and cultivating treasured memories.







I Wish I Had Lived Up to My Potential



Another regret people expressed was that they failed to become the person they felt they could and should have been. When they looked back on their lives, they realized that they never lived up to their potential, that too many songs remained unsung.

I am not speaking here of climbing the ladder of success in our various professions. That ladder, no matter how lofty it may appear on this earth, barely amounts to a single step in the great eternal journey awaiting us.

Rather, I am speaking of becoming the person God, our Heavenly Father, intended us to be.

We arrive in this world, as the poet said, “trailing clouds of glory”4 from the premortal sphere.

Our Heavenly Father sees our real potential. He knows things about us that we do not know ourselves. He prompts us during our lifetime to fulfill the measure of our creation, to live a good life, and to return to His presence.

Why, then, do we devote so much of our time and energy to things that are so fleeting, so inconsequential, and so superficial? Do we refuse to see the folly in the pursuit of the trivial and transient?

Would it not be wiser for us to “lay up for [ourselves] treasures in heaven, where neither moth nor rust doth corrupt, and where thieves do not break through nor steal”?5

How do we do this? By following the example of the Savior, by incorporating His teachings in our daily lives, by truly loving God and our fellowman.

We certainly cannot do this with a dragging-our-feet, staring-at-our-watch, complaining-as-we-go approach to discipleship.

When it comes to living the gospel, we should not be like the boy who dipped his toe in the water and then claimed he went swimming. As sons and daughters of our Heavenly Father, we are capable of so much more. For that, good intentions are not enough. We must do. Even more important, we must become what Heavenly Father wants us to be.

Declaring our testimony of the gospel is good, but being a living example of the restored gospel is better. Wishing to be more faithful to our covenants is good; actually being faithful to sacred covenants—including living a virtuous life, paying our tithes and offerings, keeping the Word of Wisdom, and serving those in need—is much better. Announcing that we will dedicate more time for family prayer, scripture study, and wholesome family activities is good; but actually doing all these things steadily will bring heavenly blessings to our lives.

Discipleship is the pursuit of holiness and happiness. It is the path to our best and happiest self.

Let us resolve to follow the Savior and work with diligence to become the person we were designed to become. Let us listen to and obey the promptings of the Holy Spirit. As we do so, Heavenly Father will reveal to us things we never knew about ourselves. He will illuminate the path ahead and open our eyes to see our unknown and perhaps unimagined talents.

The more we devote ourselves to the pursuit of holiness and happiness, the less likely we will be on a path to regrets. The more we rely on the Savior’s grace, the more we will feel that we are on the track our Father in Heaven has intended for us.







I Wish I Had Let Myself Be Happier



Another regret of those who knew they were dying may be somewhat surprising. They wished they had let themselves be happier.

So often we get caught up in the illusion that there is something just beyond our reach that would bring us happiness: a better family situation, a better financial situation, or the end of a challenging trial.

The older we get, the more we look back and realize that external circumstances don’t really matter or determine our happiness.

We do matter. We determine our happiness.

You and I are ultimately in charge of our own happiness.

My wife, Harriet, and I love riding our bicycles. It is wonderful to get out and enjoy the beauties of nature. We have certain routes we like to bike, but we don’t pay too much attention to how far we go or how fast we travel in comparison with other riders.

However, occasionally I think we should be a bit more competitive. I even think we could get a better time or ride at a higher speed if only we pushed ourselves a little more. And then sometimes I even make the big mistake of mentioning this idea to my wonderful wife.

Her typical reaction to my suggestions of this nature is always very kind, very clear, and very direct. She smiles and says, “Dieter, it’s not a race; it’s a journey. Enjoy the moment.”

How right she is!

Sometimes in life we become so focused on the finish line that we fail to find joy in the journey. I don’t go cycling with my wife because I’m excited about finishing. I go because the experience of being with her is sweet and enjoyable.

Doesn’t it seem foolish to spoil sweet and joyful experiences because we are constantly anticipating the moment when they will end?

Do we listen to beautiful music waiting for the final note to fade before we allow ourselves to truly enjoy it? No. We listen and connect to the variations of melody, rhythm, and harmony throughout the composition.

Do we say our prayers with only the “amen” or the end in mind? Of course not. We pray to be close to our Heavenly Father, to receive His Spirit and feel His love.

We shouldn’t wait to be happy until we reach some future point, only to discover that happiness was already available—all the time! Life is not meant to be appreciated only in retrospect. “This is the day which the Lord hath made … ,” the Psalmist wrote. “Rejoice and be glad in it.”6

Brothers and sisters, no matter our circumstances, no matter our challenges or trials, there is something in each day to embrace and cherish. There is something in each day that can bring gratitude and joy if only we will see and appreciate it.

Perhaps we should be looking less with our eyes and more with our hearts. I love the quote: “One sees clearly only with the heart. Anything essential is invisible to the eyes.”7

We are commanded “to give thanks in all things.”8 So isn’t it better to see with our eyes and hearts even the small things we can be thankful for, rather than magnifying the negative in our current condition?

The Lord has promised, “He who receiveth all things with thankfulness shall be made glorious; and the things of this earth shall be added unto him, even an hundred fold.”9

Brothers and sisters, with the bountiful blessings of our Heavenly Father, His generous plan of salvation, the supernal truths of the restored gospel, and the many beauties of this mortal journey, “have we not reason to rejoice?”10

Let us resolve to be happy, regardless of our circumstances.







Of Resolutions



One day we will take that unavoidable step and cross from this mortal sphere into the next estate. One day we will look back at our lives and wonder if we could have been better, made better decisions, or used our time more wisely.

To avoid some of the deepest regrets of life, it would be wise to make some resolutions today. Therefore, let us:





Resolve to spend more time with those we love.





Resolve to strive more earnestly to become the person God wants us to be.





Resolve to find happiness, regardless of our circumstances.





It is my testimony that many of the deepest regrets of tomorrow can be prevented by following the Savior today. If we have sinned or made mistakes—if we have made choices that we now regret—there is the precious gift of Christ’s Atonement, through which we can be forgiven. We cannot go back in time and change the past, but we can repent. The Savior can wipe away our tears of regret11 and remove the burden of our sins.12 His Atonement allows us to leave the past behind and move forward with clean hands, a pure heart,13 and a determination to do better and especially to become better.

Yes, this life is passing swiftly; our days seem to fade quickly; and death appears frightening at times. Nevertheless, our spirit will continue to live and will one day be united with our resurrected body to receive immortal glory. I bear solemn witness that because of the merciful Christ, we will all live again and forever. Because of our Savior and Redeemer, one day we will truly understand and rejoice in the meaning of the words “the sting of death is swallowed up in Christ.”14

The path toward fulfilling our divine destiny as sons and daughters of God is an eternal one. My dear brothers and sisters, dear friends, we must begin to walk that eternal path today; we cannot take for granted one single day. I pray that we will not wait until we are ready to die before we truly learn to live. In the sacred name of Jesus Christ, amen.

# References
1. - Alma 40:11.
2. - See Susie Steiner, “Top Five Regrets of the Dying,” Guardian, Feb. 1, 2012, www.guardian.co.uk/lifeandstyle/2012/feb/01/top-five-regrets-of-the-dying.
3. - Bronnie Ware, in Steiner, “Top Five Regrets of the Dying.”
4. - “Ode: Intimations of Immortality from Recollections of Early Childhood,” The Complete Poetical Works of William Wordsworth (1924), 359.
5. - Matthew 6:20.
6. - Psalm 118:24.
7. - Antoine de Saint-Exupéry, The Little Prince, trans. Richard Howard (2000), 63.
8. - Mosiah 26:39; see also Doctrine and Covenants 59:7.
9. - Doctrine and Covenants 78:19.
10. - Alma 26:35.
11. - See Revelation 7:17.
12. - See Matthew 11:28–30.
13. - See Psalm 24:4.
14. - Mosiah 16:8; see also 1 Corinthians 15:54.