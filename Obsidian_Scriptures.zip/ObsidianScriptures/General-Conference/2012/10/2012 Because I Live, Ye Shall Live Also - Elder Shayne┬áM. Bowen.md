Elder Shayne M. Bowen
Of the Seventy
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/because-i-live-ye-shall-live-also?lang=eng)

_Because of Him, even our Savior, Jesus Christ, those feelings of sorrow, loneliness, and despair will one day be swallowed up in a fulness of joy._

While serving as young missionaries in Chile, my companion and I met a family of seven in the branch. The mother attended every week with her children. We assumed that they were longtime members of the Church. After several weeks we learned that they had not been baptized.

We immediately contacted the family and asked if we could come to their home and teach them. The father was not interested in learning about the gospel but had no objection to our teaching his family.

Sister Ramirez advanced rapidly through the lessons. She was anxious to learn all the doctrine that we taught. One evening as we were discussing infant baptism, we taught that little children are innocent and have no need for baptism. We invited her to read in the book of Moroni:

“Behold I say unto you that this thing shall ye teach—repentance and baptism unto those who are accountable and capable of committing sin; yea, teach parents that they must repent and be baptized, and humble themselves as their little children, and they shall all be saved with their little children.

“And their little children need no repentance, neither baptism. Behold, baptism is unto repentance to the fulfilling the commandments unto the remission of sins.

“But little children are alive in Christ, even from the foundation of the world; if not so, God is a partial God, and also a changeable God, and a respecter to persons; for how many little children have died without baptism!”1

After reading this scripture, Sister Ramirez began sobbing. My companion and I were confused. I asked, “Sister Ramirez, have we said or done something that has offended you?”

She said, “Oh, no, Elder, you haven’t done anything wrong. Six years ago I had a baby boy. He died before we could have him baptized. Our priest told us that because he had not been baptized, he would be in limbo for all eternity. For six years I have carried that pain and guilt. After reading this scripture, I know by the power of the Holy Ghost that it is true. I have felt a great weight taken off of me, and these are tears of joy.”



I was reminded of the teachings of the Prophet Joseph Smith, who taught this comforting doctrine: “The Lord takes many away, even in infancy, that they may escape the envy of man, and the sorrows and evils of this present world; they were too pure, too lovely, to live on earth; therefore, if rightly considered, instead of mourning we have reason to rejoice as they are delivered from evil, and we shall soon have them again.”2

After she suffered almost unbearable grief and pain for six years, the true doctrine, revealed by a loving Father in Heaven through a living prophet, brought sweet peace to this tormented woman. Needless to say, Sister Ramirez and her children who were eight years and older were baptized.

I remember writing to my family, expressing the gratitude that I felt in my heart for the knowledge of this and so many other plain and precious truths of the restored gospel of Jesus Christ. I never dreamed how this wonderful true principle would come back to me in future years and prove to be my balm of Gilead.

I would like to speak to those who have lost a child and have asked the question, “Why me?” or maybe even questioned your own faith in a loving Father in Heaven. It is my prayer that by the power of the Holy Ghost, I may bring some measure of hope, of peace, and of understanding. It is my desire to be an instrument in bringing about a restoration of your faith in our loving Father in Heaven, who knows all things and allows us to experience trials so that we can come to know and love Him and understand that without Him we have nothing.

On February 4 of 1990, our third son and sixth child was born. We named him Tyson. He was a beautiful little boy, and the family greeted him with open hearts and open arms. His brothers and sisters were so proud of him. We all thought he was the most perfect little boy who had ever been born.

When Tyson was eight months old, he aspirated a piece of chalk that he had found on the carpet. The chalk lodged in Tyson’s throat, and he quit breathing. His older brother brought Tyson upstairs, frantically calling, “The baby won’t breathe. The baby won’t breathe.” We began to administer CPR and called 911.

The paramedics arrived and rushed Tyson to the hospital. In the waiting room we continued in fervent prayer as we pled to God for a miracle. After what seemed a lifetime, the doctor came into the room and said, “I am so sorry. There is nothing more we can do. Take all the time you need.” She then left.

As we entered the room where Tyson lay, we saw our lifeless little bundle of joy. It seemed as though he had a celestial glow around his little body. He was so radiant and pure.

At that moment it felt as if our world had come to an end. How could we return to the other children and somehow try to explain that Tyson wasn’t coming home?

I will speak in the singular as I relate the rest of this experience. My angel wife and I experienced this trial together, but I am inadequate in expressing the feelings of a mother and would not even try to do so.

It is impossible to describe the mixture of feelings that I had at that point in my life. Most of the time I felt as if I were in a bad dream and that I would soon wake up and this terrible nightmare would be over. For many nights I didn’t sleep. I often wandered in the night from one room to the other, making sure that our other children were all safe.

Feelings of guilt racked my soul. I felt so guilty. I felt dirty. I was his father; I should have done more to protect him. If only I would have done this or that. Sometimes even today, 22 years later, those feelings begin to creep into my heart, and I need to get rid of them quickly because they can be destructive.

About a month after Tyson died, I had an interview with Elder Dean L. Larsen. He took the time to listen to me, and I will always be grateful for his counsel and love. He said, “I don’t think the Lord would want you to punish yourself for the death of your little boy.” I felt the love of my Heavenly Father through one of his chosen vessels.

However, tormenting thoughts continued to plague me, and I soon began to feel anger. “This isn’t fair! How could God do this to me? Why me? What did I do to deserve this?” I even felt myself get angry with people who were just trying to comfort us. I remember friends saying, “I know how you feel.” I would think to myself, “You have no idea how I feel. Just leave me alone.” I soon found that self-pity can also be very debilitating. I was ashamed of myself for having unkind thoughts about dear friends who were only trying to help.



As I felt the guilt, anger, and self-pity trying to consume me, I prayed that my heart could change. Through very personal sacred experiences, the Lord gave me a new heart, and even though it was still lonely and painful, my whole outlook changed. I was given to know that I had not been robbed but rather that there was a great blessing awaiting me if I would prove faithful.

My life started to change, and I was able to look forward with hope, rather than look backward with despair. I testify that this life is not the end. The spirit world is real. The teachings of the prophets regarding life after death are true. This life is but a transitory step forward on our journey back to our Heavenly Father.

Tyson has remained a very integral part of our family. Through the years it has been wonderful to see the mercy and kindness of a loving Father in Heaven, who has allowed our family to feel in very tangible ways the influence of Tyson. I testify that the veil is thin. The same feelings of loyalty, love, and family unity don’t end as our loved ones pass to the other side; instead, those feelings are intensified.

Sometimes people will ask, “How long did it take you to get over it?” The truth is, you will never completely get over it until you are together once again with your departed loved ones. I will never have a fulness of joy until we are reunited in the morning of the First Resurrection.

“For man is spirit. The elements are eternal, and spirit and element, inseparably connected, receive a fulness of joy;

“And when separated, man cannot receive a fulness of joy.”3

But in the meantime, as the Savior taught, we can continue with good cheer.4

I have learned that the bitter, almost unbearable pain can become sweet as you turn to your Father in Heaven and plead for His comfort that comes through His plan; His Son, Jesus Christ; and His Comforter, who is the Holy Ghost.

What a glorious blessing this is in our lives. Wouldn’t it be tragic if we didn’t feel great sorrow when we lose a child? How grateful I am to my Father in Heaven that He allows us to love deeply and love eternally. How grateful I am for eternal families. How grateful I am that He has revealed once again through His living prophets the glorious plan of redemption.

Remember as you attended the funeral of your loved one the feelings in your heart as you drove away from the cemetery and looked back to see that solitary casket—wondering if your heart would break.

I testify that because of Him, even our Savior, Jesus Christ, those feelings of sorrow, loneliness, and despair will one day be swallowed up in a fulness of joy. I testify that we can depend on Him and when He said:

“I will not leave you comfortless: I will come to you.

“Yet a little while, and the world seeth me no more; but ye see me: because I live, ye shall live also.”5

I testify that, as stated in Preach My Gospel, “as we rely on the Atonement of Jesus Christ, He can help us endure our trials, sicknesses, and pain. We can be filled with joy, peace, and consolation. All that is unfair about life can be made right through the Atonement of Jesus Christ.”6

I testify that on that bright, glorious morning of the First Resurrection, your loved ones and mine will come forth from the grave as promised by the Lord Himself and we will have a fulness of joy. Because He lives, they and we shall live also. In the name of Jesus Christ, amen.

# References
1. - Moroni 8:10–12.
2. - Teachings of Presidents of the Church: Joseph Smith (2007), 176.
3. - Doctrine and Covenants 93:33–34.
4. - See John 16:33.
5. - John 14:18–19.
6. - Preach My Gospel: A Guide to Missionary Service (2004), 52.