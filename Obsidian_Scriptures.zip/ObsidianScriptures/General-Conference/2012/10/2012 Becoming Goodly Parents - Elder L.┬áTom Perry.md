Elder L. Tom Perry
Of the Quorum of the Twelve Apostles
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/becoming-goodly-parents?lang=eng)

_There are many ways that goodly parents can access the help and support they need to teach the gospel of Jesus Christ to their children._

I reached a special milestone this summer—I observed my 90th birthday. As you reach certain milestones in your life, it is helpful and instructive to reflect on the events and experiences of the past. You young people listening to or reading this talk may not be too impressed with 90 years of life, but at the time I was born, living this long was considered a great achievement. Every day I am grateful to Heavenly Father for blessing me with a long life.

So much has changed during my lifetime. I have seen the development of the industrial age and the information age. Mass-produced automobiles and telephones and airplanes were great innovations of my early days. Today the way we find, share, and use information changes almost daily. At my age I marvel at the rapidly changing world in which we all live. So many of today’s breakthroughs excite the imagination with their potential to better our lives.

Through all the fast-paced changes occurring around us, we earnestly pray and work to ensure that the values of the gospel of Jesus Christ endure. Already some of them are in jeopardy of being lost. At the top of the list of these values and, therefore, prime targets of the adversary, are the sanctity of marriage and the central importance of families. They provide an anchor and the safe harbor of a home where each child of a loving Heavenly Father can be influenced for good and acquire eternal values.

My own family, anticipating the celebration of this 90-year milestone in my life, started helping me remember and appreciate the experiences of my long life. For example, my niece gathered and shared with me several letters that I had written to my parents nearly 70 years ago from my marine outpost on the island of Saipan in the Pacific during World War II.

One of these letters particularly caught my eye. It was a letter I wrote to my mother for her to open and read on Mother’s Day 1945. I would like to share some excerpts with you in the hope you will see why I will ever be grateful to my loving father and mother for the lessons I learned from their teaching in the home. My parents are the defining example I retain of goodly parents who placed their marriage and the proper rearing of children as their highest priority.

My Mother’s Day 1945 letter began:

“Dear Mom,

“For the last four years I have had the great misfortune of spending Mother’s Day away from you. Each year I have wanted to be with you and tell you just how I love you and how much I think of you, but since it is once again impossible, I will have to do the next best thing and send my thoughts through the mail.

“This year more than any of the others I can see just what having a wonderful mother has done for me. First of all, I miss the little things you used to do for me. Whenever I got out of bed in the morning, I never had to worry about whether I’d find a clean shirt and clean socks. All that I had to do is open a drawer, and I would find them. At mealtime I always knew that I would find something I liked, prepared the best way possible. At night I always knew that I would find clean sheets on my bed and just the right amount of covers to keep me very comfortable. Living at home was really a great pleasure.”

When I read these first two paragraphs of the letter, I was shocked by how sentimental they sounded. Perhaps living in a tent and sleeping under a mosquito net on a camp cot had my thoughts returning to my very special home.

My letter to my mother continued:

“But deeper is the feeling for you because of the example you set for me. Life was made so enjoyable for us as a family that we wanted to follow in your footsteps, to continue on through experiencing the same joy that had been ours in our younger days. You always found time to take the family into the canyon, and we could count on you to do anything from climbing mountains to playing ball with us. You and Dad were never going on vacations alone. The family was always with you. Now that I am away from home, I always like to talk about my home life because it was so enjoyable. I couldn’t turn from your teachings now because my actions would reflect on your character. Life is a great challenge to me to be worthy to be called the son of Nora Sonne Perry. I am very proud of this title, and I hope that I will always be worthy of it.

“I hope that next year finds me with you to show you the good time I have been planning to show you on Mother’s Day for the past four years.

“May the Lord bless you for all the wonderful things you have done for this troubled world.

“All my love, Tom”1

As I reread my letter, I also reflected on the culture of the family, the ward, the stake, and the community in which I was raised.

Culture is defined as the way of life of a people. There is a unique gospel culture, a set of values and expectations and practices common to all members of The Church of Jesus Christ of Latter-day Saints. This gospel culture, or way of life, comes from the plan of salvation, the commandments of God, and the teachings of living prophets. It is given expression in the way we raise our families and live our individual lives.

The first instruction to Adam for his mortal responsibility is found in Genesis 2:24: “Therefore shall a man leave his father and his mother, and shall cleave unto his wife: and they shall be one flesh.”

The joining together of a man and a woman to be legally and lawfully wed not only is preparation for future generations to inherit the earth, but it also brings the greatest joy and satisfaction that can be found in this mortal experience. This is especially true when the powers of the priesthood proclaim a marriage to be for time and for all eternity. Children born to such marriages have a security that is found nowhere else.

Lessons taught in the home by goodly parents are becoming increasingly important in today’s world, where the influence of the adversary is so widespread. As we know, he is attempting to erode and destroy the very foundation of our society—the family. In clever and carefully camouflaged ways, he is attacking commitment to family life throughout the world and undermining the culture and covenants of faithful Latter-day Saints. Parents must resolve that teaching in the home is a most sacred and important responsibility. While other institutions such as church and school can assist parents to “train up a child in the way he [or she] should go” (Proverbs 22:6), this responsibility ultimately rests on the parents. According to the great plan of happiness, it is goodly parents who are entrusted with the care and development of Heavenly Father’s children.



In our remarkable parental stewardship, there are many ways that goodly parents can access the help and support they need to teach the gospel of Jesus Christ to their children. Let me suggest five things parents can do to create stronger family cultures:

First, parents can pray in earnest, asking our Eternal Father to help them love, understand, and guide the children He has sent to them.

Second, they can hold family prayer, scripture study, and family home evenings and eat together as often as possible, making dinner a time of communication and the teaching of values.

Third, parents can fully avail themselves of the Church’s support network, communicating with their children’s Primary teachers, youth leaders, and class and quorum presidencies. By communicating with those who are called and set apart to work with their children, parents can provide essential understanding of a child’s special and specific needs.

Fourth, parents can share their testimonies often with their children, commit them to keep the commandments of God, and promise the blessings that our Heavenly Father promises His faithful children.

Fifth, we can organize our families based on clear, simple family rules and expectations, wholesome family traditions and rituals, and “family economics,” where children have household responsibilities and can earn allowances so that they can learn to budget, save, and pay tithing on the money they earn.

These suggestions for creating stronger family cultures work in tandem with the culture of the Church. Our strengthened family cultures will be a protection for our children from “the fiery darts of the adversary” (1 Nephi 15:24) embedded in their peer culture, the entertainment and celebrity cultures, the credit and entitlement cultures, and the Internet and media cultures to which they are constantly exposed. Strong family cultures will help our children live in the world and not become “of the world” (John 15:19).

President Joseph Fielding Smith taught: “It is the duty of parents to teach their children these saving principles of the gospel of Jesus Christ, so that they will know why they are to be baptized and that they may be impressed in their hearts with a desire to continue to keep the commandments of God after they are baptized, that they may come back into his presence. Do you, my good brethren and sisters, want your families, your children; do you want to be sealed to your fathers and your mothers before you … ? If so, then you must begin by teaching at the cradle-side. You are to teach by example as well as precept.”2

The proclamation on the family says:

“Husband and wife have a solemn responsibility to love and care for each other and for their children. ‘Children are an heritage of the Lord’ (Psalm 127:3). Parents have a sacred duty to rear their children in love and righteousness, to provide for their physical and spiritual needs, and to teach them to love and serve one another, observe the commandments of God, and be law-abiding citizens wherever they live. …

“… By divine design, fathers are to preside over their families in love and righteousness and are responsible to provide the necessities of life and protection for their families. Mothers are primarily responsible for the nurture of their children. In these sacred responsibilities, fathers and mothers are obligated to help one another as equal partners.”3

I believe it is by divine design that the role of motherhood emphasizes the nurturing and teaching of the next generation. But it is wonderful to see husbands and wives who have worked out real partnerships where they blend together their influence and communicate effectively both about their children and to their children.

The onslaught of wickedness against our children is more subtle and brazen than it has ever been. Building a strong family culture adds another layer of protection for our children, insulating them from worldly influences.

God bless you goodly mothers and fathers in Zion. He has entrusted to your care His eternal children. As parents we partner, even join, with God in bringing to pass His work and glory among His children. It is our sacred duty to do our very best. Of this I testify in the name of Jesus Christ, amen.

# References
1. - Mother’s Day letter from L. Tom Perry to his mother, sent from Saipan, dated May 3, 1945.
2. - Joseph Fielding Smith, in Conference Report, Oct. 1948, 153.
3. - “The Family: A Proclamation to the World,” Liahona and Ensign, Nov. 2010, 129.