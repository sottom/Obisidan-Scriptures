President Thomas S. Monson
President of the Church
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/god-be-with-you-till-we-meet-again?lang=eng)

_As we take the messages of the past two days into our hearts and into our lives, we will be blessed._

My dear brothers and sisters, we have come to the close of another inspiring general conference. I personally have been spiritually fed and uplifted and know that you too have felt the special spirit of this conference.

We offer our heartfelt gratitude to all who have participated in any way. The truths of the gospel have been beautifully taught and reemphasized. As we take the messages of the past two days into our hearts and into our lives, we will be blessed.

As always, the proceedings of this conference will be available in the coming issues of the Ensign and the Liahona magazines. I encourage you to read the talks once again and to ponder the messages contained therein. I have found in my own life that I gain even more from these inspired sermons when I study them in greater depth.

We have had unprecedented coverage of the conference, reaching across the continents and the oceans to people everywhere. Though we are far removed from many of you, we feel of your spirit and send our love and appreciation to you.

To our Brethren who have been released at this conference, may I express the heartfelt gratitude of all of us for your many years of devoted service. Countless are those who have been blessed by your contributions to the work of the Lord.

Brothers and sisters, I have just recently celebrated my 85th birthday, and I am grateful for each year the Lord has granted me. As I reflect upon my life’s experiences, I thank Him for His many blessings to me. As I mentioned in my message this morning, I have felt His hand directing my efforts as I have tried earnestly to serve Him and to serve all of you.

The office of the President of the Church is a demanding one. How grateful I am for my two faithful counselors, who serve by my side and who are always willing and exceptionally able to assist in the work which comes to the First Presidency. I express my gratitude as well for the noble men who comprise the Quorum of the Twelve Apostles. They work tirelessly in the cause of the Master, with the members of the Quorums of the Seventy providing inspired assistance to them.

I wish also to commend you, my brothers and sisters, wherever you are throughout the world, for all that you do in your wards and branches, your stakes and districts. As you willingly fulfill callings when you are asked, you are helping to build the kingdom of God on earth.

May we ever watch over one another, assisting in times of need. Let us not be critical and judgmental but let us be tolerant, ever emulating the Savior’s example of loving-kindness. In that vein, may we willingly serve one another. May we pray for the inspiration to know of the needs of those around us, and then may we go forward and provide assistance.

Let us be of good cheer as we go about our lives. Although we live in increasingly perilous times, the Lord loves us and is mindful of us. He is always on our side as we do what is right. He will help us in time of need. Difficulties come into our lives, problems we do not anticipate and which we would never choose. None of us is immune. The purpose of mortality is to learn and to grow to be more like our Father, and it is often during the difficult times that we learn the most, as painful as the lessons may be. Our lives can also be filled with joy as we follow the teachings of the gospel of Jesus Christ.

The Lord admonished, “Be of good cheer; I have overcome the world.”1 What great happiness this knowledge should bring to us. He lived for us and He died for us. He paid the price for our sins. May we emulate His example. May we show our great gratitude to Him by accepting His sacrifice and living lives that will qualify us to return and one day live with Him.

As I have mentioned at previous conferences, I thank you for your prayers in my behalf. I need them; I feel them. We as General Authorities also remember all of you and pray for our Heavenly Father’s choicest blessings to be with you.

Now, my beloved brothers and sisters, we adjourn for six months. May God be with you until we meet again at that time. In the name of our Savior and Redeemer, even Jesus Christ the Lord, amen.

# References
1. - John 16:33.