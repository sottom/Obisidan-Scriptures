Elder Russell M. Nelson
Of the Quorum of the Twelve Apostles
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/ask-the-missionaries-they-can-help-you?lang=eng)

_All missionaries, younger and older, serve with the sole hope of making life better for other people._

My beloved brothers, sisters, and friends, we extend our love and greetings to each of you. We are thrilled with President Thomas S. Monson’s announcement this morning, which adjusts the minimum age for missionary service to 18 for young men and 19 for young women. Through this option, more of our youth may enjoy the blessings of a mission.

Two years ago and powerfully reaffirmed again this morning, President Monson declared “that every worthy, able young man should prepare to serve a mission. Missionary service is a priesthood duty—an obligation the Lord expects of us who have been given so very much.”1 Again he explained that for young sisters, a mission is a welcome option but not a responsibility. And again he invited many more mature couples to serve.

Preparation for a mission is important. A mission is a voluntary act of service to God and humankind. Missionaries support that privilege with their personal savings. Parents, families, friends, and donors to the General Missionary Fund may also assist. All missionaries, younger and older, serve with the sole hope of making life better for other people.

The decision to serve a mission will shape the spiritual destiny of the missionary, his or her spouse, and their posterity for generations to come. A desire to serve is a natural outcome of one’s conversion, worthiness, and preparation.

In this great worldwide audience, many of you are not affiliated with The Church of Jesus Christ of Latter-day Saints and know very little about us and our missionaries. You are here or tuned in because you want to know more about the Mormons and what our missionaries teach. As you learn more about us, you will find that we share many of the same values. We encourage you to keep all that is good and true and then see if we can add more. In this world filled with challenges, we do need help from time to time. Religion, eternal truth, and our missionaries are vital parts of that help.

Our young missionaries set aside their education, occupation, dating, and whatever else young adults would typically be doing at this stage of life. For 18 to 24 months they put it all on hold because of their deep desire to serve the Lord.2 And some of our missionaries serve in their more mature years of life. I know their families are blessed. In our own family, eight are currently serving as full-time missionaries—three daughters, their husbands, one granddaughter, and one grandson.

Some of you may wonder about the name Mormon. It is a nickname for us. It is not our real name, though we are widely known as Mormons. The term is derived from a book of sacred scripture known as the Book of Mormon.

The true name of the Church is The Church of Jesus Christ of Latter-day Saints. It is the reestablished original Church of Jesus Christ. When He walked upon the earth, He organized His Church. He called Apostles, Seventies, and other leaders to whom He gave priesthood authority to act in His name.3 After Christ and His Apostles passed away, men changed the ordinances and doctrine. The original Church and the priesthood were lost. After the Dark Ages, and under the direction of Heavenly Father, Jesus Christ brought back His Church. Now it lives again, restored and functioning under His divine direction.4

We follow the Lord Jesus Christ and teach of Him. We know that after His glorious triumph over death, the resurrected Lord appeared to His disciples on numerous occasions. He ate with them. He walked with them. Before His final Ascension, He commissioned them to “go … and teach all nations, baptizing them in the name of the Father, and of the Son, and of the Holy Ghost.”5 The Apostles heeded that instruction. They also called upon others to help them fulfill the Lord’s command.

Today, under the direction of modern apostles and prophets, that same charge has been extended to missionaries of The Church of Jesus Christ of Latter-day Saints. These missionaries serve in more than 150 nations. As representatives of the Lord Jesus Christ, they strive to fulfill that divine command—renewed in our day by the Lord Himself—to take the fulness of the gospel abroad and bless the lives of people everywhere.6

Missionaries in their late teens or early 20s are young in ways of the world. But they are blessed with gifts—such as the power of the Holy Spirit, the love of God, and testimonies of the truth—that make them powerful ambassadors of the Lord. They share the good news of the gospel that will bring true joy and everlasting happiness to all who heed their message. And in many instances they do so in a country and a language foreign to them.

Missionaries strive to follow Jesus Christ in both word and deed. They preach of Jesus Christ and of His Atonement.7 They teach of the literal Restoration of Christ’s ancient Church through the Lord’s first latter-day prophet, Joseph Smith.

You may have previously encountered, or even ignored, our missionaries. My hope is that you will not fear them but learn from them. They can be a heaven-sent resource to you.

That happened to Jerry, a Protestant gentleman in his mid-60s who lives in Mesa, Arizona. Jerry’s father was a Baptist minister; his mother, a Methodist minister. One day Jerry’s close friend Pricilla shared with him the pain she felt from the death of her child during childbirth and a bitter divorce that occurred shortly thereafter. Struggling as a single mother, Pricilla has four children—three daughters and a son. As she opened her heart to Jerry, she confessed that she was thinking of taking her own life. With all the strength and love Jerry could muster, he tried to help her understand that her life had value. He invited her to attend his church, but Pricilla explained that she had given up on God.

Jerry did not know what to do. Later, while watering trees in his yard, this man of faith prayed to God for guidance. As he prayed, he heard a voice in his mind saying, “Stop the boys on the bikes.” Jerry, a little bewildered, wondered what this meant. As he reflected on this impression, he gazed up the street and saw two young men in white shirts and ties riding bicycles toward his home. Stunned by this “coincidence,” he watched them ride by. Then, realizing that the situation required him to act, he shouted out, “Hey, you, please stop! I need to talk to you!”

With a puzzled but excited look, the young men stopped. As they approached, Jerry noticed that they wore name tags identifying them as missionaries in The Church of Jesus Christ of Latter-day Saints. Jerry looked at them and said, “This may sound a little weird, but I was praying and was told to ‘stop the boys on the bikes.’ I looked up the street, and here you are. Can you help me?”

The missionaries smiled, and one said, “Yes, I am sure we can.”

Jerry explained the worrisome plight of Pricilla. Soon the missionaries were meeting with Pricilla, her children, and Jerry. They discussed the purpose of life and God’s eternal plan for them. Jerry, Pricilla, and her children grew in faith through sincere prayer, their study of the Book of Mormon, and the loving fellowship with members of the Church. Jerry’s already strong faith in Jesus Christ grew even stronger. Pricilla’s doubts and thoughts of suicide turned to hope and happiness. They were baptized and became members of Christ’s restored Church.8

Yes, missionaries can help in many ways. For example, some of you might want to know more about your ancestors. You may know the names of your parents and your four grandparents, but what about your eight great-grandparents? Do you know their names? Would you like to know more about them? Ask the missionaries! They can help you!9 They have ready access to the vast family history records of The Church of Jesus Christ of Latter-day Saints.

Some of you are members but not presently participating. You love the Lord and often think of returning to His fold. But you don’t know how to start. I suggest that you ask the missionaries!10 They can help you! They can also help by teaching your loved ones. We and the missionaries love you and desire to bring joy and the light of the gospel back into your lives.

Some of you may want to know how to conquer an addiction or live longer and enjoy better health. Ask the missionaries! They can help you! Independent studies have shown that, as a group, members of The Church of Jesus Christ of Latter-day Saints are a healthy lot. Their death rates are among the lowest and their longevity greater than any yet reported in any well-defined group studied over a lengthy period of time in the United States.11

Some of you may feel that life is busy and frenetic, yet down deep in your heart you feel a gnawing emptiness, without direction or purpose. Ask the missionaries! They can help you! They can help you to learn more about the true purpose of life—why you are here on earth and where you are going after death. You can learn how the restored gospel of Jesus Christ will bless your life beyond anything you can presently even imagine.

If you have concerns about your family, ask the missionaries! They can help you! Strengthening marriages and families is of utmost importance to Latter-day Saints. Families can be together forever. Ask the missionaries to teach you how this is possible for your family.

Missionaries can also help you with your desire for greater knowledge. The human spirit yearns for enlightenment. Whether truth comes from a scientific laboratory or by revelation from God, we seek it! The glory of God indeed is intelligence.12

Increase in learning includes spiritual as well as temporal knowledge. We stress the importance of understanding sacred scriptures. An independent study recently found that Latter-day Saints were the most knowledgeable about Christianity and the Bible.13 If you want to understand the Bible better, to understand the Book of Mormon better, and gain a broader comprehension of the brotherhood of man and the fatherhood of God, ask the missionaries! They can help you!

Many of you have a deep desire to help people in need. Because we follow Jesus Christ, Latter-day Saints are also compelled by that insatiable urge.14 Anyone may join with us to help the needy and provide relief to victims of disaster anywhere in the world. If you want to participate, ask the missionaries! They can help you!



And if you want to know more about life after death, about heaven, about God’s plan for you; if you want to know more about the Lord Jesus Christ, His Atonement, and the Restoration of His Church as it was originally established, ask the missionaries! They can help you!

I know that God lives. Jesus is the Christ. His Church has been restored. Fervently I pray that God may bless each of you and each of our precious missionaries. In the name of Jesus Christ, amen.

# References
1. - Thomas S. Monson, “As We Meet Together Again,” Liahona and Ensign, Nov. 2010, 5–6.
2. - See Doctrine and Covenants 4:3.
3. - See Matthew 10:1; Luke 6:13; 10:1; Ephesians 4:11–12.
4. - See Doctrine and Covenants 1:30.
5. - Matthew 28:19.
6. - See Doctrine and Covenants 68:8; 84:62; 112:28.
7. - See 1 Corinthians 2:2; 2 Nephi 25:26.
8. - Personal communication from W. Tracy Watson, former president of the Arizona Mesa Mission.
9. - Where I have phrased the invitation to “ask the missionaries,” you could also ask a friend who is a member of the Church for assistance.
10. - Actively participating relatives, friends, and Church leaders would also be pleased to assist.
11. - See James E. Enstrom and Lester Breslow, “Lifestyle and Reduced Mortality among Active California Mormons, 1980–2004,” Preventive Medicine, vol. 46 (2008), 135.
12. - See Doctrine and Covenants 93:36.
13. - See U.S. Religious Knowledge Survey (Pew Forum on Religion and Public Life, Sept. 28, 2010), 7.
14. - See Ram Cnaan, Van Evans, and Daniel W. Curtis, Called to Serve: The Prosocial Behavior of Active Latter-day Saints (University of Pennsylvania School of Social Policy and Practice, 2012); “Mormon Volunteerism Highlighted in New Study” (Mar. 16, 2012), http://www.mormonnewsroom.org/article/mormon-volunteerism-report; Mormons in America: Certain in Their Beliefs, Uncertain of Their Place in Society (Pew Forum on Religion and Public Life, Jan. 12, 2012), 43; Robert D. Putnam and David E. Campbell, American Grace: How Religion Divides and Unites Us (2010), 444–54.