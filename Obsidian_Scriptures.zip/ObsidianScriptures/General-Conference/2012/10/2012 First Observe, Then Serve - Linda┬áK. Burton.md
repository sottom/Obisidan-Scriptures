Linda K. Burton
Relief Society General President
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/first-observe-then-serve?lang=eng)

_With practice, each of us can become more like the Savior as we serve God’s children._

One of the greatest evidences we have that our beloved prophet, President Thomas S. Monson, is the Lord’s chosen servant is that he has learned to follow the Savior’s example—serving individually, one by one. Those of us who have entered the waters of baptism have covenanted to do the same. We have covenanted to “always remember [the Savior] and keep his commandments,”1 and He has said, “This is my commandment, That ye love one another, as I have loved you.”2

Notice how the following words from President Monson include the same invitation: “We are surrounded by those in need of our attention, our encouragement, our support, our comfort, our kindness. … We are the Lord’s hands here upon the earth, with the mandate to serve and to lift His children. He is dependent upon each of us.”3

Did you hear it—the invitation to love one another? For some, serving or ministering one by one, following the Savior’s example, doesn’t come easily. But with practice, each of us can become more like the Savior as we serve God’s children. To help us better love one another, I would like to suggest four words to remember: “First observe, then serve.”

Almost 40 years ago my husband and I went to the temple for our Friday night date. We had been married only a short time, and I was nervous because this was only my second time as a newlywed. A sister sitting next to me must have noticed. She leaned over and whispered reverently, “Don’t worry. I’ll help you.” My fears were calmed, and I was able to enjoy the rest of the temple session. She first observed, then served.

We are all invited to follow Jesus’s teachings and to minister to others. This invitation is not limited to angelic sisters. As I share a few everyday examples of members who have learned to first observe and then serve, listen for the teachings of Jesus they illustrate.

A six-year-old Primary child said: “When I was chosen to be a class helper, I could choose a friend to work with me. I picked [a boy in my class who bullied me] because he never gets chosen by others. I wanted to make him feel good.”4



What did this child observe? He noticed that the class bully never got chosen. What did he do to serve? He simply chose him to be his friend as a class helper. Jesus taught, “Love your enemies, bless them that curse you, do good to them that hate you.”5

In one ward, Aaronic Priesthood holders first observed and now serve in a meaningful way. Every week the young men arrive early and stand outside the meetinghouse in rain, snow, or blistering heat, awaiting the arrival of the many elderly members in their ward. They lift wheelchairs and walkers out of cars, provide sturdy arms to grasp, and patiently escort the silver-haired seniors into the building. They are truly doing their duty to God. As they observe and then serve, they are living examples of the Savior’s teaching: “Inasmuch as ye have done it unto one of the least of these my brethren, ye have done it unto me.”6 As the new youth curriculum is implemented, the eyes of these young men will undoubtedly be opened to even more opportunities to serve in a Christlike way.

Observing and serving sometimes requires great effort. An inspired young woman named Alexandria noticed that her cousin Madison was unable to complete her own Personal Progress requirements because she suffered from severe autism. Alexandria rallied the young women in her ward, counseled with her leaders, and determined to do something for Maddy that she could not do herself. Each of the young women completed a portion of the Personal Progress activities and projects vicariously to enable Maddy to receive her own medallion.7

These young women will progress well into roles of motherhood and Relief Society sisterhood because they are learning to first observe, then serve in charitable ways.

President Monson has reminded us that charity, “the pure love of Christ”8—or in other words, observing and serving—“is evident when an elderly widow is remembered and taken to ward functions” and “when the sister sitting alone in Relief Society receives the invitation, ‘Come—sit by us.’”9 The golden rule is applicable here: “Whatsoever ye would that men [or women] should do to you, do ye even so to them.”10

An observant husband served in two important ways. He relates:

“I was assisting my wife one Sunday with her Primary class full of energetic seven-year-olds. As Primary sharing time started, I noticed one of the class members huddled on her chair and obviously not feeling well. The Spirit whispered to me that she needed comfort, so I sat by her and quietly asked what was wrong. She didn’t answer … , so I began to sing softly to her.

“The Primary was learning a new song, and when we sang, ‘If I listen with my heart I hear the Savior’s voice,’ I began to feel the most incredible light and warmth fill my soul. … I received a personal testimony of our Savior’s love for her … and for me. … I learned that we are [the Savior’s] hands when we serve the one.”11

Not only did this Christlike brother notice the need to help his wife with a class full of energetic seven-year-olds; he also gave individual service to a child in need. He followed the Savior, who taught, “The works which ye have seen me do that shall ye also do.”12

Recently a flood opened many opportunities for disciples of Jesus Christ to first observe and then serve. Men, women, teenagers, and children saw businesses and homes destroyed and dropped everything to help clean and repair damaged structures. Some observed the need to help with the overwhelming task of doing laundry. Others painstakingly wiped down photographs, legal documents, letters, and other important papers and then carefully hung them out to dry to preserve whatever they could. Observing and then serving is not always convenient and doesn’t always fit our own timetable.

What better place to first observe and then serve than in the home? An example from the life of Elder Richard G. Scott illustrates:

“One night our little son Richard, who had a heart problem, awoke crying. … Normally my wife always got up to take care of a crying baby, but this time I said, ‘I’ll take care of him.’

“Because of his problem, when he began to cry, his little heart would pound very rapidly. He would throw up and soil the bed clothing. That night I held him very close to try to calm his racing heart and stop his crying as I changed his clothes and put on new bedsheets. I held him until he went to sleep. I didn’t know then that just a few months later he would pass away. I will always remember holding him in my arms in the middle of that night.”13

Jesus said, “Whosoever will be great among you, let him be your minister.”14

Sometimes we are tempted to serve in a way that we want to serve and not necessarily in the way that is needed at the moment. When Elder Robert D. Hales taught the principle of provident living, he shared the example of buying a gift for his wife. She asked, “Are you buying this for me or for you?”15 If we adapt that question to ourselves as we serve and ask, “Am I doing this for the Savior, or am I doing this for me?” our service will more likely resemble the ministry of the Savior. The Savior asked, and so should we, “What will ye that I shall do unto you?”16

A few weeks ago, I was hurried and frazzled, with too many to-dos on my list. I had hoped to go to the temple that day but felt I was just too busy. As soon as that thought of being too busy for temple service crossed my mind, it awakened me to what I most needed to do. I left my office to walk over to the Salt Lake Temple, wondering when I was going to recapture the time I was losing. Thankfully, the Lord is patient and merciful and taught me a beautiful lesson that day.

As I sat down in the session room, a young sister leaned over and reverently whispered, “I’m really nervous. This is only my second time in the temple. Could you please help me?” How could she ever have known that those words were exactly what I needed to hear? She didn’t know, but Heavenly Father knew. He had observed my greatest need. I needed to serve. He prompted this humble young sister to serve me by inviting me to serve her. I assure you that I was the one who benefited most.

I acknowledge with deep gratitude the many Christlike people who have served our family throughout the years. I express heartfelt appreciation to my beloved husband and family, who serve selflessly and with great love.

May we all seek to first observe, then serve. As we do so, we are keeping covenants, and our service, like President Monson’s, will be evidence of our discipleship. I know the Savior lives. His Atonement enables us to live His teachings. I know President Monson is our prophet today. In the name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 20:77.
2. - John 15:12.
3. - Thomas S. Monson, “What Have I Done for Someone Today?” Liahona and Ensign, Nov. 2009, 86.
4. - Canyon H., “A Good Choice,” Friend, Jan. 2012, 31.
5. - Matthew 5:44.
6. - Matthew 25:40.
7. - See “For Madison,” lds.org/youth/video/for-madison.
8. - Moroni 7:47.
9. - Thomas S. Monson, “Charity Never Faileth,” Liahona and Ensign, Nov. 2010, 125; see also Daughters in My Kingdom: The History and Work of Relief Society (2011), 101.
10. - 3 Nephi 14:12.
11. - Al VanLeeuwen, “Serving the One,” Liahona, Aug. 2012, 19; Ensign, Aug. 2012, 15; see also Sally DeFord, “If I Listen with My Heart,” 2011 Outline for Sharing Time, 28.
12. - 3 Nephi 27:21.
13. - Richard G. Scott, “The Eternal Blessings of Marriage,” Liahona and Ensign, May 2011, 96.
14. - Matthew 20:26.
15. - Robert D. Hales, “Becoming Provident Providers Temporally and Spiritually,” Liahona and Ensign, May 2009, 9.
16. - Matthew 20:32.