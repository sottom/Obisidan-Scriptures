President Henry B. Eyring
First Counselor in the First Presidency
10-2012
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2012/10/where-is-the-pavilion?lang=eng)

_The pavilion that seems to intercept divine aid does not cover God but occasionally covers us. God is never hidden, yet sometimes we are._

In the depths of his anguish in Liberty Jail, the Prophet Joseph Smith cried out: “O God, where art thou? And where is the pavilion that covereth thy hiding place?”1 Many of us, in moments of personal anguish, feel that God is far from us. The pavilion that seems to intercept divine aid does not cover God but occasionally covers us. God is never hidden, yet sometimes we are, covered by a pavilion of motivations that draw us away from God and make Him seem distant and inaccessible. Our own desires, rather than a feeling of “Thy will be done,”2 create the feeling of a pavilion blocking God. God is not unable to see us or communicate with us, but we may be unwilling to listen or submit to His will and His time.

Our feelings of separation from God will diminish as we become more childlike before Him. That is not easy in a world where the opinions of other human beings can have such an effect on our motives. But it will help us recognize this truth: God is close to us and aware of us and never hides from His faithful children.

My three-year-old granddaughter illustrated the power of innocence and humility to connect us with God. She went with her family to the open house of the Brigham City Temple in Utah. In one of the rooms of that beautiful building, she looked around and asked, “Mommy, where is Jesus?” Her mother explained that she would not see Jesus in the temple, but she would be able to feel His influence in her heart. Eliza carefully considered her mother’s response and then seemed satisfied and said, “Oh, Jesus is gone helping someone,” she concluded.

No pavilion obscured Eliza’s understanding or obstructed her view of reality. God is close to her, and she feels close to Him. She knew that the temple is the house of the Lord but also understood that the resurrected and glorified Jesus Christ has a body and can only be in one place at a time.3 If He was not at His house, she recognized that He must be in another place. And from what she knows of the Savior, she knew that He would be somewhere doing good for His Father’s children. It was clear that she had hoped to see Jesus, not for a confirming miracle of His existence but simply because she loved Him.

The Spirit could reveal to her childlike mind and heart the comfort all of us need and want. Jesus Christ lives, knows us, watches over us, and cares for us. In moments of pain, loneliness, or confusion, we do not need to see Jesus Christ to know that He is aware of our circumstances and that His mission is to bless.

I know from my own life that Eliza’s experience can be our own long after we leave childhood. In the early years of my career, I worked hard to secure a tenured professorship at Stanford University. I thought I had made a good life for myself and for my family. We lived close to my wife’s parents in very comfortable surroundings. By the world’s standards, I had achieved success. But I was given by the Church the chance to leave California and go to Ricks College in Rexburg, Idaho. My lifetime professional objectives might have been a pavilion dividing me from a loving Father who knew better than I did what my future could hold. But I was blessed to know that whatever success I had in my career and family life to that point was a gift from God. And so, like a child, I knelt in prayer to ask what I should do. I was able to hear a quiet voice in my mind that said, “It’s my school.” There was no pavilion shielding me from God. In faith and humility, I submitted my will to His and felt His care and closeness.

My years at Ricks College, during which I tried to seek God’s will and do it, kept the pavilion from covering me or obscuring God’s active role in my life. As I sought to do His work, I felt close to Him and felt assurance that He knew of my affairs and cared deeply for my happiness. But as they had at Stanford, worldly motivations began to present themselves to me. One was an attractive job offer, extended just as I was finishing my fifth year as president of Ricks College. I considered the offer and prayed about it and even discussed it with the First Presidency. They responded with warmth and a little humor but certainly not with any direction. President Spencer W. Kimball listened to me describe the offer I had received from a large corporation and said: “Well, Hal, that sounds like a wonderful opportunity! And if we ever needed you, we’d know where to find you.” They would have known where to find me, but my desires for professional success might have created a pavilion that would make it hard for me to find God and harder for me to listen to and follow His invitations.

My wife, sensing this, had a strong impression that we were not to leave Ricks College. I said, “That’s good enough for me.” But she insisted, wisely, that I must get my own revelation. And so I prayed again. This time I did receive direction, in the form of a voice in my mind that said, “I’ll let you stay at Ricks College a little longer.” My personal ambitions might have clouded my view of reality and made it hard for me to receive revelation.

Thirty days after I was blessed with the inspired decision to turn down the job offer and stay at Ricks College, the Teton Dam burst nearby. God knew that dam would burst and that hundreds of people would need help. He let me seek counsel and gain His permission to stay at Ricks College. He knew all the reasons that my service might still be valuable at the college and in Rexburg. So I was there to ask Heavenly Father frequently in prayer that He would have me do those things that would help the people whose property and lives had been damaged. I spent hours working with other people to clear mud and water from homes. My desire to know and do His will gave me a soul-stretching opportunity.

That incident illustrates another way we can create a barrier to knowing God’s will or feeling His love for us: we can’t insist on our timetable when the Lord has His own. I thought I had spent enough time in my service in Rexburg and was in a hurry to move on. Sometimes our insistence on acting according to our own timetable can obscure His will for us.

In Liberty Jail, the Prophet Joseph asked the Lord to punish those who persecuted the members of the Church in Missouri. His prayer was for sure and swift retribution. But the Lord responded that in “not many years hence,”4 He would deal with those enemies of the Church. In the 24th and 25th verses of the 121st section of the Doctrine and Covenants, He says:

“Behold, mine eyes see and know all their works, and I have in reserve a swift judgment in the season thereof, for them all;

“For there is a time appointed for every man, according as his works shall be.”5

We remove the pavilion when we feel and pray, “Thy will be done” and “in Thine own time.” His time should be soon enough for us since we know that He wants only what is best.

One of my daughters-in-law spent many years feeling that God had placed a pavilion over her. She was a young mother of three who longed for more children. After two miscarriages, her prayers of pleading grew anguished. As more barren years passed, she felt tempted to anger. When her youngest went off to school, the emptiness of her house seemed to mock her focus on motherhood—so did the unplanned and even unwanted pregnancies of acquaintances. She felt as committed and consecrated as Mary, who declared, “Behold the handmaid of the Lord.”6 But although she spoke these words in her heart, she could hear nothing in reply.

Hoping to lift her spirits, her husband invited her to join him on a business trip to California. While he attended meetings, she walked along the beautiful, empty beach. Her heart ready to burst, she prayed aloud. For the first time, she asked not for another child but for a divine errand. “Heavenly Father,” she cried, “I will give you all of my time; please show me how to fill it.” She expressed her willingness to take her family wherever they might be required to go. That prayer produced an unexpected feeling of peace. It did not satisfy her mind’s craving for certainty, but for the first time in years, it calmed her heart.

The prayer removed the pavilion and opened the windows of heaven. Within two weeks she learned that she was expecting a child. The new baby was just one year old when a mission call came to my son and my daughter-in-law. Having promised to go and do anything, anywhere, she put fear aside and took her children overseas. In the mission field she had another child—on a missionary transfer day.

Submitting fully to heaven’s will, as this young mother did, is essential to removing the spiritual pavilions we sometimes put over our heads. But it does not guarantee immediate answers to our prayers.

Abraham’s heart seems to have been right long before Sarah conceived Isaac and before they received their promised land. Heaven had other purposes to fulfill first. Those purposes included not only building Abraham and Sarah’s faith but also teaching them eternal truths that they shared with others on their long, circuitous route to the land prepared for them. The Lord’s delays often seem long; some last a lifetime. But they are always calculated to bless. They need never be times of loneliness or sorrow or impatience.

Although His time is not always our time, we can be sure that the Lord keeps His promises. For any of you who now feel that He is hard to reach, I testify that the day will come that we all will see Him face to face. Just as there is nothing now to obscure His view of us, there will be nothing to obscure our view of Him. We will all stand before Him, in person. Like my granddaughter, we want to see Jesus Christ now, but our certain reunion with Him at the judgment bar will be more pleasing if we first do the things that make Him as familiar to us as we are to Him. As we serve Him, we become like Him, and we feel closer to Him as we approach that day when nothing will hide our view.

The movement toward God can be ongoing. “Come, ye blessed of my Father, inherit the kingdom prepared for you from the foundation of the world,”7 the Savior teaches. And then He tells us how:

“For I was an hungred, and ye gave me meat: I was thirsty, and ye gave me drink: I was a stranger, and ye took me in:

“Naked, and ye clothed me: I was sick, and ye visited me: I was in prison, and ye came unto me.

“Then shall the righteous answer him, saying, Lord, when saw we thee an hungred, and fed thee? or thirsty, and gave thee drink?

“When saw we thee a stranger, and took thee in? or naked, and clothed thee?

“Or when saw we thee sick, or in prison, and came unto thee?

“And the King shall answer and say unto them, Verily I say unto you, Inasmuch as ye have done it unto one of the least of these my brethren, ye have done it unto me.”8

As we do what He would have us do for His Father’s children, the Lord considers it kindness to Him, and we will feel closer to Him as we feel His love and His approval. In time we will become like Him and will think of the Judgment Day with happy anticipation.

The pavilion that seems to be hiding you from God may be fear of man rather than this desire to serve others. The Savior’s only motivation was to help people. Many of you, as I have, have felt fear in approaching someone you have offended or who has hurt you. And yet I have seen the Lord melt hearts time after time, including my own. And so I challenge you to go for the Lord to someone, despite any fear you may have, to extend love and forgiveness. I promise you that as you do, you will feel the love of the Savior for that person and His love for you, and it will not seem to come from a great distance. For you, that challenge may be in a family, it may be in a community, or it may be across a nation.

But if you go for the Lord to bless others, He will see and reward it. If you do this often enough and long enough, you will feel a change in your very nature through the Atonement of Jesus Christ. Not only will you feel closer to Him, but you will also feel more and more that you are becoming like Him. Then, when you do see Him, as we all will, it will be for you as it was for Moroni when he said: “And now I bid unto all, farewell. I soon go to rest in the paradise of God, until my spirit and body shall again reunite, and I am brought forth triumphant through the air, to meet you before the pleasing bar of the great Jehovah, the Eternal Judge of both quick and dead. Amen.”9

If we serve with faith, humility, and a desire to do God’s will, I testify that the judgment bar of the great Jehovah will be pleasing. We will see our loving Father and His Son as They see us now—with perfect clarity and with perfect love. In the sacred name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 121:1.
2. - See Matthew 6:10; Luke 11:2; 3 Nephi 13:10; Ether 12:29; Doctrine and Covenants 109:44; Moses 4:2.
3. - See Doctrine and Covenants 130:22.
4. - Doctrine and Covenants 121:15.
5. - Doctrine and Covenants 121:24–25.
6. - Luke 1:38.
7. - Matthew 25:34.
8. - Matthew 25:35–40.
9. - Moroni 10:34.