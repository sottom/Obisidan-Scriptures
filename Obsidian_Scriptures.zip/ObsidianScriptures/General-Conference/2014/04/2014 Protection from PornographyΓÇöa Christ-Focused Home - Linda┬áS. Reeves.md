Linda S. Reeves
Second Counselor in the Relief Society General Presidency
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/protection-from-pornography-a-christ-focused-home?lang=eng)

_The greatest filter in the world … is the personal internal filter that comes from a deep and abiding testimony._

Dear brothers and sisters, today I am blessed to have my 13 oldest grandchildren in the congregation. This has caused me to ask, “What do I want my grandchildren to know?” This morning I would like to talk frankly to my family and to yours.

We as leaders are increasingly concerned about the destruction that pornography is causing in the lives of Church members and their families. Satan is attacking with unprecedented fury.

One reason we are here on earth is to learn to manage the passions and feelings of our mortal bodies. These God-given feelings help us want to marry and have children. The intimate marriage relationship between a man and a woman that brings children into mortality is also meant to be a beautiful, loving experience that binds together two devoted hearts, unites both spirit and body, and brings a fulness of joy and happiness as we learn to put each other first. President Spencer W. Kimball taught that in marriage, “the spouse … becomes preeminent in the life of the husband or wife, and … [no] other interest [or] person [or] thing shall ever take precedence over the companion spouse. …

“Marriage presupposes total allegiance and total fidelity.”1

Many years ago one of our children was noticeably distressed. I stepped into her bedroom, where she opened up her heart and explained to me that she had been at a friend’s home and had accidentally seen startling and disturbing images and actions on the television between a man and a woman without clothing. She began sobbing and expressed how horrible she felt about what she had seen and wished she could get it out of her mind. I was so grateful that she would confide in me, giving me a chance to soothe her innocent and aching heart and help her know how to get relief through our Savior’s Atonement. I remember the sacred feelings I had as we knelt together, as mother and daughter, and petitioned the help of our Heavenly Father.

Many children, youth, and adults are innocently exposed to pornography, but a growing number of both men and women are choosing to view it and are drawn back repeatedly until it becomes an addiction. These individuals may desire with all of their hearts to get out of this trap but often cannot overcome it on their own. How grateful we are when these loved ones choose to confide in us as parents or a Church leader. We would be wise not to react with shock, anger, or rejection, which may cause them to be silent again.

We as parents and leaders need to counsel with our children and youth on an ongoing basis, listening with love and understanding. They need to know the dangers of pornography and how it overtakes lives, causing loss of the Spirit, distorted feelings, deceit, damaged relationships, loss of self-control, and nearly total consumption of time, thought, and energy.

Pornography is more vile, evil, and graphic than ever before. As we counsel with our children, together we can create a family plan with standards and boundaries, being proactive to protect our homes with filters on electronic devices. Parents, are we aware that mobile devices with Internet capacity, not computers, are the biggest culprit?2

Young people and adults, if you are caught in Satan’s trap of pornography, remember how merciful our beloved Savior is. Do you realize how deeply the Lord loves and cherishes you, even now? Our Savior has the power to cleanse and heal you. He can remove the pain and sorrow you feel and make you clean again through the power of His Atonement.



We as leaders are also greatly concerned about the spouses and families of those suffering from pornography addiction. Elder Richard G. Scott has pleaded: “If you are free of serious sin yourself, don’t suffer needlessly the consequences of another’s sins. … You can feel compassion. … Yet you should not take upon yourself a feeling of responsibility for those acts.”3 Know that you are not alone. There is help. Addiction recovery meetings for spouses are available, including phone-in meetings, which allow spouses to call in to a meeting and participate from their own homes.

Brothers and sisters, how do we protect our children and youth? Filters are useful tools, but the greatest filter in the world, the only one that will ultimately work, is the personal internal filter that comes from a deep and abiding testimony of our Heavenly Father’s love and our Savior’s atoning sacrifice for each one of us.

How do we lead our children to deep conversion and to access our Savior’s Atonement? I love the prophet Nephi’s declaration of what his people did to fortify the youth of his day: “We talk of Christ, we rejoice in Christ, we preach of Christ, [and] we prophesy of Christ … that our children may know to what source they may look for a remission of their sins.”4

How can we do this in our homes? Some of you have heard me tell how overwhelmed my husband, Mel, and I felt as the parents of four young children. As we faced the challenges of parenting and keeping up with the demands of life, we were desperate for help. We prayed and pleaded to know what to do. The answer that came was clear: “It is OK if the house is a mess and the children are still in their pajamas and some responsibilities are left undone. The only things that really need to be accomplished in the home are daily scripture study and prayer and weekly family home evening.”

We were trying to do these things, but they were not always the priority and, amidst the chaos, were sometimes neglected. We changed our focus and tried not to worry about the less-important things. Our focus became to talk, rejoice, preach, and testify of Christ by striving to daily pray and study the scriptures and have weekly family home evening.

A friend recently cautioned, “When you ask the sisters to read the scriptures and pray more, it stresses them out. They already feel like they have too much to do.”

Brothers and sisters, because I know from my own experiences, and those of my husband, I must testify of the blessings of daily scripture study and prayer and weekly family home evening. These are the very practices that help take away stress, give direction to our lives, and add protection to our homes. Then, if pornography or other challenges do strike our families, we can petition the Lord for help and expect great guidance from the Spirit, knowing that we have done what our Father has asked us to do.

Brothers and sisters, if these have not been practices in our homes, we can all begin now. If our children are older and refuse to join us, we can start with ourselves. As we do, the influence of the Spirit will begin to fill our homes and our lives and, over time, children may respond.

Remember that living Apostles have also promised that as we search out our ancestors and prepare our own family names for the temple, we will be protected now and throughout our lives as we keep ourselves worthy of a temple recommend.5 What promises!

Youth, take responsibility for your own spiritual well-being. Turn off your phone if necessary, sing a Primary song, pray for help, think of a scripture, walk out of a movie, picture the Savior, take the sacrament worthily, study For the Strength of Youth, be an example to your friends, confide in a parent, go see your bishop, ask for help, and seek professional counseling, if needed.

What do I want my grandchildren to know? I want them and you to know that I know the Savior lives and loves us. He has paid the price for our sins, but we must kneel before our Father in Heaven, in deep humility, confessing our sins, and plead with Him for forgiveness. We must want to change our hearts and our desires and be humble enough to seek the help and forgiveness of those we may have hurt or forsaken.

I know that Joseph Smith saw God, our Heavenly Father, and our Savior, Jesus Christ. I testify that we have a living prophet upon the earth, President Thomas S. Monson. I also testify that we will never be led astray if we heed the counsel of the prophet of God. I testify of the power of our covenants and the blessings of the temple.

I know that the Book of Mormon is true! I cannot explain the power of this great book. I only know that, coupled with prayer, the Book of Mormon carries the power to protect families, strengthen relationships, and give personal confidence before the Lord. I testify of these things in the holy name of Jesus Christ, amen.

# References
1. - Teachings of Presidents of the Church: Spencer W. Kimball (2006), 199–200.
2. - See Clay Olsen, “What Teens Wish Parents Knew” (address given at Utah Coalition Against Pornography Conference, Mar. 22, 2014); utahcoalition.org.
3. - Richard G. Scott, “To Be Free of Heavy Burdens,” Ensign or Liahona, Nov. 2002, 88.
4. - 2 Nephi 25:26.
5. - See David A. Bednar, “The Hearts of the Children Shall Turn,” Ensign or Liahona, Nov. 2011, 24–27; Richard G. Scott, “The Joy of Redeeming the Dead,” Ensign or Liahona, Nov. 2012, 93–95; Neil L. Andersen, “Find Our Cousins!” (address given at RootsTech 2014 Family History Conference, Feb. 8, 2014); lds.org/prophets-and-apostles/unto-all-the-world/find-our-cousins.