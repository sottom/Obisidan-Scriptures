President Thomas S. Monson
President of the Church
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/love-the-essence-of-the-gospel?lang=eng)

_We cannot truly love God if we do not love our fellow travelers on this mortal journey._

My beloved brothers and sisters, when our Savior ministered among men, He was asked by the inquiring lawyer, “Master, which is the great commandment in the law?”

Matthew records that Jesus responded:

“Thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy mind.

“This is the first and great commandment.

“And the second is like unto it, Thou shalt love thy neighbour as thyself.”1

Mark concludes the account with the Savior’s statement: “There is none other commandment greater than these.”2

We cannot truly love God if we do not love our fellow travelers on this mortal journey. Likewise, we cannot fully love our fellowmen if we do not love God, the Father of us all. The Apostle John tells us, “This commandment have we from him, That he who loveth God love his brother also.”3 We are all spirit children of our Heavenly Father and, as such, are brothers and sisters. As we keep this truth in mind, loving all of God’s children will become easier.

Actually, love is the very essence of the gospel, and Jesus Christ is our Exemplar. His life was a legacy of love. The sick He healed; the downtrodden He lifted; the sinner He saved. At the end the angry mob took His life. And yet there rings from Golgotha’s hill the words: “Father, forgive them; for they know not what they do”4—a crowning expression in mortality of compassion and love.

There are many attributes which are manifestations of love, such as kindness, patience, selflessness, understanding, and forgiveness. In all our associations, these and other such attributes will help make evident the love in our hearts.

Usually our love will be shown in our day-to-day interactions one with another. All important will be our ability to recognize someone’s need and then to respond. I have always cherished the sentiment expressed in the short poem:





I have wept in the night

For the shortness of sight

That to somebody’s need made me blind;

But I never have yet

Felt a tinge of regret

For being a little too kind.5





I recently was made aware of a touching example of loving kindness—one that had unforeseen results. The year was 1933, when because of the Great Depression, employment opportunities were scarce. The location was the eastern part of the United States. Arlene Biesecker had just graduated from high school. After a lengthy search for employment, she was finally able to obtain work at a clothing mill as a seamstress. The mill workers were paid only for each of the correctly completed pieces they sewed together daily. The more pieces they produced, the more they were paid.

One day shortly after starting at the mill, Arlene was faced with a procedure that had her confused and frustrated. She sat at her sewing machine trying to unpick her unsuccessful attempt to complete the piece on which she was working. There seemed to be no one to help her, for all of the other seamstresses were hurrying to complete as many pieces as they could. Arlene felt helpless and hopeless. Quietly, she began to cry.

Across from Arlene sat Bernice Rock. She was older and more experienced as a seamstress. Observing Arlene’s distress, Bernice left her own work and went to Arlene’s side, kindly giving her instruction and help. She stayed until Arlene gained confidence and was able to successfully complete the piece. Bernice then went back to her own machine, having missed the opportunity to complete as many pieces as she could have, had she not helped.

With this one act of loving kindness, Bernice and Arlene became lifelong friends. Each eventually married and had children. Sometime in the 1950s, Bernice, who was a member of the Church, gave Arlene and her family a copy of the Book of Mormon. In 1960, Arlene and her husband and children were baptized members of the Church. Later they were sealed in a holy temple of God.

As a result of the compassion shown by Bernice as she went out of her way to help one whom she didn’t know but who was in distress and needed assistance, countless individuals, both living and dead, now enjoy the saving ordinances of the gospel.

Every day of our lives we are given opportunities to show love and kindness to those around us. Said President Spencer W. Kimball: “We must remember that those mortals we meet in parking lots, offices, elevators, and elsewhere are that portion of mankind God has given us to love and to serve. It will do us little good to speak of the general brotherhood of mankind if we cannot regard those who are all around us as our brothers and sisters.”6

Often our opportunities to show our love come unexpectedly. An example of such an opportunity appeared in a newspaper article in October 1981. So impressed was I with the love and compassion related therein that I have kept the clipping in my files for over 30 years.

The article indicates that an Alaska Airlines nonstop flight from Anchorage, Alaska, to Seattle, Washington—a flight carrying 150 passengers—was diverted to a remote Alaskan town in order to transport a gravely injured child. The two-year-old boy had severed an artery in his arm when he fell on a piece of glass while playing near his home. The town was 450 miles (725 km) south of Anchorage and was certainly not on the flight path. However, medics at the scene had sent out a frantic request for help, and so the flight was diverted to pick up the child and take him to Seattle so that he could be treated in a hospital.

When the flight touched down near the remote town, medics informed the pilot that the boy was bleeding so badly he could not survive the flight to Seattle. A decision was made to fly another 200 miles (320 km) out of the way to Juneau, Alaska, the nearest city with a hospital.

After transporting the boy to Juneau, the flight headed for Seattle, now hours behind schedule. Not one passenger complained, even though most of them would miss appointments and connecting flights. In fact, as the minutes and hours ticked by, they took up a collection, raising a considerable sum for the boy and his family.

As the flight was about to land in Seattle, the passengers broke into a cheer when the pilot announced that he had received word by radio that the boy was going to be all right.7

To my mind come the words of the scripture: “Charity is the pure love of Christ, … and whoso is found possessed of it at the last day, it shall be well with him.”8

Brothers and sisters, some of our greatest opportunities to demonstrate our love will be within the walls of our own homes. Love should be the very heart of family life, and yet sometimes it is not. There can be too much impatience, too much arguing, too many fights, too many tears. Lamented President Gordon B. Hinckley: “Why is it that the [ones] we love [most] become so frequently the targets of our harsh words? Why is it that [we] sometimes speak as if with daggers that cut to the quick?”9 The answers to these questions may be different for each of us, and yet the bottom line is that the reasons do not matter. If we would keep the commandment to love one another, we must treat each other with kindness and respect.

Of course there will be times when discipline needs to be meted out. Let us remember, however, the counsel found in the Doctrine and Covenants—namely, that when it is necessary for us to reprove another, we afterward show forth an increase of love.10

I would hope that we would strive always to be considerate and to be sensitive to the thoughts and feelings and circumstances of those around us. Let us not demean or belittle. Rather, let us be compassionate and encouraging. We must be careful that we do not destroy another person’s confidence through careless words or actions.

Forgiveness should go hand in hand with love. In our families, as well as with our friends, there can be hurt feelings and disagreements. Again, it doesn’t really matter how small the issue was. It cannot and should not be left to canker, to fester, and ultimately to destroy. Blame keeps wounds open. Only forgiveness heals.

A lovely lady who has since passed away visited with me one day and unexpectedly recounted some regrets. She spoke of an incident which had taken place many years earlier and involved a neighboring farmer, once a good friend but with whom she and her husband had disagreed on multiple occasions. One day the farmer asked if he could take a shortcut across her property to reach his own acreage. At this point she paused in her narrative to me and, with a tremor in her voice, said, “Brother Monson, I didn’t let him cross our property then or ever but required him to take the long way around on foot to reach his property. I was wrong, and I regret it. He’s gone now, but oh, I wish I could say to him, ‘I’m so sorry.’ How I wish I had a second chance to be kind.”

As I listened to her, there came to my mind the doleful observation of John Greenleaf Whittier: “Of all sad words of tongue or pen, the saddest are these: ‘It might have been!’”11 Brothers and sisters, as we treat others with love and kind consideration, we will avoid such regrets.

Love is expressed in many recognizable ways: a smile, a wave, a kind comment, a compliment. Other expressions may be more subtle, such as showing interest in another’s activities, teaching a principle with kindness and patience, visiting one who is ill or homebound. These words and actions and many others can communicate love.

Dale Carnegie, a well-known American author and lecturer, believed that each person has within himself or herself the “power to increase the sum total of [the] world’s happiness … by giving a few words of sincere appreciation to someone who is lonely or discouraged.” Said he, “Perhaps you will forget tomorrow the kind words you say today, but the recipient may cherish them over a lifetime.”12

May we begin now, this very day, to express love to all of God’s children, whether they be our family members, our friends, mere acquaintances, or total strangers. As we arise each morning, let us determine to respond with love and kindness to whatever might come our way.

Beyond comprehension, my brothers and sisters, is the love of God for us. Because of this love, He sent His Son, who loved us enough to give His life for us, that we might have eternal life. As we come to understand this incomparable gift, our hearts will be filled with love for our Eternal Father, for our Savior, and for all mankind. That such may be so is my earnest prayer in the sacred name of Jesus Christ, amen.

# References
1. - Matthew 22:36–39.
2. - Mark 12:31.
3. - 1 John 4:21.
4. - Luke 23:34.
5. - Author unknown, in Richard L. Evans, “The Quality of Kindness,” Improvement Era, May 1960, 340.
6. - The Teachings of Spencer W. Kimball, ed. Edward L. Kimball (1982), 483.
7. - See “Injured Boy Flown to Safety,” Daily Sitka Sentinel (Alaska), Oct. 22, 1981.
8. - Moroni 7:47.
9. - Gordon B. Hinckley, “Let Love Be the Lodestar of Your Life,” Ensign, May 1989, 67.
10. - See Doctrine and Covenants 121:43.
11. - “Maud Muller,” in The Complete Poetical Works of John Greenleaf Whittier (1878), 206; emphasis added.
12. - Dale Carnegie, in, for example, Larry Chang, Wisdom for the Soul (2006), 54.