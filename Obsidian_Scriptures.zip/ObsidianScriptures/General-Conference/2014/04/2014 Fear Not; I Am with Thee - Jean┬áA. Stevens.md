Jean A. Stevens
First Counselor in the Primary General Presidency
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/fear-not-i-am-with-thee?lang=eng)

_As we develop greater faith and trust in the Lord, we can access His power to bless and deliver us._

Few feelings compare with the tender emotions of becoming a parent. There is nothing sweeter than receiving a precious baby, direct from heaven. One of my brothers experienced this feeling in an especially poignant way. His first little son was born prematurely and weighed only 2 pounds 14 ounces (1.3 kg). Hunter spent his first two months of life in the neonatal intensive care unit of the hospital. Those months were a tender time for all the family as we hoped and petitioned the Lord for His help.

Little Hunter was so dependent. He struggled to gain the strength necessary to live. The strong hand of his loving father often reached for his son’s tiny hand to encourage his vulnerable little child.

And so it is for all of God’s children. Our Father in Heaven reaches out for each of us with His infinite love. He has power over all things and desires to help us learn, grow, and return to Him. This defines our Father’s purpose: “to bring to pass the immortality and eternal life of man.”1

As we develop greater faith and trust in the Lord, we can access His power to bless and deliver us.

The Book of Mormon weaves this beautiful theme of the Lord’s power to deliver His children throughout its pages. Nephi introduced it in the very first chapter of the book. In verse 20, we read, “Behold, I, Nephi, will show unto you that the tender mercies of the Lord are over all those whom he hath chosen, because of their faith, to make them mighty even unto the power of deliverance.”2

Many years ago I came to know in a very personal way the truths expressed in this verse. I came to know just how near our Father in Heaven really is and just how much He desires to help us.

One evening as night was falling, I was driving with my children when I noticed a boy walking along a lonely road. After passing him, I had a distinct impression I should go back and help him. But worried it could frighten him to have a stranger pull up beside him at night, I continued driving. The strong impression came again with the words in my mind: “Go help that boy!”

I drove back to him and asked, “Do you need some help? I had a feeling I should help you.”



He turned toward us and with tears streaming down his cheeks said, “Would you? I’ve been praying someone would help me.”

His prayer for help was answered with the inspiration that came to me. This experience of receiving such clear direction from the Spirit left an unforgettable imprint that is still in my heart.

And now after 25 years and through a tender mercy, I connected again with this boy for the first time just a few months ago. I discovered that the experience isn’t just my story—it is his story too. Deric Nance is now a father with a family of his own. He too has never forgotten this experience. It helped us lay a foundation of faith that God hears and answers our prayers. Both of us have used it to teach our children that God is watching over us. We are not alone.

On that night, Deric had stayed after school for an activity and had missed the last bus. As a young teenager, he felt confident he could make it home, so he started walking.

An hour and a half had passed as he walked the lonely road. Still miles from home and with no houses in sight, he was scared. In despair, he walked behind a pile of gravel, got on his knees, and asked Heavenly Father for help. Just minutes after Deric returned to the road, I stopped to provide the help he prayed for.

And now these many years later, Deric reflects: “The Lord was mindful of me, a skinny, shortsighted boy. And despite everything else going on in the world, He was aware of my situation and loved me enough to send help. The Lord has answered my prayers many times since that abandoned roadside. His answers aren’t always as immediate and clear, but His awareness of me is just as evident today as it was that lonely night. Whenever the dark shadows of life blanket my world, I know He always has a plan to see me safely home again.”

As Deric expressed, not every prayer is answered so quickly. But truly our Father knows us and hears the pleadings of our hearts. He accomplishes His miracles one prayer at a time, one person at a time.

We can trust that He will help us, not necessarily in the way we want but in the way that will best help us to grow. Submitting our will to His may be difficult, but it is essential to becoming like Him and finding the peace He offers us.

We can come to feel, as C. S. Lewis described: “I pray because I can’t help myself. … I pray because the need flows out of me all the time, waking and sleeping. It doesn’t change God. It changes me.”3

There are many accounts in the scriptures of those who have put their trust in the Lord and who have been helped and delivered by Him. Think of young David, who escaped certain death at the hand of the mighty Goliath by relying on the Lord. Consider Nephi, whose pleadings to God in faith brought deliverance from his brothers who sought to take his life. Remember young Joseph Smith, who prayerfully sought the Lord’s help. He was delivered from the power of darkness and received a miraculous answer. Each faced real and difficult challenges. Each acted in faith and put his trust in the Lord. Each received His help. And still in our day, God’s power and love are manifest in the lives of His children.

I have seen it recently in the lives of faith-filled Saints in Zimbabwe and Botswana. In a fast and testimony meeting in a small branch, I was humbled and inspired by the testimonies shared by many—children, youth, and adults alike. Each conveyed a powerful expression of faith in the Lord Jesus Christ. With challenges and difficult circumstances surrounding them, they live each day by putting their trust in God. They acknowledge His hand in their lives and often express it with the phrase “I am so much grateful to God.”

A few years ago a faithful family exemplified for members of our ward that same trust in the Lord. Arn and Venita Gatrell were living a happy life when Arn was diagnosed with an aggressive cancer. The prognosis was devastating—he had just a few weeks to live. The family wanted to be together one last time. So all the children gathered, some from distant locations. They had only 48 precious hours to spend together. The Gatrells carefully chose what mattered most to them—a family picture, a family dinner, and a session in the Salt Lake Temple. Venita said, “When we walked out of the temple doors, it was the last time we would ever be together in this life.”

But they left with the assurance that there is so much more for them than just this life. Because of sacred temple covenants, they have hope in God’s promises. They can be together forever.

The next two months were filled with blessings too numerous to recount. Arn and Venita’s faith and trust in the Lord were growing, as evidenced in Venita’s words: “I was carried. I learned that you can feel peace in the midst of turmoil. I knew the Lord was watching over us. If you trust in the Lord, truly you can overcome any of life’s challenges.”

One of their daughters added: “We watched our parents and saw their example. We saw their faith and how they handled it. I would never have asked for this trial, but I would never give it away. We were surrounded with God’s love.”

Of course, Arn’s passing was not the outcome the Gatrells had hoped for. But their crisis was not a crisis of faith. The gospel of Jesus Christ is not a checklist of things to do; rather, it lives in our hearts. The gospel “is not weight; it is wings.”4 It carries us. It carried the Gatrells. They felt peace in the midst of the storm. They held fast to each other and to temple covenants they had made and kept. They grew in their ability to trust in the Lord and were strengthened by their faith in Jesus Christ and in His atoning power.

Wherever we find ourselves on the path of discipleship, whatever our worries and challenges may be, we are not alone. You are not forgotten. Like Deric, the Saints of Africa, and the Gatrell family, we can choose to reach for God’s hand in our need. We can face our challenges with prayer and trust in the Lord. And in the process we become more like Him.

Speaking to each of us, the Lord says, “Fear … not; … I am with thee: be not dismayed; for I am thy God: I will strengthen thee; … I will help thee; yea, I will uphold thee with the right hand of my righteousness.”5

I share my humble but certain witness that God our Father knows us personally and reaches out to help us. Through His Beloved Son, Jesus Christ, we may overcome the challenges of this world and be safely delivered home. May we have faith to trust in Him, I pray in the name of Jesus Christ, amen.

# References
1. - Moses 1:39.
2. - 1 Nephi 1:20.
3. - Spoken by the character of C. S. Lewis as portrayed in William Nicholson, Shadowlands (1989), 103.
4. - Harry Emerson Fosdick, Twelve Tests of Character (1923), 88.
5. - Isaiah 41:10.