Elder Richard G. Scott
Of the Quorum of the Twelve Apostles
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/i-have-given-you-an-example?lang=eng)

_The greatest example who ever walked the earth is our Savior, Jesus Christ. … He invites us to follow His perfect example._

As I have pondered my duty to share the gospel, I have reflected on loved ones whose tender influence helped me find the divinely appointed path that aided my spiritual progression. At vital times in my life, Father in Heaven blessed me with someone who cared for me enough to help guide my choices in an appropriate direction. They observed these words of the Savior: “For I have given you an example, that ye should do as I have done to you.”1

When I was a young child, my father was not a member of the Church and my mother had become less active. We lived in Washington, D.C., and my mother’s parents lived 2,500 miles (4,000 km) away in the state of Washington. Some months after my eighth birthday, Grandmother Whittle came across the country to visit us. Grandmother was concerned that neither I nor my older brother had been baptized. I don’t know what she said to my parents about this, but I do know that one morning she took my brother and me to the park and shared with us her feelings about the importance of being baptized and attending Church meetings regularly. I don’t remember the specifics of what she said, but her words stirred something in my heart, and soon my brother and I were baptized.

Grandmother continued to support us. I remember that anytime my brother or I was assigned to give a talk in church, we would call her on the telephone for some suggestions. Within a few days a handwritten talk would arrive by mail. After some time her suggestions changed to an outline requiring more effort on our part.

Grandmother used just the right amount of courage and respect to help our father recognize the importance of his driving us to the church for our meetings. In every appropriate way, she helped us to feel a need for the gospel in our lives.

Most importantly, we knew Grandmother loved us and that she loved the gospel. She was a marvelous example! How grateful I am for the testimony she shared with me when I was very young. Her influence changed the direction of my life for eternal good.

Later, as I was about to graduate from the university, I fell in love with a beautiful young woman named Jeanene Watkins. I thought she was beginning to have some deep feelings for me also. One night when we were talking about the future, she carefully wove into the discussion a statement that changed my life forever. She said, “When I marry, it will be to a faithful returned missionary in the temple.”

I hadn’t thought much about a mission before then. That night my motivation to consider missionary service changed dramatically. I went home, and I could think of nothing else. I was awake all night long. I was completely distracted from my studies the next day. After many prayers I made the decision to meet with my bishop and begin my missionary application.

Jeanene never asked me to serve a mission for her. She loved me enough to share her conviction and then gave me the opportunity to work out the direction of my own life. We both served missions and later were sealed in the temple. Jeanene’s courage and commitment to her faith have made all the difference in our lives together. I am certain we would not have found the happiness we enjoy without her strong faith in the principle of serving the Lord first. She is a wonderful, righteous example!

Both Grandmother Whittle and Jeanene loved me enough to share their conviction that the ordinances of the gospel and serving Father in Heaven would bless my life. Neither of them coerced me or made me feel bad about the person I was. They simply loved me and loved Father in Heaven. Both knew He could do more with my life than I could on my own. Each courageously helped me in loving ways to find the path of greatest happiness.

How can each of us become such a significant influence? We must be sure to sincerely love those we want to help in righteousness so they can begin to develop confidence in God’s love. For so many in the world, the first challenge in accepting the gospel is to develop faith in a Father in Heaven, who loves them perfectly. It is easier to develop that faith when they have friends or family members who love them in a similar way.

Giving them confidence in your love can help them develop faith in God’s love. Then through your loving, thoughtful communication, their lives will be blessed by your sharing lessons you have learned, experiences you have had, and principles you have followed to find solutions to your own struggles. Show your sincere interest in their well-being; then share your testimony of the gospel of Jesus Christ.

You can help in ways that are grounded in principle and doctrine. Encourage those you love to seek to understand what the Lord would have them do. One way to do this is to ask them questions that make them think and then allow them sufficient time—whether hours, days, months, or more—to ponder and seek to work out the answers for themselves. You may need to help them know how to pray and how to recognize answers to their prayers. Help them to know that the scriptures are a vital source of receiving and recognizing answers. In that way you will help them prepare for future opportunities and challenges.

God’s purpose is “to bring to pass the immortality and eternal life of man.”2 That is fundamental to all we do. Sometimes we get so wrapped up in things that we find fascinating or become so consumed by mundane responsibilities that we lose sight of God’s objectives. As you consistently focus your life on the most basic principles, you will gain an understanding of what you are to do, and you will produce more fruit for the Lord and more happiness for yourself.

When you focus your life on the basic principles of the plan of salvation, you will better concentrate on sharing what you know because you understand the eternal importance of the ordinances of the gospel. You will share what you know in a way that encourages your friends to want to be strengthened spiritually. You will help your loved ones want to commit to obey all of His commandments and take upon themselves the name of Jesus Christ.

Remember that the conversion of individuals is only part of the work. Always seek to strengthen families. Teach with a vision of the importance of families being sealed in the temple. With some families it may take years. This was the case with my parents. Many years after I was baptized, my father was baptized, and later my family was sealed in the temple. My father served as a sealer in the temple, and my mother served there with him. When you have the vision of the sealing ordinances of the temple, you will help build the kingdom of God on earth.

Remember, loving them is the powerful foundation for influencing those you want to help. The influence of my Grandmother Whittle and my wife, Jeanene, would have been negligible had I not first known that they loved me and wanted me to have the best in life.

As a companion to that love, trust them. In some cases it may seem difficult to trust, but find some way to trust them. The children of Father in Heaven can do amazing things when they feel trusted. Every child of God in mortality chose the Savior’s plan. Trust that given the opportunity, they will do so again.

Share principles that help those you love to press forward along the path to eternal life. Remember, we all grow line upon line. You have followed that same pattern in your understanding of the gospel. Keep your sharing of the gospel simple.

Your personal testimony of the Atonement of Jesus Christ is a powerful tool. Accompanying resources are prayer, the Book of Mormon and the other scriptures, and your commitment to priesthood ordinances. All of these will facilitate the direction of the Spirit, which is so crucially important for you to rely upon.

To be effective and to do as Christ has done,3 concentrate on this basic principle of the gospel: the Atonement of Jesus Christ makes possible our becoming more like our Father in Heaven so that we can live together eternally in our family units.

There is no doctrine more fundamental to our work than the Atonement of Jesus Christ. At every appropriate opportunity, testify of the Savior and of the power of His Atoning sacrifice. Use scriptures that teach of Him and why He is the perfect pattern for everyone in life.4 You will need to study diligently. Do not become so absorbed with trivial things that you miss learning the doctrine and teachings of the Lord. With a solid, personal doctrinal foundation, you will be a powerful source for sharing vital truths with others who desperately need them.

We best serve our Father in Heaven by righteously influencing others and serving them.5 The greatest example who ever walked the earth is our Savior, Jesus Christ. His mortal ministry was filled with teaching, serving, and loving others. He sat down with individuals who were judged to be unworthy of His companionship. He loved each of them. He discerned their needs and taught them His gospel. He invites us to follow His perfect example.

I know that His gospel is the path to peace and happiness in this life. May we remember to do as He has done by sharing our love, trust, and knowledge of truth with others who have not yet embraced the brilliant light of the gospel. In the name of Jesus Christ, amen.

# References
1. - John 13:15.
2. - Moses 1:39.
3. - See John 13:15.
4. - See, for example, Luke 22:39–46; John 8:3–11; Philippians 4:13; James 5:15–16; 1 John 1:7; 2 Nephi 1:15; 2; 25:17–30; 31; Jacob 4; Alma 7; 42; 3 Nephi 11–30; Moroni 10:32–33; Doctrine and Covenants 18:10–16; 19:13–19; 29:3; 88:1–13; 138:2–4; Moses 5:6–12.
5. - See Matthew 22:35–40; Mosiah 2:17.