Elder Michael John U. Teh
Of the Seventy
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/where-your-treasure-is?lang=eng)

_If we are not careful, we will begin to chase after the temporal more than the spiritual._

Shortly after general conference in October 2007, one of my brethren told me that it would be about seven years before I got this harrowing experience again. I was relieved and told him that I would consider it my “seven years of plenty.” Well, here I am; my seven years of plenty have come to an end.

Last January my sweetheart, Grace, and I received an assignment to visit the members in the Philippines who were devastated by a major earthquake and a super typhoon. We rejoiced because the assignment was an answer to our prayers and a testament to the mercy and goodness of a loving Father in Heaven. It provided some closure to our longing to personally express to them our love and concern.

Most of the members we met were still living in temporary shelters like tents, community centers, and Church meetinghouses. The homes we visited had either partial roofing or no roofing at all. The people did not have much to begin with, and what little they had was swept away. There was mud and debris everywhere. However, they were full of gratitude for the little help they received and were in good spirits despite their very difficult circumstances. When we asked them how they were coping, everyone responded with a resounding, “We’re OK.” Obviously, their faith in Jesus Christ gave them hope that everything would work out eventually. Home after home, tent after tent, Sister Teh and I were being taught by these faithful Saints.

In times of calamity or tragedy, the Lord has a way of refocusing us and our priorities. All of a sudden, all the material things we worked so hard to acquire do not matter. All that matters is our family and our relationships with others. One good sister put it this way: “After the water receded and it was time to begin cleaning up, I looked around my home and thought, ‘Wow, I have accumulated a lot of garbage these many years.’”

I suspect that this sister has gained a better perspective and henceforth will be very cautious in deciding which things are necessary and which ones she really can live without.



In working with many members over the years, we have been pleased to observe an abundance of spiritual strength. We have also seen both an abundance and a lack of material possessions among these faithful members.

Out of necessity, most of us are involved in earning money and acquiring some of the world’s goods to be able to sustain our families. It requires a good part of our time and attention. There is no end to what the world has to offer, so it is critical that we learn to recognize when we have enough. If we are not careful, we will begin to chase after the temporal more than the spiritual. Our pursuit for the spiritual and eternal will then take a backseat, instead of the other way around. Sadly, there appears to be a strong inclination to acquire more and more and to own the latest and the most sophisticated.

How do we make sure that we are not drawn down this path? Jacob gives this counsel: “Wherefore, do not spend money for that which is of no worth, nor your labor for that which cannot satisfy. Hearken diligently unto me, and remember the words which I have spoken; and come unto the Holy One of Israel, and feast upon that which perisheth not, neither can be corrupted, and let your soul delight in fatness.”1

I hope none of us spend money for that which is of no worth nor labor for that which does not satisfy.

The Savior taught the following to both the Jews and the Nephites:

“Lay not up for yourselves treasures upon earth, where moth and rust doth corrupt, and where thieves break through and steal:

“But lay up for yourselves treasures in heaven, where neither moth nor rust doth corrupt, and where thieves do not break through nor steal:

“For where your treasure is, there will your heart be also.”2

In another setting, the Savior gave this parable:

“The ground of a certain rich man brought forth plentifully:

“And he thought within himself, saying, What shall I do, because I have no room where to bestow my fruits?

“And he said, This will I do: I will pull down my barns, and build greater; and there will I bestow all my fruits and my goods.

“And I will say to my soul, Soul, thou hast much goods laid up for many years; take thine ease, eat, drink, and be merry.

“But God said unto him, Thou fool, this night thy soul shall be required of thee: then whose shall those things be, which thou hast provided?

“So is he that layeth up treasure for himself, and is not rich toward God.”3

President Dieter F. Uchtdorf gave the following counsel not too long ago:

“Our Heavenly Father sees our real potential. He knows things about us that we do not know ourselves. He prompts us during our lifetime to fulfill the measure of our creation, to live a good life, and to return to His presence.

“Why, then, do we devote so much of our time and energy to things that are so fleeting, so inconsequential, and so superficial? Do we refuse to see the folly in the pursuit of the trivial and transient?”4

We all know that our list of earthly treasures consists of pride, wealth, material things, power, and the honors of men. They do not merit any more time and attention, so I will focus instead on the things that will constitute our treasures in heaven.

What are some treasures in heaven that we can lay up for ourselves? For starters, it will be well for us to acquire the Christlike attributes of faith, hope, humility, and charity. We have been counseled repeatedly to “[put] off the natural man and … [become] as a child.”5 The Savior’s admonition is for us to strive to be perfect like Him and our Heavenly Father.6

Second, we need to put more quality time and effort into strengthening family relationships. After all, “the family is ordained of God. It is the most important unit in time and in eternity.”7

Third, serving others is a hallmark of a true follower of Christ. He said, “Inasmuch as ye have done it unto one of the least of these my brethren, ye have done it unto me.”8

Fourth, understanding the doctrine of Christ and strengthening our testimony is a labor that will bring real joy and satisfaction. We need to consistently study the words of Christ as found in the scriptures and the words of living prophets. “For behold, the words of Christ will tell you all things what ye should do.”9

May I conclude with the story of a 73-year-old widow whom we met during our trip to the Philippines:

When the earthquake struck the island of Bohol, the home that she and her late husband had worked so hard to build crumbled to the ground, killing her daughter and grandson. Now alone, she needs to work to support herself. She has started taking in laundry (which she does by hand) and has to go up and down a good-sized hill several times a day to fetch water. When we visited her, she was still living in a tent.

These are her words: “Elder, I accept everything that the Lord has asked me to pass through. I have no hard feelings. I treasure my temple recommend and keep it under my pillow. Please know that I pay a full tithing on my meager income from doing laundry. No matter what happens, I will always pay tithing.”

I bear testimony that our priorities, tendencies, inclinations, desires, appetites, and passions will have a direct bearing on our next estate. Let us always remember the words of the Savior: “For where your treasure is, there will your heart be also.” May our hearts be found in the right place is my prayer, in the name of Jesus Christ, amen.

# References
1. - 2 Nephi 9:51.
2. - Matthew 6:19–21; see also 3 Nephi 13:19–21.
3. - Luke 12:16–21.
4. - Dieter F. Uchtdorf, “Of Regrets and Resolutions,” Ensign or Liahona, Nov. 2012, 22–23.
5. - Mosiah 3:19.
6. - See 3 Nephi 12:48.
7. - Handbook 2: Administering the Church (2010), 1.1.1.
8. - Matthew 25:40.
9. - 2 Nephi 32:3.