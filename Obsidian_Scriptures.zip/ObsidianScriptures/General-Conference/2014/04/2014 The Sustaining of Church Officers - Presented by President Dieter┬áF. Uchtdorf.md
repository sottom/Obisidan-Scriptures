Presented by President Dieter F. Uchtdorf
Second Counselor in the First Presidency
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/the-sustaining-of-church-officers?lang=eng)

It is proposed that we sustain Thomas Spencer Monson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Henry Bennion Eyring as First Counselor in the First Presidency; and Dieter Friedrich Uchtdorf as Second Counselor in the First Presidency.

Those in favor may manifest it.

Those opposed, if any, may manifest it.

It is proposed that we sustain Boyd Kenneth Packer as President of the Quorum of the Twelve Apostles and the following as members of that quorum: Boyd K. Packer, L. Tom Perry, Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, Richard G. Scott, Robert D. Hales, Jeffrey R. Holland, David A. Bednar, Quentin L. Cook, D. Todd Christofferson, and Neil L. Andersen.

Those in favor, please manifest it.

Any opposed may so indicate.

It is proposed that we sustain the counselors in the First Presidency and the Quorum of the Twelve Apostles as prophets, seers, and revelators.

All in favor, please manifest it.

Contrary, if there be any, by the same sign.

At this time we release with sincere appreciation Elder Tad R. Callister as a General Authority and member of the Presidency of the Quorums of the Seventy.

Those who wish to join us in a vote of appreciation, please manifest it.

It is proposed that we sustain Elder Lynn G. Robbins as a member of the Presidency of the Quorums of the Seventy.

All in favor, please manifest it.

Those opposed, if any.

It is proposed that we release the following as Area Seventies, effective on May 1, 2014: Pedro E. Abularach, Julio A. Angulo, Victor A. Asconavieta, Duck Soo Bae, Juan C. Barros, Colin H. Bricknell, Dennis C. Brimhall, Thomas M. Cherrington, Kim B. Clark, Wynn R. Dewsnup, Rodolfo C. Franco, G. Guillermo Garcia, Julio C. González, Mauro Junot De Maria, Larry S. Kacher, David E. LeSueur, Paulo C. Loureiro, Steven J. Lund, Abraham Martinez, Hugo E. Martinez, Sergey N. Mikulin, Christopher B. Munday, Hirofumi Nakatsuka, Chikao Oishi, Alejandro S. Patanía, Renato M. Petla, Anatoly K. Reshetnikov, Jonathan C. Roberts, J. Craig Rowe, Robert B. Smith, Warren G. Tate, Hesbon O. Usi, Taniela B. Wakolo, Randy W. Wilkinson, and Chi Hong (Sam) Wong.

Those who wish to join us in expressing gratitude for their excellent service, please manifest it.

It is proposed that we release with a vote of appreciation Brothers Russell T. Osguthorpe, David M. McConkie, and Matthew O. Richardson as the Sunday School general presidency.



We likewise extend a release to all members of the Sunday School general board.

All who wish to join us in expressing appreciation to these brothers and sisters for their remarkable service and devotion, please manifest it.

It is proposed that we sustain as new members of the First Quorum of the Seventy Chi Hong (Sam) Wong and Jörg Klebingat and as new members of the Second Quorum of the Seventy Larry S. Kacher and Hugo E. Martinez.

All in favor, please manifest it.

Those opposed, by the same sign.

It is proposed that we sustain the following as new Area Seventies: Julio Cesar Acosta, Blake R. Alder, Alain C. Allard, Taiichi Aoba, Carlos F. Arredondo, Vladimir N. Astashov, Jorge T. Becerra, Michael H. Bourne, Romulo V. Cabrera, Jose Claudio F. Campos, Nicolas Castañeda, Walter Chatora, Fook Chuen Zeno Chow, J. Kevin Ence, K. Mark Frost, Mauricio G. Gonzaga, Leonard D. Greer, Jose Isaguirre, Michael R. Jensen, Adolf Johan Johansson, Tae Gul Jung, Wisit Khanakham, Serhii A. Kovalov, Sergio Krasnoselsky, Milan F. Kunz, Bryan R. Larsen, Geraldo Lima, W. Jean-Pierre Lono, Tasara Makasi, Khumbulani Mdletshe, Dale H. Munk, Eduardo A. Norambuena, Yutaka Onda, Raimundo Pacheco De Pinho, Marco Antonio Rais, Steven K. Randall, R. Scott Runia, Alexey V. Samaykin, Edwin A. Sexton, Raul H. Spitale, Carlos Walter Treviño, and Juan A. Urra.

All in favor, please manifest it.

Those opposed, if any.

It is proposed that we sustain Tad R. Callister as general president of the Sunday School, with John S. Tanner as first counselor and Devin G. Durrant as second counselor.

Those in favor may manifest it.

Any opposed may so signify.

We note that Brothers Tanner and Durrant are both currently serving as mission presidents and are, therefore, not in attendance here in the Conference Center.

They will begin their official service in the Sunday School general presidency following their release as mission presidents in July 2014.

It is proposed that we sustain the other General Authorities, Area Seventies, and general auxiliary presidencies as presently constituted.

Those in favor, please manifest it.

Any opposed may manifest it.

Thank you, brothers and sisters, for your sustaining vote and for your continued faith and prayers in our behalf.

We invite the newly called General Authorities to come forward and take their places on the stand.

# References
