Elder Dallin H. Oaks
Of the Quorum of the Twelve Apostles
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/the-keys-and-authority-of-the-priesthood?lang=eng)

_Priesthood keys direct women as well as men, and priesthood ordinances and priesthood authority pertain to women as well as men._

I.



At this conference we have seen the release of some faithful brothers, and we have sustained the callings of others. In this rotation—so familiar in the Church—we do not “step down” when we are released, and we do not “step up” when we are called. There is no “up or down” in the service of the Lord. There is only “forward or backward,” and that difference depends on how we accept and act upon our releases and our callings. I once presided at the release of a young stake president who had given fine service for nine years and was now rejoicing in his release and in the new calling he and his wife had just received. They were called to be the nursery leaders in their ward. Only in this Church would that be seen as equally honorable!







II.



While addressing a women’s conference, Relief Society general president Linda K. Burton said, “We hope to instill within each of us a greater desire to better understand the priesthood.”1 That need applies to all of us, and I will pursue it by speaking of the keys and authority of the priesthood. Since these subjects are of equal concern to men and to women, I am pleased that these proceedings are broadcast and published for all members of the Church. Priesthood power blesses all of us. Priesthood keys direct women as well as men, and priesthood ordinances and priesthood authority pertain to women as well as men.







III.



President Joseph F. Smith described the priesthood as “the power of God delegated to man by which man can act in the earth for the salvation of the human family.”2 Other leaders have taught us that the priesthood “is the consummate power on this earth. It is the power by which the earth was created.”3 The scriptures teach that “this same Priesthood, which was in the beginning, shall be in the end of the world also” (Moses 6:7). Thus, the priesthood is the power by which we will be resurrected and proceed to eternal life.

The understanding we seek begins with an understanding of the keys of the priesthood. “Priesthood keys are the authority God has given to priesthood [holders] to direct, control, and govern the use of His priesthood on earth.”4 Every act or ordinance performed in the Church is done under the direct or indirect authorization of one holding the keys for that function. As Elder M. Russell Ballard has explained, “Those who have priesthood keys … literally make it possible for all who serve faithfully under their direction to exercise priesthood authority and have access to priesthood power.”5

In the controlling of the exercise of priesthood authority, the function of priesthood keys both enlarges and limits. It enlarges by making it possible for priesthood authority and blessings to be available for all of God’s children. It limits by directing who will be given the authority of the priesthood, who will hold its offices, and how its rights and powers will be conferred. For example, a person who holds the priesthood is not able to confer his office or authority on another unless authorized by one who holds the keys. Without that authorization, the ordination would be invalid. This explains why a priesthood holder—regardless of office—cannot ordain a member of his family or administer the sacrament in his own home without authorization from the one who holds the appropriate keys.

With the exception of the sacred work that sisters do in the temple under the keys held by the temple president, which I will describe hereafter, only one who holds a priesthood office can officiate in a priesthood ordinance. And all authorized priesthood ordinances are recorded on the records of the Church.

Ultimately, all keys of the priesthood are held by the Lord Jesus Christ, whose priesthood it is. He is the one who determines what keys are delegated to mortals and how those keys will be used. We are accustomed to thinking that all keys of the priesthood were conferred on Joseph Smith in the Kirtland Temple, but the scripture states that all that was conferred there were “the keys of this dispensation” (D&C 110:16). At general conference many years ago, President Spencer W. Kimball reminded us that there are other priesthood keys that have not been given to man on the earth, including the keys of creation and resurrection.6

The divine nature of the limitations put upon the exercise of priesthood keys explains an essential contrast between decisions on matters of Church administration and decisions affecting the priesthood. The First Presidency and the Council of the First Presidency and Quorum of the Twelve, who preside over the Church, are empowered to make many decisions affecting Church policies and procedures—matters such as the location of Church buildings and the ages for missionary service. But even though these presiding authorities hold and exercise all of the keys delegated to men in this dispensation, they are not free to alter the divinely decreed pattern that only men will hold offices in the priesthood.







IV.



I come now to the subject of priesthood authority. I begin with the three principles just discussed: (1) priesthood is the power of God delegated to man to act for the salvation of the human family, (2) priesthood authority is governed by priesthood holders who hold priesthood keys, and (3) since the scriptures state that “all other authorities [and] offices in the church are appendages to this [Melchizedek] priesthood” (D&C 107:5), all that is done under the direction of those priesthood keys is done with priesthood authority.

How does this apply to women? In an address to the Relief Society, President Joseph Fielding Smith, then President of the Quorum of the Twelve Apostles, said this: “While the sisters have not been given the Priesthood, it has not been conferred upon them, that does not mean that the Lord has not given unto them authority. … A person may have authority given to him, or a sister to her, to do certain things in the Church that are binding and absolutely necessary for our salvation, such as the work that our sisters do in the House of the Lord. They have authority given unto them to do some great and wonderful things, sacred unto the Lord, and binding just as thoroughly as are the blessings that are given by the men who hold the Priesthood.”7

In that notable address, President Smith said again and again that women have been given authority. To the women he said, “You can speak with authority, because the Lord has placed authority upon you.” He also said that the Relief Society “[has] been given power and authority to do a great many things. The work which they do is done by divine authority.” And, of course, the Church work done by women or men, whether in the temple or in the wards or branches, is done under the direction of those who hold priesthood keys. Thus, speaking of the Relief Society, President Smith explained, “[The Lord] has given to them this great organization where they have authority to serve under the directions of the bishops of the wards … , looking after the interest of our people both spiritually and temporally.”8

Thus, it is truly said that Relief Society is not just a class for women but something they belong to—a divinely established appendage to the priesthood.9

We are not accustomed to speaking of women having the authority of the priesthood in their Church callings, but what other authority can it be? When a woman—young or old—is set apart to preach the gospel as a full-time missionary, she is given priesthood authority to perform a priesthood function. The same is true when a woman is set apart to function as an officer or teacher in a Church organization under the direction of one who holds the keys of the priesthood. Whoever functions in an office or calling received from one who holds priesthood keys exercises priesthood authority in performing her or his assigned duties.

Whoever exercises priesthood authority should forget about their rights and concentrate on their responsibilities. That is a principle needed in society at large. The famous Russian writer Aleksandr Solzhenitsyn is quoted as saying, “It is time … to defend not so much human rights as human obligations.”10 Latter-day Saints surely recognize that qualifying for exaltation is not a matter of asserting rights but a matter of fulfilling responsibilities.







V.



The Lord has directed that only men will be ordained to offices in the priesthood. But, as various Church leaders have emphasized, men are not “the priesthood.”11 Men hold the priesthood, with a sacred duty to use it for the blessing of all of the children of God.

The greatest power God has given to His sons cannot be exercised without the companionship of one of His daughters, because only to His daughters has God given the power “to be a creator of bodies … so that God’s design and the Great Plan might meet fruition.”12 Those are the words of President J. Reuben Clark.

He continued: “This is the place of our wives and of our mothers in the Eternal Plan. They are not bearers of the Priesthood; they are not charged with carrying out the duties and functions of the Priesthood; nor are they laden with its responsibilities; they are builders and organizers under its power, and partakers of its blessings, possessing the complement of the Priesthood powers and possessing a function as divinely called, as eternally important in its place as the Priesthood itself.”13

In those inspired words, President Clark was speaking of the family. As stated in the family proclamation, the father presides in the family and he and the mother have separate responsibilities, but they are “obligated to help one another as equal partners.”14 Some years before the family proclamation, President Spencer W. Kimball gave this inspired explanation: “When we speak of marriage as a partnership, let us speak of marriage as a full partnership. We do not want our LDS women to be silent partners or limited partners in that eternal assignment! Please be a contributing and full partner.”15



In the eyes of God, whether in the Church or in the family, women and men are equal, with different responsibilities.

I close with some truths about the blessings of the priesthood. Unlike priesthood keys and priesthood ordinations, the blessings of the priesthood are available to women and to men on the same terms. The gift of the Holy Ghost and the blessings of the temple are familiar illustrations of this truth.

In his insightful talk at BYU Education Week last summer, Elder M. Russell Ballard gave these teachings:

“Our Church doctrine places women equal to and yet different from men. God does not regard either gender as better or more important than the other. …

“When men and women go to the temple, they are both endowed with the same power, which is priesthood power. … Access to the power and the blessings of the priesthood is available to all of God’s children.”16

I testify of the power and blessings of the priesthood of God, available for His sons and daughters alike. I testify of the authority of the priesthood, which functions throughout all of the offices and activities of The Church of Jesus Christ of Latter-day Saints. I testify of the divinely directed function of the keys of the priesthood, held and exercised in their fulness by our prophet/president, Thomas S. Monson. Finally and most important, I testify of our Lord and Savior, Jesus Christ, whose priesthood this is and whose servants we are, in the name of Jesus Christ, amen.

# References
1. - Linda K. Burton, “Priesthood: ‘A Sacred Trust to Be Used for the Benefit of Men, Women, and Children’” (Brigham Young University Women’s Conference address, May 3, 2013), 1; ce.byu.edu/cw/womensconference/transcripts.php.
2. - Joseph F. Smith, Gospel Doctrine, 5th ed. (1939), 139.
3. - Boyd K. Packer, “Priesthood Power in the Home” (worldwide leadership training meeting, Feb. 2012); lds.org/broadcasts; see also James E. Faust, “Power of the Priesthood,” Ensign, May 1997, 41–43.
4. - Handbook 2: Administering the Church (2010), 2.1.1.
5. - M. Russell Ballard, “Men and Women in the Work of the Lord,” New Era, Apr. 2014, 4; Liahona, Apr. 2014, 48; see also Daughters in My Kingdom: The History and Work of Relief Society (2011), 138.
6. - See Spencer W. Kimball, “Our Great Potential,” Ensign, May 1977, 49.
7. - Joseph Fielding Smith, “Relief Society—an Aid to the Priesthood,” Relief Society Magazine, Jan. 1959, 4.
8. - Joseph Fielding Smith, “Relief Society—an Aid to the Priesthood,” 4, 5; see also Teachings of Presidents of the Church: Joseph Fielding Smith (2013), 302.
9. - See Boyd K. Packer, “The Relief Society,” Ensign, May 1998, 72; see also Daughters in My Kingdom, 138.
10. - Aleksandr Solzhenitsyn, “A World Split Apart” (commencement address delivered at Harvard University, June 8, 1978); see also Patricia T. Holland, “A Woman’s Perspective on the Priesthood,” Ensign, July 1980, 25; Tambuli, June 1982, 23; Dallin H. Oaks, “Rights and Responsibilities,” Mercer Law Review, vol. 36, no. 2 (winter 1985), 427–42.
11. - See James E. Faust, “You Are All Heaven Sent,” Ensign or Liahona, Nov. 2002, 113; M. Russell Ballard, “This Is My Work and Glory,” Ensign or Liahona, May 2013, 19; Dallin H. Oaks, “Priesthood Authority in the Family and the Church,” Ensign or Liahona, Nov. 2005, 26. We sometimes say that the Relief Society is a “partner with the priesthood.” It would be more accurate to say that in the work of the Lord the Relief Society and the women of the Church are “partners with the holders of the priesthood.”
12. - J. Reuben Clark Jr., “Our Wives and Our Mothers in the Eternal Plan,” Relief Society Magazine, Dec. 1946, 800.
13. - J. Reuben Clark Jr., “Our Wives and Our Mothers,” 801.
14. - “The Family: A Proclamation to the World,” Ensign or Liahona, Nov. 2010, 129.
15. - Spencer W. Kimball, “Privileges and Responsibilities of Sisters,” Ensign, Nov. 1978, 106.
16. - M. Russell Ballard, New Era, Apr. 2014, 4; Liahona, Apr. 2014, 48; see also Sheri L. Dew, Women and the Priesthood (2013), especially chapter 6, for a valuable elaboration of the doctrines stated here.