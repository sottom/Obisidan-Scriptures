President Henry B. Eyring
First Counselor in the First Presidency
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/daughters-in-the-covenant?lang=eng)

_The path … we must take on our journey back to our Heavenly Father … is marked by sacred covenants with God._

We have been taught with spiritual power tonight. I pray that the words spoken by these great sister leaders will go down into your heart as they have into mine.

This is an historic meeting. All the women of the Church eight years of age and older have been invited to join with us tonight. Many of us have prayed that the Holy Ghost would be with us. That blessing was granted as we heard these sisters speak and listened to the uplifting music. I pray that the Spirit will continue to be with us as I offer some words of encouragement and testimony in addition to what has already been said—and particularly to testify that what we have been told is what the Lord would have us hear.

I will speak tonight about the path—which in such beautiful ways has been described today—that we must take on our journey back to our Heavenly Father. That path is marked by sacred covenants with God. I will talk with you about the joy of making and keeping those covenants and helping others keep them.

A number of you were baptized recently and received the gift of the Holy Ghost by the laying on of hands. To you that memory is fresh. Others were baptized long ago, so the memory of your feelings of that covenant experience may be less clear, but some of those feelings come back whenever you listen to the sacramental prayers.

No two of us will have the same memories of the day when we made that sacred baptismal covenant and received the gift of the Holy Ghost. But we each felt God’s approval. And we felt a desire to forgive and to be forgiven and an increased determination to do right.

How deeply those feelings went down into your heart was determined largely by the way you were prepared by loving people. I hope that those of you who came into the kingdom recently are blessed to be sitting near your mother. If you are, you might send her a smile of thanks right now. I can remember the feeling of joy and gratitude as I sat behind my mother on the drive home from my baptism in Philadelphia, Pennsylvania.

My mother was the one who had carefully prepared me for making that covenant and all the others that would follow. She had been faithful to this charge from the Lord:

“And again, inasmuch as parents have children in Zion, or in any of her stakes which are organized, that teach them not to understand the doctrine of repentance, faith in Christ the Son of the living God, and of baptism and the gift of the Holy Ghost by the laying on of the hands, when eight years old, the sin be upon the heads of the parents.



“For this shall be a law unto the inhabitants of Zion, or in any of her stakes which are organized.

“And their children shall be baptized for the remission of their sins when eight years old, and receive the [Holy Ghost].”1

My mother had done her part. She had prepared her children with words much like those of Alma, as recorded in the Book of Mormon:

“And it came to pass that he said unto them: Behold, here are the waters of Mormon (for thus were they called) and now, as ye are desirous to come into the fold of God, and to be called his people, and are willing to bear one another’s burdens, that they may be light;

“Yea, and are willing to mourn with those that mourn; yea, and comfort those that stand in need of comfort, and to stand as witnesses of God at all times and in all things, and in all places that ye may be in, even until death, that ye may be redeemed of God, and be numbered with those of the first resurrection, that ye may have eternal life—

“Now I say unto you, if this be the desire of your hearts, what have you against being baptized in the name of the Lord, as a witness before him that ye have entered into a covenant with him, that ye will serve him and keep his commandments, that he may pour out his Spirit more abundantly upon you?

“And now when the people had heard these words, they clapped their hands for joy, and exclaimed: This is the desire of our hearts.”2

You may not have clapped your hands when you first heard that invitation to covenant by baptism, but you surely felt the love of the Savior and a greater commitment to nurture others for Him. I can say “surely” because those feelings are placed deep in the hearts of all of Heavenly Father’s daughters. That is part of your divine heritage from Him.

You were tutored by Him before you came into this life. He helped you understand and accept that you would have trials, tests, and opportunities perfectly chosen just for you. You learned that our Father had a plan of happiness to get you safely through those trials and that you would help bring others safely through theirs. This plan is marked by covenants with God.

It is our free choice whether we make and keep those covenants. Only a few of His daughters have the opportunity in this life to even learn of those covenants. You are one of the favored few. You dear sisters, each of you is a daughter in the covenant.

Heavenly Father taught you before you were born about the experiences you would have as you left Him and came to earth. You were taught that the way back home to Him would not be easy. He knew that it would be too hard for you to make the journey without help.

You have been blessed not only to find the way to make those covenants in this life but also to be surrounded by others who will help—who, like you, are covenant daughters of Heavenly Father.

You all have felt the blessing of being in the company tonight of daughters of God who are also under covenant to help and direct you as they promised to do. I have seen what you have seen as covenant sisters keep that commitment to comfort and help—and do it with a smile.

I remember the smile of Sister Ruby Haight. She was the wife of Elder David B. Haight, who was a member of the Quorum of the Twelve Apostles. As a young man he served as the president of the Palo Alto stake in California. He prayed over, and worried about, the girls in the Mia Maid class in his own ward.

So President Haight was inspired to ask the bishop to call Ruby Haight to teach those young girls. He knew she would be a witness of God who would lift, comfort, and love the girls in that class.

Sister Haight was at least 30 years older than the girls she taught. Yet 40 years after she taught them, each time she would meet my wife, who had been one of the girls in her class, she would put out her hand, smile, and say to Kathy, “Oh! My Mia Maid.” I saw more than her smile. I felt her deep love for a sister she still cared for as if she were her own daughter. Her smile and warm greeting came from seeing that a sister and daughter of God was still on the covenant path home.

Heavenly Father smiles on you as well whenever He sees you help a daughter of His move along the covenant path toward eternal life. And He is pleased every time you try to choose the right. He sees not only what you are but also what you may become.

You may have had an earthly parent who thought that you could be better than you thought you could be. I had such a mother.

What I didn’t know when I was young was that my Heavenly Father, your Heavenly Father, sees greater potential in His children than we or even our earthly mothers see in us. And whenever you move upward on that path toward your potential, it brings Him happiness. And you can feel His approval.

He sees that glorious potential in all of His daughters, wherever they are. Now, that puts a great responsibility on each of you. He expects you to treat every person you meet as a child of God. That is the reason He commands us to love our neighbors as we love ourselves and to forgive them. Your feelings of kindness and forgiveness toward others come as your divine inheritance from Him as His daughter. Each person you meet is His loved spiritual child.

As you feel of that great sisterhood, what we thought divides us falls away. For instance, younger and older sisters share their feelings with the expectation of being understood and accepted. You are more alike as daughters of God than you are different.

With that view, young women should look forward to their entry into Relief Society as an opportunity to enlarge their circle of sisters whom they will come to know, admire, and love.

That same capacity to see what we can be is increasing in families and in Primary. It is happening in family home evenings and in Primary programs. Little children are being inspired to say great and marvelous things, as they did when the Savior loosed their tongues when He taught them after He was resurrected.3

While Satan may be attacking sisters at earlier ages, the Lord is lifting sisters to higher and higher levels of spirituality. For example, young women are teaching their mothers how to use FamilySearch to find and save ancestors. Some young sisters that I know are choosing to go early in the morning to perform proxy baptisms in temples without any urging beyond the spirit of Elijah.

In missions across the earth, sisters are being called to serve as leaders. The Lord created the need for their service by touching the hearts of sisters in greater numbers to serve. More than a few mission presidents have seen the sister missionaries become ever more powerful as proselyters and particularly as nurturing leaders.

Whether or not you serve as a full-time missionary, you can gain the same ability to enrich your marriage and the capacity to raise noble children by following the examples of great women.

Consider Eve, the mother of all living. Elder Russell M. Nelson said this of Eve: “We and all mankind are forever blessed because of Eve’s great courage and wisdom. By partaking of the fruit first, she did what needed to be done. Adam was wise enough to do likewise.”4

Every daughter of Eve has the potential to bring the same blessing to her family that Eve brought to hers. She was so important in the establishment of families that we have this report of her creation: “And the Gods said: Let us make an help meet for the man, for it is not good that the man should be alone, therefore we will form an help meet for him.”5

We don’t know all the help Eve was to Adam and to their family. But we do know of one great gift that she gave, which each of you can also give: she helped her family see the path home when the way ahead seemed hard. “And Eve, his wife, heard all these things and was glad, saying: Were it not for our transgression we never should have had seed, and never should have known good and evil, and the joy of our redemption, and the eternal life which God giveth unto all the obedient.”6

You have her example to follow.

By revelation, Eve recognized the way home to God. She knew that the Atonement of Jesus Christ made eternal life possible in families. She was sure, as you can be, that as she kept her covenants with her Heavenly Father, the Redeemer and the Holy Ghost would see her and her family through whatever sorrows and disappointments would come. She knew she could trust in Them.

“Trust in the Lord with all thine heart; and lean not unto thine own understanding.

“In all thy ways acknowledge him, and he shall direct thy paths.”7

I know that Eve faced sorrows and disappointments, but I also know that she found joy in the knowledge that she and her family could return to live with God. I know that many of you who are here face sorrows and disappointments. I leave you my blessing that, like Eve, you may feel the same joy that she felt as you journey back home.

I have a sure witness that God the Father watches over you in love. He loves each of you. You are His daughters in the covenant. Because He loves you, He will provide the help that you need to move yourself and others upward along the way back to His presence.

I know that the Savior paid the price of all of our sins and that the Holy Ghost testifies of truth. You have felt that comfort in this meeting. I have a testimony that all the keys which bind sacred covenants have been restored. They are held and exercised today by our living prophet, President Thomas S. Monson. I leave these words of comfort and hope with you, His beloved covenant daughters, in the sacred name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 68:25–27.
2. - Mosiah 18:8–11.
3. - See 3 Nephi 26:14.
4. - Russell M. Nelson, “Constancy amid Change,” Ensign, Nov. 1993, 34.
5. - Abraham 5:14.
6. - Moses 5:11.
7. - Proverbs 3:5–6.