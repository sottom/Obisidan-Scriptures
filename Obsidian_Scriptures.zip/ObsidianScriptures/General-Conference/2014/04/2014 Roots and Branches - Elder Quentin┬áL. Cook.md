Elder Quentin L. Cook
Of the Quorum of the Twelve Apostles
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/roots-and-branches?lang=eng)

_Hastening family history and temple work in our day is essential for the salvation and exaltation of families._

Just before his death from cancer in 1981, the controversial writer William Saroyan told the press, “Everybody has to die, but I always believed an exception would be made in my case. Now what?”1

The “now what” in the face of death in this life and the “now what” in contemplation of life after death are at the heart of the questions of the soul that the restored gospel of Jesus Christ answers so beautifully in the Father’s plan of happiness.

In this life we laugh, we cry, we work, we play, we live, and then we die. Job asks the succinct question, “If a man die, shall he live again?”2 The answer is a resounding yes because of the atoning sacrifice of the Savior. Part of Job’s diverse preamble to the question is interesting: “Man that is born of a woman is of few days. … He cometh forth like a flower, and is cut down. … There is hope of a tree, if it be cut down, that it will sprout again, and that the tender branch thereof will not cease … and bring forth boughs like a plant.”3

Our Father’s plan is about families. Several of our most poignant scriptures use the concept of the tree with its roots and branches as an analogy.

In the closing chapter of the Old Testament, Malachi, in describing the Second Coming of the Savior, vividly uses this analogy. Speaking of the proud and wicked, he notes that they shall be burned as stubble and “that it shall leave them neither root nor branch.”4 Malachi closes this chapter with the Lord’s reassuring promise:

“Behold, I will send you Elijah the prophet before the coming of the great and dreadful day of the Lord:

“And he shall turn the heart of the fathers to the children, and the heart of the children to their fathers, lest I come and smite the earth with a curse.”5

At the dawn of the Restoration, Moroni reemphasized this message in his initial instruction to young Joseph Smith in 1823.6

Christians and Jews the world over accept the Old Testament account of Elijah.7 He was the last prophet to hold the sealing power of the Melchizedek Priesthood before the time of Jesus Christ.8





Elijah Restores Keys



Elijah’s return occurred in the Kirtland Temple on April 3, 1836. He declared he was fulfilling Malachi’s promise. He committed the priesthood keys for sealing families in this dispensation.9 Elijah’s mission is facilitated by what is sometimes called the spirit of Elijah, which, as Elder Russell M. Nelson has taught, is “a manifestation of the Holy Ghost bearing witness of the divine nature of the family.”10

The Savior was emphatic about the necessity of baptism. He taught, “Except a man be born of water and of the Spirit, he cannot enter into the kingdom of God.”11 The Savior was personally baptized to set the example. What about the deceased who have not been baptized?







Doctrine of Temple and Family History Work



On October 11, 1840, in Nauvoo, Vilate Kimball wrote a letter to her husband, Elder Heber C. Kimball, who with other members of the Twelve was serving a mission in Great Britain. The October general conference had been held a few days before.

I quote from parts of Vilate’s personal letter: “We had the largest and most interesting conference that ever has been since the Church was organized. … President [Joseph] Smith has opened a new and glorious subject. … That is, being baptized for the dead. Paul speaks of it, in First Corinthians 15th chapter 29th verse. Joseph has received a more full explanation of it by revelation. He says it is the privilege of [members of] this Church to be baptized for all their kinsfolk that have died before this gospel came forth. … By so doing, we act as agents for them, and give them the privilege of coming forth in the First Resurrection. He says they will have the gospel preached to them in prison.”

Vilate added: “I want to be baptized for my mother. … Is not this a glorious doctrine?”12

The essential doctrine of uniting families came forth line upon line and precept upon precept. Vicarious ordinances are at the heart of welding together eternal families, connecting roots to branches.

The doctrine of the family in relation to family history and temple work is clear. The Lord in initial revelatory instructions referred to “baptism for your dead.”13 Our doctrinal obligation is to our own ancestors. This is because the celestial organization of heaven is based on families.14 The First Presidency has encouraged members, especially youth and young single adults, to emphasize family history work and ordinances for their own family names or the names of ancestors of their ward and stake members.15 We need to be connected to both our roots and branches. The thought of being associated in the eternal realm is indeed glorious.







Temples



Wilford Woodruff indicated that the Prophet Joseph Smith lived long enough to lay the foundation for temple work. By the last time he, Joseph Smith, ever met with the Quorum of the Twelve, he had given them their endowments.16

After the Prophet’s martyrdom, the Saints completed the Nauvoo Temple, and the sealing power was used to bless thousands of faithful members before the exodus to the Mountain West. Thirty years later, at the completion of the St. George Temple, President Brigham Young noted the eternal significance of saving ordinances finally being available for both the living and the dead.17

This is simply stated by President Wilford Woodruff: “There is hardly any principle the Lord has revealed that I have rejoiced more in than in the redemption of our dead; that we will have our fathers, our mothers, our wives and our children with us in the family organization, in the morning of the first resurrection and in the Celestial Kingdom. These are grand principles. They are worth every sacrifice.”18

What a great time to be alive. This is the last dispensation, and we can feel the hastening of the work of salvation in every area where a saving ordinance is involved.19 We now have temples across much of the world to provide these saving ordinances. Attending the temple for spiritual renewal, peace, safety, and direction in our lives is also a great blessing.20

Less than a year after President Thomas S. Monson was called as an Apostle, he dedicated the Los Angeles Temple Genealogical Library. He spoke of deceased ancestors “waiting [for] the day when you and I will do the research which is necessary to clear the way, … [and] likewise go into the house of God and perform that work … that they … cannot perform.”21

When then-Elder Monson delivered those dedicatory remarks on June 20, 1964, there were only 12 operating temples. During the period President Monson has served in the senior councils of the Church, 130 of our 142 operating temples have had their initial dedication. It is nothing short of miraculous to see the hastening of the work of salvation in our day. Twenty-eight more temples have been announced and are in various stages of completion. Eighty-five percent of the Church members now live within 200 miles (320 km) of a temple.







Family History Technology



Family history technology has also advanced dramatically. President Howard W. Hunter declared in November 1994: “We have begun using information technology to hasten the sacred work of providing ordinances for the deceased. The role of technology … has been accelerated by the Lord himself. … However, we stand only on the threshold of what we can do with these tools.”22

In the 19 years since this prophetic statement, the acceleration of technology is almost unbelievable. A 36-year-old mother of young children recently exclaimed to me, “Just think—we have gone from microfilm readers in dedicated family history centers to sitting at my kitchen table with my computer doing family history after my children are finally asleep.” Brothers and sisters, family history centers are now in our homes.

Temple and family history work is not just about us. Think of those on the other side of the veil waiting for the saving ordinances that would free them from the bondage of spirit prison. Prison is defined as “a state of confinement or captivity.”23 Those in captivity might be asking William Saroyan’s question: “Now what?”

One faithful sister shared a special spiritual experience in the Salt Lake Temple. While in the confirmation room, after a vicarious confirmation ordinance was pronounced, she heard, “And the prisoner shall go free!” She felt a great sense of urgency for those who were waiting for their baptismal and confirmation work. Upon returning home, she searched the scriptures for the phrase she had heard. She found Joseph Smith’s declaration in section 128 of the Doctrine and Covenants: “Let your hearts rejoice, and be exceedingly glad. Let the earth break forth into singing. Let the dead speak forth anthems of eternal praise to the King Immanuel, who hath ordained, before the world was, that which would enable us to redeem them out of their prison; for the prisoners shall go free.”24

The question is, what do we need to do? The Prophet Joseph’s counsel was to present in the temple “the records of our dead, which shall be worthy of all acceptation.”25

The leadership of the Church has issued a clarion call to the rising generation to lead the way in the use of technology to experience the spirit of Elijah, to search out their ancestors, and to perform temple ordinances for them.26 Much of the heavy lifting in hastening the work of salvation for both the living and the dead will be done by you young people.27

If the youth in each ward will not only go to the temple and do baptisms for their dead but also work with their families and other ward members to provide the family names for the ordinance work they perform, both they and the Church will be greatly blessed. Don’t underestimate the influence of the deceased in assisting your efforts and the joy of ultimately meeting those you serve. The eternally significant blessing of uniting our own families is almost beyond comprehension.28

In the worldwide membership of the Church, fifty-one percent of adults currently do not have both parents in the Family Tree section of the Church’s FamilySearch Internet site. Sixty-five percent of adults do not have all four grandparents listed.29 Remember, we without our roots and branches cannot be saved. Church members need to obtain and input this vital information.

We finally have the doctrine, the temples, and the technology for families to accomplish this glorious work of salvation. I suggest one way this might be done. Families could hold a “Family Tree Gathering.” This should be a recurring effort. Everyone would bring existing family histories, stories, and photos, including cherished possessions of grandparents and parents. Our young people are excited to learn about the lives of family members—where they came from and how they lived. Many have had their hearts turned to the fathers. They love the stories and photos, and they have the technological expertise to scan and upload these stories and photos to Family Tree and connect source documents with ancestors to preserve these for all time. Of course, the main objective is to determine what ordinances still need to be done and make assignments for the essential temple work. The My Family booklet can be utilized to help record family information, stories, and photos that can then be uploaded to Family Tree.

Family commitments and expectations should be at the top of our priorities to protect our divine destiny. For those who are looking for more fruitful use of the Sabbath day for the family as a whole, the hastening of this work is fertile ground. One mother glowingly tells how her 17-year-old son gets on the computer after church on Sunday to do family history work and her 10-year-old son loves to hear the stories and see pictures of his ancestors. This has blessed their entire family to experience the spirit of Elijah. Our precious roots and branches must be nourished.

Jesus Christ gave His life as a vicarious atonement. He resolved the ultimate question raised by Job. He overcame death for all mankind, which we could not do for ourselves. We can, however, perform vicarious ordinances and truly become saviors on Mount Zion30 for our own families in order that we, with them, might be exalted as well as saved.

I bear witness of the Savior’s atoning sacrifice and the certainty of the Father’s plan for us and our families. In the name of Jesus Christ, amen.

# References
1. - William Saroyan, in Henry Allen, “Raging against Aging,” Wall Street Journal, Dec. 31, 2011–Jan. 1, 2012, C9.
2. - Job 14:14.
3. - Job 14:1, 2, 7, 9.
4. - Malachi 4:1. Recently several articles have reported that an increasingly significant number of people are choosing not to have children in order to improve their standard of living (see Abby Ellin, “The Childless Plan for Their Fading Days,” New York Times, Feb. 15, 2014, B4). Many countries are decreasing in population as a result of these individual choices. This is sometimes referred to as the “demographic winter” (see The New Economic Reality: Demographic Winter [documentary], byutv.org/shows).
5. - Malachi 4:5–6.
6. - See History of the Church, 1:12; Doctrine and Covenants 2.
7. - The Jews have been waiting for Elijah’s return for 2,400 years. To this day, at their annual Passover Seders, or dinners, they set a place for him and go to the door hoping he has arrived to herald the coming of the Messiah.
8. - See Bible Dictionary, “Elijah.”
9. - See Doctrine and Covenants 110:14–16; see also Doctrine and Covenants 2.
10. - Russell M. Nelson, “A New Harvest Time,” Ensign, May 1998, 34.
11. - John 3:5.
12. - Vilate M. Kimball to Heber C. Kimball, Oct. 11, 1840, Vilate M. Kimball letters, Church History Library; spelling and capitalization standardized.
13. - Doctrine and Covenants 127:5; emphasis added.
14. - See Teachings of Presidents of the Church: Joseph Fielding Smith (2013), 68.
15. - See First Presidency letter, Oct. 8, 2012.
16. - See The Discourses of Wilford Woodruff, sel. G. Homer Durham (1946), 147.
17. - Brigham Young stated, “All I want is to see this people devote their means and interests to the building up of the kingdom of God, erecting temples, and in them officiate for the living and the dead … that they may be crowned sons and daughters of the Almighty” (Deseret News, Sept. 6, 1876, 498). Baptisms for the dead commenced on January 9, 1877, and endowments for the dead were performed two days later. The joy of this was expressed by Lucy B. Young, who said that “her heart was full in the prospect of being received by [her dead relatives] with open arms, as all would be by those who could not do the work for themselves” (in Richard E. Bennett, “‘Which Is the Wisest Course?’ The Transformation in Mormon Temple Consciousness, 1870–1898,” BYU Studies Quarterly, vol. 52, no. 2 [2013], 22).
18. - Teachings of Presidents of the Church: Wilford Woodruff (2004), 192–93.
19. - President Wilford Woodruff (who is known to be one of the greatest missionaries of all time to the living), speaking of work for the dead, said: “I look upon this portion of our ministry as a mission of as much importance as preaching to the living; the dead will hear the voice of the servants of God in the spirit-world, and they cannot come forth in the morning of the [first] resurrection, unless certain ordinances are performed, for [them].” He also said, “It takes just as much to save a dead man … as a living man” (Teachings of Presidents of the Church: Wilford Woodruff, 188).
20. - President Howard W. Hunter invited Church members to go to the temple often “for the personal blessing of temple worship, for the sanctity and safety which is provided within those hallowed and consecrated walls. … It is holy unto the Lord. It should be holy unto us” (“The Great Symbol of Our Membership,” Ensign, Oct. 1994, 5; Tambuli, Nov. 1994, 6).
21. - “Messages of Inspiration from President Thomas S. Monson,” Church News, Dec. 29, 2013, 2.
22. - Howard W. Hunter, “We Have a Work to Do,” Ensign, Mar. 1995, 65.
23. - Merriam-Webster’s Collegiate Dictionary, 11th ed. (2003), “prison.”
24. - Doctrine and Covenants 128:22; see also Doctrine and Covenants 138:42. “Before [the] world was, the Lord ordained that which enables spirits in [prison] to be redeemed” (index to the triple combination, “Prison”).
25. - Doctrine and Covenants 128:24.
26. - See First Presidency letter, Oct. 8, 2012; see also David A. Bednar, “The Hearts of the Children Shall Turn,” Ensign or Liahona, Nov. 2011, 24–27; R. Scott Lloyd, “‘Find Our Cousins’: Apostle [Neil L. Andersen] Counsels LDS Youth at RootsTech Conference,” Church News, Feb. 16, 2014, 8–9.
27. - One recent study indicated that a major emphasis for this generation is living a meaningful life where they “give to others, and orient themselves to a larger purpose” (Emily Esfahani Smith and Jennifer L. Aaker, “Millennial Searchers,” New York Times Sunday Review, Dec. 1, 2013, 6).
28. - See Howard W. Hunter, “A Temple-Motivated People,” Ensign, Feb. 1995, 2–5; Liahona, May 1995, 2–7.
29. - Statistics provided by Family History Department.
30. - See Obadiah 1:21.