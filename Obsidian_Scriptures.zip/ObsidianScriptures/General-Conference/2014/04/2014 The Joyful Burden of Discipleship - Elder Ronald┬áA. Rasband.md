Elder Ronald A. Rasband
Of the Presidency of the Seventy
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/the-joyful-burden-of-discipleship?lang=eng)

_To sustain our leaders is a privilege; it comes coupled with a personal responsibility to share their burden and to be disciples of the Lord._

On May 20 of last year a massive tornado pummeled the suburbs of Oklahoma City, in the heartland of America, carving a trail more than a mile (1.6 km) wide and 17 miles (27 km) long. This storm, an onslaught of devastating tornadoes, altered the landscape and the lives of the people in its path.

Just a week after the massive storm struck, I was assigned to visit the area where homes and belongings were strewn across the flattened, ravaged neighborhoods.

Before I left, I spoke with our beloved prophet, President Thomas S. Monson, who relishes such errands for the Lord. With respect borne not only of his office but also of his goodness, I asked, “What do you want me to do? What do you want me to say?”

He tenderly took my hand, as he would have done with each one of the victims and each of those helping with the devastation had he been there, and said:

“First, tell them I love them.

“Second, tell them I am praying for them.

“Third, please thank all those who are helping.”

As a member of the Presidency of the Seventy, I could feel the weight on my shoulders in the words the Lord spoke unto Moses:

“Gather unto me seventy men of the elders of Israel, whom thou knowest to be the elders of the people, and officers over them; …

“And I will come down and talk with thee there: and I will take of the spirit which is upon thee [Moses], and will put it upon them; and they shall bear the burden of the people with thee, that thou bear it not thyself alone.”1

These are words from ancient times, yet the Lord’s ways have not changed.

Currently in the Church, the Lord has called 317 Seventies, serving in 8 quorums, to assist the Twelve Apostles in carrying the burden placed on the First Presidency. I joyfully feel that responsibility in the depths of my very soul, as do my fellow Brethren. However, we are not the only ones assisting in this glorious work. As members of the Church worldwide, we all have the wonderful opportunity of blessing the lives of others.

I had learned from our dear prophet what the storm-tossed people needed—love, prayers, and appreciation for helping hands.

This afternoon each of us will raise our right arm to the square and sustain the First Presidency and Quorum of the Twelve Apostles as prophets, seers, and revelators of The Church of Jesus Christ of Latter-day Saints. This is not a mere formality, nor is it reserved for those called to general service. To sustain our leaders is a privilege; it comes coupled with a personal responsibility to share their burden and to be disciples of the Lord Jesus Christ.

President Monson has said:

“We are surrounded by those in need of our attention, our encouragement, our support, our comfort, our kindness—be they family members, friends, acquaintances, or strangers. We are the Lord’s hands here upon the earth, with the mandate to serve and to lift His children. He is dependent upon each of us. …

“‘… Inasmuch as ye have done it unto one of the least of these … , ye have done it unto me’ [Matthew 25:40].”2

Will we respond with love when an opportunity is before us to make a visit or a phone call, write a note, or spend a day meeting the needs of someone else? Or will we be like the young man who attested to following all of God’s commandments:

“All these things have I kept from my youth up: what lack I yet?

“Jesus said unto him, If thou wilt be perfect, go and sell that thou hast, and give to the poor, and thou shalt have treasure in heaven: and come and follow me.”3

The young man was being called to a greater service at the side of the Lord to do the work of the kingdom of God on earth, yet he turned away, “for he had great possessions.”4

What of our earthly possessions? We can see what a tornado can do with them in just minutes. It is so important for each of us to strive to lay up our spiritual treasures in heaven—using our time, talents, and agency in service to God.

Jesus Christ continues to extend the call “Come and follow me.”5 He walked His homeland with His followers in a selfless manner. He continues to walk with us, stand by us, and lead us. To follow His perfect example is to recognize and honor the Savior, who has borne all of our burdens through His sacred and saving Atonement, the ultimate act of service. What He asks of each one of us is to be able and willing to take up the joyful “burden” of discipleship.

While in Oklahoma, I had the opportunity to meet with a few of the families devastated by the mighty twisters. As I visited with the Sorrels family, I was particularly touched by the experience of their daughter, Tori, then a fifth grader at Plaza Towers Elementary School. She and her mother are here with us today.

Tori and a handful of her friends huddled in a restroom for shelter as the tornado roared through the school. Listen as I read, in Tori’s own words, the account of that day:

“I heard something hit the roof. I thought it was just hailing. The sound got louder and louder. I said a prayer that Heavenly Father would protect us all and keep us safe. All of a sudden we heard a loud vacuum sound, and the roof disappeared right above our heads. There was lots of wind and debris flying around and hitting every part of my body. It was darker outside and it looked like the sky was black, but it wasn’t—it was the inside of the tornado. I just closed my eyes, hoping and praying that it would be over soon.

“All of a sudden it got quiet.

“When I opened my eyes, I saw a stop sign right in front of my eyes! It was almost touching my nose.”6

Tori, her mother, three of her siblings, and numerous friends who were also in the school with her miraculously survived that tornado; seven of their schoolmates did not.

That weekend the priesthood brethren gave many blessings to members who had suffered in the storm. I was humbled to give Tori a blessing. As I laid my hands on her head, a favorite scripture came to mind: “I will go before your face. I will be on your right hand and on your left, and my Spirit shall be in your hearts, and mine angels round about you, to bear you up.”7

I counseled Tori to remember the day when a servant of the Lord laid his hands on her head and pronounced that she had been protected by angels in the storm.

Reaching out to rescue one another, under any condition, is an eternal measure of love. This is the service I witnessed in Oklahoma that week.

Often we are given the opportunity to help others in their time of need. As members of the Church, we each have the sacred responsibility “to bear one another’s burdens, that they may be light,”8 “to mourn with those that mourn,”9 and to “lift up the hands which hang down, and strengthen the feeble knees.”10

Brothers and sisters, how grateful the Lord is for each and every one of you, for the countless hours and acts of service, whether large or small, you so generously and graciously give each day.

King Benjamin taught in the Book of Mormon, “When ye are in the service of your fellow beings ye are only in the service of your God.”11

Focusing on serving our brothers and sisters can guide us to make divine decisions in our daily lives and prepares us to value and love what the Lord loves. In so doing, we witness by our very lives that we are His disciples. When we are engaged in His work, we feel His Spirit with us. We grow in testimony, faith, trust, and love.

I know that my Redeemer lives, even Jesus Christ, and that He speaks to and through His prophet, dear President Thomas S. Monson, in this, our day.

May we all find the joy that comes from the sacred service of bearing one another’s burdens, even those simple and small, is my prayer in the name of Jesus Christ, amen.

# References
1. - Numbers 11:16–17.
2. - Thomas S. Monson, “What Have I Done for Someone Today?” Ensign or Liahona, Nov. 2009, 86, 87.
3. - Matthew 19:20–21.
4. - Matthew 19:22.
5. - Matthew 19:21.
6. - Experience of Victoria (Tori) Sorrels, recounted Jan. 16, 2014.
7. - Doctrine and Covenants 84:88.
8. - Mosiah 18:8.
9. - Mosiah 18:9.
10. - Doctrine and Covenants 81:5.
11. - Mosiah 2:17.