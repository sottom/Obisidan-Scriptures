President Henry B. Eyring
First Counselor in the First Presidency
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/the-priesthood-man?lang=eng)

_You can be a great model, an average one, or a bad model. You may think it doesn’t matter to you, but it does to the Lord._

We all have heroes, particularly when we are young. I was born and grew up in Princeton, New Jersey, in the United States. The most famous sports teams near where we lived were headquartered in New York City. It was the home of three professional baseball teams in those faraway days: the Brooklyn Dodgers, the New York Giants, and the New York Yankees. Philadelphia was even closer to our home and was the home of the Athletics and the Phillies baseball teams. There were many potential baseball heroes for me on those teams.

Joe DiMaggio, who played for the New York Yankees, became my baseball hero. When my brothers and my friends played baseball on the school grounds next to our house, I tried to swing the bat the way I thought Joe DiMaggio did it. That was before the days of television (this is ancient history), so I only had pictures from newspapers to use to copy his swing.

When I was growing up, my father drove me to Yankee Stadium. That was the only time I saw Joe DiMaggio play. As if I am still there, in my mind I can see him swing the bat and see the white baseball fly straight into the stands at center field.

Now, my baseball skills never came close to those of my childhood hero. But the few times I hit a baseball well, I copied the level of his powerful swing as closely as I could.



When we choose heroes, we begin to copy, consciously or unconsciously, what we admire most in them.

Happily, my wise parents put great heroes in my path as a boy. My dad took me to Yankee Stadium only once to observe my baseball hero play, but every Sunday he let me observe a priesthood man who became a hero. That hero shaped my life. My father was the branch president of the little branch which met in our home. By the way, if you came down to the first floor on Sunday morning, you were in church. Our branch never had more than 30 people in attendance.

There was a young man who drove his mother to our house for meetings, but he never came into the house. He was not a member. It was my father who succeeded by going out to him where he parked the car and inviting him into our home. He was baptized and became my first and only Aaronic Priesthood leader. He became my priesthood hero. I still remember the wooden statue he gave me as a reward after we had completed a project to cut firewood for a widow. I have tried to be like him whenever I give justified praise to a servant of God.

I chose another hero in that little branch of the Church. He was a United States Marine who came to our meetings wearing his green marine uniform. It was wartime, so that alone made him my hero. He had been sent to Princeton University by the marines to further his education. But far more than admiring his military uniform, I watched him play in Palmer Stadium as captain of the Princeton University football team. I saw him play on the university basketball team and also watched him play as the star catcher on their baseball team.

But even more, he came to my home during the week to show me how to shoot a basketball with both my left and my right hand. He told me that I would need that skill because I would someday play basketball on good teams. I did not realize it then, but for years he was, for me, a model of a true priesthood man.

Each of you will be a model of a priesthood man whether you want to be or not. You became a lighted candle when you accepted the priesthood. The Lord put you on the candlestick to light the way for everyone who surrounds you. That is especially true for those in your priesthood quorum. You can be a great model, an average one, or a bad model. You may think it doesn’t matter to you, but it does to the Lord. He said it this way:

“Ye are the light of the world. A city that is set on an hill cannot be hid.

“Neither do men light a candle, and put it under a bushel, but on a candlestick; and it giveth light unto all that are in the house.

“Let your light so shine before men, that they may see your good works, and glorify your Father which is in heaven.”1

I have been blessed by examples of great priesthood holders in quorums where I was fortunate to serve. You can do what they have done for me by being an example for others to follow.

I have observed three common characteristics of the priesthood holders who are my heroes. One is a pattern of prayer, the second is a habit of service, and the third is a rock-hard decision to be honest.

We all pray, but the priesthood holder you want to be prays often and with real intent. In the evening you will get on your knees and thank God for the blessings of the day. You will thank Him for parents, for teachers, and for great examples to follow. You will describe in your prayers specifically who has blessed your life and how, during that day. That will take more than a few minutes and more than a little thought. It will surprise you and change you.

As you pray for forgiveness, you will find yourself forgiving others. As you thank God for His kindness, you will think of others, by name, who need your kindness. Again, that experience will surprise you every day, and over time it will change you.

One way you will be changed by such fervent prayer is, I promise you, that you will feel truly that you are a child of God. When you know that you are a child of God, you will also know that He expects much of you. Because you are His child, He will expect you to follow His teachings and the teachings of His dear Son, Jesus Christ. He will expect you to be generous and kind to others. He will be disappointed if you are proud and self-centered. He will bless you to have the desire to put the interests of others above your own.

Some of you are already models of unselfish priesthood service. In temples across the world, priesthood holders arrive before sunrise. And some serve long after sunset. There is no recognition or public acclaim in this world for that sacrifice of time and effort. I have gone with young people as they serve those in the spirit world, who are not able to claim temple blessings for themselves.

As I see happiness rather than fatigue in the faces of those who serve there early and late, I know there are great rewards in this life for that type of unselfish priesthood service, but it is only a token of the joy they will share with those whom they served in the spirit world.

I have seen that same happiness in the faces of those who speak to others about the blessings which come from belonging to the kingdom of God. I know of a branch president who almost every day brings people to the missionaries for them to teach. Just a few months ago he was not yet a member of the Church. Now there are missionaries teaching and a branch growing in numbers and strength because of him. But more than that, he is a light to others who will open their mouths and so hasten the Lord’s gathering of the children of Heavenly Father.

As you pray and serve others, your knowledge that you are a child of God and your feelings about Him will grow. You will become more aware that He is saddened if you are dishonest in any way. You will be more determined to keep your word to God and to others. You will be more aware of taking anything that does not belong to you. You will be more honest with your employers. You will be more determined to be on time and to complete every task you are given by the Lord that you have accepted to do.

Rather than wondering if their home teachers will come, children in the families you are called to teach will look forward with anticipation to your visit. My children have received that blessing. As they grew, they had priesthood heroes help them set their own courses in serving the Lord. That blessed example is now passing into the third generation.

My message is also one of thanks.

I thank you for your prayers. I thank you for getting on your knees in recognition of the fact that you don’t have all the answers. You pray to the God of heaven to express your gratitude and to invoke His blessings upon your lives and your families. I thank you for your service to others and for the times you felt no need for acknowledgment of your service.

We have accepted the Lord’s warning that if we seek credit in this world for our service, we may forfeit greater blessings. You will remember these words:



“Take heed that ye do not your alms before men, to be seen of them: otherwise ye have no reward of your Father which is in heaven.

“Therefore when thou doest thine alms, do not sound a trumpet before thee, as the hypocrites do in the synagogues and in the streets, that they may have glory of men. Verily I say unto you, They have their reward.

“But when thou doest alms, let not thy left hand know what thy right hand doeth:

“That thine alms may be in secret: and thy Father which seeth in secret himself shall reward thee openly.”2

Those who have been my models of great priesthood holders do not easily recognize that they possess heroic qualities. In fact, they seem to have difficulty seeing those things that I so much admire in them. I mentioned my father was a faithful president of a tiny branch of the Church in New Jersey. He later was a member of the Sunday School general board for the Church. Yet I am careful today to speak modestly about his priesthood service, because he was modest.

The same is true for the marine who was my childhood hero. He never spoke to me of his priesthood service or of his accomplishments. He just gave service. I learned about his faithfulness from others. If he even saw the characteristics in himself that I admired, I could not tell.

So my counsel to you who want to bless others with your priesthood has to do with your life which is private to all but God.

Pray to Him. Thank Him for all that is good in your life. Ask Him to know what individuals He has placed in your way for you to serve. Plead that He will help you give that service. Pray so that you can forgive and so that you can be forgiven. Then serve them, love them, and forgive them.

Above all, remember that of all the service you give, none is greater than to help people choose to qualify for eternal life. God has given that overarching direction to us on how to use our priesthood. He is the perfect example of it. This is the example we see in small part in the best of His mortal servants:

“And the Lord God spake unto Moses, saying: The heavens, they are many, and they cannot be numbered unto man; but they are numbered unto me, for they are mine.

“And as one earth shall pass away, and the heavens thereof even so shall another come; and there is no end to my works, neither to my words.

“For behold, this is my work and my glory—to bring to pass the immortality and eternal life of man.”3

We are to help in that work. Each of us can make a difference. We have been prepared for our time and place in the last days of that sacred work. Each of us has been blessed with examples of those who have made that work the overriding purpose of their time on earth.

I pray that we may help each other rise to that opportunity.

God the Father lives and will answer your prayers for the help you need to serve Him well. Jesus Christ is the risen Lord. This is His Church. The priesthood you hold is the power to act in His name in His work to serve the children of God. As you give your whole heart to this work, He will magnify you. I so promise in the name of Jesus Christ, our Savior, amen.

# References
1. - Matthew 5:14–16.
2. - Matthew 6:1–4.
3. - Moses 1:37–39.