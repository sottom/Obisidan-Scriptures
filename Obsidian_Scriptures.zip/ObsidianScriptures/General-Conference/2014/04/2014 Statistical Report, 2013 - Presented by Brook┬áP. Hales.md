Presented by Brook P. Hales
Secretary to the First Presidency
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/statistical-report-2013?lang=eng)

For the information of the members of the Church, the First Presidency has issued the following statistical report regarding the growth and status of the Church as of December 31, 2013.



Church Units



Stakes



3,050



Missions



405



Districts



571



Wards and Branches



29,253



Church Membership



Total Membership



15,082,028



New Children of Record



115,486



Converts Baptized



282,945



Missionaries



Full-Time Missionaries



83,035



Church-Service Missionaries



24,032



Temples



Temples Dedicated during 2013 (Tegucigalpa Honduras Temple)



1



Temples in Operation at Year End



141

# References
