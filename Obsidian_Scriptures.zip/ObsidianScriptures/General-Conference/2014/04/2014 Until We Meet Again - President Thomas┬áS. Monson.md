President Thomas S. Monson
President of the Church
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/until-we-meet-again?lang=eng)

_May the Spirit we have felt during these past two days be and abide with us as we go about those things which occupy us each day._

My brothers and sisters, what a wonderful conference this has been. We have been fed spiritually as we have listened to the inspired words of the men and women who have addressed us. The music has been superb, the messages have been prepared and delivered under the promptings of the Holy Spirit, and the prayers have drawn us nearer to heaven. We have been uplifted in every way as we have participated together.

I hope that we will take the time to read the conference messages when they become available on LDS.org within the next few days and when they are printed in coming issues of the Ensign and Liahona magazines, for they are deserving of our careful review and study.

I know you join with me in expressing our sincere gratitude to those brethren and sisters who were released during this conference. They have served well and have made significant contributions to the work of the Lord. Their dedication has been complete.

We have also sustained, by uplifted hands, brethren who have been called to new positions of responsibility. We welcome them and want them to know that we look forward to serving with them in the cause of the Master.

As we ponder the messages we have heard, may we resolve to do a little better than we have done in the past. May we be kind and loving to those who do not share our beliefs and our standards. The Savior brought to this earth a message of love and goodwill to all men and women. May we ever follow His example.

We face many serious challenges in the world today, but I assure you that our Heavenly Father is mindful of us. He will guide and bless us as we put our faith and trust in Him and will see us through whatever difficulties come our way.

May heaven’s blessings be with each of us. May our homes be filled with love and courtesy and with the Spirit of the Lord. May we constantly nourish our testimonies of the gospel, that they will be a protection for us against the buffetings of the adversary. May the Spirit we have felt during these past two days be and abide with us as we go about those things which occupy us each day, and may we ever be found doing the work of the Lord.

I bear testimony that this work is true, that our Savior lives, and that He guides and directs His Church here upon the earth. I leave with you my witness and my testimony that God our Eternal Father lives and loves us. He is indeed our Father, and He is personal and real. May we realize how close to us He is willing to come, how far He is willing to go to help us, and how much He loves us.

My brothers and sisters, may God bless you. May His promised peace be with you now and always.

I bid you farewell until we meet again in six months’ time, and I do so in the name of Jesus Christ, our Lord and Savior, amen.

# References
