Elder Donald L. Hallstrom
Of the Presidency of the Seventy
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/what-manner-of-men?lang=eng)

_What changes are required of us to become the manner of men we ought to be?_

As we visualize this worldwide meeting, we are reminded that there is nothing comparable to this gathering—anywhere. The purpose of the priesthood session of general conference is to teach priesthood holders what manner of men we ought to be (see 3 Nephi 27:27) and to inspire us to reach that ideal.

In my Aaronic Priesthood years in Hawaii half a century ago and as a missionary in England, we would gather in meetinghouses and (with intense effort) listen to the priesthood session using a telephone connection. In later years satellites allowed broadcasts to selected Church locations with those enormous dish receivers so we could both hear and view the proceedings. We were in awe of that technology! Few could have imagined today’s world, where anyone who has access to the Internet with a smartphone, tablet, or computer can receive the messages of this meeting.

However, this vastly increased accessibility to the voices of the Lord’s servants, which are the same as the Lord’s own voice (see D&C 1:38), has little value unless we are willing to receive the word (see D&C 11:21) and then follow it. Simply stated, the purpose of general conference and of this priesthood session is fulfilled only if we are willing to act—if we are willing to change.

Several decades ago I was serving as a bishop. Over an extended period I met with a man in our ward who was many years my senior. This brother had a troubled relationship with his wife and was estranged from their children. He struggled to keep employment, had no close friends, and found interaction with ward members so difficult he finally was unwilling to serve in the Church. During one intense discussion about the challenges in his life, he leaned toward me—as his conclusion to our numerous talks—and said, “Bishop, I have a bad temper, and that’s just the way I am!”

That statement stunned me that night and has haunted me ever since. Once this man decided—once any of us conclude—“That’s just the way I am,” we give up our ability to change. We might as well raise the white flag, put down our weapons, concede the battle, and just surrender—any prospect of winning is lost. While some of us may think that does not describe us, perhaps every one of us demonstrates by at least one or two bad habits, “That’s just the way I am.”

Well, we meet in this priesthood meeting because who we are is not who we can become. We meet here tonight in the name of Jesus Christ. We meet with the confidence that His Atonement gives every one of us—no matter our weaknesses, our frailties, our addictions—the ability to change. We meet with the hope that our future, no matter our history, can be better.

When we participate in this meeting with the “real intent” to change (Moroni 10:4), the Spirit has full access to our hearts and minds. As the Lord revealed to the Prophet Joseph Smith, “And it shall come to pass, that inasmuch as they … exercise faith in me”—remember, faith is a principle of power and of action—“I will pour out my Spirit upon them in the day that they assemble themselves together” (D&C 44:2). That means tonight!

If you think your challenges are insurmountable, let me tell you of a man we met in a small village outside of Hyderabad, India, in 2006. This man exemplified a willingness to change. Appa Rao Nulu was born in rural India. When he was three years old, he contracted polio and was left physically disabled. His society taught him that his potential was severely limited. However, as a young adult he met our missionaries. They taught him of a greater potential, both in this life and in the eternity to come. He was baptized and confirmed a member of the Church. With a significantly raised vision, he set a goal to receive the Melchizedek Priesthood and to serve a full-time mission. In 1986 he was ordained an elder and called to serve in India. Walking was not easy—he did his best, using a cane in each hand, and he fell often—but quitting was never an option. He made a commitment to honorably and devotedly serve a mission, and he did.

When we met Brother Nulu, nearly 20 years after his mission, he cheerfully greeted us where the road ended and led us down an uneven dirt path to the two-room home he shared with his wife and three children. It was an extremely hot and uncomfortable day. He still walked with great difficulty, but there was no self-pity. Through personal diligence, he has become a teacher, providing schooling for the village children. When we entered his modest house, he immediately took me to a corner and pulled out a box that contained his most important possessions. He wanted me to see a piece of paper. It read, “With good wishes and blessings to Elder Nulu, a courageous and happy missionary; [dated] June 25, 1987; [signed] Boyd K. Packer.” On that occasion, when then-Elder Packer visited India and spoke to a group of missionaries, he affirmed to Elder Nulu his potential. In essence, what Brother Nulu was telling me that day in 2006 was that the gospel had changed him—permanently!

On this visit to the Nulu home, we were accompanied by the mission president. He was there to interview Brother Nulu, his wife, and his children—for the parents to receive their endowments and be sealed and for the children to be sealed to their parents. We also presented the family with arrangements for them to travel to the Hong Kong China Temple for these ordinances. They wept with joy as their long-awaited dream was to be realized.



What is expected of a holder of the priesthood of God? What changes are required of us to become the manner of men we ought to be? I make three suggestions:





We need to be priesthood men! Whether we are young men holding the Aaronic Priesthood or men bearing the Melchizedek Priesthood, we need to be priesthood men, showing spiritual maturity because we have made covenants. As Paul said, “When I was a child, I spake as a child, I understood as a child, I thought as a child: but when I became a man, I put away childish things” (1 Corinthians 13:11). We should be different because we hold the priesthood—not arrogant or prideful or patronizing but humble and teachable and meek. Receiving the priesthood and its various offices should mean something to us. It should not be a perfunctory “rite of passage” that automatically happens at certain ages but a sacred act of covenant thoughtfully made. We should feel so privileged and so grateful that our every action shows it. If we seldom even think about the priesthood, we need to change.





We need to serve! The essence of holding the priesthood is to magnify our calling (see D&C 84:33) by serving others. Avoiding our most important duty to serve our wives and children, not accepting or passively fulfilling callings in the Church, or not caring about others unless it is convenient is not who we should be. The Savior declared, “Thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy mind” (Matthew 22:37) and later added, “If thou lovest me thou shalt serve me” (D&C 42:29). Selfishness is the antithesis of priesthood responsibility, and if it is a trait of our character, we need to change.





We need to be worthy! I may not have the ability of Elder Jeffrey R. Holland when he spoke in a priesthood session a few years ago to “get in your face … , nose to nose, with just enough fire … to singe your eyebrows” (“We Are All Enlisted,” Ensign or Liahona, Nov. 2011, 45); but, dear brethren, we need to wake up to how commonly accepted practices in the world choke our power in the priesthood. If we think we can even flirt with pornography or violations of chastity or dishonesty in any form and not have it negatively affect us and our families, we are deceived. Moroni stated, “See that ye do all things in worthiness” (Mormon 9:29). The Lord powerfully directed, “And I now give unto you a commandment to beware concerning yourselves, to give diligent heed to the words of eternal life” (D&C 84:43). If there are any unresolved sins preventing our worthiness, we need to change.





The only complete response to the question posed by Jesus Christ “What manner of men ought ye to be?” is the one He succinctly and profoundly gave: “Even as I am” (3 Nephi 27:27). The invitation to “come unto Christ, and be perfected in him” (Moroni 10:32) both requires and expects change. Mercifully, He has not left us alone. “And if men come unto me I will show unto them their weakness. … Then will I make weak things become strong” (Ether 12:27). Relying upon the Savior’s Atonement, we can change. Of this I am certain. In the name of Jesus Christ, amen.

# References
