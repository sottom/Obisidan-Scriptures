President Thomas S. Monson
President of the Church
04-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/04/welcome-to-conference?lang=eng)

_We are … united in our faith and in our desire to listen to and learn from the messages which will be presented to us._

My beloved brothers and sisters, how pleased I am to welcome you to this worldwide conference of The Church of Jesus Christ of Latter-day Saints. We are gathered together as a great family, more than 15 million strong, united in our faith and in our desire to listen to and learn from the messages which will be presented to us.

The past six months have gone by quickly as the work of the Church has moved forward unhindered. It was my privilege just over a month ago to dedicate the Gilbert Arizona Temple, a magnificent structure. The evening before the dedication, a cultural event was held at the nearby Discovery Park. Twelve thousand young people performed a 90-minute program. The dancing, the singing, and the musical performances were outstanding.

This area had been experiencing an especially dry season, and I believe many prayers had been sent heavenward over the preceding several weeks for much-needed rain. Unfortunately, it came just before the performance and stayed for the entire production! Despite the fact that the youth were soaked through with the rain and chilled from the cool temperature, we all felt the Spirit of the Lord. The theme of the program, “Live True to the Faith”—think about that: “Live True to the Faith”—was portrayed magnificently by smiling and enthusiastic young men and young women. Despite the cold and the rain, this was a faith-filled and inspiring experience these young people will ever treasure and will be relating to their children and grandchildren in the years to come.

The following day, the dedication of the Gilbert Arizona Temple took place. It became the 142nd operating temple in the Church. Unlike the evening before, the day was beautiful and filled with sunshine. The sessions were truly inspiring. Attending with me were President Henry B. Eyring, Elder and Sister Tad R. Callister, Elder and Sister William R. Walker, and Elder and Sister Kent F. Richards.

In May the Fort Lauderdale Florida Temple will be dedicated. Other temples are scheduled to be completed and dedicated later this year. In 2015 we anticipate completing and dedicating new temples in many parts of the world. This process will continue. When all the previously announced temples are completed, we will have 170 operating temples throughout the world.

Although we are currently concentrating our efforts on completing the previously announced temples and will not be announcing any new temples in the immediate future, we will continue the process of determining needs and of finding locations for temples yet to come. Announcements will then be made in future general conferences. We are a temple-building and a temple-attending people.

Now, brothers and sisters, we are anxious to listen to the messages which will be presented to us today and tomorrow. Those who will address us have sought heaven’s help and direction as they have prepared their messages.

May we—all of us, here and elsewhere—be filled with the Spirit of the Lord and be uplifted and inspired as we listen and learn. In the name of Jesus Christ, our Savior, amen.

# References
