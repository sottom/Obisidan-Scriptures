Jean A. Stevens
First Counselor in the Primary General Presidency
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/covenant-daughters-of-god?lang=eng)

_When daughters of God focus on the temple and on their sacred covenants, God is able to send blessings in personal and powerful ways._

Dear sisters, I greet you with so much love. Right now, wherever you are in the world, I hope you feel the Lord’s love for you personally and the Spirit witnessing to your heart the message just sung by this beautiful choir. I add my voice of testimony to theirs: I know that my Redeemer lives and that He loves each one of us.

Tonight we gather as covenant daughters of God. Our ages, circumstances, and personalities cannot separate us, because above all we are His. We have made a covenant to remember His Son always.

The power of that individual covenant was impressed upon my heart three weeks ago as I attended a baptismal service. There before me were eight beautiful children sitting with reverent anticipation that finally their special day had arrived. But as I looked into their bright faces, I did not see just a group of children. Instead I saw them as I think the Lord would—individually. I saw Emma and Sophia and Ian and Logan and Aden and William and Sophie and Micah. Each baptismal covenant is made one by one. Each dressed in white, they were there—ready and willing with all their eight-year-old hearts to make their first covenant with God.

Think back and picture your own baptismal day. Whether you can remember many details or just a few, try to feel now the significance of the covenant you individually made. Having been called by your own name, you were immersed in water and came forth as God’s daughter—a covenant daughter, one willing to be called by the name of His Son and promising to follow Him and keep His commandments.

Covenants with God help us to know who we really are. They connect us to Him in a personal way through which we come to feel our value in His sight and our place in His kingdom. In a way we can’t fully comprehend, we are known and loved individually by Him. Think of it—each of us holds such a place in His heart. His desire is that we will choose the path that will bring us home to Him.

As essential and significant as the covenant of baptism is, it is only the beginning—the gate that puts us on the path to eternal life. Ahead on our journey are temple covenants to be made and priesthood ordinances to receive. As Elder David A. Bednar reminds us, “As we stand in the waters of baptism, we look to the temple.”1

It is not only in making covenants but also in faithfully keeping these covenants that we are prepared to receive eternal life. That is our hope, our goal, and our joy.

I was an eyewitness to the power of covenants as I watched my righteous parents, who loved and lived the gospel. In my sweet mother I was privileged to see clearly the daily decisions of a covenant daughter of God. Even when she was a girl, her choices reflected her priorities and identified her as a true disciple of Jesus Christ. I have seen the peace, the power, and the protection that came into her life as she made and kept sacred covenants on her journey. Her life on this earth reflected her love for the Savior and her desire to follow Him. Oh, how I want to follow her example.

My parents’ lives together began in an unusual way. It was 1936. They were dating seriously and were planning to marry, when my dad received a letter inviting him to serve as a full-time missionary in South Africa. The letter said that if he was worthy and willing to serve, he was to contact his bishop. You can quickly see that the process of being called as a missionary was very different in those days! Dad showed the letter to his sweetheart, Helen, and they determined without question he would serve.

For two weeks before he left, Mom met Dad each day for a picnic lunch in Memory Grove near downtown Salt Lake City. During one of their lunches, having sought direction through fasting and prayer, Mother told her dear Claron that if he still wanted to, she would marry him before he left. In the early days of the Church, men were sometimes called to missionary service and left wives and families at home. So it was with my mother and dad. With the approval of his priesthood leaders, they decided to be married before he departed for his mission.

In the Salt Lake Temple, Mother received her endowment, and then they were married for time and all eternity by President David O. McKay. Theirs was a humble beginning. There were no photographs, no beautiful wedding dress, no flowers, and no reception to celebrate the occasion. Their clear focus was on the temple and their covenants. For them, the covenants were everything. After only six days of marriage and with a tearful good-bye, my dad left for South Africa.

But their marriage was more than just the deep love they had for each other. They also had a love of the Lord and a desire to serve Him. The sacred temple covenants they had made gave them strength and power to carry them through the two years of separation. They had an eternal perspective of life’s purpose and of promised blessings that come to those who are faithful to their covenants. All these blessings transcended their short-term sacrifice and separation.

While it certainly wasn’t an easy way to begin married life, it proved to be an ideal way to lay a foundation for an eternal family. As children came along, we knew what mattered most to our parents. It was their love for the Lord and their unwavering commitment to keeping the covenants they had made. Though my parents have both passed away, their pattern of righteousness is blessing our family still.

The example of their lives is reflected in the words of Sister Linda K. Burton: “The best way to strengthen a home, current or future, is to keep covenants.”2

Their season of hardship and trial was not over. Three years after Dad returned from his mission, World War II was raging, and like so many others, he enlisted in the military. He was away from home for another four years as he served in the navy aboard battleships in the Pacific.

It was a difficult time for my parents to be separated again. But for my mother, those days of loneliness, worry, and uncertainty were also marked by whisperings of the Spirit that spoke of eternal promises, of comfort and peace amid the storm.

Despite her challenges, my mother lived a rich life, full of happiness, joy, love, and service. Her love of the Savior was reflected in the way she lived her life. She had a remarkable connection to heaven and a gift and capacity to love and bless everyone around her. Her faith in God and hope in His promises are reflected in President Thomas S. Monson’s words about the temple when he said, “No sacrifice is too great, no price too heavy, no struggle too difficult in order to receive those blessings.”3

In all the seasons of her life, Mother was strengthened and blessed by her love of the Lord and by the covenants she faithfully made and kept.

There is no doubt the details of your story will be different than hers. But principles from her life apply to all of us. When daughters of God focus on the temple and on their sacred covenants, God is able to send blessings in personal and powerful ways. Like my mother’s example to me, your choice to believe and keep covenants will leave a rich legacy of faith for those who follow you. So, dear sisters, how can we access the power and blessings of temple covenants? What can we do now to prepare for those blessings?

As I have traveled, I have come to know there are sisters of all ages, in all circumstances, whose lives provide answers to these questions.

I met Mary shortly after her eighth birthday. Like so many others, she is excited about doing family history and has contributed over 1,000 names for temple work. Mary is preparing herself now for the blessing of entering the temple when she turns 12.

Brianna is 13 and loves doing family history and temple work. She has accepted Elder Neil L. Andersen’s temple challenge.4 She has prepared hundreds of names for temple work and, along with herself, has included her family and friends in performing the baptisms. In this sacred work, Brianna’s heart is turning not only to her earthly fathers but to her Heavenly Father as well.

Although Anfissa is a busy young adult who is working and going to graduate school, she still makes time to attend the temple each week. She seeks revelation and finds peace as she serves in the house of the Lord.

Katya, a dear sister in Ukraine, has a deep love for the temple. Before the temple in Kyiv was built, she and others in her branch sacrificed to travel 36 hours on a bus to attend the temple once a year in Germany. These devoted Saints prayed, studied scriptures, sang hymns, and discussed the gospel as they traveled. Katya told me, “When we finally arrived at the temple, we were prepared to receive what the Lord had to give us.”

If we are to receive all the blessings God so generously offers, our earthly path must lead to the temple. Temples are an expression of God’s love. He invites us all to come, learn of Him, feel His love, and receive the priesthood ordinances necessary for eternal life with Him. Each covenant is made one by one. Every mighty change of heart matters to the Lord. And yours will make all the difference to you. For as we go to His holy house, we can be “armed with [His] power, … [His] name … upon [us], … [His] glory … round about [us], and [His] angels have charge over [us].”5

I share with you my certain witness that our loving Father in Heaven lives. It is through His Beloved Son, Jesus Christ, that every hope, every promise, and every blessing of the temple is fulfilled. May we have faith to trust in Him and His covenants, I pray in the name of Jesus Christ, amen.

# References
1. - David A. Bednar, “Honorably Hold a Name and Standing,” Ensign or Liahona, May 2009, 98.
2. - Linda K. Burton, “Wanted: Hands and Hearts to Hasten the Work,” Ensign or Liahona, May 2014, 123.
3. - Thomas S. Monson, “The Holy Temple—a Beacon to the World,” Ensign or Liahona, May 2011, 92.
4. - See templechallenge.lds.org.
5. - Doctrine and Covenants 109:22.