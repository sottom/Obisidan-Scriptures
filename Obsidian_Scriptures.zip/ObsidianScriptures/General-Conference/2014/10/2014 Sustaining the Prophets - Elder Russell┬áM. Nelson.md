Elder Russell M. Nelson
Of the Quorum of the Twelve Apostles
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/sustaining-the-prophets?lang=eng)

_Our sustaining of prophets is a personal commitment that we will do our utmost to uphold their prophetic priorities._

President Eyring, we thank you for your instructive and inspiring message. My dear brothers and sisters, we thank you for your faith and devotion. Yesterday, we were each invited to sustain Thomas S. Monson as the prophet of the Lord and President of the Lord’s Church. And often we sing, “We thank thee, O God, for a prophet.”1 Do you and I really understand what that means? Imagine the privilege the Lord has given us of sustaining His prophet, whose counsel will be untainted, unvarnished, unmotivated by any personal aspiration, and utterly true!

How do we really sustain a prophet? Long before he became President of the Church, President Joseph F. Smith explained, “It is an important duty resting upon the Saints who … sustain the authorities of the Church, to do so not only by the lifting of the hand, the mere form, but in deed and in truth.”2

Well do I remember my most unique “deed” to sustain a prophet. As a medical doctor and cardiac surgeon, I had the responsibility of performing open-heart surgery on President Spencer W. Kimball in 1972, when he was Acting President of the Quorum of the Twelve Apostles. He needed a very complex operation. But I had no experience doing such a procedure on a 77-year-old patient in heart failure. I did not recommend the operation and so informed President Kimball and the First Presidency. But, in faith, President Kimball chose to have the operation, only because it was advised by the First Presidency. That shows how he sustained his leaders! And his decision made me tremble!

Thanks to the Lord, the operation was a success. When President Kimball’s heart resumed beating, it did so with great power! At that very moment, I had a clear witness of the Spirit that this man would one day become President of the Church!3

You know the outcome. Only 20 months later, President Kimball became President of the Church. And he provided bold and courageous leadership for many years.

Since then we have sustained Presidents Ezra Taft Benson, Howard W. Hunter, Gordon B. Hinckley, and now Thomas S. Monson as Presidents of the Church—prophets in every sense of the word!

My dear brothers and sisters, if the Restoration did anything, it shattered the age-old myth that God had stopped talking to His children. Nothing could be further from the truth. A prophet has stood at the head of God’s Church in all dispensations, from Adam to the present day.4 Prophets testify of Jesus Christ—of His divinity and of His earthly mission and ministry.5 We honor the Prophet Joseph Smith as the prophet of this last dispensation. And we honor each man who has succeeded him as President of the Church.

When we sustain prophets and other leaders,6 we invoke the law of common consent, for the Lord said, “It shall not be given to any one to go forth to preach my gospel, or to build up my church, except he be ordained by some one who has authority, and it is known to the church that he has authority and has been regularly ordained by the heads of the church.”7

This gives us, as members of the Lord’s Church, confidence and faith as we strive to keep the scriptural injunction to heed the Lord’s voice8 as it comes through the voice of His servants the prophets.9 All leaders in the Lord’s Church are called by proper authority. No prophet or any other leader in this Church, for that matter, has ever called himself or herself. No prophet has ever been elected. The Lord made that clear when He said, “Ye have not chosen me, but I have chosen you, and ordained you.”10 You and I do not “vote” on Church leaders at any level. We do, though, have the privilege of sustaining them.

The ways of the Lord are different from the ways of man. Man’s ways remove people from office or business when they grow old or become disabled. But man’s ways are not and never will be the Lord’s ways. Our sustaining of prophets is a personal commitment that we will do our utmost to uphold their prophetic priorities. Our sustaining is an oath-like indication that we recognize their calling as a prophet to be legitimate and binding upon us.

Twenty-six years before he became President of the Church, then-Elder George Albert Smith said: “The obligation that we make when we raise our hands … is a most sacred one. It does not mean that we will go quietly on our way and be willing that the prophet of the Lord shall direct this work, but it means … that we will stand behind him; we will pray for him; we will defend his good name, and we will strive to carry out his instructions as the Lord shall direct.”11

The living Lord leads His living Church!12 The Lord reveals His will for the Church to His prophet. Yesterday, after we were invited to sustain Thomas S. Monson as President of the Church, we also had the privilege to sustain him, the counselors in the First Presidency, and members of the Quorum of the Twelve Apostles as prophets, seers, and revelators. Think of that! We sustain 15 men as prophets of God! They hold all the priesthood keys that have ever been conferred upon man in this dispensation.

The calling of 15 men to the holy apostleship provides great protection for us as members of the Church. Why? Because decisions of these leaders must be unanimous.13 Can you imagine how the Spirit needs to move upon 15 men to bring about unanimity? These 15 men have varied educational and professional backgrounds, with differing opinions about many things. Trust me! These 15 men—prophets, seers, and revelators—know what the will of the Lord is when unanimity is reached! They are committed to see that the Lord’s will truly will be done. The Lord’s Prayer provides the pattern for each of these 15 men when they pray: “Thy will be done on earth as it is in heaven.”14

The Apostle with the longest seniority in the office of Apostle presides.15 That system of seniority will usually bring older men to the office of President of the Church.16 It provides continuity, seasoned maturity, experience, and extensive preparation, as guided by the Lord.

The Church today has been organized by the Lord Himself. He has put in place a remarkable system of governance that provides redundancy and backup. That system provides for prophetic leadership even when the inevitable illnesses and incapacities may come with advancing age.17 Counterbalances and safeguards abound so that no one can ever lead the Church astray. Senior leaders are constantly being tutored such that one day they are ready to sit in the highest councils. They learn how to hear the voice of the Lord through the whisperings of the Spirit.

While serving as First Counselor to President Ezra Taft Benson, who was then nearing the end of his mortal life, President Gordon B. Hinckley explained:

“The principles and procedures which the Lord has put in place for the governance of His church make provision for any … circumstance. It is important … that there be no doubts or concerns about the governance of the Church and the exercise of the prophetic gifts, including the right to inspiration and revelation in administering the affairs and programs of the Church, when the President may be ill or is not able to function fully.

“The First Presidency and the Council of the Twelve Apostles, called and ordained to hold the keys of the priesthood, have the authority and responsibility to govern the Church, to administer its ordinances, to expound its doctrine, and to establish and maintain its practices.”

President Hinckley continued:

“When the President is ill or not able to function fully in all of the duties of his office, his two Counselors together comprise a Quorum of the First Presidency. They carry on with the day-to-day work of the Presidency. …

“… But any major questions of policy, procedures, programs, or doctrine are considered deliberately and prayerfully by the First Presidency and the Twelve together.”18

Last year, when President Monson reached the milestone of 5 years of service as President of the Church, he reflected on his 50 years of apostolic service and made this statement: “Age eventually takes its toll on all of us. However, we join our voices with King Benjamin, who said, … ‘I am like as yourselves, subject to all manner of infirmities in body and mind; yet I have been chosen … and consecrated by my father, … and have been kept and preserved by his matchless power, to serve you with all the might, mind and strength which the Lord hath granted unto me’ (Mosiah 2:11).”

President Monson continued: “Despite any health challenges that may come to us, despite any weakness in body or mind, we serve to the best of our ability. I assure you that the Church is in good hands. The system set up for the Council of the First Presidency and Quorum of the Twelve [Apostles] assures [us] that it will always be in good hands and that, come what may, there is no need to worry or to fear. Our Savior, Jesus Christ, whom we follow, whom we worship, and whom we serve, is ever at the helm.”19

President Monson, we thank you for those truths! And we thank you for your lifetime of exemplary and dedicated service. May I presume to speak for the members of the Church throughout the world in our united and sincere expression of gratitude for you. We honor you! We love you! We sustain you, not only with uplifted hands but with all our hearts and consecrated efforts. Humbly and fervently, “we ever pray for thee, our prophet dear”!20 In the name of Jesus Christ, amen.

# References
1. - “We Thank Thee, O God, for a Prophet,” Hymns, no. 19.
2. - Teachings of Presidents of the Church: Joseph F. Smith (1998), 211; emphasis added. This statement was made in 1898, when President Smith was Second Counselor in the First Presidency.
3. - For further details, see Spencer J. Condie, Russell M. Nelson: Father, Surgeon, Apostle (2003), 153–56.
4. - See Bible Dictionary, “Dispensations.”
5. - A number of prophets foretold the coming of the Lord, including Lehi (see 1 Nephi 1:19), Nephi (see 1 Nephi 11:31–33; 19:7–8), Jacob (see Jacob 4:4–6), Benjamin (see Mosiah 3:5–11, 15), Abinadi (see Mosiah 15:1–9), Alma (see Alma 40:2), and Samuel the Lamanite (see Helaman 14:12). Before the Savior was born in Bethlehem, they foresaw His atoning sacrifice and His subsequent Resurrection.
6. - The principle of sustaining leaders is fundamental throughout the Lord’s Church. A person is sustained before being set apart to a calling or being ordained to an office in the priesthood.
7. - Doctrine and Covenants 42:11. The practice of sustaining our leaders was implemented on April 6, 1830, when the Church was organized, and in March 1836, when members of the First Presidency and the Quorum of the Twelve Apostles were sustained as prophets, seers, and revelators (see History of the Church, 1:74–77; 2:417).
8. - The Book of Mormon warns of danger if we disregard prophetic teachings. From it we read that “the great and spacious building was the pride of the world; and it fell, and the fall thereof was exceedingly great. And the angel of the Lord spake … , saying: Thus shall be the destruction of all nations, kindreds, tongues, and people, that shall fight against the twelve apostles of the Lamb” (1 Nephi 11:36).
9. - See Daniel 9:10; Amos 3:7; Doctrine and Covenants 21:1, 4–5; 124:45–46.
10. - John 15:16. The fifth article of faith clarifies: “We believe that a man must be called of God, by prophecy, and by the laying on of hands by those who are in authority, to preach the Gospel and administer in the ordinances thereof.”
11. - Teachings of Presidents of the Church: George Albert Smith (2011), 64; emphasis added. This quotation came from a conference address by Elder George Albert Smith in 1919. He became President of the Church in 1945.
12. - See Doctrine and Covenants 1:30, 38.
13. - See Doctrine and Covenants 107:27.
14. - 3 Nephi 13:10; see also Matthew 6:10; Luke 11:2.
15. - When a President of the Church dies, the First Presidency is dissolved and the counselors take their places in the Quorum of the Twelve Apostles. The Quorum of the Twelve then presides over the Church until the First Presidency is reorganized. That period of time is known as an apostolic interregnum. Historically, that interval has varied in length from four days to three and a half years.
16. - Of course, that pattern of succession did not apply to the calling of Joseph Smith, who was foreordained to be the prophet of the Restoration and the first President of the Church (see 2 Nephi 3:6–22; see also Abraham 3:22–23).
17. - We know that the Lord Himself can call any of us home anytime He chooses.
18. - Gordon B. Hinckley, “God Is at the Helm,” Ensign, May 1994, 54; see also Gordon B. Hinckley, “He Slumbers Not, nor Sleeps,” Ensign, May 1983, 6.
19. - “Message from President Thomas S. Monson,” Church News, Feb. 3, 2013, 9.
20. - “We Ever Pray for Thee,” Hymns, no. 23.