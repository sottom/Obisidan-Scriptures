Tad R. Callister
Sunday School General President
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/parents-the-prime-gospel-teachers-of-their-children?lang=eng)

_When all is said and done, the home is the ideal forum for teaching the gospel of Jesus Christ._

Ben Carson said of himself, “I was the worst student in my whole fifth-grade class.” One day Ben took a math test with 30 problems. The student behind him corrected it and handed it back. The teacher, Mrs. Williamson, started calling each student’s name for the score. Finally, she got to Ben. Out of embarrassment, he mumbled the answer. Mrs. Williamson, thinking he had said “9,” replied that for Ben to score 9 out of 30 was a wonderful improvement. The student behind Ben then yelled out, “Not nine! … He got none … right.” Ben said he wanted to drop through the floor.

At the same time, Ben’s mother, Sonya, faced obstacles of her own. She was one of 24 children, had only a third-grade education, and could not read. She was married at age 13, was divorced, had two sons, and was raising them in the ghettos of Detroit. Nonetheless, she was fiercely self-reliant and had a firm belief that God would help her and her sons if they did their part.

One day a turning point came in her life and that of her sons. It dawned on her that successful people for whom she cleaned homes had libraries—they read. After work she went home and turned off the television that Ben and his brother were watching. She said in essence: You boys are watching too much television. From now on you can watch three programs a week. In your free time you will go to the library—read two books a week and give me a report.

The boys were shocked. Ben said he had never read a book in his entire life except when required to do so at school. They protested, they complained, they argued, but it was to no avail. Then Ben reflected, “She laid down the law. I didn’t like the rule, but her determination to see us improve changed the course of my life.”

And what a change it made. By the seventh grade he was at the top of his class. He went on to attend Yale University on a scholarship, then Johns Hopkins medical school, where at age 33 he became its chief of pediatric neurosurgery and a world-renowned surgeon. How was that possible? Largely because of a mother who, without many of the advantages of life, magnified her calling as a parent.1

The scriptures speak of the role of parents—that it is their duty to teach their children “the doctrine of repentance, faith in Christ the Son of the living God, and of baptism and the gift of the Holy Ghost” (D&C 68:25).

As parents, we are to be the prime gospel teachers and examples for our children—not the bishop, the Sunday School, the Young Women or Young Men, but the parents. As their prime gospel teachers, we can teach them the power and reality of the Atonement—of their identity and divine destiny—and in so doing give them a rock foundation upon which to build. When all is said and done, the home is the ideal forum for teaching the gospel of Jesus Christ.

About a year ago I was on assignment in Beirut, Lebanon. While there, I learned about a 12-year-old girl, Sarah. Her parents and two older siblings had converted to the Church in Romania but were then required to return to their homeland when Sarah was just 7 years of age. In their homeland there was no Church presence, no organized units, no Sunday School or Young Women program. After five years this family learned of a branch in Beirut and, just before I arrived, sent their 12-year-old daughter, Sarah, accompanied by older siblings, to be baptized. While there, I gave a devotional on the plan of salvation. With some frequency Sarah raised her hand and answered the questions.

After the meeting, and knowing of her almost nonexistent Church exposure, I approached her and asked, “Sarah, how did you know the answers to those questions?” She immediately replied, “My mother taught me.” They did not have the Church in their community, but they did have the gospel in their home. Her mother was her prime gospel teacher.

It was Enos who said, “The words which I had often heard my father speak concerning eternal life, and the joy of the saints, sunk deep into my heart” (Enos 1:3). There is no question who Enos’s prime gospel teacher was.

I remember my father stretched out by the fireplace, reading the scriptures and other good books, and I would stretch out by his side. I remember the cards he would keep in his shirt pocket with quotes of the scriptures and Shakespeare and new words that he would memorize and learn. I remember the gospel questions and discussions at the dinner table. I remember the many times my father took me to visit the elderly—how we would stop by to pick up ice cream for one or a chicken dinner for another or his final handshake with some money enclosed. I remember the good feeling and the desire to be like him.

I remember my mother, age 90 or so, cooking in her condominium kitchen and then exiting with a tray of food. I asked her where she was going. She replied, “Oh, I am taking some food to the elderly.” I thought to myself, “Mother, you are the elderly.” I can never express enough gratitude for my parents, who were my prime gospel teachers.

One of the most meaningful things we can do as parents is teach our children the power of prayer, not just the routine of prayer. When I was about 17 years of age, I was kneeling by my bed, saying my evening prayers. Unbeknown to me, my mother was standing in the doorway. When I finished, she said, “Tad, are you asking the Lord to help you find a good wife?”

Her question caught me totally off guard. That was the furthest thing from my mind. I was thinking about basketball and school. And so, I replied, “No,” to which she responded, “Well, you should, Son; it will be the most important decision you will ever make.” Those words sunk deep into my heart, and so for the next six years, I prayed that God would help me find a good wife. And, oh, how He answered that prayer.

As parents, we can teach our children to pray for things of eternal consequence—to pray for the strength to be morally clean in a very challenging world, to be obedient, and to have the courage to stand for the right.

No doubt most of our youth have their evening prayers, but perhaps many of them struggle with the habit of personal morning prayer. As parents, as their prime gospel teachers, we can correct this. Which parent in Book of Mormon times would have let their sons march out to the front of battle without a breastplate and shield and sword to protect them against the potentially mortal blows of the enemy? But how many of us let our children march out the front door each morning to the most dangerous of all battlefields, to face Satan and his myriad of temptations, without their spiritual breastplate and shield and sword that come from the protective power of prayer? The Lord said, “Pray always, … that you may conquer Satan” (D&C 10:5). As parents, we can help instill within our children the habit and power of morning prayer.

We can also teach our children to use their time wisely. On occasion, like Sonya Carson, we will need to put our foot lovingly but firmly down to restrict our children’s time with television and other electronic devices that in many cases are monopolizing their lives. Instead we may need to redirect their time into more productive gospel-oriented efforts. There may be some initial resistance, some complaining, but like Sonya Carson, we need to have the vision and the will to stick with it. One day our children will understand and appreciate what we have done. If we do not do this, who will?

We might all ask ourselves: do our children receive our best spiritual, intellectual, and creative efforts, or do they receive our leftover time and talents, after we have given our all to our Church calling or professional pursuits? In the life to come, I do not know if titles such as bishop or Relief Society president will survive, but I do know that the titles of husband and wife, father and mother, will continue and be revered, worlds without end. That is one reason it is so important to honor our responsibilities as parents here on earth so we can prepare for those even greater, but similar, responsibilities in the life to come.

As parents, we can proceed with the assurance God will never leave us alone. God never gives us a responsibility without offering divine aid—of that I can testify. May we in our divine role as parents, and in partnership with God, become the prime gospel teachers and examples for our children, I so pray in the name of Jesus Christ, amen.

# References
1. - See Ben Carson, Gifted Hands: The Ben Carson Story (1990).