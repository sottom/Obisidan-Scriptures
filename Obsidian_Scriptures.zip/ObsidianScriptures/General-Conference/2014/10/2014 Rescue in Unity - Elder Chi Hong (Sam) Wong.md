Elder Chi Hong (Sam) Wong
Of the Seventy
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/rescue-in-unity?lang=eng)

_In order to assist the Savior, we have to work together in unity and in harmony. Everyone, every position, and every calling is important._

We often hear President Thomas S. Monson say, “Reach out to rescue.”1 An account in the New Testament comes to my mind. It is a perfect illustration of how members and missionaries can work together in unity through ward councils to reach out and rescue. The story is found in Mark 2:1–5. I find that the experiences Jesus used to teach us certain doctrines or principles are always most inspiring and easy to understand.

One of the characters in this account is a man with palsy, someone who was not able to move without assistance. This man could only stay home, waiting for rescue.

In our day, it might happen like this. Four people were fulfilling an assignment from their bishop to visit, at his home, a man who was sick with palsy. I can visualize one of them coming from the Relief Society, one from the elders quorum, one from the Aaronic Priesthood, and, last but not least, one full-time missionary. In the most recent ward council, after counseling together about the needs in the ward, the bishop had given out “rescuing” assignments. These four were assigned to help this man suffering with palsy. They could not wait for him to come to church by himself. They had to go to his home and visit him. They had to seek him out, and so they went. The man was being brought to Jesus.

“And they [came] unto him, bringing one sick of the palsy, which was borne of four” (Mark 2:3).

However, the room was too crowded. They could not get in through the door. I am sure they tried everything they could think of, but they just could not get through. Things did not happen as smoothly as planned. There were obstacles along their way of “rescue.” But they did not give up. They did not leave the man with palsy by the door. They counseled together on what to do next—how they could bring the man unto Jesus Christ for healing. The work to assist Jesus Christ in saving souls, at least for them, was never too demanding. They came up with a plan—not an easy one, but they acted on it.

“And when they could not come nigh unto him for the press, they uncovered the roof where he was: and when they had broken it up, they let down the bed wherein the sick of the palsy lay” (Mark 2:4).

They brought him up to the roof. Assuming there was no outside staircase for them to climb, it would have taken them quite some time to get everyone onto the roof. I think it might have happened this way: the young man from his ward would have climbed up to the roof first. As he was young and full of energy, it would not have been too difficult for him. His home teaching companion from the elders quorum and the tall and strong full-time missionary would have pushed really hard from below. The Relief Society sister would have reminded them to be careful and given them words of encouragement. The men would then uncover the roof while the sister continued to comfort the man as he waited to be healed—to be able to move by himself and to be free.

This rescue assignment needed everyone working together. At the crucial moment, it would take careful coordination to lower the man with palsy from the roof. The four people would have to work in unity and in harmony. There could not be any discord among the four. They would have to lower the man with palsy at the same pace. If someone released the rope faster than the other three, the man would fall out of his bed. He could not hold on by himself due to his weakened condition.

In order to assist the Savior, we have to work together in unity and in harmony. Everyone, every position, and every calling is important. We have to be united in our Lord Jesus Christ.

Finally, the sick, palsied man was laid before Jesus. “When Jesus saw their faith, he said unto the sick of the palsy, Son, thy sins be forgiven thee” (Mark 2:5). Jesus showed mercy on him and healed him—not only physically but also spiritually: “Son, thy sins be forgiven thee.” Isn’t that wonderful? Wouldn’t we like that to happen to all of us too? Certainly I would.

Do we know anyone in our life who is afflicted with spiritual palsy, someone who just cannot come back to the Church by himself or herself? He or she could be one of our children, one of our parents, a spouse, or a friend.

With so many more full-time missionaries now available in each Church unit, it will be wise for bishops and branch presidents to make better use of their ward and branch councils. The bishop can invite each member of the ward council to come with a list of names of those who may need assistance. Members of the ward council will counsel together carefully on how they might best help. Bishops will listen attentively to the ideas and make assignments.

Full-time missionaries are great resources to the wards in these rescue efforts. They are young and full of energy. They love to have a list of specific names of people to work with. They enjoy working together with ward members. They know these are great finding opportunities for them. They are devoted to establishing the Lord’s kingdom. They have a strong testimony that they will become more Christlike as they participate in these rescuing efforts.

In conclusion, may I share with you one more hidden treasure found in this scripture account. It is in verse 5: “When Jesus saw their faith” (emphasis added). I had not noticed this in the past—their faith. Our combined faith will also affect the well-being of others.

Who were those people that Jesus mentioned? They could well include the four who carried the man with palsy, the man himself, the people who had prayed for him, and all those who were there listening to the preaching of Jesus and cheering quietly in their hearts for the soon-to-come miracle. They could also include a spouse, a parent, a son or a daughter, a missionary, a quorum president, a Relief Society president, a bishop, and a faraway friend. We can all help one another. We should always be anxiously engaged in seeking to rescue those in need.

I testify that Jesus Christ is a God of miracles. Jesus Christ loves us all and has the power to save and heal, both physically and spiritually. When we assist Him in His mission of saving souls, we too will be rescued in the process. I so testify in His holy name, even Jesus Christ, amen.



This address was delivered in Cantonese.

# References
1. - See, for example, Thomas S. Monson, “Our Responsibility to Rescue,” Ensign or Liahona, Oct. 2013, 5.