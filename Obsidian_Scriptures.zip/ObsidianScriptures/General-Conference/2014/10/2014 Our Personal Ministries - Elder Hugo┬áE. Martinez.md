Elder Hugo E. Martinez
Of the Seventy
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/our-personal-ministries?lang=eng)

_The love of Jesus Christ must be our guide if we are to become aware of the needs of those we can help in some way._

In The Church of Jesus Christ of Latter-day Saints, we are given the opportunity and personal blessing to serve. For as long as I have been a member, I have served in many ways. Like Brother Udine Falabella, father of Elder Enrique R. Falabella, used to say, “He who serves in some thing is good for something; he who serves in no thing is good for nothing.” These are words that we need to keep in our minds and in our hearts.

As I have sought guidance during my service, I have found comfort in remembering that the Savior focuses on the individual and the family. His love and tender attention to the individual have taught me that He recognizes the great worth of each of Heavenly Father’s children and that it is essential for us to ensure that each individual is ministered to and strengthened by the gospel of Jesus Christ.

In the scriptures we read:

“Remember the worth of souls is great in the sight of God. …

“And if it so be that you should labor all your days … and bring, save it be one soul unto me, how great shall be your joy with him in the kingdom of my Father!”1

Every soul is of great worth to God, for we are His children and we have the potential to become as He is.2

The love of Jesus Christ must be our guide if we are to become aware of the needs of those we can help in some way. The teachings of our Lord, Jesus Christ, show us the way. And that is how our personal ministry begins: discovering needs, then tending to them. As Sister Linda K. Burton, Relief Society general president, said, “First observe, then serve.”3

President Thomas S. Monson is a great example of this principle. In January of 2005, he was presiding over a priesthood leadership conference in Puerto Rico when he demonstrated how the Savior and His servants render service through personal ministry. At the conclusion of that wonderful meeting, President Monson began to greet all the priesthood leaders in attendance. Suddenly, he noticed that one of them was watching everything from afar, off by himself.

President Monson walked away from the group, toward that brother, and spoke to him. With emotion, José R. Zayas told him it was a miracle that he had approached him and an answer to the prayers that he and his wife, Yolanda, had offered before the meeting. He told President Monson that his daughter was in very poor health and that he had with him a letter from his wife that she wanted delivered to President Monson. Brother Zayas had told his wife that it would be impossible since President Monson would be too busy. President Monson listened to the story and asked for the letter, which he read silently. Then he put it in his suit pocket and told Brother Zayas that he would take care of their request.

In this way, that family was touched by our Lord, Jesus Christ, through His servant. I believe the words of the Savior in the parable of the good Samaritan apply to us: “Go, and do thou likewise.”4

On September 21, 1998, Hurricane Georges hit Puerto Rico, causing extensive damage. Sister Martinez, our five children, and I managed to survive that great storm and its hurricane-force winds by staying in our home. However, we went two weeks without running water and without power.

When our supply of water ran out, obtaining more was difficult. I will never forget the brethren who ministered to us by providing that precious liquid, nor will I forget the loving way the sisters also served us.

Germán Colón came to our house with a large plastic water container in a pickup truck. He told us he was doing it because, in his words, “I know you have little children who need water.” A couple of days later, Brothers Noel Muñoz and Herminio Gómez loaded three large water tanks onto a flatbed truck. They showed up at our house unexpectedly and filled every available water bottle with drinking water, also inviting our neighbors to fill theirs.

Our prayers were answered by their personal ministries. The faces of those three brethren reflected the love that Jesus Christ has for us, and their service—in other words, their personal ministry—brought much more than drinking water into our lives. To every son or daughter of God, knowing that people are interested in and watching out for his or her welfare is essential.

I testify to you that Heavenly Father and our Lord, Jesus Christ, know us individually and personally. For that reason, They provide what we need so we will have the opportunity to reach our divine potential. Along the road, They place people who will help us. Then, as we become instruments in Their hands, we are able to serve and help those They show to us by revelation.

In this way, the Lord Jesus Christ will reach all of Heavenly Father’s children. The Good Shepherd will gather all His sheep. He will do so one by one as they make good use of their moral agency—after hearing the voice of His servants and receiving their ministrations. Then they will recognize His voice, and they will follow Him. Such personal ministry is integral to keeping our baptismal covenants.

Likewise, being a good example of a disciple of Jesus Christ is our best letter of introduction to those with whom we can share His gospel. As we open our mouths and share the restored gospel of Jesus Christ, we become “His undershepherds, charged with nourishing the sheep of His pasture and the lambs of His fold”5; we become “the weak and the simple”6 “fishers of men.”7

Our service and personal ministry are not limited to the living on this earth. We can also do work for the dead—for those who live in the spirit world and who, during their mortal life, did not have the opportunity to receive the saving ordinances of the gospel of Jesus Christ. We can also keep a journal and write our family histories to turn the hearts of the living toward the living—as well as the hearts of the living toward their ancestors. It is all about linking our family, generation by generation, in eternal bonds. As we do so, we become “saviours … on mount Zion.”8

We have the special opportunity to be instruments in His hands. We can be so in our marriages, in our families, with our friends, and with our fellowman. That is our personal ministry as true disciples of Jesus Christ.

“And before him shall be gathered all nations: and he shall separate them one from another, as a shepherd divideth his sheep from the goats:

“And he shall set the sheep on his right hand, but the goats on the left.

“Then shall the King say unto them on his right hand, Come, ye blessed of my Father, inherit the kingdom prepared for you from the foundation of the world:

“For I was an hungred, and ye gave me meat: I was thirsty, and ye gave me drink: I was a stranger, and ye took me in:

“Naked, and ye clothed me: I was sick, and ye visited me: I was in prison, and ye came unto me.

“Then shall the righteous answer him, saying, Lord, when saw we thee an hungred, and fed thee? or thirsty, and gave thee drink?

“When saw we thee a stranger, and took thee in? or naked, and clothed thee?

“Or when saw we thee sick, or in prison, and came unto thee?

“And the King shall answer and say unto them, Verily I say unto you, Inasmuch as ye have done it unto one of the least of these my brethren, ye have done it unto me.”9

That we may do so is my prayer in the name of Jesus Christ, amen.



This address was delivered in Spanish.

# References
1. - Doctrine and Covenants 18:10, 15; emphasis added.
2. - See Guide to the Scriptures, “Soul”; scriptures.lds.org.
3. - Linda K. Burton, “First Observe, Then Serve,” Ensign or Liahona, Nov. 2012, 78.
4. - Luke 10:37.
5. - Alexander B. Morrison, “Nourish the Flock of Christ,” Ensign, May 1992, 13.
6. - Doctrine and Covenants 1:23.
7. - Matthew 4:19.
8. - Obadiah 1:21.
9. - Matthew 25:32–40.