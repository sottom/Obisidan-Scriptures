Elder Dallin H. Oaks
Of the Quorum of the Twelve Apostles
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/loving-others-and-living-with-differences?lang=eng)

_As followers of Christ we should live peacefully with others who do not share our values or accept the teachings upon which they are based._

I.



In the concluding days of His mortal ministry, Jesus gave His disciples what He called “a new commandment” (John 13:34). Repeated three times, that commandment was simple but difficult: “Love one another, as I have loved you” (John 15:12; see also verse 17). The teaching to love one another had been a central teaching of the Savior’s ministry. The second great commandment was “love thy neighbour as thyself” (Matthew 22:39). Jesus even taught, “Love your enemies” (Matthew 5:44). But the commandment to love others as He had loved His flock was to His disciples—and is to us—a challenge that was unique. “Actually,” President Thomas S. Monson taught us last April, “love is the very essence of the gospel, and Jesus Christ is our Exemplar. His life was a legacy of love.”1

Why is it so difficult to have Christlike love for one another? It is difficult because we must live among those who do not share our beliefs and values and covenant obligations. In His great Intercessory Prayer, offered just before His Crucifixion, Jesus prayed for His followers: “I have given them thy word; and the world hath hated them, because they are not of the world, even as I am not of the world” (John 17:14). Then, to the Father He pleaded, “I pray not that thou shouldest take them out of the world, but that thou shouldest keep them from the evil” (verse 15).

We are to live in the world but not be of the world. We must live in the world because, as Jesus taught in a parable, His kingdom is “like leaven,” whose function is to raise the whole mass by its influence (see Luke 13:21; Matthew 13:33; see also 1 Corinthians 5:6–8). His followers cannot do that if they associate only with those who share their beliefs and practices. But the Savior also taught that if we love Him, we will keep His commandments (see John 14:15).







II.



The gospel has many teachings about keeping the commandments while living among people with different beliefs and practices. The teachings about contention are central. When the resurrected Christ found the Nephites disputing over the manner of baptism, He gave clear directions on how this ordinance should be performed. Then He taught this great principle:

“There shall be no disputations among you, as there have hitherto been; neither shall there be disputations among you concerning the points of my doctrine, as there have hitherto been.

“For verily, verily I say unto you, he that hath the spirit of contention is not of me, but is of the devil, who is the father of contention, and he stirreth up the hearts of men to contend with anger, one with another.

“Behold, this is … my doctrine, that such things should be done away” (3 Nephi 11:28–30; emphasis added).



The Savior did not limit His warning against contention to those who were not keeping the commandment about baptism. He forbade contention by anyone. Even those who keep the commandments must not stir up the hearts of men to contend with anger. The “father of contention” is the devil; the Savior is the Prince of Peace.

Similarly, the Bible teaches that “wise men turn away wrath” (Proverbs 29:8). The early Apostles taught that we should “follow after the things [that] make for peace” (Romans 14:19) and “[speak] the truth in love” (Ephesians 4:15), “for the wrath of man worketh not the righteousness of God” (James 1:20). In modern revelation the Lord commanded that the glad tidings of the restored gospel should be declared “every man to his neighbor, in mildness and in meekness” (D&C 38:41), “with all humility, … reviling not against revilers” (D&C 19:30).







III.



Even as we seek to be meek and to avoid contention, we must not compromise or dilute our commitment to the truths we understand. We must not surrender our positions or our values. The gospel of Jesus Christ and the covenants we have made inevitably cast us as combatants in the eternal contest between truth and error. There is no middle ground in that contest.

The Savior showed the way when His adversaries confronted Him with the woman who had been “taken in adultery, in the very act” (John 8:4). When shamed with their own hypocrisy, the accusers withdrew and left Jesus alone with the woman. He treated her with kindness by declining to condemn her at that time. But He also firmly directed her to “sin no more” (John 8:11). Loving-kindness is required, but a follower of Christ—just like the Master—will be firm in the truth.







IV.



Like the Savior, His followers are sometimes confronted by sinful behavior, and today when they hold out for right and wrong as they understand it, they are sometimes called “bigots” or “fanatics.” Many worldly values and practices pose such challenges to Latter-day Saints. Prominent among these today is the strong tide that is legalizing same-sex marriage in many states and provinces in the United States and Canada and many other countries in the world. We also live among some who don’t believe in marriage at all. Some don’t believe in having children. Some oppose any restrictions on pornography or dangerous drugs. Another example—familiar to most believers—is the challenge of living with a nonbelieving spouse or family member or associating with nonbelieving fellow workers.

In dedicated spaces, like temples, houses of worship, and our own homes, we should teach the truth and the commandments plainly and thoroughly as we understand them from the plan of salvation revealed in the restored gospel. Our right to do so is protected by constitutional guarantees of freedom of speech and religion, as well as by the privacy that is honored even in countries without formal constitutional guarantees.

In public, what religious persons say and do involves other considerations. The free exercise of religion covers most public actions, but it is subject to qualifications necessary to accommodate the beliefs and practices of others. Laws can prohibit behavior that is generally recognized as wrong or unacceptable, like sexual exploitation, violence, or terrorist behavior, even when done by extremists in the name of religion. Less grievous behaviors, even though unacceptable to some believers, may simply need to be endured if legalized by what a Book of Mormon prophet called “the voice of the people” (Mosiah 29:26).

On the subject of public discourse, we should all follow the gospel teachings to love our neighbor and avoid contention. Followers of Christ should be examples of civility. We should love all people, be good listeners, and show concern for their sincere beliefs. Though we may disagree, we should not be disagreeable. Our stands and communications on controversial topics should not be contentious. We should be wise in explaining and pursuing our positions and in exercising our influence. In doing so, we ask that others not be offended by our sincere religious beliefs and the free exercise of our religion. We encourage all of us to practice the Savior’s Golden Rule: “Whatsoever ye would that men should do to you, do ye even so to them” (Matthew 7:12).

When our positions do not prevail, we should accept unfavorable results graciously and practice civility with our adversaries. In any event, we should be persons of goodwill toward all, rejecting persecution of any kind, including persecution based on race, ethnicity, religious belief or nonbelief, and differences in sexual orientation.







V.



I have spoken of general principles. Now I will speak of how those principles should apply in a variety of familiar circumstances in which the Savior’s teachings should be followed more faithfully.

I begin with what our young children learn in their play activities. Too often non-Mormons here in Utah have been offended and alienated by some of our members who will not allow their children to be friends with children of other faiths. Surely we can teach our children values and standards of behavior without having them distance themselves or show disrespect to any who are different.

Many teachers in church and school have grieved at the way some teenagers, including LDS youth, treat one another. The commandment to love one another surely includes love and respect across religious lines and also across racial, cultural, and economic lines. We challenge all youth to avoid bullying, insults, or language and practices that deliberately inflict pain on others. All of these violate the Savior’s command to love one another.

The Savior taught that contention is a tool of the devil. That surely teaches against some of the current language and practices of politics. Living with policy differences is essential to politics, but policy differences need not involve personal attacks that poison the process of government and punish participants. All of us should banish hateful communications and practice civility for differences of opinion.

The most important setting to forgo contention and practice respect for differences is in our homes and family relationships. Differences are inevitable—some minor and some major. As to major differences, suppose a family member is in a cohabitation relationship. That brings two important values into conflict—our love for the family member and our commitment to the commandments. Following the Savior’s example, we can show loving-kindness and still be firm in the truth by forgoing actions that facilitate or seem to condone what we know to be wrong.

I close with another example of a family relationship. At a stake conference in the Midwest about 10 years ago, I met a sister who told me that her nonmember husband had been accompanying her to church for 12 years but had never joined the Church. What should she do? she asked. I counseled her to keep doing all the right things and to be patient and kind with her husband.

About a month later she wrote me as follows: “Well, I thought that the 12 years was a good show of patience, but I didn’t know if I was being very kind about it. So, I practiced real hard for over a month, and he got baptized.”



Kindness is powerful, especially in a family setting. Her letter continued, “I am even trying to be kinder now because we are working on a temple sealing this year!”

Six years later she wrote me another letter: “My husband was [just] called and set apart as the bishop [of our ward].”2







VI.



In so many relationships and circumstances in life, we must live with differences. Where vital, our side of these differences should not be denied or abandoned, but as followers of Christ we should live peacefully with others who do not share our values or accept the teachings upon which they are based. The Father’s plan of salvation, which we know by prophetic revelation, places us in a mortal circumstance where we are to keep His commandments. That includes loving our neighbors of different cultures and beliefs as He has loved us. As a Book of Mormon prophet taught, we must press forward, having “a love of God and of all men” (2 Nephi 31:20).

As difficult as it is to live in the turmoil surrounding us, our Savior’s command to love one another as He loves us is probably our greatest challenge. I pray that we may understand this and seek to live it in all of our relationships and activities, in the name of Jesus Christ, amen.

# References
1. - Thomas S. Monson, “Love—the Essence of the Gospel,” Ensign or Liahona, May 2014, 91.
2. - Letters to Dallin H. Oaks, Jan. 23, 2006, and Oct. 30, 2012.