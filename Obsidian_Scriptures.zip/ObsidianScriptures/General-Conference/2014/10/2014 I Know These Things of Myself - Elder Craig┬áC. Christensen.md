Elder Craig C. Christensen
Of the Presidency of the Seventy
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/i-know-these-things-of-myself?lang=eng)

_Learning for ourselves that the restored gospel of Jesus Christ is true can be one of the greatest and most joyful experiences in life._

My dear brethren, we are continually inspired by the personal example and priesthood service of President Thomas S. Monson. Recently, several deacons were asked, “What do you admire most about President Monson?” One deacon recalled how President Monson, as a child, gave his toys to needy friends. Another mentioned how President Monson cared for the many widows in his ward. A third noted that he was called as an Apostle at a very young age and has blessed people all around the world. Then one young man said, “The thing I admire most about President Monson is his strong testimony.”

Indeed, we have all felt our prophet’s special witness of the Savior Jesus Christ and his commitment to always follow the promptings of the Spirit. With each experience he shares, President Monson invites us to live the gospel more fully and to seek for and strengthen our own personal testimonies. Remember what he said from this pulpit just a few conferences ago: “In order for us to be strong and to withstand all the forces pulling us in the wrong direction … , we must have our own testimony. Whether you are 12 or 112—or anywhere in between—you can know for yourself that the gospel of Jesus Christ is true.”1

Although my message tonight is directed to those who are closer to 12 than 112, the principles I share apply to everyone. In response to President Monson’s statement, I would ask: Does each of us know for ourselves that the gospel is true? Can we say with confidence that our testimonies are truly our own? To quote President Monson again: “I maintain that a strong testimony of our Savior and of His gospel will … protect you from the sin and evil around you. … If you do not already have a testimony of these things, do that which is necessary to obtain one. It is essential for you to have your own testimony, for the testimonies of others will carry you only so far.”2





I Know These Things of Myself



Learning for ourselves that the restored gospel of Jesus Christ is true can be one of the greatest and most joyful experiences in life. We may have to begin by relying on the testimonies of others—saying, as the stripling warriors did, “We do not doubt our mothers knew it.”3 This is a good place to start, but we must build from there. To be strong in living the gospel, there is nothing more important than receiving and strengthening our own testimony. We must be able to declare, as Alma did, “I … know these things of myself.”4

“And how do ye suppose that I know of their surety?” Alma continued. “Behold, I say unto you they are made known unto me by the Holy Spirit of God. Behold, I have fasted and prayed many days that I might know these things of myself. And now I do know of myself that they are true.”5







I Desire to Behold the Things Which My Father Saw



Like Alma, Nephi also came to know the truth for himself. After listening to his father speak of his many spiritual experiences, Nephi wanted to know what his father knew. This was more than simple curiosity—it was something he hungered and thirsted after. Even though he was “exceedingly young,” he had “great desires to know of the mysteries of God.”6 He yearned to “see, and hear, and know of these things, by the power of the Holy Ghost.”7

As Nephi “sat pondering in [his] heart,” he was carried “away in the Spirit … into an exceedingly high mountain,” where he was asked, “What desirest thou?” His response was simple: “I desire to behold the things which my father saw.”8 Because of his believing heart and his diligent efforts, Nephi was blessed with a marvelous experience. He received a witness of the forthcoming birth, life, and Crucifixion of the Savior Jesus Christ; he saw the coming forth of the Book of Mormon and the Restoration of the gospel in the last days—all as a result of his sincere desire to know for himself.9

These personal experiences with the Lord prepared Nephi for the adversity and challenges he would soon face. They enabled him to stand strong even when others in his family were struggling. He could do this because he had learned for himself and he knew for himself. He had been blessed with his own testimony.







Let Him Ask of God



Similar to Nephi, the Prophet Joseph Smith was also “exceedingly young” when his “mind was called up to serious reflection” about spiritual truths. For Joseph, it was a time of “great uneasiness,” being surrounded by conflicting and confusing messages about religion. He wanted to know which church was right.10 Inspired by these words in the Bible, “If any of you lack wisdom, let him ask of God,”11 he acted for himself to find an answer. On a beautiful morning in the spring of 1820, he entered a grove of trees and knelt in prayer. Because of his faith and because God had a special work for him to do, Joseph received a glorious vision of God the Father and His Son, Jesus Christ, and learned for himself what he was to do.

Do you see in Joseph’s experience a pattern you could apply in gaining or strengthening your own testimony? Joseph allowed the scriptures to penetrate his heart. He pondered them deeply and applied them to his own situation. He then acted on what he had learned. The result was the glorious First Vision—and everything that came after it. This Church quite literally was founded on the principle that anyone—including a 14-year-old farm boy—can “ask of God” and receive an answer to his prayers.







So What Is a Testimony?



We often hear members of the Church say that their testimony of the gospel is their most prized possession. It is a sacred gift from God that comes to us by the power of the Holy Ghost. It is the calm, unwavering certainty we receive as we study, pray, and live the gospel. It is the feeling of the Holy Ghost bearing witness to our souls that what we are learning and doing is right.

Some people speak of a testimony as if it were a light switch—it’s either on or off; you either have a testimony, or you do not. In reality, a testimony is more like a tree that passes through various stages of growth and development. Some of the tallest trees on earth are found in Redwood National Park in the western United States. When you stand at the base of these massive trees, it is amazing to think that each one grew from a tiny seed. So it is with our testimonies. Although they may begin with a single spiritual experience, they grow and develop over time through constant nourishment and frequent spiritual encounters.

It’s not surprising, then, that when the prophet Alma explained how we develop a testimony, he spoke of a seed growing into a tree. “If ye give place,” he said, “that a seed may be planted in your heart, behold, if it be a true seed, or a good seed, if ye do not cast it out by your unbelief, … it will begin to swell within your breasts; and when you feel these swelling motions, ye will begin to say within yourselves—It must needs be that this is a good seed, or that the word is good, for it beginneth to enlarge my soul; yea, it beginneth to enlighten my understanding, yea, it beginneth to be delicious to me.”12

This is often how a testimony begins: with sacred, enlightening, assuring feelings that demonstrate to us that the word of God is true. However, as wonderful as these feelings are, they are only the beginning. Your work to grow your testimony is not done—any more than the work of growing a redwood tree is done when the first tiny sprout pokes out of the ground. If we ignore or neglect these early spiritual promptings, if we do not nurture them by continuing to study the scriptures and pray and by seeking more experiences with the Spirit, our feelings will fade and our testimonies will diminish.

As Alma put it: “If ye neglect the tree, and take no thought for its nourishment, behold it will not get any root; and when the heat of the sun cometh and scorcheth it, because it hath no root it withers away, and ye pluck it up and cast it out.”13

In most cases, our testimonies will grow the same way a tree grows: gradually, almost imperceptibly, as a result of our constant care and diligent efforts. “But if ye will nourish the word,” Alma promised, “yea, nourish the tree as it beginneth to grow, by your faith with great diligence, and with patience, looking forward to the fruit thereof, it shall take root; and behold it shall be a tree springing up unto everlasting life.”14







Now Is the Time; Today Is the Day



My own testimony began as I studied and pondered the teachings found in the Book of Mormon. As I knelt down to ask God in humble prayer, the Holy Ghost testified to my soul that what I was reading was true. This early witness became the catalyst for my testimony of many other gospel truths, for, as President Monson taught: “When we know the Book of Mormon is true, then it follows that Joseph Smith was indeed a prophet and that he saw God the Eternal Father and His Son, Jesus Christ. It also follows that the gospel was restored in these latter days through Joseph Smith—including the restoration of both the Aaronic and Melchizedek Priesthoods.”15 Since that day, I have had many sacred experiences with the Holy Ghost that have reaffirmed to me that Jesus Christ is the Savior of the world and that His restored gospel is true. With Alma, I can say with certainty that I know these things of myself.

My young friends, now is the time and today is the day to learn or reaffirm for ourselves that the gospel is true. Each of us has an important work to do. To accomplish that work, and to be protected from worldly influences that seem to be constantly looming, we must have the faith of Alma, Nephi, and young Joseph Smith to obtain and develop our own testimony.

Like the young deacon I spoke of earlier, I admire President Monson for his testimony. It is like a towering redwood, yet even President Monson’s testimony had to grow and develop over time. We can come to know for ourselves, just as President Monson has, that Jesus Christ is our Savior and the Redeemer of the world, that Joseph Smith is the prophet of the Restoration, including the restoration of the priesthood of God. We bear that holy priesthood. May we learn these things and know them for ourselves is my humble prayer in the sacred name of Jesus Christ, amen.

# References
1. - Thomas S. Monson, “Dare to Stand Alone,” Ensign or Liahona, Nov. 2011, 62.
2. - Thomas S. Monson, “Priesthood Power,” Ensign or Liahona, May 2011, 66.
3. - Alma 56:48.
4. - Alma 5:46.
5. - Alma 5:45–46.
6. - 1 Nephi 2:16.
7. - 1 Nephi 10:17.
8. - 1 Nephi 11:1–3.
9. - See 1 Nephi 11–14.
10. - See Joseph Smith—History 1:8–10.
11. - James 1:5.
12. - Alma 32:28.
13. - Alma 32:38.
14. - Alma 32:41.
15. - Thomas S. Monson, Ensign or Liahona, Nov. 2011, 67.