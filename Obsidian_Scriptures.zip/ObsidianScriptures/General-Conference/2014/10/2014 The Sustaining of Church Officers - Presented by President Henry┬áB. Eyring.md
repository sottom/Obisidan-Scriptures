Presented by President Henry B. Eyring
First Counselor in the First Presidency
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/the-sustaining-of-church-officers?lang=eng)

It is proposed that we sustain Thomas Spencer Monson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Henry Bennion Eyring as First Counselor in the First Presidency; and Dieter Friedrich Uchtdorf as Second Counselor in the First Presidency.

Those in favor may manifest it.

Those opposed, if any, may manifest it.

It is proposed that we sustain Boyd Kenneth Packer as President of the Quorum of the Twelve Apostles and the following as members of that quorum: Boyd K. Packer, L. Tom Perry, Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, Richard G. Scott, Robert D. Hales, Jeffrey R. Holland, David A. Bednar, Quentin L. Cook, D. Todd Christofferson, and Neil L. Andersen.

Those in favor, please manifest it.

Any opposed may so indicate.

It is proposed that we sustain the counselors in the First Presidency and the Twelve Apostles as prophets, seers, and revelators.

All in favor, please manifest it.

Contrary, if there be any, by the same sign.

It is proposed that we release with appreciation for their distinguished service Elders Carlos H. Amado and William R. Walker as members of the First Quorum of the Seventy and designate them as emeritus General Authorities.

Those who wish to join with us in expressing gratitude for their devoted service, please manifest it.

Elders Arayik V. Minasyan and Gvido Senkans have been released as Area Seventies. It is proposed that we extend to them a vote of appreciation for their service.

All in favor, please signify.

It is proposed that we sustain the other General Authorities, Area Seventies, and general auxiliary presidencies as presently constituted.

Those in favor, please manifest it.

Any opposed may manifest it.

Thank you, brothers and sisters, for your faith and prayers in our behalf.

# References
