Elder Larry S. Kacher
Of the Seventy
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/trifle-not-with-sacred-things?lang=eng)

_Examine your choices by asking yourself the question, “Are my decisions firmly planted in the rich soil of the gospel of Jesus Christ?”_

Brothers and sisters, the decisions we make in this life greatly affect the course of our eternal life. There are both seen and unseen forces that influence our choices. This point was brought home some five years ago in a way that almost cost me dearly.

We were traveling with family and friends in the south of Oman. We decided to relax on the beach along the coast of the Indian Ocean. Soon after our arrival, our 16-year-old daughter, Nellie, asked if she could swim out to what she thought was a sandbar. Noticing the choppy water, I told her that I would go first, thinking there might be dangerous currents.

After swimming a short while, I called to my wife, asking if I was close to the sandbar. Her response was, “You have gone way past it.” Unbeknownst to me I was trapped in a riptide1 and was being pulled rapidly out to sea.

I was unsure what to do. The only thing I could think of was to turn around and swim back toward shore. That was exactly the wrong thing to do. I felt helpless. Forces beyond my control were pulling me farther out to sea. What made matters worse was that my wife, trusting my decision, had followed me.

Brothers and sisters, I thought there was a high likelihood I would not survive and that I, because of my decision, would also cause my wife’s death. After great effort and what I believe was divine intervention, our feet somehow touched the sandy bottom and we were able to walk safely back to our friends and daughter.

There are many currents in this earthly life—some safe and others not. President Spencer W. Kimball taught that there are powerful forces in our own lives much like the unseen currents of the ocean.2 These forces are real. We should never ignore them.

Let me tell you about another current, a divine current, that has become a great blessing in my life. I am a convert to the Church. Prior to my conversion, my life’s ambition was to ski and, accordingly, I moved to Europe after high school to fulfill that desire. After several months of what seemed an ideal life, I felt I should leave. At the time I did not understand the source of that feeling, but I chose to follow it. I ended up in Provo, Utah, with a few good friends who, like me, were members of a different faith.

While in Provo I met people who were living a much different life than I was. I felt drawn to them, though I did not know why. Initially, I resisted these feelings, but I soon found a peace and comfort that I had never known. I began to embrace a different current—one that brought me to an understanding of a loving Heavenly Father and to His Son, Jesus Christ.

I was baptized with my friends in 1972. This new current I chose to follow, the gospel of Jesus Christ, provided direction and meaning to my life. However, it was not without its challenges. Everything was new to me. At times I felt lost and confused. Questions and challenges were posed by both friends and family.

I had a choice to make. Some of their questions created doubt and uncertainty. The choice was an important one. Where would I turn for answers? There were many who wanted to convince me of the error of my ways—“riptides” determined to pull me away from the peaceful current that had become a wonderful source of happiness. I learned very clearly the principle that there is “opposition in all things” and the importance of acting for myself and not forsaking my agency to others.3

I asked myself, “Why would I turn away from that which had brought me such great comfort?” As the Lord reminded Oliver Cowdery, “Did I not speak peace to your mind concerning the matter?”4 My experience had been similar. Therefore, I turned, with yet more commitment, to a loving Heavenly Father, to the scriptures, and to trusted friends.

Still, there were many questions I could not answer. How would I address the uncertainty they created? Rather than allow them to destroy the peace and happiness that had come into my life, I chose to set them aside for a season, trusting that in the Lord’s time, He would reveal all things. I found solace in His statement to the Prophet Joseph: “Behold, ye are little children and ye cannot bear all things now; ye must grow in grace and in the knowledge of the truth.”5 I chose not to forsake what I knew to be true by following an unknown and a questionable current—a potential “riptide.” As President N. Eldon Tanner taught, I learned “how much wiser and better it is for man to accept the simple truths of the gospel … and to accept by faith those things which he … cannot understand.”6

Does this mean there is no room for honest inquiry? Ask the young boy who sought refuge in a sacred grove wanting to know which of all the churches he should join. Hold the Doctrine and Covenants in your hand, and know that much of what has been revealed in this inspired record has been the result of a humble search for truth. As Joseph found out, “If any of you lack wisdom, let him ask of God, [who] giveth to all men liberally, … and it shall be given him.”7 By asking sincere questions and by seeking divine answers, we learn “line upon line, precept upon precept,”8 as we increase in knowledge and wisdom.

The question is not, “Is there room for honest, sincere inquiry?” but rather, “Where do I turn for truth when questions do arise?” “Will I be wise enough to hold fast to what I know to be true in spite of a few questions I might have?” I testify there is a divine source—One who knows all things, the end from the beginning. All things are present before Him.9 The scriptures testify that He does “not walk in crooked paths, … neither doth he vary from that which he hath said.”10



On this mortal journey we must never think that our choices affect only us. Recently, a young man visited my home. He had a good spirit about him, but I sensed he was not fully participating in Church activity. He told me that he had been raised in a gospel-centered home until his father was unfaithful to his mother, resulting in their divorce and influencing all his siblings to question the Church and to fall away. My heart was heavy as I spoke with this young father who now, affected by his father’s choices, was raising these precious spirits outside the blessings of the gospel of Jesus Christ.

Another man I know, a onetime faithful Church member, had questions regarding certain doctrine. Rather than ask Heavenly Father for answers, he chose to rely solely on secular sources for guidance. His heart turned in the wrong direction as he sought what seemed to be the honors of men. His pride may have been gratified, at least temporarily, but he was cut off from the powers of heaven.11 Rather than find truth, he lost his testimony and brought with him many family members.

These two men became trapped in unseen riptides and brought many with them.

Conversely, I think of LaRue and Louise Miller, my wife’s parents, who despite never having much by way of worldly possessions, chose to teach the pure doctrine of the restored gospel to their children and to live it every day of their lives. By so doing they have blessed their posterity with the fruits of the gospel and the hope of eternal life.

In their home they established a pattern where the priesthood was respected, where love and harmony were abundant, and where the principles of the gospel directed their lives. Louise and LaRue, side by side, demonstrated what it meant to live lives patterned after Jesus Christ. Their children could clearly see which of life’s currents would bring peace and happiness. And they chose accordingly. As President Kimball taught, “If we can create … a strong, steady current flowing toward our goal of righteous life, we and our children may be carried forward in spite of the contrary winds of hardship, disappointment, [and] temptations.”12

Do our choices matter? Do they affect only us? Have we set our course firmly in the eternal current of the restored gospel?

From time to time I have an image that haunts me. What if that September day, while relaxing on the beach of the Indian Ocean, I had said to my daughter Nellie, “Yes, go ahead. Swim out to the sandbar.” Or if she too had followed my example and had been unable to swim back? What if I had to live life knowing that my example resulted in her being pulled by a riptide out to sea, never to return?

Are the currents we choose to follow important? Do our examples matter?

Heavenly Father has blessed us with the supernal gift of the Holy Ghost to guide our choices. He has promised us inspiration and revelation as we live worthy to receive such. I invite you to take advantage of this divine gift and examine your choices by asking yourself the question, “Are my decisions firmly planted in the rich soil of the gospel of Jesus Christ?” I invite you to make whatever adjustments are needed, whether small or large, to ensure the eternal blessings of Heavenly Father’s plan for you and those you love.

I testify that Jesus Christ is our Savior and Redeemer. I testify that the covenants we make with Him are sacred and holy. We must never trifle with sacred things.13 May we remain ever faithful, I pray in the name of Jesus Christ, amen.

# References
1. - Riptide: “a tide that opposes another or other tides, causing a violent disturbance in the sea” (Dictionary.com).
2. - See Spencer W. Kimball, “Ocean Currents and Family Influences,” Ensign, Nov. 1974, 110–13.
3. - See 2 Nephi 2:11, 16.
4. - Doctrine and Covenants 6:23.
5. - Doctrine and Covenants 50:40.
6. - N. Eldon Tanner, in Conference Report, Oct. 1968, 49.
7. - James 1:5.
8. - Doctrine and Covenants 98:12.
9. - See Moses 1:6.
10. - Doctrine and Covenants 3:2.
11. - See Doctrine and Covenants 121:35–37.
12. - Spencer W. Kimball, Ensign, Nov. 1974, 110.
13. - See Doctrine and Covenants 6:12.