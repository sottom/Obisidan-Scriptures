President Thomas S. Monson
President of the Church
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/until-we-meet-again?lang=eng)

_May we all ponder the truths we have heard, and may they help us to become even more valiant disciples._

My brothers and sisters, we have experienced two glorious days of inspired messages. Our hearts have been touched and our faith strengthened as we have partaken of the spirit which has been present during these conference sessions. As we conclude, we thank our Heavenly Father for His many blessings to us.

We have been lifted and inspired by the beautiful music that has been provided during the sessions. The prayers which have been given have drawn us nearer to heaven.

May I express the heartfelt thanks of the entire Church to our Brethren who have been released at this conference. We will miss them. Their contributions to the work of the Lord have been enormous and will be felt throughout generations to come.

May we return to our homes with a resolve in our hearts to be a little better than we have been in the past. May we be a little kinder and more thoughtful. May we reach out in helpfulness, not only to our fellow members but also to those who are not of our faith. As we associate with them, may we show our respect for them.



There are those who struggle every day with challenges. Let us extend to them our concern, as well as a helping hand. As we care for each other, we will be blessed.

May we remember the elderly and those who are homebound. As we take time to visit them, they will know that they are loved and valued. May we follow the mandate to “succor the weak, lift up the hands which hang down, and strengthen the feeble knees.”1

May we be people of honesty and integrity, trying to do the right thing at all times and in all circumstances. May we be faithful followers of Christ, examples of righteousness, thus becoming “lights in the world.”2

My brothers and sisters, I thank you for your prayers in my behalf. They strengthen me and lift me as I strive with all my heart and strength to do God’s will and to serve Him and to serve you.

As we leave this conference, I invoke the blessings of heaven upon each of you. May you who are away from your homes return to them safely and find all in order. May we all ponder the truths we have heard, and may they help us to become even more valiant disciples than we were when this conference began.

Until we meet again in six months’ time, I ask the Lord’s blessings to be upon you and, indeed, upon all of us, and I do so in His holy name—even Jesus Christ, our Lord and Savior—amen.

# References
1. - Doctrine and Covenants 81:5.
2. - Philippians 2:15.