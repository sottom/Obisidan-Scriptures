President Dieter F. Uchtdorf
Second Counselor in the First Presidency
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/lord-is-it-i?lang=eng)

_We must put aside our pride, see beyond our vanity, and in humility ask, “Lord, is it I?”_

It was our beloved Savior’s final night in mortality, the evening before He would offer Himself a ransom for all mankind. As He broke bread with His disciples, He said something that must have filled their hearts with great alarm and deep sadness. “One of you shall betray me,” He told them.

The disciples didn’t question the truth of what He said. Nor did they look around, point to someone else, and ask, “Is it him?”

Instead, “they were exceeding sorrowful, and began every one of them to say unto him, Lord, is it I?”1

I wonder what each of us would do if we were asked that question by the Savior. Would we look at those around us and say in our hearts, “He’s probably talking about Brother Johnson. I’ve always wondered about him,” or “I’m glad Brother Brown is here. He really needs to hear this message”? Or would we, like those disciples of old, look inward and ask that penetrating question: “Is it I?”

In these simple words, “Lord, is it I?” lies the beginning of wisdom and the pathway to personal conversion and lasting change.





A Parable of Dandelions





Once there was a man who enjoyed taking evening walks around his neighborhood. He particularly looked forward to walking past his neighbor’s house. This neighbor kept his lawn perfectly manicured, flowers always in bloom, the trees healthy and shady. It was obvious that the neighbor made every effort to have a beautiful lawn.

But one day as the man was walking past his neighbor’s house, he noticed in the middle of this beautiful lawn a single, enormous, yellow dandelion weed.

It looked so out of place that it surprised him. Why didn’t his neighbor pull it out? Couldn’t he see it? Didn’t he know that the dandelion could cast seeds that could give root to dozens of additional weeds?

This solitary dandelion bothered him beyond description, and he wanted to do something about it. Should he just pluck it out? Or spray it with weed killer? Perhaps if he went under cover of night, he could remove it secretly.

These thoughts totally occupied his mind as he walked toward his own home. He entered his house without even glancing at his own front yard—which was blanketed with hundreds of yellow dandelions.





Beams and Motes



Does this story remind us of the words of the Savior?

“Why beholdest thou the mote that is in thy brother’s eye, but considerest not the beam that is in thine own eye? …

“… First cast out the beam out of thine own eye; and then shalt thou see clearly to cast out the mote out of thy brother’s eye.”2

This business of beams and motes seems to be closely related to our inability to see ourselves clearly. I’m not sure why we are able to diagnose and recommend remedies for other people’s ills so well, while we often have difficulty seeing our own.

Some years ago there was a news story about a man who believed that if he rubbed lemon juice on his face, it would make him invisible to cameras. So he put lemon juice all over his face, went out, and robbed two banks. Not much later he was arrested when his image was broadcast over the evening news. When police showed the man the videos of himself from the security cameras, he couldn’t believe his eyes. “But I had lemon juice on my face!” he protested.3

When a scientist at Cornell University heard about this story, he was intrigued that a man could be so painfully unaware of his own incompetence. To determine whether this was a general problem, two researchers invited college students to participate in a series of tests on various life skills and then asked them to rate how they did. The students who performed poorly were the least accurate at evaluating their own performance—some of them estimating their scores to be five times higher than they actually were.4

This study has been replicated in numerous ways, confirming over and over again the same conclusion: many of us have a difficult time seeing ourselves as we truly are, and even successful people overestimate their own contribution and underestimate the contributions that others make.5

It might not be so significant to overestimate how well we drive a car or how far we can drive a golf ball. But when we start believing that our contributions at home, at work, and at church are greater than they actually are, we blind ourselves to blessings and opportunities to improve ourselves in significant and profound ways.







Spiritual Blind Spots



An acquaintance of mine used to live in a ward with some of the highest statistics in the Church—attendance was high, home teaching numbers were high, Primary children were always well behaved, ward dinners included fantastic food that members rarely spilled on the meetinghouse floor, and I think there were never any arguments at Church ball.

My friend and his wife were subsequently called on a mission. When they returned three years later, this couple was astonished to learn that during the time they were away serving, 11 marriages had ended in divorce.

Although the ward had every outward indication of faithfulness and strength, something unfortunate was happening in the hearts and lives of the members. And the troubling thing is that this situation is not unique. Such terrible and often unnecessary things happen when members of the Church become disengaged from gospel principles. They may appear on the outside to be disciples of Jesus Christ, but on the inside their hearts have separated from their Savior and His teachings. They have gradually turned away from the things of the Spirit and moved toward the things of the world.

Once-worthy priesthood holders start to tell themselves that the Church is a good thing for women and children but not for them. Or some are convinced that their busy schedules or unique circumstances make them exempt from the daily acts of devotion and service that would keep them close to the Spirit. In this age of self-justification and narcissism, it is easy to become quite creative at coming up with excuses for not regularly approaching God in prayer, procrastinating the study of the scriptures, avoiding Church meetings and family home evenings, or not paying an honest tithe and offerings.

My dear brethren, will you please look inside your hearts and ask the simple question: “Lord, is it I?”

Have you disengaged—even slightly—from “the … gospel of the blessed God, which was committed to [your] trust”?6 Have you allowed “the god of this world” to darken your minds to “the light of the glorious gospel of Christ”?7

My beloved friends, my dear brethren, ask yourselves, “Where is my treasure?”

Is your heart set on the convenient things of this world, or is it focused on the teachings of the diligent Jesus Christ? “For where your treasure is, there will your heart be also.”8

Does the Spirit of God dwell in your hearts? Are you “rooted and grounded” in the love of God and of your fellowmen? Do you devote sufficient time and creativity to bringing happiness to your marriage and family? Do you give your energies to the sublime goal of comprehending and living “the breadth, and length, and depth, and height”9 of the restored gospel of Jesus Christ?

Brethren, if it is your great desire to cultivate Christlike attributes of “faith, virtue, knowledge, temperance, patience, brotherly kindness, godliness, charity, humility, [and service],”10 Heavenly Father will make you an instrument in His hands unto the salvation of many souls.11







The Examined Life



Brethren, none of us likes to admit when we are drifting off the right course. Often we try to avoid looking deeply into our souls and confronting our weaknesses, limitations, and fears. Consequently, when we do examine our lives, we look through the filter of biases, excuses, and stories we tell ourselves in order to justify unworthy thoughts and actions.

But being able to see ourselves clearly is essential to our spiritual growth and well-being. If our weaknesses and shortcomings remain obscured in the shadows, then the redeeming power of the Savior cannot heal them and make them strengths.12 Ironically, our blindness toward our human weaknesses will also make us blind to the divine potential that our Father yearns to nurture within each of us.

So how can we shine the pure light of God’s truth into our souls and see ourselves as He sees us?

May I suggest that the holy scriptures and the talks given at general conference are an effective mirror we can hold up for self-examination.

As you hear or read the words of the ancient and modern prophets, refrain from thinking about how the words apply to someone else and ask the simple question: “Lord, is it I?”

We must approach our Eternal Father with broken hearts and teachable minds. We must be willing to learn and to change. And, oh, how much we gain by committing to live the life our Heavenly Father intends for us.

Those who do not wish to learn and change probably will not and most likely will begin to wonder whether the Church has anything to offer them.

But those who want to improve and progress, those who learn of the Savior and desire to be like Him, those who humble themselves as a little child and seek to bring their thoughts and actions into harmony with our Father in Heaven—they will experience the miracle of the Savior’s Atonement. They will surely feel God’s resplendent Spirit. They will taste the indescribable joy that is the fruit of a meek and humble heart. They will be blessed with the desire and discipline to become true disciples of Jesus Christ.







The Power of Good



Over the course of my life, I have had the opportunity to rub shoulders with some of the most competent and intelligent men and women this world has to offer. When I was younger, I was impressed by those who were educated, accomplished, successful, and applauded by the world. But over the years, I have come to the realization that I am far more impressed by those wonderful and blessed souls who are truly good and without guile.

And isn’t that what the gospel is all about and does for us? It is the good news, and it helps us to become good.

The words of the Apostle James apply to us today:

“God resisteth the proud, but giveth grace unto the humble. …

“Humble yourselves in the sight of the Lord, and he shall lift you up.”13

Brethren, we must put aside our pride, see beyond our vanity, and in humility ask, “Lord, is it I?”

And if the Lord’s answer happens to be “Yes, my son, there are things you must improve, things I can help you to overcome,” I pray that we will accept this answer, humbly acknowledge our sins and shortcomings, and then change our ways by becoming better husbands, better fathers, better sons. May we from this time forward seek with all our might to walk steadfastly in the Savior’s blessed way—for seeing ourselves clearly is the beginning of wisdom.



As we do so, our bountiful God will lead us by the hand; we will “be made strong, and blessed from on high.”14

My beloved friends, a first step on this wondrous and fulfilling path of true discipleship starts with our asking the simple question:

“Lord, is it I?”

Of this I testify and leave you my blessing in the name of Jesus Christ, amen.

# References
1. - Matthew 26:21–22; emphasis added.
2. - Matthew 7:3, 5.
3. - See Errol Morris, “The Anosognosic’s Dilemma: Something’s Wrong but You’ll Never Know What It Is,” New York Times, June 20, 2010; opinionator.blogs.nytimes.com/2010/06/20/the-anosognosics-dilemma-1.
4. - See Justin Kruger and David Dunning, “Unskilled and Unaware of It: How Difficulties in Recognizing One’s Own Incompetence Lead to Inflated Self-Assessments,” Journal of Personality and Social Psychology, Dec. 1999, 1121–34. “Across 4 studies, the authors found that participants scoring in the bottom quartile on tests of humor, grammar, and logic grossly overestimated their test performance and ability. Although their test scores put them in the 12th percentile, they estimated themselves to be in the 62nd” (from the abstract at psycnet.apa.org/?&fa=main.doiLanding&doi=10.1037/0022-3514.77.6.1121).
5. - See Marshall Goldsmith, What Got You Here Won’t Get You There (2007), chapter 3. The researcher asked three partners to rate their own contributions to the success of the company. Their self-assessed contributions added up to 150 percent.
6. - 1 Timothy 1:11.
7. - 2 Corinthians 4:4.
8. - Luke 12:34.
9. - Ephesians 3:18.
10. - Doctrine and Covenants 4:6.
11. - See Alma 17:11.
12. - See Ether 12:27.
13. - James 4:6, 10.
14. - Doctrine and Covenants 1:28.