Bishop Dean M. Davies
Second Counselor in the Presiding Bishopric
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/the-law-of-the-fast-a-personal-responsibility-to-care-for-the-poor-and-needy?lang=eng)

_As followers of the Savior, we have a personal responsibility to care for the poor and needy._

My dear brethren, I love the priesthood, and I love being with you. I am so deeply grateful that we can serve together in this great cause.

We live in remarkable times. Miraculous advances in medicine, science, and technology have improved the quality of life for many. Yet there is also evidence of great human suffering and distress. In addition to wars and rumors of wars, an increase in natural disasters—including floods, fires, earthquakes, and disease—is impacting the lives of millions worldwide.

Church leadership is aware of and vigilant regarding the well-being of God’s children everywhere. When and where possible, Church emergency resources are provided to respond to those in need. For example, last November, Typhoon Haiyan hit the island nation of the Philippines.

A Category 5 super typhoon, Haiyan left in its wake extensive destruction and suffering. Complete cities were destroyed; many lives were lost; millions of homes were severely damaged or destroyed; and basic services such as water, sewer, and electricity ceased functioning.

Church resources were made available in the very early hours following this disaster. Church members living in the Philippines rallied to the rescue of their brothers and sisters by providing food, water, clothing, and hygiene kits to members and nonmembers alike.

Church meetinghouses became places of refuge to thousands of the homeless. Under the leadership of the Area Presidency and local priesthood leaders, many of whom had lost everything they had, assessments were made as to the condition and safety of all members. Inspired plans began to take shape to help restore members to acceptable living conditions and self-reliance.

Modest resources were provided to help Church members rebuild their wood-frame shelters and homes. This was not just a free handout. Members received training and performed the needed labor for themselves and then for others.

One resulting blessing was that as members developed carpentry, plumbing, and other construction skills, they were able to secure meaningful work opportunities as nearby cities and communities began rebuilding.

Caring for the poor and needy is a fundamental gospel doctrine and an essential element in the eternal plan of salvation.

Prior to His mortal ministry, Jehovah declared through His prophet: “For the poor shall never cease out of the land: therefore I command thee, saying, Thou shalt open thine hand wide unto thy brother, to thy poor, and to thy needy, in thy land.”1

In our day, caring for the poor and needy is one of four divinely appointed Church responsibilities that help individuals and families qualify for exaltation.2



Caring for the poor and needy contemplates both temporal and spiritual salvation. It includes the service of individual Church members as they personally care for the poor and needy, as well as formal Church welfare, which is administered through priesthood authority.

Central to the Lord’s plan for caring for the poor and needy is the law of the fast. “The Lord has established the law of the fast and fast offerings to bless His people and to provide a way for them to serve those in need.”3

As followers of the Savior, we have a personal responsibility to care for the poor and needy. Faithful Church members everywhere assist by fasting each month—abstaining from food and water for 24 hours—and then giving to the Church a financial fast offering equal to at least the value of the food they would have eaten.

Isaiah’s words should be prayerfully considered and taught in every home:

“Is not this the fast that I have chosen? to loose the bands of wickedness, to undo the heavy burdens, and to let the oppressed go free, and that ye break every yoke?

“Is it not to deal thy bread to the hungry, and that thou bring the poor that are cast out to thy house? when thou seest the naked, that thou cover him; and that thou hide not thyself from thine own flesh?”4

Isaiah then went on to list the wonderful blessings promised by the Lord to those who obey the law of the fast. He says:

“Then shall thy light break forth as the morning, and thine health shall spring forth speedily: and thy righteousness shall go before thee; the glory of the Lord shall be thy rearward.

“Then shalt thou call, and the Lord shall answer; thou shalt cry, and he shall say, Here I am. …

“And if thou draw out thy soul to the hungry, and satisfy the afflicted soul; then shall thy light rise in obscurity, and thy darkness be as the noonday:

“And the Lord shall guide thee continually, and satisfy thy soul in drought.”5

Regarding this scripture, President Harold B. Lee had this to say: “The tremendous blessings that come [from fasting] have been spelled out in every dispensation, and here the Lord is telling us through this great prophet why there is fasting, and the blessings that come from fasting. … If you analyze … the 58th chapter of the book of Isaiah you will find unraveled why the Lord wants us to pay fast offerings, why he wants us to fast. It’s because by qualifying thus we can call and the Lord can answer. We can cry and the Lord will say, ‘Here I am.’”

President Lee adds: “Do we ever want to be in a condition where we can call and he won’t answer? We will cry in our distress and he won’t be with us? I think it is time we are thinking about these fundamentals because these are the days that lie ahead, when we are going to need more and more the blessings of the Lord, when the judgments are poured out without mixture upon the whole earth.”6

Our beloved prophet, President Thomas S. Monson, has shared his testimony of these principles—a testimony borne of personal experience. He said: “No member of the Church who has helped provide for those in need ever forgets or regrets the experience. Industry, thrift, self-reliance, and sharing with others are not new to us.”7

Brethren, members of The Church of Jesus Christ of Latter-day Saints are a covenant-making, commandment-keeping people. I cannot think of any law, any commandment, which, if kept faithfully, is easier to keep and which provides greater blessings than the law of the fast. When we fast and give an honest fast offering, we contribute to the Lord’s storehouse what would have been expended on the cost of the meals. It does not require monetary sacrifice in excess of what would be expended normally. At the same time, we are promised the extraordinary blessings, as previously noted.

The law of the fast applies to all Church members. Even young children can be taught to fast, beginning with one meal and then two, as they are able to understand and physically keep the law of the fast. Husbands and wives, single members, youth, and children should begin the fast with prayer, giving gratitude for blessings in their lives while seeking the Lord’s blessings and strength through the fast period. Complete fulfillment of the law of the fast occurs when the fast offering is made to the Lord’s agent, the bishop.

Bishops, you direct welfare in the ward. You have a divine mandate to seek out and care for the poor. With the support of the Relief Society president and Melchizedek Priesthood quorum leaders, your goal is to help members help themselves and become self-reliant. You minister to the temporal and spiritual needs of members by carefully using fast offerings as a temporary support and as a supplement to extended family and community resources. As you prayerfully exercise priesthood keys and discernment in helping the poor and needy, you will come to know that the correct use of fast offerings is intended to support life, not lifestyle.

Aaronic Priesthood quorum presidents, you hold keys and have the power to administer in outward ordinances. You work with the bishop and instruct quorum members regarding their duties in the priesthood and in seeking out Church members to give them the opportunity to contribute to the fast. As you Aaronic Priesthood holders magnify your priesthood responsibilities and extend this opportunity to all Church members, you frequently facilitate the promised blessings of the fast to those who may need them the most. You will witness that the spirit of caring for the poor and needy has the power to soften otherwise hardened hearts and blesses the lives of those who may infrequently attend Church.

President Monson has said, “Those bishops who organize their Aaronic Priesthood quorums to participate in the collection of fast offerings will find increased success in this sacred responsibility.”8

Bishops, remember that circumstances vary widely from one area to another and from country to country. Door-to-door contacting by Aaronic Priesthood quorum members may not be practical in the region where you live. However, we invite you to prayerfully consider the prophet’s counsel and seek inspiration on appropriate ways in which the Aaronic Priesthood holders in your wards can magnify their priesthood by participating in the collection of fast offerings.

In chapter 27 of 3 Nephi, the risen Lord asked, “What manner of men ought ye to be?” He responded, “Even as I am.”9 As we take upon ourselves the name of Christ and strive to follow Him, we will receive His image in our countenance and become more like Him. Caring for the poor and needy is inherent in the ministry of the Savior. It is in everything He does. He reaches out to all and lifts us. His yoke is easy, and His burden is light. I invite each of us to become more like the Savior by caring for the poor and needy, by faithfully keeping the law of the fast, and by contributing a generous fast offering. I humbly testify that faithfully caring for the poor and needy is a reflection of spiritual maturity and will bless both the giver and the receiver. In the sacred name of Jesus Christ, amen.

# References
1. - Deuteronomy 15:11.
2. - See Handbook 2: Administering the Church (2010), 2.2.
3. - Handbook 2, 6.1.2.
4. - Isaiah 58:6–7.
5. - Isaiah 58:8–11.
6. - Harold B. Lee, “Listen, and Obey” (Welfare Agricultural Meeting, Apr. 3, 1971), copy of typescript, 14, Church History Library, Salt Lake City.
7. - Thomas S. Monson, “Are We Prepared?” Ensign or Liahona, Sept. 2014, 4.
8. - Thomas S. Monson, in a meeting with the Presiding Bishopric, Feb. 28, 2014.
9. - 3 Nephi 27:27.