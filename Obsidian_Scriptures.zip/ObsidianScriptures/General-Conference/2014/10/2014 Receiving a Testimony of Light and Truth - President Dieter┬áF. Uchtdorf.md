President Dieter F. Uchtdorf
Second Counselor in the First Presidency
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/receiving-a-testimony-of-light-and-truth?lang=eng)

_Your personal testimony of light and truth will not only bless you and your posterity here in mortality, but it will also accompany you throughout all eternity._

As an airline pilot, I flew numerous hours across continents and oceans during the darkness of night. Watching the night sky out of my cockpit window, especially the Milky Way, often made me marvel at the vastness and depth of God’s creations—what the scriptures describe as “worlds without number.”1

It was less than a century ago that most astronomers assumed that our Milky Way galaxy was the only galaxy in the universe.2 They supposed all that lay beyond our galaxy was an immense nothingness, an infinite void—empty, cold, and devoid of stars, light, and life.

Un-MutePlay/PauseLanguagesSubtitlesopenFont sizedefault50%75%100%150%200%300%400%Font familydefaultmonospaced serifproportional serifmonospaced sans serifproportional serifcasualcursivesmall capitalFont colordefaultwhiteblackredgreenbluecyanyellowmagentaFont opacitydefault100%75%50%25%Character edgedefaultraiseddepresseduniformdrop shadowedBackground colordefaultwhiteblackredgreenbluecyanyellowmagentaBackground opacitydefault100%75%50%25%0%Window colordefaultwhiteblackredgreenbluecyanyellowmagentaWindow opacitydefault100%75%50%25%0%BackResetVideo QualitySpeed0.25x0.5xnormal1.5x2x00:0100:00PlayMuteSettingsSettingsSettingsFullscreenGoogle CastApple AirPlayReplay

As telescopes became more sophisticated—including telescopes that could be launched into space—astronomers began to grasp a spectacular, almost incomprehensible truth: the universe is mind-bogglingly bigger than anyone had previously believed, and the heavens are filled with numberless galaxies, unimaginably far away from us, each containing hundreds of billions of stars.3

In a very short period of time, our understanding of the universe changed forever.

Today we can see some of these distant galaxies.4

We know that they are there.

They have been there for a very long time.

But before mankind had instruments powerful enough to gather celestial light and bring these galaxies into visibility, we did not believe such a thing was possible.

The immensity of the universe didn’t suddenly change, but our ability to see and understand this truth changed dramatically. And with that greater light, mankind was introduced to glorious vistas we had never before imagined.





It Is Hard for Us to Believe What We Cannot See



Suppose you were able to travel back in time and have a conversation with people who lived a thousand or even a hundred years ago. Imagine trying to describe to them some of the modern technologies that you and I take for granted today. For example, what might these people think of us if we told them stories of jumbo jets, microwave ovens, handheld devices that contain vast digital libraries, and videos of our grandchildren that we instantly share with millions of people around the world?

Some might believe us. Most would ridicule, oppose, or perhaps even seek to silence or harm us. Some might attempt to apply logic, reason, and facts as they know them to show that we are misguided, foolish, or even dangerous. They might condemn us for attempting to mislead others.

But of course, these people would be completely mistaken. They might be well-meaning and sincere. They might feel absolutely positive of their opinion. But they simply would not be able to see clearly because they had not yet received the more complete light of truth.







The Promise of Light



It seems to be a trait of humanity to assume that we are right even when we are wrong. And if that is the case, what hope is there for any of us? Are we destined to drift aimlessly on an ocean of conflicting information, stranded on a raft we have poorly pieced together from our own biases?

Is it possible to find truth?



The purpose of my remarks is to proclaim the joyful message that God Himself—the Lord of Hosts who knows all truth—has given His children the promise that they can know truth for themselves.

Please consider the magnitude of this promise:

The Everlasting and Almighty God, the Creator of this vast universe, will speak to those who approach Him with a sincere heart and real intent.

He will speak to them in dreams, visions, thoughts, and feelings.

He will speak in a way that is unmistakable and that transcends human experience. He will give them divine direction and answers for their personal lives.

Of course, there will be those who scoff and say such a thing is impossible, that if there were a God, He would have better things to do than hear and answer a single person’s prayer.

But I tell you this: God cares about you. He will listen, and He will answer your personal questions. The answers to your prayers will come in His own way and in His own time, and therefore, you need to learn to listen to His voice. God wants you to find your way back to Him, and the Savior is the way.5 God wants you to learn of His Son, Jesus Christ, and experience the profound peace and joy that come from following the path of divine discipleship.

My dear friends, here is a fairly straightforward experiment, with a guarantee from God, found in a book of ancient scripture available to every man, woman, and child willing to put it to the test:

First, you must search the word of God. That means reading the scriptures and studying the words of the ancient as well as modern prophets regarding the restored gospel of Jesus Christ—not with an intent to doubt or criticize but with a sincere desire to discover truth. Ponder upon the things you will feel, and prepare your minds to receive the truth.6 “Even if ye can no more than desire to believe, let this desire work in you … that ye can give place for [the word of God].”7

Second, you must consider, ponder, fearlessly strive to believe,8 and be grateful for how merciful the Lord has been to His children from the time of Adam to our day by providing prophets, seers, and revelators to lead His Church and help us find the way back to Him.

Third, you must ask your Heavenly Father, in the name of His Son, Jesus Christ, to manifest the truth of The Church of Jesus Christ of Latter-day Saints unto you. Ask with a sincere heart and with real intent, having faith in Christ.9

There is also a fourth step, given to us by the Savior: “If any man will do [God’s] will, he shall know of the doctrine, whether it be of God, or whether I speak of myself.”10 In other words, when you are trying to verify the truth of gospel principles, you must first live them. Put gospel doctrine and Church teachings to the test in your own life. Do it with real intent and enduring faith in God.

If you will do these things, you have a promise from God—who is bound by His word11—that He will manifest the truth to you by the power of the Holy Ghost. He will grant you greater light that will allow you to look through the darkness and witness unimaginably glorious vistas incomprehensible to mortal sight.

Some may say that the steps are too hard or that they are not worth the effort. But I suggest that this personal testimony of the gospel and the Church is the most important thing you can earn in this life. It will not only bless and guide you during this life, but it will also have a direct bearing on your life throughout eternity.







The Things of the Spirit Can Be Understood Only by the Spirit



Scientists were struggling to understand the breadth of the universe until instruments became sophisticated enough to gather in greater light so they could understand a more complete truth.

The Apostle Paul taught a parallel principle regarding spiritual knowledge. “The natural man receiveth not the things of the Spirit of God,” he wrote to the Corinthians, “for they are foolishness unto him: neither can he know them, because they are spiritually discerned.”12

In other words, if you want to recognize spiritual truth, you have to use the right instruments. You can’t come to an understanding of spiritual truth with instruments that are unable to detect it.

The Savior has told us in our day, “That which is of God is light; and he that receiveth light, and continueth in God, receiveth more light; and that light groweth brighter and brighter until the perfect day.”13

The more we incline our hearts and minds toward God, the more heavenly light distills upon our souls. And each time we willingly and earnestly seek that light, we indicate to God our readiness to receive more light. Gradually, things that before seemed hazy, dark, and remote become clear, bright, and familiar to us.

By the same token, if we remove ourselves from the light of the gospel, our own light begins to dim—not in a day or a week but gradually over time—until we look back and can’t quite understand why we had ever believed the gospel was true. Our previous knowledge might even seem foolish to us because what once was so clear has again become blurred, hazy, and distant.

This is why Paul was so insistent that the message of the gospel is foolishness to those who are perishing, “but unto [those who] are saved it is the power of God.”14







There Is No Litmus Test



The Church of Jesus Christ of Latter-day Saints is a place for people with all kinds of testimonies. There are some members of the Church whose testimony is sure and burns brightly within them. Others are still striving to know for themselves. The Church is a home for all to come together, regardless of the depth or the height of our testimony. I know of no sign on the doors of our meetinghouses that says, “Your testimony must be this tall to enter.”

The Church is not just for perfect people, but it is for all to “come unto Christ, and be perfected in him.”15 The Church is for people like you and me. The Church is a place of welcoming and nurturing, not of separating or criticizing. It is a place where we reach out to encourage, uplift, and sustain one another as we pursue our individual search for divine truth.

In the end, we are all pilgrims seeking God’s light as we journey on the path of discipleship. We do not condemn others for the amount of light they may or may not have; rather, we nourish and encourage all light until it grows clear, bright, and true.









A Promise to All



Let us acknowledge that most often gaining a testimony is not a task of a minute, an hour, or a day. It is not once and done. The process of gathering spiritual light is the quest of a lifetime.

Your testimony of the living Son of God and His restored Church, The Church of Jesus Christ of Latter-day Saints, may not come as quickly as you desire, but I promise you this: if you do your part, it will come.

And it will be glorious.

I offer you my personal witness that spiritual truth will fill your heart and bring light to your spirit. It will reveal to you pure intelligence with wonderful joy and heavenly peace. I have experienced this for myself by the power of the Holy Ghost.

As the ancient scriptures promise, the unspeakable presence of the Spirit of God will cause you to sing the song of redeeming love,16 lift your eyes to heaven, and raise your voice in praise to the Most High God, your Refuge, your Hope, your Protector, your Father. The Savior promised that if you seek, you will find.17

I testify that this is true. If you seek God’s truth, that which now may appear dim, out of focus, and distant will gradually be revealed and clarified and become close to your heart by the light of God’s grace. Glorious spiritual vistas, unimaginable to the human eye, will be revealed to you.

It is my testimony that this spiritual light is within the reach of every child of God. It will enlighten your mind and bring healing to your heart and joy to your days. My dear friends, please do not delay the moment to seek and strengthen your own personal testimony of God’s divine work, even the work of light and truth.

Your personal testimony of light and truth will not only bless you and your posterity here in mortality, but it will also accompany you throughout all eternity, among worlds without end. Of this I testify and leave you my blessing in the name of Jesus Christ, amen.

# References
1. - Moses 1:33.
2. - See Marcia Bartusiak, The Day We Found the Universe (2009), xii. It is always surprising to me that we can be so confident of our conclusions. Sometimes our confidence is so great that we assume we have all the truth there is. Case in point: “Simon Newcomb, the dean of American astronomy in the late nineteenth century, remarked at an observatory dedication in 1887 that ‘so far as astronomy is concerned … we do appear to be fast approaching the limits of our knowledge. … The result is that the work which really occupies the attention of the astronomer is less the discovery of new things than the elaboration of those already known’” (Bartusiak, xv).
3. - It is interesting to consider Moses 1:33, 35 in light of this “recent” discovery. The book of Moses in the Pearl of Great Price was revealed to the Prophet Joseph Smith in June 1830, nearly a century before Edwin Hubble announced his discovery of distant galaxies.
4. - See, for example, the Hubble Heritage Image Gallery at heritage.stsci.edu/gallery/gallery.html.
5. - See John 14:6.
6. - See 3 Nephi 17:3.
7. - Alma 32:27.
8. - See Doctrine and Covenants 67:3.
9. - See Moroni 10:3–5.
10. - John 7:17; see also Psalm 25:14; John 3:21.
11. - See Doctrine and Covenants 82:10.
12. - 1 Corinthians 2:14.
13. - Doctrine and Covenants 50:24.
14. - 1 Corinthians 1:18.
15. - Moroni 10:32; see also Doctrine and Covenants 20:59.
16. - See Alma 5:26.
17. - See Doctrine and Covenants 88:63.