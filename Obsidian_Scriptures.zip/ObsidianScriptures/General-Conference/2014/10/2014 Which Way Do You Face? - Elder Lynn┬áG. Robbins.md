Elder Lynn G. Robbins
Of the Presidency of the Seventy
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/which-way-do-you-face?lang=eng)

_Trying to please others before pleasing God is inverting the first and second great commandments._

“Which way do you face?” President Boyd K. Packer surprised me with this puzzling question while we were traveling together on my very first assignment as a new Seventy. Without an explanation to put the question in context, I was baffled. “A Seventy,” he continued, “does not represent the people to the prophet but the prophet to the people. Never forget which way you face!” It was a powerful lesson.

Trying to please others before pleasing God is inverting the first and second great commandments (see Matthew 22:37–39). It is forgetting which way we face. And yet, we have all made that mistake because of the fear of men. In Isaiah the Lord warns us, “Fear ye not the reproach of men” (Isaiah 51:7; see also 2 Nephi 8:7). In Lehi’s dream, this fear was triggered by the finger of scorn pointed from the great and spacious building, causing many to forget which way they faced and to leave the tree “ashamed” (see 1 Nephi 8:25–28).

This peer pressure tries to change a person’s attitudes, if not behavior, by making one feel guilty for giving offense. We seek respectful coexistence with those who point fingers, but when this fear of men tempts us to condone sin, it becomes a “snare” according to the book of Proverbs (see Proverbs 29:25). The snare may be cleverly baited to appeal to our compassionate side to tolerate or even approve of something that has been condemned by God. For the weak of faith, it can be a major stumbling block. For example, some young missionaries carry this fear of men into the mission field and fail to report the flagrant disobedience of a companion to their mission president because they don’t want to offend their wayward companion. Decisions of character are made by remembering the right order of the first and second great commandments (see Matthew 22:37–39). When these confused missionaries realize they are accountable to God and not to their companion, it should give them courage to do an about-face.

At the youthful age of 22, even Joseph Smith forgot which way he faced when he repeatedly importuned the Lord to allow Martin Harris to borrow the 116 manuscript pages. Perhaps Joseph wanted to show gratitude to Martin for his support. We know that Joseph was extremely anxious for other eyewitnesses to stand with him against the distressing falsehoods and lies being spread about him.

Whatever Joseph’s reasons were, or as justified as they may appear, the Lord did not excuse them and sharply rebuked him: “How oft you have transgressed … and have gone on in the persuasions of men. For, behold, you should not have feared man more than God” (D&C 3:6–7; emphasis added). This poignant experience helped Joseph remember, forever after, which way he faced.

When people try to save face with men, they can unwittingly lose face with God. Thinking one can please God and at the same time condone the disobedience of men isn’t neutrality but duplicity, or being two-faced or trying to “serve two masters” (Matthew 6:24; 3 Nephi 13:24).

While it certainly takes courage to face perils, the true badge of courage is overcoming the fear of men. For example, Daniel’s prayers helped him face lions, but what made him lionhearted was defying King Darius (see Daniel 6). That kind of courage is a gift of the Spirit to the God-fearing who have said their prayers. Queen Esther’s prayers also gave her that same courage to confront her husband, King Ahasuerus, knowing that she risked her life in doing so (see Esther 4:8–16).

Courage is not just one of the cardinal virtues, but as C. S. Lewis observed: “Courage is … the form of every virtue at the testing point. … Pilate was merciful till it became risky.”1 King Herod was sorrowful at the request to behead John the Baptist but wanted to please “them which sat with him at meat” (Matthew 14:9). King Noah was ready to free Abinadi until peer pressure from his wicked priests caused him to waver (see Mosiah 17:11–12). King Saul disobeyed the word of the Lord by keeping the spoils of war because he “feared the people, and obeyed their voice” (1 Samuel 15:24). To appease rebellious Israel at the foot of Mount Sinai, Aaron crafted a golden calf, forgetting which way he faced (see Exodus 32). Many of the New Testament chief rulers “believed on [the Lord]; but because of the Pharisees they did not confess him, lest they should be put out of the synagogue: for they loved the praise of men more than the praise of God” (John 12:42–43). The scriptures are full of such examples.

Now listen to some inspiring examples:





First, Mormon: “Behold, I speak with boldness, having authority from God; and I fear not what man can do; for perfect love casteth out all fear” (Moroni 8:16; emphasis added).





Nephi: “Wherefore, the things which are pleasing unto the world I do not write, but the things which are pleasing unto God and unto those who are not of the world” (1 Nephi 6:5).





Captain Moroni: “Behold, I am Moroni, your chief captain. I seek not for power, but to pull it down. I seek not for honor of the world, but for the glory of my God, and the freedom and welfare of my country” (Alma 60:36).





Moroni had such great courage in remembering which way he faced that it was said of him, “If all men had been, and were, and ever would be, like unto Moroni, behold, the very powers of hell would have been shaken forever; yea, the devil would never have power over the hearts of the children of men” (Alma 48:17).

Prophets through the ages have always come under attack by the finger of scorn. Why? According to the scriptures, it is because “the guilty taketh the truth to be hard, for it cutteth them to the very center” (1 Nephi 16:2), or as President Harold B. Lee observed, “The hit bird flutters!”2 Their scornful reaction is, in reality, guilt trying to reassure itself, just as with Korihor, who finally admitted, “I always knew that there was a God” (Alma 30:52). Korihor was so convincing in his deception that he came to believe his own lie (see Alma 30:53).

The scornful often accuse prophets of not living in the 21st century or of being bigoted. They attempt to persuade or even pressure the Church into lowering God’s standards to the level of their own inappropriate behavior, which in the words of Elder Neal A. Maxwell, will “develop self-contentment instead of seeking self-improvement”3 and repentance. Lowering the Lord’s standards to the level of a society’s inappropriate behavior is—apostasy. Many of the churches among the Nephites two centuries after the Savior’s visit to them began to “dumb down” the doctrine, borrowing a phrase from Elder Holland.4

As you listen to this passage from 4 Nephi, look for parallels in our day: “And it came to pass that when two hundred and ten years had passed away there were many churches in the land; yea, there were many churches which professed to know the Christ, and yet they did deny the more parts of his gospel, insomuch that they did receive all manner of wickedness, and did administer that which was sacred unto him to whom it had been forbidden because of unworthiness” (4 Nephi 1:27).

Déjà vu in the latter days! Some members don’t realize they are falling into the same snare when they lobby for acceptance of local or ethnic “tradition[s] of their fathers” (D&C 93:39) that are not in harmony with the gospel culture. Still others, self-deceived and in self-denial, plead or demand that bishops lower the standard on temple recommends, school endorsements, or missionary applications. It isn’t easy being a bishop under that kind of pressure. However, like the Savior who cleansed the temple to defend its sanctity (see John 2:15–16), bishops today are called upon to boldly defend the temple standard. It was the Savior who said, “I will manifest myself to my people in mercy … if my people will keep my commandments, and do not pollute this holy house” (D&C 110:7–8).

The Savior, our great Exemplar, always faced His Father. He loved and served His fellowmen but said, “I receive not honour from men” (John 5:41). He wanted those He taught to follow Him, but He did not court their favor. When He performed an act of charity, such as healing the sick, the gift often came with the request to “tell no man” (Matthew 8:4; Mark 7:36; Luke 5:14; 8:56). In part, this was to avoid the very fame which followed Him in spite of His efforts to eschew it (see Matthew 4:24). He condemned the Pharisees for doing good works only to be seen of men (see Matthew 6:5).

The Savior, the only perfect being who ever lived, was the most fearless. In His life, He was confronted by scores of accusers but never yielded to their finger of scorn. He is the only person who never once forgot which way He faced: “I do always those things that please [the Father]” (John 8:29; emphasis added), and “I seek not mine own will, but the will of the Father which hath sent me” (John 5:30).

Between 3 Nephi chapter 11 and 3 Nephi chapter 28, the Savior used the title Father at least 150 times, making it very clear to the Nephites that He was there representing His Father. And from John chapters 14 through 17, the Savior refers to the Father at least 50 times. In every way possible, He was His Father’s perfect disciple. He was so perfect in representing His Father that to know the Savior was also to know the Father. To see the Son was to see the Father (see John 14:9). To hear the Son was to hear the Father (see John 5:36). He had, in essence, become indistinguishable from His Father. His Father and He were one (see John 17:21–22). He flawlessly knew which way He faced.

May His inspiring example strengthen us against the pitfalls of flattery from without or of conceit from within. May it give us courage to never cower or fawn at the feet of intimidation. May it inspire us to go about doing good as anonymously as possible and not “aspire to the honors of men” (D&C 121:35). And may His incomparable example help us always remember which is “the first and great commandment” (Matthew 22:38). When others demand approval in defiance of God’s commandments, may we always remember whose disciples we are, and which way we face, is my prayer in the name of Jesus Christ, amen.

# References
1. - C. S. Lewis, The Screwtape Letters, rev. ed. (1982), 137–38.
2. - Harold B. Lee, in Mine Errand from the Lord: Selections from the Sermons and Writings of Boyd K. Packer (2008), 356.
3. - Neal A. Maxwell, “Repentance,” Ensign, Nov. 1991, 32.
4. - Jeffrey R. Holland, “The Call to Be Christlike,” Ensign, June 2014, 33; Liahona, June 2014, 35.