Elder M. Russell Ballard
Of the Quorum of the Twelve Apostles
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/stay-in-the-boat-and-hold-on?lang=eng)

_If we keep our focus on the Lord, we are promised a blessing beyond comparison._

Recently, a friend of mine took his son on a trip down the Colorado River through Cataract Canyon, located in southeastern Utah. The canyon is famous for its 14 miles (23 km) of white-water rapids that can be particularly hazardous.

In preparation for their adventure, they had carefully reviewed the National Park Service website, which contains important information about personal preparedness and common, hidden hazards.

At the beginning of the trip, one of the experienced river guides reviewed important safety instructions, emphasizing three rules that would ensure the group’s safe travel through the rapids. “Rule number one: stay in the boat! Rule number two: always wear a life jacket! Rule number three: always hold on with both hands!” He then said again, with even more emphasis, “Above all, remember rule number one: stay in the boat!”

This adventure reminds me of our mortal journey. Most of us experience periods in our lives where the tranquil waters of life are appreciated. At other times, we encounter white-water rapids that are metaphorically comparable to those found in the 14-mile stretch through Cataract Canyon—challenges that may include physical and mental health issues, the death of a loved one, dashed dreams and hopes, and—for some—even a crisis of faith when faced with life’s problems, questions, and doubts.

Un-MutePlay/PauseLanguagesSubtitlesopenFont sizedefault50%75%100%150%200%300%400%Font familydefaultmonospaced serifproportional serifmonospaced sans serifproportional serifcasualcursivesmall capitalFont colordefaultwhiteblackredgreenbluecyanyellowmagentaFont opacitydefault100%75%50%25%Character edgedefaultraiseddepresseduniformdrop shadowedBackground colordefaultwhiteblackredgreenbluecyanyellowmagentaBackground opacitydefault100%75%50%25%0%Window colordefaultwhiteblackredgreenbluecyanyellowmagentaWindow opacitydefault100%75%50%25%0%BackResetVideo QualitySpeed0.25x0.5xnormal1.5x2x00:0100:00PlayMuteSettingsSettingsSettingsFullscreenGoogle CastApple AirPlayReplay

The Lord in His goodness has provided help, including a boat, essential supplies such as life jackets, and experienced river guides who give guidance and safety instructions to help us make our way down the river of life to our final destination.

Let’s think about rule number one: stay in the boat!

President Brigham Young commonly employed “the Old Ship Zion” as a metaphor for The Church of Jesus Christ of Latter-day Saints.

He said on one occasion: “We are in the midst of the ocean. A storm comes on, and, as sailors say, she labors very hard. ‘I am not going to stay here,’ says one; ‘I don’t believe this is the “Ship Zion.”’ ‘But we are in the midst of the ocean.’ ‘I don’t care, I am not going to stay here.’ Off goes the coat, and he jumps overboard. Will he not be drowned? Yes. So with those who leave this Church. It is the ‘Old Ship Zion,’ let us stay in it.”1

On another occasion, President Young said that he also worried about people losing their way when they were being blessed—when life was good: “It is in calm weather, when the old ship of Zion is sailing with a gentle breeze, [and] when all is quiet on deck, that some of the brethren want to go out in the whaling boats to have … a swim, and some get drowned, others drifted away, and others again get back to the ship. Let us stick to the old ship and she will carry us [safely] into the harbor; you need not be concerned.”2

And finally, President Young reminded the Saints: “We are on the old ship Zion. … [God] is at the helm and will stay there. … All is right, sing Hallelujah, for the Lord is here. He dictates, guides and directs. If the people will have implicit confidence in their God, never forsake their covenants nor their God, He will guide us right.”3

Given the challenges we all face today, how do we stay on the Old Ship Zion?

Here is how. We need to experience a continuing conversion by increasing our faith in Jesus Christ and our faithfulness to His gospel throughout our lives—not just once but regularly. Alma asked, “And now behold, I say unto you, my brethren [and sisters], if ye have experienced a change of heart, and if ye have felt to sing the song of redeeming love, I would ask, can ye feel so now?”4

The experienced river guides today can be likened to the Church’s apostles and prophets and inspired local priesthood and auxiliary leaders. They help us arrive safely to our final destination.

Recently, I spoke at the new mission presidents’ seminar and counseled these leaders:

“Keep the eyes of the mission on the leaders of the Church. … We will not and … cannot lead [you] astray.

“And as you teach your missionaries to focus their eyes on us, teach them to never follow those who think they know more about how to administer the affairs of the Church than … Heavenly Father and the Lord Jesus Christ do” through the priesthood leaders who have the keys to preside.

“I have discovered in my ministry that those who have become lost [and] confused are typically those who have most often … forgotten that when the First Presidency and the Quorum of the Twelve speak with a united voice, it is the voice of the Lord for that time. The Lord reminds us, ‘Whether by mine own voice or by the voice of my servants, it is the same’ [D&C 1:38].”5

In other words, they leave the Old Ship Zion—they fall away; they apostatize. Tragically, they often experience short-term and eventually long-term unintended consequences, not only for themselves but also for their families.

Our local Church leaders, like seasoned river guides, have been tutored by life’s experiences; have been trained and mentored by apostles and prophets and other officers of the Church; and, most important, have been tutored by the Lord Himself.

On another occasion this year, I spoke to the young adults of the Church in the May CES devotional broadcast. I said:

“I have heard that some people think the Church leaders live in a ‘bubble.’ What they forget is that we are men and women of experience, and we have lived our lives in so many places and worked with many people from different backgrounds. Our current assignments literally take us around the globe, where we meet the political, religious, business, and humanitarian leaders of the world. Although we have visited [leaders in] the White House in Washington, D.C., and leaders of nations [and religions] throughout the world, we have also visited the most humble [families and people] on earth. …

“When you thoughtfully consider our lives and ministry, you will most likely agree that we see and experience the world in ways few others do. You will realize that we live less in a ‘bubble’ than most people. …

“… There is something about the individual and combined wisdom of the [Church leaders] that should provide some comfort. We have experienced it all, including the consequences of different public laws and policies, disappointments, tragedies, and deaths in our own families. We are not out of touch with your lives.”6



Along with rule number one as I’ve applied it, remember rules two and three: always wear a life jacket, and hold on with both hands. The words of the Lord are found in the scriptures and the teachings of the apostles and prophets. They provide us counsel and direction that, when followed, will act like a spiritual life jacket and will help us know how to hold on with both hands.

We need to become like the sons of Mosiah, who “waxed strong in the knowledge of the truth.” We can become men and women “of a sound understanding.” This can be accomplished only by our “search[ing] the scriptures diligently, that [we] might know the word of God.”7

In searching the scriptures and the words of past and current apostles and prophets, we should focus on studying, living, and loving the doctrine of Christ.

In addition to developing the habit of personal scripture reading, we need to be like the sons of Mosiah and give ourselves “to much prayer, and fasting.”8

It seems that these things which are not easily measured are of great importance. Stay focused on these simple things, and avoid becoming distracted.

As I have known people who have not stayed in the boat and have not held on with both hands during times of trials and troubles or who have not stayed in the boat during times of relative calm, I have observed that many of them have lost their focus on the central truths of the gospel—the reasons why they joined the Church in the first place; the reasons they remained fully committed and active in living gospel standards and blessing others through dedicated, consecrated service; and the ways in which the Church has been in their lives “a place of spiritual nourishment and growth.”9

Joseph Smith taught this central truth: “The fundamental principles of our religion [are] the testimony of the apostles and prophets concerning Jesus Christ, … ‘that he died, was buried, and rose again the third day, and ascended up into heaven;’ and all other things are only appendages to these, which pertain to our religion.”10

If we keep our focus on the Lord, we are promised a blessing beyond comparison: “Wherefore, ye must press forward with a steadfastness in Christ, having a perfect brightness of hope, and a love of God and of all men. Wherefore, if ye shall press forward, feasting upon the word of Christ, and endure to the end, behold, thus saith the Father: Ye shall have eternal life.”11

Sometimes faithful Latter-day Saints and sincere investigators begin to focus on the “appendages” instead of on the fundamental principles. That is, Satan tempts us to become distracted from the simple and clear message of the restored gospel. Those so distracted often give up partaking of the sacrament because they have become focused, even preoccupied, with less important practices or teachings.

Others may focus on the questions and doubts they experience. Of course, having questions and experiencing doubts are not incongruent with dedicated discipleship. Recently, the Council of the First Presidency and the Quorum of the Twelve Apostles stated: “We understand that from time to time Church members will have questions about Church doctrine, history, or practice. Members are always free to ask such questions and earnestly seek greater understanding.”12

Remember, Joseph Smith himself had questions that began the Restoration. He was a seeker and, like Abraham, found the answers to life’s most important questions.

The important questions focus on what matters most—Heavenly Father’s plan and the Savior’s Atonement. Our search should lead us to become kind, gentle, loving, forgiving, patient, and dedicated disciples. We must be willing, as Paul taught, to “bear ye one another’s burdens, and so fulfil the law of Christ.”13

To bear another’s burdens includes helping, supporting, and understanding everyone, including the sick, the infirm, the poor in spirit and body, the seeker and the troubled, and also other member-disciples—including Church leaders who have been called by the Lord to serve for a season.

Brothers and sisters, stay in the boat, use your life jackets, and hold on with both hands. Avoid distractions! And if any one of you have fallen out of the boat, we will seek you, find you, minister to you, and pull you safely back onto the Old Ship Zion, where God our Father and the Lord Jesus Christ are at the helm and will guide us right, to which I humbly testify in the name of Jesus Christ, amen.

# References
1. - Teachings of Presidents of the Church: Brigham Young (1997), 82–83.
2. - Brigham Young, “Discourse,” Deseret News, Jan. 27, 1858, 373.
3. - Brigham Young, “Remarks,” Deseret News, Nov. 18, 1857, 291.
4. - Alma 5:26.
5. - M. Russell Ballard, “Mission Leadership” (address given at the seminar for new mission presidents, June 25, 2014), 8.
6. - M. Russell Ballard, “Be Still, and Know That I Am God” (Church Educational System devotional, May 4, 2014); lds.org/broadcasts.
7. - Alma 17:2.
8. - Alma 17:3.
9. - First Presidency and Quorum of the Twelve Apostles letter, June 28, 2014.
10. - Joseph Smith, Elders’ Journal, July 1838, 44.
11. - 2 Nephi 31:20.
12. - First Presidency and Quorum of the Twelve Apostles letter, June 28, 2014.
13. - Galatians 6:2.