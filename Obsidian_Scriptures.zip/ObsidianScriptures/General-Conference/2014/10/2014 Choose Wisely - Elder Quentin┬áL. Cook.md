Elder Quentin L. Cook
Of the Quorum of the Twelve Apostles
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/choose-wisely?lang=eng)

_“Refuse the evil, and choose the good” (Isaiah 7:15)._

My beloved brethren, my desire this evening is to share some counsel about decisions and choices.

When I was a young lawyer in the San Francisco Bay Area, our firm did some legal work for the company that produced the Charlie Brown holiday TV specials.1 I became a fan of Charles Schulz and his creation—Peanuts, with Charlie Brown, Lucy, Snoopy, and other wonderful characters.

One of my favorite comic strips involved Lucy. As I remember it, Charlie Brown’s baseball team was in an important game—Lucy was playing right field, and a high fly ball was hit to her. The bases were loaded, and it was the last of the ninth inning. If Lucy caught the ball, her team would win. If Lucy dropped the ball, the other team would win.

As could happen only in a comic strip, the entire team surrounded Lucy as the ball came down. Lucy was thinking, “If I catch the ball, I will be the hero; if I don’t, I will be the goat.”

The ball came down, and as her teammates eagerly looked on, Lucy dropped the ball. Charlie Brown threw his glove to the ground in disgust. Lucy then looked at her teammates, put her hands on her hips, and said, “How do you expect me to catch the ball when I am worried about our country’s foreign policy?”

This was one of many fly balls Lucy dropped through the years, and she had a new excuse each time.2 While always humorous, Lucy’s excuses were rationalizations; they were untrue reasons for her failure to catch the ball.

During the ministry of President Thomas S. Monson, he has often taught that decisions determine destiny.3 In that spirit my counsel tonight is to rise above any rationalizations that prevent us from making righteous decisions, especially with respect to serving Jesus Christ. In Isaiah we are taught we must “refuse the evil, and choose the good.”4

I believe it is of particular importance in our day, when Satan is raging in the hearts of men in so many new and subtle ways, that our choices and decisions be made carefully, consistent with the goals and objectives by which we profess to live. We need unequivocal commitment to the commandments and strict adherence to sacred covenants. When we allow rationalizations to prevent us from temple endowments, worthy missions, and temple marriage, they are particularly harmful. It is heartbreaking when we profess belief in these goals yet neglect the everyday conduct required to achieve them.5

Some young people profess their goal is to be married in the temple but do not date temple-worthy individuals. To be honest, some don’t even date, period! You single men, the longer you remain single after an appropriate age and maturity, the more comfortable you can become. But the more uncomfortable you ought to become! Please get “anxiously engaged”6 in spiritual and social activities compatible with your goal of a temple marriage.

Some postpone marriage until education is complete and a job obtained. While widely accepted in the world, this reasoning does not demonstrate faith, does not comply with counsel of modern prophets, and is not compatible with sound doctrine.

I recently met a fine teenage young man. His goals were to go on a mission, obtain an education, marry in the temple, and have a faithful happy family. I was very pleased with his goals. But during further conversation, it became evident that his conduct and the choices he was making were not consistent with his goals. I felt he genuinely wanted to go on a mission and was avoiding serious transgressions that would prohibit a mission, but his day-to-day conduct was not preparing him for the physical, emotional, social, intellectual, and spiritual challenges he would face.7 He had not learned to work hard. He was not serious about school or seminary. He attended church, but he had not read the Book of Mormon. He was spending a large amount of time on video games and social media. He seemed to think that showing up for his mission would be sufficient. Young men, please recommit to worthy conduct and serious preparation to be emissaries of our Lord and Savior, Jesus Christ.

My concern is not only about the big tipping-point decisions but also the middle ground—the workaday world and seemingly ordinary decisions where we spend most of our time. In these areas, we need to emphasize moderation, balance, and especially wisdom. It is important to rise above rationalizations and make the best choices.

A wonderful example of the need for moderation, balance, and wisdom is the use of the Internet. It can be used to do missionary outreach, to assist with priesthood responsibilities, to find precious ancestors for sacred temple ordinances, and much more. The potential for good is enormous. We also know that it can transmit much that is evil, including pornography, digital cruelty,8 and anonymous yakking. It can also perpetuate foolishness. As Brother Randall L. Ridd poignantly taught at the last general conference, speaking of the Internet, “You can get caught up in endless loops of triviality that waste your time and degrade your potential.”9

Distractions and opposition to righteousness are not just on the Internet; they are everywhere. They affect not just the youth but all of us. We live in a world that is literally in commotion.10 We are surrounded by obsessive portrayals of “fun and games” and immoral and dysfunctional lives. These are presented as normal conduct in much of the media.

Elder David A. Bednar recently cautioned members to be authentic in the use of social media.11 A prominent thought leader, Arthur C. Brooks, has emphasized this point. He observes that when using social media, we tend to broadcast the smiling details of our lives but not the hard times at school or work. We portray an incomplete life—sometimes in a self-aggrandizing or fake way. We share this life, and then we consume the “almost exclusively … fake lives of [our] social media ‘friends.’” Brooks asserts, “How could it not make you feel worse to spend part of your time pretending to be happier than you are, and the other part of your time seeing how much happier others seem to be than you?”12

Sometimes it feels like we are drowning in frivolous foolishness, nonsensical noise, and continuous contention. When we turn down the volume and examine the substance, there is very little that will assist us in our eternal quest toward righteous goals. One father wisely responds to his children with their numerous requests to participate in these distractions. He simply asks them, “Will this make you a better person?”

When we rationalize wrong choices, big or small, which are inconsistent with the restored gospel, we lose the blessings and protections we need and often become ensnared in sin or simply lose our way.

I am particularly concerned with foolishness13 and being obsessed with “every new thing.” In the Church we encourage and celebrate truth and knowledge of every kind. But when culture, knowledge, and social mores are separated from God’s plan of happiness and the essential role of Jesus Christ, there is an inevitable disintegration of society.14 In our day, despite unprecedented gains in many areas, especially science and communication, essential basic values have eroded and overall happiness and well-being have diminished.

When the Apostle Paul was invited to speak on Mars Hill in Athens, he found some of the same intellectual pretension and absence of true wisdom that exist today.15 In Acts we read this account: “For all the Athenians and strangers which were there spent their time in nothing else, but either to tell, or to hear some new thing.”16 Paul’s emphasis was the Resurrection of Jesus Christ. When the crowd realized the religious nature of his message, some mocked him; others essentially dismissed him, saying, “We will hear thee again of this matter.”17 Paul left Athens without any success. Dean Frederic Farrar wrote of this visit: “At Athens he founded no church, to Athens he wrote no epistle, and in Athens, often as he passed its neighbourhood, he never set foot again.”18

I believe Elder Dallin H. Oaks’s inspired message distinguishing between “good, better, best” provides an effective way to evaluate choices and priorities.19 Many choices are not inherently evil, but if they absorb all of our time and keep us from the best choices, then they become insidious.

Even worthwhile endeavors need evaluation in order to determine if they have become distractions from the best goals. I had a memorable discussion with my father when I was a teenager. He did not believe enough young people were focused on or preparing for long-term important goals—like employment and providing for families.

Meaningful study and preparatory work experience were always at the top of my father’s recommended priorities. He appreciated that extracurricular activities like debate and student government might have a direct connection with some of my important goals. He was less certain about the extensive time I spent participating in football, basketball, baseball, and track. He acknowledged that athletics could build strength, endurance, and teamwork but asserted that perhaps concentrating on one sport for a shorter time would be better. In his view, sports were good but not the best for me. He was concerned that some sports were about building local celebrity or fame at the expense of more important long-term goals.

Given this history, one of the reasons I like the account of Lucy playing baseball is that, in my father’s view, I should have been studying foreign policy and not worrying about whether I was going to catch a ball. I should make it clear that my mother loved sports. It would have taken a hospitalization for her to miss one of my games.

I had decided to follow my dad’s advice and not play intercollegiate sports in college. Then our high school football coach informed me that the Stanford football coach wanted to have lunch with Merlin Olsen and me. Those of you who are younger may not know Merlin. He was an incredible all-American tackle on the Logan High School football team where I played quarterback and safety and returned kickoffs and punts. In high school Merlin was recruited by most football powers across the nation. In college he won the Outland Trophy as the nation’s best interior lineman. Merlin was ultimately the third overall pick in the National Football League draft and played in an amazing 14 consecutive Pro Bowls. He was inducted into the Pro Football Hall of Fame in 1982.20

The lunch with the Stanford coach was at the Bluebird restaurant in Logan, Utah. After we shook hands, he never once made eye contact with me. He talked directly to Merlin but ignored me. At the end of the lunch, for the first time, he turned toward me, but he could not remember my name. He then informed Merlin, “If you choose Stanford and want to bring your friend with you, he has good enough grades and it could probably be arranged.” This experience confirmed for me that I should follow my dad’s wise counsel.

My intent is not to discourage participation in sports or the use of the Internet or other worthwhile activities young people enjoy. They are the kind of activities that require moderation, balance, and wisdom. When used wisely, they enrich our lives.

However, I encourage everyone, young and old, to review goals and objectives and strive to exercise greater discipline. Our daily conduct and choices should be consistent with our goals. We need to rise above rationalizations and distractions. It is especially important to make choices consistent with our covenants to serve Jesus Christ in righteousness.21 We must not take our eyes off or drop that ball for any reason.

This life is the time to prepare to meet God.22 We are a happy, joyous people. We appreciate a good sense of humor and treasure unstructured time with friends and family. But we need to recognize that there is a seriousness of purpose that must undergird our approach to life and all our choices. Distractions and rationalizations that limit progress are harmful enough, but when they diminish faith in Jesus Christ and His Church, they are tragic.

My prayer is that as a body of priesthood holders, we will make our conduct consistent with the noble purposes required of those who are in the service of the Master. In all things we should remember that being “valiant in the testimony of Jesus” is the great dividing test between the celestial and terrestrial kingdoms.23 We want to be found on the celestial side of that divide. As one of His Apostles, I bear fervent testimony of the reality of the Atonement and the divinity of Jesus Christ, our Savior. In the name of Jesus Christ, amen.

# References
1. - Lee Mendelson-Bill Melendez Production TV Specials.
2. - From the moons of Saturn distracting her to worrying about possible toxic substances in her glove, Lucy always rationalized why she dropped the ball.
3. - See “Decisions Determine Destiny,” chapter 8 in Pathways to Perfection: Discourses of Thomas S. Monson (1973), 57–65.
4. - Isaiah 7:15.
5. - “If to do were as easy as to know what were good to do, chapels had been churches and poor men’s cottages princes’ palaces” (William Shakespeare, The Merchant of Venice, act 1, scene 2, lines 12–14).
6. - Doctrine and Covenants 58:27.
7. - See Adjusting to Missionary Life (booklet, 2013), 23–49.
8. - See Stephanie Rosenbloom, “Dealing with Digital Cruelty,” New York Times, Aug. 24, 2014, SR1.
9. - Randall L. Ridd, “The Choice Generation,” Ensign or Liahona, May 2014, 56.
10. - See Doctrine and Covenants 45:26.
11. - See David A. Bednar, “To Sweep the Earth as with a Flood” (speech delivered at BYU Campus Education Week, Aug. 19, 2014); lds.org/prophets-and-apostles/unto-all-the-world/to-sweep-the-earth-as-with-a-flood.
12. - Arthur C. Brooks, “Love People, Not Pleasure,” New York Times, July 20, 2014, SR1.
13. - Unfortunately, one diversion that has increased in our day is pure foolishness. When the Savior enumerated some of the things that can defile man, He included foolishness (see Mark 7:22).
14. - This happened in ancient Greece and Rome, as well as with the Book of Mormon civilizations.
15. - See Frederic W. Farrar, The Life and Work of St. Paul (1898), 302. There were philosophers of all kinds, including Epicureans and Stoics, rival groups who some described as the Pharisees and the Sadducees of the pagan world. See also Quentin L. Cook, “Looking beyond the Mark,” Ensign, Mar. 2003, 41–44; Liahona, Mar. 2003, 21–24.
16. - Acts 17:21.
17. - Acts 17:32.
18. - Farrar, The Life and Work of St. Paul, 312.
19. - See Dallin H. Oaks, “Good, Better, Best,” Ensign or Liahona, Nov. 2007, 104–8.
20. - Merlin Olsen was a hall of fame football player, actor, and NFL commentator for NBC. He won the Outland Trophy playing football for Utah State University. He played pro football for the Los Angeles Rams. On TV he played Jonathan Garvey opposite Michael Landon on Little House on the Prairie and had his own TV program, Father Murphy. Merlin is now deceased (Mar. 11, 2010), and we miss him very much.
21. - See Doctrine and Covenants 76:5.
22. - See Alma 34:32.
23. - Doctrine and Covenants 76:79.