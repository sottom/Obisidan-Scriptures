President Henry B. Eyring
First Counselor in the First Presidency
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/the-preparatory-priesthood?lang=eng)

_In priesthood preparation, “show me” counts more than “tell me.”_

I am grateful to be gathered with the priesthood of God, which stretches across the world. I appreciate your faith, your service, and your prayers.

My message tonight is about the Aaronic Priesthood. It is also to all of us who help in the realization of the Lord’s promises for those who hold what is described in scripture as the “lesser priesthood.”1 It is also called the preparatory priesthood. It is that glorious preparation about which I will speak tonight.

The Lord’s plan for His work is filled with preparation. He prepared the earth for us to experience the tests and the opportunities of mortality. While we are here, we are in what the scriptures call a “preparatory state.”2

The prophet Alma described the crucial importance of that preparation for eternal life, where we may live forever in families with God the Father and Jesus Christ.

He explained the need for preparation this way: “And we see that death comes upon mankind, yea, the death which has been spoken of by Amulek, which is the temporal death; nevertheless there was a space granted unto man in which he might repent; therefore this life became a probationary state; a time to prepare to meet God; a time to prepare for that endless state which has been spoken of by us, which is after the resurrection of the dead.”3

Just as the time we have been given to live in mortality is to prepare to meet God, the time we are given to serve in the Aaronic Priesthood is an opportunity to prepare us to learn how to give crucial help to others. Just as the Lord gives the help we require to pass the tests of mortal life, He also sends us help in our priesthood preparation.

My message is to those whom the Lord sends to help prepare Aaronic Priesthood holders as much as it is to those who hold the Aaronic Priesthood. I speak to fathers. I speak to bishops. And I speak to those of the Melchizedek Priesthood who are trusted to be companions and teachers of young men who are in priesthood preparation.

I speak in praise and in gratitude for many of you across the world and across time.

I would be remiss if I did not speak of a branch president and a bishop of my youth. I became a deacon at the age of 12 in a little branch in the eastern part of the United States. The branch was so tiny that my older brother and I were its only Aaronic Priesthood holders until my father, who was the branch president, invited a middle-aged man to join the Church.

The new convert received the Aaronic Priesthood and, with it, a call to watch over the Aaronic Priesthood. I still remember as if it were yesterday. I can recall the beautiful fall leaves as that new convert accompanied my brother and me to do something for a widow. I don’t remember what the project was, but I do remember feeling that the priesthood power joined in doing what I later learned the Lord had said we must all do to have our sins forgiven and so be prepared to see Him.

As I look back now, I feel gratitude for a branch president who called a new convert to help the Lord prepare two boys who would in turn someday be bishops, charged to care for the poor and the needy and also to preside over the preparatory priesthood.

I was still a deacon when our family moved to a large ward in Utah. It was the first time I had felt the power of a full quorum in the Aaronic Priesthood. In fact, it was the first time I saw one. And later it was the first time I felt the power and the blessing of a bishop presiding in a priests quorum.

The bishop called me to be his first assistant in the priests quorum. I remember that he taught the quorum himself—busy as he was, with other gifted men whom he could have called to teach us. He had the chairs in the classroom arranged in a circle. He had me sit in the chair next to him, to his right.

I could look over his shoulder as he taught. He looked down occasionally at the carefully typed notes in the little leather binder on one knee and at the well-worn and marked scriptures he had open on the other knee. I can remember the thrill as he recounted the stories of bravery from the book of Daniel and his testimony of the Savior, the Lord Jesus Christ.

I will always remember how the Lord calls companions carefully chosen for his priesthood holders in preparation.

My bishop had powerful counselors, and for reasons I did not understand then, more than once he called me on the phone at home and said, “Hal, I need you to go with me as a companion to make some visits.” Once, it was to take me with him to the home of a widow living alone and without any food in the house. On the way home he stopped his car, opened his scriptures, and told me why he had treated that widow as if she had the power not only to care for herself but would, at some time in the future, be able to help others.

Another visit was to a man long absent from the Church. My bishop invited him back to be with the Saints. I felt my bishop’s love for someone who seemed to me an unlovable and rebellious enemy.

On yet another occasion we visited a home where two little girls were sent to meet us at the door by their alcoholic parents. The little girls said through the screen door that their mother and father were asleep. The bishop kept talking to them, smiling and praising their goodness and their bravery, for what seemed to me 10 minutes or more. As I walked away at his side, he said quietly, “That was a good visit. Those little girls will never forget that we came.”

Two of the blessings that a senior priesthood companion can give are trust and an example of caring. I saw that when my son was given a home teaching companion who had vastly more priesthood experience than he did. His senior companion had been a mission president twice and had served in other leadership positions.

Before they were to visit one of their assigned families, that seasoned priesthood leader asked to visit my son in our home beforehand. They allowed me to listen. The senior companion opened with prayer, asking for help. Then he said something like this to my son: “I think we should teach a lesson that will sound to this family like a call to repentance. I think they won’t take it very well from me. I think they would take the message better from you. How do you feel about that?”

I remember the terror in my son’s eyes. I can still feel the happiness of that moment when my son accepted the trust.

It was not by accident that the bishop put that companionship together. It was by careful preparation that the senior companion had learned about the feelings of that family they were about to teach. It was by inspiration that he felt to step back, to trust an inexperienced youth to call older children of God to repentance and to safety.

I don’t know the outcome of their visit, but I do know that a bishop, a Melchizedek Priesthood holder, and the Lord were preparing a boy to be a priesthood man and someday a bishop.

Now, such stories of success in priesthood preparation are familiar to you from what you have seen and what you have experienced in your own lives. You have known and have been such bishops, companions, and parents. You have seen the hand of the Lord in your preparation for the priesthood duties which He knew would lie ahead of you.

All of us in the priesthood have an obligation to help the Lord prepare others. There are some things we can do that could matter most. Even more powerful than using words in our teaching the doctrine will be our examples of living the doctrine.

Paramount in our priesthood service is inviting people to come unto Christ by faith, repentance, baptism, and receiving the Holy Ghost. President Thomas S. Monson, for instance, has given sermons to stir the heart on all those doctrines. But what I know of what he did with people and missionaries and friends of the Church when presiding over the mission in Toronto motivates me to action.

In priesthood preparation, “show me” counts more than “tell me.”

That is why the scriptures are so important to prepare us in the priesthood. They are filled with examples. I feel as if I can see Alma following the angel’s command and then hurrying back to teach the wicked people in Ammonihah who had rejected him.4 I can feel the cold in the jail cell when the Prophet Joseph was told by God to take courage and that he was watched over.5 With those scripture pictures in mind, we can be prepared to endure in our service when it seems hard.

A father or a bishop or a senior home teaching companion who shows that he trusts a young priesthood holder can change his life. My father was once asked by a member of the Quorum of the Twelve Apostles to write a short paper on science and religion. My father was a famous scientist and a faithful priesthood holder. But I can still remember the moment he handed me the paper he had written and said, “Here, before I send this to the Twelve, I want you to read it. You will know if it is right.” He was 32 years older than me and immeasurably more wise and intelligent.

I still am strengthened by that trust from a great father and priesthood man. I knew that his trust was not in me but that God could and would tell me what was true. You seasoned companions can bless a young priesthood holder in preparation whenever you can show him that kind of trust. It will help him trust the gentle feeling of inspiration for himself when it comes as he someday places his hands to seal the blessing to heal a child the doctors say will die. That trust has helped me more than once.

Our success in preparing others in the priesthood will come in proportion to how much we love them. That will be especially true when we must correct them. Think of the moment when an Aaronic Priesthood holder, perhaps at the sacrament table, makes a mistake in performing an ordinance. That is a serious matter. Sometimes the error requires public correction with a possibility of resentment, a feeling of humiliation or even of being rejected.

You will remember the Lord’s counsel: “Reproving betimes with sharpness, when moved upon by the Holy Ghost; and then showing forth afterwards an increase of love toward him whom thou hast reproved, lest he esteem thee to be his enemy.”6

The word increase has special meaning in preparing priesthood holders when they need correction. The word suggests an increase of a love that was already there. The “showing forth” is about the increase. Those of you who are preparing priesthood holders will certainly see them make mistakes. Before they receive your correction, they must have felt of your love early and steadily. They must have felt your genuine praise before they will accept your correction.

The Lord Himself held those of the lesser priesthood with a regard that honors their potential and their value to Him. Listen to these words, spoken by John the Baptist when the Aaronic Priesthood was restored: “Upon you my fellow servants, in the name of Messiah I confer the Priesthood of Aaron, which holds the keys of the ministering of angels, and of the gospel of repentance, and of baptism by immersion for the remission of sins; and this shall never be taken again from the earth, until the sons of Levi do offer again an offering unto the Lord in righteousness.”7

The Aaronic Priesthood is an appendage to the greater Melchizedek Priesthood.8 As the president of all the priesthood, the President of the Church presides over the preparatory priesthood as well. His messages over the years of going to the rescue fit perfectly the mandate to take the gospel of repentance and baptism into the lives of others.

Quorums of deacons, teachers, and priests counsel regularly to draw every member of the quorum to the Lord. Presidencies assign members to reach out in faith and love. Deacons pass the sacrament with reverence and with faith that members will feel the effect of the Atonement and resolve to keep commandments as they partake of those sacred emblems.

Teachers and priests pray with their companions to fulfill the charge to watch over the Church, person by person. And those companionships pray together as they learn the needs and the hopes of heads of families. As they do, they are being prepared for the great day when they will preside as a father, in faith, in a family of their own.

I testify that all who serve together in the priesthood are preparing a people for the coming of the Lord to His Church. God the Father lives. I know—I know—that Jesus is the Christ and that He loves us. President Thomas S. Monson is the Lord’s living prophet. I so testify in the sacred name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 84:26, 30; 107:14.
2. - Alma 42:10, 13.
3. - Alma 12:24.
4. - See Alma 8:14–18.
5. - See Doctrine and Covenants 122:9.
6. - Doctrine and Covenants 121:43.
7. - Doctrine and Covenants 13:1.
8. - See Doctrine and Covenants 107:14.