President Boyd K. Packer
President of the Quorum of the Twelve Apostles
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/the-reason-for-our-hope?lang=eng)

_A testimony of the hope of redemption is something which cannot be measured or counted. Jesus Christ is the source of that hope._

Several years ago, Sister Packer and I went to Oxford University. We were looking for the records of my seventh great-grandfather. The head of Christ’s College at Oxford, Dr. Poppelwell, was kind enough to have the college archivist bring the records. There in the year 1583 we found my ancestor’s name, John Packer.

The following year we returned to Oxford to present a beautifully bound set of the standard works for the library at Christ’s College. It seemed a bit awkward for Dr. Poppelwell. Perhaps he thought we were not really Christians. So he called for the college chaplain to receive the books.

Before handing the scriptures to the chaplain, I opened the Topical Guide and showed him one subject: 18 pages, very fine print, single-spaced, listing references to the subject of “Jesus Christ.” It is one of the most comprehensive compilations of scriptural references on the subject of the Savior that has ever been assembled in the history of the world—a testimony from the Old and New Testaments, the Book of Mormon, the Doctrine and Covenants, and the Pearl of Great Price.

“However you follow these references,” I told him, “side to side, up and down, book to book, subject after subject—you will find that they are a consistent, harmonious witness to the divinity of the mission of the Lord Jesus Christ—His birth, His life, His teachings, His Crucifixion, His Resurrection, and His Atonement.”

After I shared with the chaplain some of the teachings of the Savior, the atmosphere changed, and he gave us a tour of the facility, including a recent excavation revealing murals which dated to Roman days.

Among the references listed in the Topical Guide is this one from the Book of Mormon: Another Testament of Jesus Christ: “We preach of Christ, we prophesy of Christ, and we write according to our prophecies, that our children may know to what source they may look for a remission of their sins” (2 Nephi 25:26).

In His own words, the Savior has declared, “I am the way, the truth, and the life: no man cometh unto the Father, but by me” (John 14:6).

And from the Book of Mormon, He declares: “Behold, I am he who was prepared from the foundation of the world to redeem my people. Behold, I am Jesus Christ. … In me shall all mankind have life, and that eternally, even they who shall believe on my name; and they shall become my sons and my daughters” (Ether 3:14).

There are many, many other references throughout the standard works which proclaim the divine role of Jesus Christ as the Redeemer of all who have ever been or ever will be born into mortality.

Through the Atonement of Jesus Christ we are all redeemed from the Fall of man, which occurred when Adam and Eve partook of the forbidden fruit in the Garden of Eden, as stated in 1 Corinthians: “For as in Adam all die, even so in Christ shall all be made alive” (1 Corinthians 15:22).

The Book of Mormon teaches, “For it is expedient that an atonement should be made … , or else all mankind must unavoidably perish; yea, all are hardened; yea, all are fallen and are lost, and must perish except it be through the atonement … an infinite and eternal sacrifice” (Alma 34:9–10).

We may not live perfect lives, and there are penalties for our mistakes, but before we came to earth, we agreed to be subject to His laws and to accept the punishment for violating those laws.

“For all have sinned, and come short of the glory of God;

“Being justified freely by his grace through the redemption that is in Christ Jesus” (Romans 3:23–24).

The Savior wrought the Atonement, which provides a way for us to become clean. Jesus Christ is the resurrected Christ. We worship and recognize Him for the pain He suffered for us collectively and for the pain He endured for each of us individually, both in the Garden of Gethsemane and on the cross. He bore all with great humility and with an eternal understanding of His divine role and purpose.

Those who will repent and forsake sin will find that His merciful arm is outstretched still. Those who listen to and heed His words and the words of His chosen servants will find peace and understanding even in the midst of great heartache and sorrow. The result of His sacrifice is to free us from the effects of sin, that all may have guilt erased and feel hope.

Had He not accomplished the Atonement, there would be no redemption. It would be a difficult world to live in if we could never be forgiven for our mistakes, if we could never purify ourselves and move on.

The mercy and grace of Jesus Christ are not limited to those who commit sins either of commission or omission, but they encompass the promise of everlasting peace to all who will accept and follow Him and His teachings. His mercy is the mighty healer, even to the wounded innocent.

I recently received a letter from a woman who reported having endured great suffering in her life. A terrible wrong, which she did not identify but alluded to, had been committed against her. She admitted that she struggled with feelings of great bitterness. In her anger, she mentally cried out, “Someone must pay for this terrible wrong.” In this extreme moment of sorrow and questioning, she wrote that there came into her heart an immediate reply: “Someone already has paid.”

If we are not aware of what the Savior’s sacrifice can do for us, we may go through life carrying regrets that we have done something that was not right or offended someone. The guilt that accompanies mistakes can be washed away. If we seek to understand His Atonement, we will come to a deep reverence for the Lord Jesus Christ, His earthly ministry, and His divine mission as our Savior.

The Church of Jesus Christ of Latter-day Saints was restored to move throughout the world the knowledge of the life and teachings of the Savior. This great conference is being broadcast in 94 languages by satellite to 102 countries but is also available on the Internet to every nation where the Church is present. We have over 3,000 stakes. Our full-time missionary force exceeds 88,000, and total Church membership has passed 15 million. These numbers serve as evidence that the “stone which is cut out of the mountain without hands” continues to roll forth and will eventually fill “the whole earth” (D&C 65:2).

But no matter how large the organization of the Church becomes or how many millions of members join our ranks, no matter how many continents and countries our missionaries enter or how many different languages we speak, the true success of the gospel of Jesus Christ will be measured by the spiritual strength of its individual members. We need the strength of conviction that is found in the heart of every loyal disciple of Christ.

A testimony of the hope of redemption is something which cannot be measured or counted. Jesus Christ is the source of that hope.

We seek to strengthen the testimonies of the young and old, the married and single. We need to teach the gospel of Jesus Christ to men, women, and children, those of every race and nationality, the rich and the poor. We need the recent convert and those among our numbers descended from the pioneers. We need to seek out those who have strayed and assist them to return to the fold. We need everyone’s wisdom and insight and spiritual strength. Each member of this Church as an individual is a critical element of the body of the Church.

“For as the body is one, and hath many members, and all the members of that one body, being many, are one body: so also is Christ.

“For by one Spirit are we all baptized into one body. …

“For the body is not one member, but many” (1 Corinthians 12:12–14).

Each member serves as a testimony of the life and teachings of Jesus Christ. We are at war with the forces of the adversary, and we need each and every one of us if we are going to succeed in the work the Savior has for us to do.

You might think, “What can I do? I am only one person.”

Certainly Joseph Smith felt very alone at times. He rose to greatness, but he started as a 14-year-old boy who had a question: “Which of all the churches should I join?” (see Joseph Smith—History 1:10). Joseph’s faith and testimony of the Savior grew as ours must grow, “line upon line, precept upon precept, here a little and there a little” (2 Nephi 28:30; see also D&C 128:21). Joseph knelt to pray, and what marvelous things have come about as a result of that prayer and the First Vision.

As one of the Twelve Apostles, I bear witness of the Lord Jesus Christ. He lives. He is our Redeemer and our Savior. “Through the Atonement of Christ, all mankind may be saved” (Articles of Faith 1:3). He presides over this Church. He is no stranger to His servants. As we move into the future with quiet confidence, His Spirit will be with us. There is no end to His power to bless and direct the lives of those who seek truth and righteousness. I bear witness of Him in the name of Jesus Christ, amen.

# References
