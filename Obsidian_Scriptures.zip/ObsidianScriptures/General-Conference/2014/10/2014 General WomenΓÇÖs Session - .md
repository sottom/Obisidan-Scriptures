

10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/womens-session?lang=eng)



# References
