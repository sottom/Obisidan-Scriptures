Neill F. Marriott
Second Counselor in the Young Women General Presidency
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/sharing-your-light?lang=eng)

_We must stand firm in our faith and lift our voices to proclaim true doctrine._

Tonight I would like to consider two important responsibilities we carry: first, consistently adding gospel light and truth to our lives, and second, sharing that light and truth with others.

Do you know how important you are? Every one of you—right now—is valuable and essential in Heavenly Father’s plan of salvation. We have a work to do. We know the truth of the restored gospel. Are we ready to defend that truth? We need to live it; we need to share it. We must stand firm in our faith and lift our voices to proclaim true doctrine.

In the September 2014 Ensign and Liahona, Elder M. Russell Ballard writes: “We need more of the distinctive, influential voices and faith of women. We need them to learn the doctrine and to understand what we believe so that they can bear their testimonies about the truth of all things.”1

Sisters, you strengthen my faith in Jesus Christ. I have watched your examples, heard your testimonies, and felt of your faith from Brazil to Botswana! You carry a circle of influence with you wherever you go. It is felt by the people around you—from your family to the contacts in your cell phone and from your friends on social media to those seated next to you tonight. I agree with Sister Harriet Uchtdorf, who wrote, “You … are vibrant and enthusiastic beacons in an ever-darkening world as you show, through the way you live your lives, that the gospel is a joyful message.”2



President Thomas S. Monson pointed out, “If you want to give a light to others, you have to glow yourself.”3 How can we keep that light of truth glowing within us? Sometimes I feel like a dim lightbulb. How do we grow brighter?

The scriptures teach, “That which is of God is light; and he that receiveth light, and continueth in God, receiveth more light.”4 We must continue in God, as the scripture says. We must go to the source of light—to Heavenly Father and Jesus Christ and the scriptures. We can also go to the temple, knowing that all things within its walls point to Christ and His great atoning sacrifice.

Think of the effect temples have on their surroundings. They beautify inner cities; they shine from prominent hills. Why do they beautify and shine? Because, as the scriptures say, “Truth shineth,”5 and temples contain truth and eternal purpose; so do you.

In 1877, President George Q. Cannon said, “Every Temple … lessens the power of Satan on the earth.”6 I believe that wherever a temple is built on the earth, it pushes back the darkness. The temple’s purpose is to serve mankind and give all of Heavenly Father’s children the ability to return and live with Him. Isn’t our purpose similar to these dedicated buildings, these houses of the Lord? To serve others and help them push back the darkness and return to Heavenly Father’s light?

Sacred temple work will increase our faith in Christ, and then we can better influence the faith of others. By the nourishing spirit of the temple, we can learn the reality, the power, and the hope of the Savior’s Atonement in our personal life.

Some years ago our family encountered a major challenge. I went to the temple and there prayed earnestly for help. I was given a moment of truth. I received a clear impression of my weaknesses, and I was shocked. In that spiritually instructive moment, I saw a prideful woman doing things her own way, not necessarily the Lord’s way, and privately taking credit for any so-called accomplishment. I knew I was looking at myself. I cried out in my heart to Heavenly Father and said, “I don’t want to be that woman, but how do I change?”

Through the pure spirit of revelation in the temple, I was taught of my utter need for a Redeemer. I turned immediately to the Savior Jesus Christ in my thoughts and felt my anguish melt away and a great hope spring up in my heart. He was my only hope, and I longed to cling only to Him. It was clear to me that a self-absorbed natural woman “is an enemy to God”7 and to people in her sphere of influence. In the temple that day I learned it was only through the Atonement of Jesus Christ that my prideful nature could change and that I would be enabled to do good. I felt His love keenly, and I knew He would teach me by the Spirit and change me if I gave my heart to Him, holding back nothing.

I still fight my weaknesses, but I trust in the divine help of the Atonement. This pure instruction came because I entered the holy temple, seeking relief and answers. I entered the temple burdened, and I left knowing I had an all-powerful and all-loving Savior. I was lighter and joyful because I had received His light and accepted His plan for me.

Placed around the world, temples have their own unique look and design on the outside, but inside they all contain the same eternal light, purpose, and truth. In 1 Corinthians 3:16 we read, “Know ye not that ye are the temple of God, and that the Spirit of God dwelleth in you?” We too as daughters of God have been placed all around the world, like temples, and we each have our own unique look and outward design, like temples. We also have a spiritual light within us, like temples. This spiritual light is a reflection of the Savior’s light. Others will be attracted to this brightness.

We have our own roles on the earth—from daughter, mother, leader, and teacher to sister, wage earner, wife, and more. Each is influential. Each role will have moral power as we reflect gospel truths and temple covenants in our lives.

Elder D. Todd Christofferson said, “In all events, a mother can exert an influence unequaled by any other person in any other relationship.”8

When our children were young, I felt like the cocaptain, with my husband, David, of a ship, and I pictured our 11 children as a flotilla of little boats bobbing around us in the harbor, preparing to set forth on the sea of the world. David and I felt a need to consult the compass of the Lord daily for the best direction to sail with our small fleet.

My days were full of forgettable things like folding laundry, reading children’s books, and putting casseroles together for dinner. Sometimes in the harbor of our homes, we can’t see that by the simple, consistent acts—including family prayer, scripture study, and family home evening—great things are brought to pass. But I testify that these very acts carry eternal significance. Great joy comes when those little boats—our children—grow into mighty seafaring vessels filled with gospel light and ready to “embark in the service of God.”9 Our small acts of faith and service are how most of us can continue in God and eventually bring eternal light and glory to our family, our friends, and our associates. You truly carry a circle of influence with you!

Think of the influence that the faith of a Primary-aged girl can have on her family. Our daughter’s faith blessed our family when we lost our young son at an amusement park. The family rushed around frantically looking for him. Finally, our 10-year-old daughter tugged on my arm and said, “Mom, shouldn’t we pray?” She was right! The family gathered in the middle of a crowd of onlookers and prayed to find our child. We found him. To all the Primary girls I say, “Please keep reminding your parents to pray!”

This summer I had the privilege of attending an encampment of 900 young women in Alaska. Their influence on me was profound. They came to the camp spiritually prepared, having read the Book of Mormon and having memorized “The Living Christ: The Testimony of the Apostles.” On the third night of camp, all 900 young women stood together and recited the entire document word for word.

The Spirit filled the vast hall, and I yearned to join in. But I couldn’t. I hadn’t paid the price of memorization.

I have now begun to learn the words of “The Living Christ” as these sisters did, and because of their influence I am more fully experiencing the sacramental covenant to always remember the Savior as I repeat over and over the Apostles’ testimony of Christ. The sacrament is taking on a deeper meaning for me.

My hope is to offer the Savior a Christmas gift this year of having “The Living Christ” memorized and securely held in my heart by December 25th. I hope I can be an influence for good—as the sisters of Alaska were for me.



Can you find yourself in the following words of this document, “The Living Christ”? “He entreated all to follow His example. He walked the roads of Palestine, healing the sick, causing the blind to see, and raising the dead.”10

We, sisters of the Church, do not walk the roads of Palestine healing the sick, but we can pray for and apply the healing love of the Atonement to a sickened, strained relationship.

Though we will not cause the blind to see in the manner of the Savior, we can testify of the plan of salvation to the spiritually blind. We can open the eyes of their understanding to the necessity of priesthood power in eternal covenants.

We will not be raising the dead as did the Savior, but we can bless the dead by finding their names for temple work. Then we will indeed raise them from their spirit prison and offer them the path of eternal life.

I testify we have a living Savior, Jesus Christ, and with His power and light we will be enabled to push back the darkness of the world, give voice to the truth we know, and influence others to come unto Him. In the name of Jesus Christ, amen.

# References
1. - M. Russell Ballard, “Men and Women and Priesthood Power,” Ensign, Sept. 2014, 32; Liahona, Sept. 2014, 36.
2. - Harriet R. Uchtdorf, The Light We Share (Deseret Book Company, 2014), 41; used by permission.
3. - Thomas S. Monson, “For I Was Blind, but Now I See,” Ensign, May 1999, 56; Liahona, July 1999, 69.
4. - Doctrine and Covenants 50:24.
5. - Doctrine and Covenants 88:7.
6. - George Q. Cannon, in Preparing to Enter the Holy Temple (booklet, 2002), 36.
7. - Mosiah 3:19.
8. - D. Todd Christofferson, “The Moral Force of Women,” Ensign or Liahona, Nov. 2013, 30.
9. - Doctrine and Covenants 4:2.
10. - “The Living Christ: The Testimony of the Apostles,” Ensign or Liahona, Apr. 2000, 2.