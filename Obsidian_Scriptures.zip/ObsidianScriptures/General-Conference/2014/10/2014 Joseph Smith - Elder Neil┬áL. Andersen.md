Elder Neil L. Andersen
Of the Quorum of the Twelve Apostles
10-2014
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2014/10/joseph-smith?lang=eng)

_Jesus Christ chose a holy man, a righteous man, to lead the Restoration of the fulness of His gospel. He chose Joseph Smith._

On his first visit to the Prophet Joseph Smith at age 17, an angel called Joseph by name and told him that he, Moroni, was a messenger sent from the presence of God and that God had a work for him to do. Imagine what Joseph must have thought when the angel then told him that his name would “be had for good and evil among all nations, kindreds, and tongues.”1 Perhaps the shock in Joseph’s eyes caused Moroni to repeat again that both good and evil would be spoken of him among all people.2

The good spoken of Joseph Smith came slowly; the evil speaking began immediately. Joseph wrote, “How very strange it was that an obscure boy … should be thought … of sufficient importance to attract … the most bitter persecution.”3

While love for Joseph grew, so also did hostility. At the age of 38, he was murdered by a mob of 150 men with painted faces.4 While the Prophet’s life abruptly ended, the good and evil spoken of Joseph was just beginning.

Should we be surprised with the evil spoken against him? The Apostle Paul was called mad and deranged.5 Our Beloved Savior, the Son of God, was labeled gluttonous, a winebibber, and possessed of a devil.6

The Lord told Joseph of his destiny:

“The ends of the earth shall inquire after thy name, and fools shall have thee in derision, and hell shall rage against thee;

“While the pure in heart, … the wise, … and the virtuous, shall seek … blessings constantly from under thy hand.”7

Why does the Lord allow the evil speaking to chase after the good? One reason is that opposition against the things of God sends seekers of truth to their knees for answers.8

Joseph Smith is the prophet of the Restoration. His spiritual work began with the appearance of the Father and the Son, followed by numerous heavenly visitations. He was the instrument in God’s hands in bringing forth sacred scripture, lost doctrine, and the restoration of the priesthood. The importance of Joseph’s work requires more than intellectual consideration; it requires that we, like Joseph, “ask of God.”9 Spiritual questions deserve spiritual answers from God.

Many of those who dismiss the work of the Restoration simply do not believe that heavenly beings speak to men on earth. Impossible, they say, that golden plates were delivered by an angel and translated by the power of God. From that disbelief, they quickly reject Joseph’s testimony, and a few unfortunately sink to discrediting the Prophet’s life and slandering his character.

We are especially saddened when someone who once revered Joseph retreats from his or her conviction and then maligns the Prophet.10

“Studying the Church … through the eyes of its defectors,” Elder Neal A. Maxwell once said, is “like interviewing Judas to understand Jesus. Defectors always tell us more about themselves than about that from which they have departed.”11

Jesus said, “Bless them that curse you, … and pray for them which despitefully use you, and persecute you.”12 Let us offer kindness to those who criticize Joseph Smith, knowing in our own hearts that he was a prophet of God and taking comfort that all this was long ago foretold by Moroni.

How should we respond to a sincere inquirer who is concerned about negative comments he or she has heard or read about the Prophet Joseph Smith? Of course, we always welcome honest and genuine questions.

To questions about Joseph’s character, we might share the words of thousands who knew him personally and who gave their lives for the work he helped establish. John Taylor, who was shot four times by the mob that killed Joseph, would later declare: “I testify before God, angels, and men, that [Joseph] was a good, honorable, [and] virtuous man— … [and] that his private and public character was unimpeachable—and that he lived and died as a man of God.”13

We might remind the sincere inquirer that Internet information does not have a “truth” filter. Some information, no matter how convincing, is simply not true.

Years ago I read a Time magazine article that reported the discovery of a letter, supposedly written by Martin Harris, that conflicted with Joseph Smith’s account of finding the Book of Mormon plates.14

A few members left the Church because of the document.15

Sadly, they left too quickly. Months later experts discovered (and the forger confessed) that the letter was a complete deception.16 You may understandably question what you hear on the news, but you need never doubt the testimony of God’s prophets.

We might remind the inquirer that some information about Joseph, while true, may be presented completely out of context to his own day and situation.

Elder Russell M. Nelson illustrated this point. He said: “I was serving as a consultant to the United States government at its National Center for Disease Control in Atlanta, Georgia. Once while awaiting a taxi to take me to the airport after our meetings were over, I stretched out on the lawn to soak in a few welcome rays of sunshine before returning to the winter weather of Utah. … Later I received a photograph in the mail taken by a photographer with a telephoto lens, capturing my moment of relaxation on the lawn. Under it was a caption, ‘Governmental consultant at the National Center.’ The picture was true, the caption was true, but the truth was used to promote a false impression.”17 We do not discard something we know to be true because of something we do not yet understand.

We might remind the inquirer that Joseph was not alone in the visit of angels.

The Book of Mormon witnesses wrote, “We declare with words of soberness, that an angel of God came down from heaven, and … we beheld and saw the plates.”18 We could quote many others as well.19

A sincere inquirer should see the spreading of the restored gospel as the fruit of the Lord’s work through the Prophet.

There are now more than 29,000 congregations and 88,000 missionaries teaching the gospel across the world. Millions of Latter-day Saints are seeking to follow Jesus Christ, live honorable lives, care for the poor, and give of their time and talents in helping others.

Jesus said:

“A good tree cannot bring forth evil fruit, neither can a corrupt tree bring forth good fruit. …

“… By their fruits ye shall know them.”20

These explanations are convincing, but the sincere inquirer should not rely on them exclusively to settle his or her search for truth.

Each believer needs a spiritual confirmation of the divine mission and character of the Prophet Joseph Smith. This is true for every generation. Spiritual questions deserve spiritual answers from God.

Recently while I was on the East Coast of the United States, a returned missionary spoke to me about a friend who had become disillusioned with information he had received about the Prophet Joseph Smith. They had spoken several times, and the returned missionary seemed to have some doubts himself as a result of the discussions.

Although I hoped he could strengthen his friend, I felt concerned for his own testimony. Brothers and sisters, let me give you a caution: you won’t be of much help to others if your own faith is not securely in place.

A few weeks ago I boarded a plane for South America. The flight attendant directed our attention to a safety video. “It is unlikely,” we were warned, “but if cabin pressure changes, the panels above your seat will open, revealing oxygen masks. If this happens, reach up and pull a mask toward you. Place the mask over your nose and mouth. Slip the elastic strap over your head and adjust the mask if necessary.” Then this caution: “Be sure to adjust your own mask before helping others.”

Un-MutePlay/PauseLanguagesSubtitlesopenFont sizedefault50%75%100%150%200%300%400%Font familydefaultmonospaced serifproportional serifmonospaced sans serifproportional serifcasualcursivesmall capitalFont colordefaultwhiteblackredgreenbluecyanyellowmagentaFont opacitydefault100%75%50%25%Character edgedefaultraiseddepresseduniformdrop shadowedBackground colordefaultwhiteblackredgreenbluecyanyellowmagentaBackground opacitydefault100%75%50%25%0%Window colordefaultwhiteblackredgreenbluecyanyellowmagentaWindow opacitydefault100%75%50%25%0%BackResetVideo QualitySpeed0.25x0.5xnormal1.5x2x00:0100:00PlayMuteSettingsSettingsSettingsFullscreenGoogle CastApple AirPlayReplay

The negative commentary about the Prophet Joseph Smith will increase as we move toward the Second Coming of the Savior. The half-truths and subtle deceptions will not diminish. There will be family members and friends who will need your help. Now is the time to adjust your own spiritual oxygen mask so that you are prepared to help others who are seeking the truth.21

A testimony of the Prophet Joseph Smith can come differently to each of us. It may come as you kneel in prayer, asking God to confirm that he was a true prophet. It may come as you read the Prophet’s account of the First Vision. A testimony may distill upon your soul as you read the Book of Mormon again and again. It may come as you bear your own testimony of the Prophet or as you stand in the temple and realize that through Joseph Smith the holy sealing power was restored to the earth.22 With faith and real intent, your testimony of the Prophet Joseph Smith will strengthen. The constant water balloon volleys from the sidelines may occasionally get you wet, but they need never, never extinguish your burning fire of faith.

To the youth listening today or reading these words in the days ahead, I give a specific challenge: Gain a personal witness of the Prophet Joseph Smith. Let your voice help fulfill Moroni’s prophetic words to speak good of the Prophet. Here are two ideas: First, find scriptures in the Book of Mormon that you feel and know are absolutely true. Then share them with family and friends in family home evening, seminary, and your Young Men and Young Women classes, acknowledging that Joseph was an instrument in God’s hands. Next, read the testimony of the Prophet Joseph Smith in the Pearl of Great Price or in this pamphlet, now in 158 languages. You can find it online at LDS.org or with the missionaries. This is Joseph’s own testimony of what actually occurred. Read it often. Consider recording the testimony of Joseph Smith in your own voice, listening to it regularly, and sharing it with friends. Listening to the Prophet’s testimony in your own voice will help bring the witness you seek.



  ImageThe Testimony of the Prophet Joseph Smith



The Testimony of the Prophet Joseph Smith is now in 158 languages.





There are great and wonderful days ahead. President Thomas S. Monson has said: “This great cause … will continue to go forth, changing and blessing lives. … No force in the entire world can stop the work of God. Despite what comes, this great cause will go forward.”23



I give you my witness that Jesus is the Christ, our Savior and Redeemer. He chose a holy man, a righteous man, to lead the Restoration of the fulness of His gospel. He chose Joseph Smith.

I testify that Joseph Smith was an honest and virtuous man, a disciple of the Lord Jesus Christ. God the Father and His Son, Jesus Christ, did appear to him. He did translate the Book of Mormon by the gift and power of God.

In our society beyond the veil of death, we will clearly understand the sacred calling and divine mission of the Prophet Joseph Smith. In that not-too-distant day, you and I and “millions [more] shall know ‘Brother Joseph’ again.”24 In the name of Jesus Christ, amen.

# References
1. - Joseph Smith—History 1:33.
2. - See Joseph Smith—History 1:29–46.
3. - Joseph Smith—History 1:23.
4. - See Doctrine and Covenants 135:1.
5. - See Acts 26:24.
6. - See Matthew 11:19; John 10:20.
7. - Doctrine and Covenants 122:1–2.
8. - President Dieter F. Uchtdorf said: “First doubt your doubts before you doubt your faith. We must never allow doubt to hold us prisoner and keep us from the divine love, peace, and gifts that come through faith in the Lord Jesus Christ” (“Come, Join with Us,” Ensign or Liahona, Nov. 2013, 23). Elder Jeffrey R. Holland said: “This is a divine work in process, with the manifestations and blessings of it abounding in every direction, so please don’t hyperventilate if from time to time issues arise that need to be examined, understood, and resolved. They do and they will. In this Church, what we know will always trump what we do not know” (“Lord, I Believe,” Ensign or Liahona, May 2013, 94).
9. - James 1:5; see also Joseph Smith—History 1:11–13.
10. - Daniel Tyler recalled: “Brother Isaac Behunin and myself [visited the Prophet] at his residence. His persecutions were the topic of conversation. He repeated many false, inconsistent and contradictory statements made by apostates. … He also told how most of the officials who would … have [willingly] taken his life, when he was arrested, turned in his favor on [knowing him better]. …
“… Brother Behunin remarked: ‘If I should leave this Church I would not do as those men have done: I would go to some remote place where Mormonism had never been heard of, settle down, and no one would ever learn that I knew anything about it.’
“[Joseph] immediately replied: ‘Brother Behunin, you don’t know what you would do. No doubt these men once thought as you do. Before you joined this Church you stood on neutral ground. … When you joined this Church you enlisted to serve God. When you did that you left the neutral ground, and you never can get back on to it. Should you forsake the Master you enlisted to serve, it will be by the instigation of the evil one, and you will follow his dictation and be his servant’” (in Teachings of Presidents of the Church: Joseph Smith [2007], 324).
11. - Neal A. Maxwell, “All Hell Is Moved” (Brigham Young University devotional, Nov. 8, 1977), 3; speeches.byu.edu.
12. - Matthew 5:44.
13. - Teachings of Presidents of the Church: John Taylor (2001), 83; see also Doctrine and Covenants 135:3.
14. - See Richard N. Ostling, “Challenging Mormonism’s Roots,” Time, May 20, 1985, 44.
15. - See Ostling, “Challenging Mormonism’s Roots,” 44; see also Gordon B. Hinckley, “Lord, Increase Our Faith,” Ensign, Nov. 1987, 52; Neil L. Andersen, “Trial of Your Faith,” Ensign or Liahona, Nov. 2012, 41.
16. - See Richard E. Turley Jr., Victims: The LDS Church and the Mark Hofmann Case (1992).
17. - Russell M. Nelson, “Truth—and More,” Ensign, Jan. 1986, 71.
18. - “The Testimony of Three Witnesses,” Book of Mormon.
19. - See Joseph Smith—History 1:71, note; see also Doctrine and Covenants 76:23.
20. - Matthew 7:18, 20.
21. - President Henry B. Eyring, in speaking about those with doubts, said: “In your love for them you may decide to try to give them what they ask. You may be tempted to go with them through their doubts, with the hope that you can find proof or reasoning to dispel their doubts. Persons with doubts often want to talk about what they think are the facts or the arguments that have caused their doubts, and about how much it hurts. …
“You and I can do better if we do not stay long with what our students see as the source of their doubts. … Their problem does not lie in what they think they see; it lies in what they cannot yet see. … We do best if we turn the conversation soon to the things of the heart, those changes of the heart that open spiritual eyes” (“‘And Thus We See’: Helping a Student in a Moment of Doubt” [address to Church Educational System religious educators, Feb. 5, 1993], 3, 4; si.lds.org).
22. - President Gordon B. Hinckley said: “Many years ago when at the age of twelve I was ordained a deacon, my father, who was president of our stake, took me to my first stake priesthood meeting. … [The opening hymn was “Praise to the Man.”] They were singing of the Prophet Joseph Smith, and as they did so there came into my heart a great surge of love for and belief in the mighty Prophet of this dispensation. … I knew then, by the power of the Holy Ghost, that Joseph Smith was indeed a prophet of God” (“Praise to the Man,” Ensign, Aug. 1983, 2; Tambuli, Jan. 1984, 1, 2).
23. - Thomas S. Monson, “As We Gather Once Again,” Ensign or Liahona, May 2012, 4.
24. - “Praise to the Man,” Hymns, no. 27.