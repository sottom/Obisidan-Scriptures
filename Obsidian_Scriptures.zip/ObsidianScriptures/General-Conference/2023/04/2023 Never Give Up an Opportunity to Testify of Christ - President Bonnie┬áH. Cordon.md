President Bonnie H. Cordon
Young Women General President
04-2023
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2023/04/12cordon?lang=eng)

_True joy rests on our willingness to come closer to Christ and witness for ourselves._

Five years ago today, we raised our hands to sustain our beloved prophet, President Russell M. Nelson, as President of The Church of Jesus Christ of Latter-day Saints―the Lord’s mouthpiece for this remarkable season of growth and revelation. Through him, we have received countless invitations and have been promised glorious blessings if we will center our lives on our Savior, Jesus Christ.

In 2011, while I was serving with my husband as mission leaders in beautiful Curitiba, Brazil, my phone rang during a meeting. Rushing to silence it, I noticed the call was from my father. I quickly left the meeting to answer: “Hi, Dad!”

Unexpectedly, his voice was filled with emotion: “Hi, Bonnie. I need to tell you something. I’ve been diagnosed with ALS.”

My mind swirled with confusion, “Wait! What is ALS?”

Dad was already explaining, “My mind will stay alert while my body slowly shuts down.”

I felt my whole world shift as I began to wrestle with the implications of this grievous news. But on that unforgettable day, it was his last sentence that found a permanent place in my heart. My dear father said with urgency, “Bonnie, never give up an opportunity to testify of Christ.”

I have pondered and prayed over Dad’s counsel. I have often asked myself if I fully know what it means to never give up an opportunity to testify of Jesus Christ.

Like you, I have occasionally stood on the first Sunday of the month and borne a witness of Christ. Many times I have testified of gospel truths as part of a lesson. I have boldly taught truth and declared the divinity of Christ as a missionary.

Yet this plea felt more personal! It seemed as though he was saying, “Bonnie, don’t let the world overtake you! Stay true to your covenants with the Savior. Seek to experience His blessings every day, and be able to testify through the Holy Ghost of His power and presence in your life!”

We live in a fallen world, with distractions coaxing our eyes and hearts downward instead of heavenward. Much like the Nephites in 3 Nephi 11, we need Jesus Christ. Can you imagine yourself there, among people who had experienced so much chaos and destruction? What would it be like to hear the Lord’s personal invitation:

“Arise and come forth unto me, that ye may thrust your hands into my side, and also that ye may feel the prints of the nails in my hands and in my feet, that ye may know that I am … the God of the whole earth, and have been slain for the sins of the world.

“And … the multitude went forth … one by one … and did see with their eyes and did feel with their hands, and did know … and had witnessed for themselves.”1

These Nephites eagerly went forward to thrust their hands into His side and feel the prints of the nails in His hands and feet so they could witness for themselves that this was the Christ. Similarly, many faithful people we have studied in the New Testament this year had anxiously awaited Christ’s coming. Then they stepped from their fields, workbenches, and dinner tables and followed Him, pressed upon Him, thronged Him, and sat with Him. Are we as anxious to witness for ourselves as the multitudes in the scriptures? Are the blessings we seek less needful than theirs?

When Christ physically visited the Nephites at their temple, His invitation was not to stand at a distance and look upon Him, but to touch Him, to feel for themselves the reality of the Savior of humankind. How can we draw close enough to gain a personal witness of Jesus Christ? This may be part of what my father was trying to teach me. While we may not enjoy the same physical proximity as those who walked with Christ during His earthly ministry, through the Holy Ghost we can experience His power every day! As much as we need!

The young women around the world have taught me so much about seeking Christ and gaining a daily, personal witness of Him. Let me share the wisdom of two of them:

Livvy has watched general conference her entire life. In fact, in her home they traditionally watch all five sessions as a family. In the past, conference for Livvy had meant doodling or drifting into the occasional unintended nap. But this past October general conference was different. It became personal.

This time, Livvy decided to be an active recipient. She silenced notifications on her phone and took notes of impressions from the Spirit. She was amazed as she felt specific things God wanted her to hear and do. This decision made a difference in her life almost immediately.

Just days later her friends invited her to an inappropriate movie. She reflected, “I felt the words and spirit of conference return into my heart, and I heard myself declining their invitation.” She also had the courage to share her testimony of the Savior in her ward.

After these events she stated, “The amazing thing is, when I heard myself testify that Jesus is the Christ, I felt the Holy Ghost confirm it again for me.”

Livvy did not skip like a stone over the surface of conference weekend; she dove in, mind and spirit, and found the Savior there.

And then there is Maddy. When her family stopped attending church, Maddy was confused and not certain what to do. She realized something significant was missing. So at age 13, Maddy began attending church alone. Even though being alone was sometimes hard and uncomfortable, she knew she could find the Savior at church and she wanted to be where He was. She said, “In church my soul felt like it was at home.”

Maddy held onto the fact that her family had been sealed together for eternity. She started bringing her younger brothers with her to church and studying scriptures with them at home. Eventually her mom began joining them. Maddy told her mom of her desire to serve a mission and asked if her mom could be ready to attend the temple with her.

Today Maddy is in the MTC. She is serving. She is witnessing of Christ. Her example helped lead both of her parents back to the temple and back to Christ.

Like Livvy and Maddy, as we choose to seek Christ, the Spirit will witness of Him in many different situations. These witnesses of the Spirit occur as we fast, pray, wait, and continue forward. Our closeness to Christ grows through worshipping frequently in the temple, repenting daily, studying scriptures, attending church and seminary, pondering our patriarchal blessings, worthily receiving ordinances, and honoring sacred covenants. All of these invite the Spirit to enlighten our minds, and they bring added peace and protection. But do we honor them as sacred opportunities to testify of Christ?

I have attended the temple many times, but when I worship in the house of the Lord, it changes me. Sometimes while fasting, I find myself simply going hungry, but other times, I feast on the Spirit with purpose. I sometimes have mumbled prayers that are repetitive and routine, but I have also come eager to receive counsel from the Lord through prayer.

There is power in making these holy habits less of a checklist and more of a witness. The process will be gradual but will grow with daily, active participation and purposeful experiences with Christ. As we consistently act on His teaching, we gain a testimony of Him; we build a relationship with Him and our Heavenly Father. We begin to become like Them.

The adversary creates so much noise that it can be difficult to hear the Lord’s voice. Our world, our challenges, our circumstances will not get quieter, but we can and must hunger and thirst after the things of Christ to “hear Him” with clarity.2 We want to create muscle memory of discipleship and testimony that will bring into focus our reliance on our Savior each day.

My father has been gone for over 11 years now, but his words are alive in me. “Bonnie, never give up an opportunity to testify of Christ.” I invite you to join me in accepting his invitation. Look for Christ everywhere―I promise He is there!3 True joy rests on our willingness to come closer to Christ and witness for ourselves.

We know that in the last days, “every knee shall bow, and every tongue confess” that Jesus is the Christ.4 I pray this witness will become a normal and natural experience for us now—that we will take every opportunity to joyfully testify: Jesus Christ lives!

Oh, how I love Him. How grateful we are for His infinite Atonement, which has “made eternal life a possibility and immortality a reality for [us] all.”5 I testify of our Savior’s goodness and great glory in His sacred name, even Jesus Christ, amen.

# References
1. - 3 Nephi 11:14–16; emphasis added.
2. - See Russell M. Nelson, “Hear Him,” Ensign or Liahona, May 2020, 88–92.
3. - See Alma 30:44; Doctrine and Covenants 6:36; Moses 6:63.
4. - Mosiah 27:31; see also Doctrine and Covenants 88:104.
5. - Russell M. Nelson, “Revelation for the Church, Revelation for Our Lives,” Ensign or Liahona, May 2018, 93.