Elder Gary E. Stevenson
Of the Quorum of the Twelve Apostles
04-2023
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2023/04/11stevenson?lang=eng)

_Look at the Book of Mormon in a new light and consider the profound witness it bears of the reality of the risen Christ._

First Presidency Letter on Easter



​You likely remember hearing a letter from the First Presidency read in your ward or branch several weeks ago. That letter announced that next Sunday—Easter Sunday—all wards and branches are to meet for sacrament meeting only, leaving additional time for worship at home as families to commemorate this most important holiday.1

The First Presidency’s letter caught my attention, and it caused me to reflect on the way our family has celebrated Easter through the years. The more I thought about our celebrations, the more I found myself wondering if we are inadvertently shortchanging the true meaning of this holiday, so central to all believers in Jesus Christ.







Christmas and Easter Traditions



​Those thoughts led me to ponder the difference between the way we have celebrated Christmas as compared with Easter. During December, we somehow manage to incorporate the fun of “Jingle Bells,” Christmas stockings, and gifts alongside other, more thoughtful traditions—such as caring for those in need, singing our favorite Christmas carols and hymns, and of course opening the scriptures and reading the Christmas story in Luke 2. Every year as we read this beloved story from a large old Bible, our family does what your family probably does—dressed with towels on our heads and shoulders and donning bathrobes to represent Joseph, Mary, and the many who came to worship the baby Jesus, we reenact the treasured Christmas story of the Savior’s birth.

​Our family celebrations at Easter, however, have been somewhat different. I feel our family has relied more on “going to church” to provide the meaningful, Christ-centered part of Easter; and then, as a family, we have gathered to share in other Easter-related traditions. I have loved watching our children and now our grandchildren hunt for Easter eggs and dig through their Easter baskets.

But the First Presidency letter was a wake-up call. Not only did they invite all of us to make sure our celebration of the most important event to ever happen on this earth—the Atonement and Resurrection of Jesus Christ—includes the reverence and respect the Lord deserves, but they also gave us more time with our families and friends on Easter Sunday to do so.

  ImageHe is Risen

These words of the Prophet Joseph Smith add additional context to the significance of the events surrounding Easter: “The fundamental principles of our religion are the testimony of the Apostles and Prophets, concerning Jesus Christ, that He died, was buried, and rose again the third day, and ascended into heaven; and all other things which pertain to our religion are only appendages to it.”2

Lesa and I have discussed ways that our family can do better during the Easter season. Perhaps the question we have asked ourselves is one we could all contemplate: How do we model the teaching and celebration of the Resurrection of Jesus Christ, the Easter story, with the same balance, fulness, and rich religious tradition of the birth of Jesus Christ, the Christmas story?

It seems we are all trying. I observe a growing effort among Latter-day Saints toward a more Christ-centered Easter. This includes a greater and more thoughtful recognition of Palm Sunday and Good Friday as practiced by some of our Christian cousins. We might also adopt appropriate Christ-centered Easter traditions found in the cultures and practices of countries worldwide.

New Testament scholar N. T. Wright suggested: “We should be taking steps to celebrate Easter in creative new ways: in art, literature, children’s games, poetry, music, dance, festivals, bells, special concerts. … This is our greatest festival. Take Christmas away, and in biblical terms you lose two chapters at the front of Matthew and Luke, nothing else. Take Easter away, and you don’t have a New Testament; you don’t have a Christianity.”3







Easter, the Bible, and the Book of Mormon



​We cherish the Bible for all it teaches us about the birth, ministry, Crucifixion, and Resurrection of Jesus Christ. No three words embody more hope and eternal consequence for all of humankind than those uttered by a heavenly angel on Easter morning at the Garden Tomb: “He is risen.”4 We are deeply grateful for New Testament scripture that preserves the story of Easter and the Savior’s Easter ministry in Judea and Galilee.

As Lesa and I continued to ponder and seek ways to expand our family Easter celebration to be more Christ-centered, we discussed what scripture reading tradition we might introduce to our family—the Luke 2 equivalent for Easter, if you will.

And then we had this heavenly epiphany: In addition to the important verses about Easter in the New Testament, we as Latter-day Saints are endowed with a most remarkable Easter gift! A gift of unique witness, another testament of the Easter miracle that contains perhaps the most magnificent Easter scriptures in all of Christianity. I am referring of course to the Book of Mormon and, more specifically, to the account of Jesus Christ appearing to inhabitants in the New World in His resurrected glory.

The Prophet Joseph Smith described the Book of Mormon as “the most correct of any book,”5 and beginning with 3 Nephi 11, it tells the magnificent story of the resurrected Christ’s visit to the Nephites, the Savior’s Easter ministry. These Easter scriptures bear record of the Resurrection of the Lord Jesus Christ.

In these chapters, Christ calls twelve disciples, teaches as He did in His Sermon on the Mount, announces that He has fulfilled the law of Moses, and prophesies about the latter-day gathering of Israel. He heals the sick and prays for the people in such a glorious way that “no tongue can speak, neither can there be written by any man, neither can the hearts of men conceive so great and marvelous things as we both saw and heard Jesus speak; and no one can conceive of the joy which filled our souls at the time we heard him pray for us unto the Father.”6

  ImageJesus Christ Visits the Americas

This Easter, our family is going to focus on the first 17 verses of 3 Nephi 11, with which you are familiar. You recall the great multitude round about the temple in the land Bountiful who heard the voice of God the Father and saw Jesus Christ descending out of heaven to extend the most beautiful Easter invitation:

“Arise and come forth unto me, … that ye may feel the prints of the nails in my hands and in my feet, that ye may know that I am … the God of the whole earth, and have been slain for the sins of the world.

“And … the multitude went forth, … one by one … and did see with their eyes and did feel with their hands, … and did bear record, that it was he. …

“And … they did cry out with one accord, saying:

“Hosanna! Blessed be the name of the Most High God! And they did fall down at the feet of Jesus, and did worship him.”7

Imagine: the Nephites at the temple actually touched the hands of the risen Lord! We hope to make these chapters in 3 Nephi as much a part of our Easter tradition as Luke 2 is of our Christmas tradition. In reality, the Book of Mormon shares the greatest Easter story ever told. Let it not be the greatest Easter story never told.

I invite you to look at the Book of Mormon in a new light and consider the profound witness it bears of the reality of the risen Christ as well as the richness and depth of the doctrine of Christ.







The Book of Mormon Testifies of Jesus Christ



We might ask, How can reading Book of Mormon scriptures at Easter bless our lives and those of our loved ones in a meaningful way? More than one might realize. Anytime we read and study from the Book of Mormon, we can expect remarkable outcomes.

Recently, Lesa and I attended the viewing of a dear friend, a woman of faith whose life was cut short by illness. We gathered with her family and close friends, exchanging fond memories of this beautiful soul who had enriched our lives.

While standing away some distance from the casket, conversing with others, I noticed two young Primary-age girls approach the casket and stretch up on their tiptoes—eyes just reaching its edge—to pay their final respects to their beloved aunt. With no one else nearby, Lesa slipped over and crouched down beside them to offer comfort and teaching. She asked how they were doing and if they knew where their aunt was now. They shared their sadness, but then these precious daughters of God, with confidence brimming in their eyes, said they knew their aunt was now happy and she could be with Jesus.

At this tender age, they found peace in the great plan of happiness and, in their own childlike way, testified of the profound reality and simple beauty of the Resurrection of the Savior. They knew this in their hearts because of thoughtful teachings of loving parents, family, and Primary leaders planting a seed of faith in Jesus Christ and eternal life. Wise beyond their years, these young girls understood truths that come to us through the Easter message and ministry of the resurrected Savior and the words of the prophets as told in the Book of Mormon.

I have observed that when President Russell M. Nelson gives a gift of the Book of Mormon to someone not of our faith, including world leaders, he often turns to 3 Nephi and reads about the appearance of the resurrected Christ to the Nephites. In doing so, the living prophet is in essence bearing witness of the living Christ.

We cannot stand as witnesses of Jesus Christ until we can bear witness of Him. The Book of Mormon is another witness of Jesus Christ because throughout its sacred pages, one prophet after another testifies not only that Christ would come but that He did come.







Because of Him



​I am holding in my hand a copy of the first edition of the Book of Mormon. Doing so always moves me. For much of my adult life, I have been fascinated, enthralled, and riveted with what young Joseph Smith did to get this sacred book of scripture translated and published. The miracles that had to occur are staggering to contemplate.

​But that is not why this book moves me. It is because this book, more than any other ever published on this earth, bears witness of the life, the ministry, the teachings, the Atonement, and the Resurrection of Jesus Christ. My dear brothers and sisters, studying regularly from this book about Jesus Christ will change your life. It will open your eyes to new possibilities. It will increase your hope and fill you with charity. Most of all, it will build and strengthen your faith in Jesus Christ and bless you with a sure knowledge that He and our Father know you, love you, and want you to find your way back home, with a capital H.

Dear brothers and sisters, the time has come, foretold by prophets of old, “when the knowledge of a Savior shall spread throughout every nation, kindred, tongue, and people.”8 We are seeing the fulfillment of this prophecy before our very eyes, through the witness of Jesus Christ found in the Book of Mormon.

  Image[Christ's image]

No book does more to show that:





Because of Jesus Christ, everything changed.





Because of Him, everything is better.





Because of Him, life is manageable—especially the painful moments.





Because of Him, everything is possible.





His visit as a resurrected Savior, introduced by God the Father, is a most glorious and triumphant Easter message. It will help our family members gain a personal testimony of Jesus Christ as our Savior and Redeemer, who broke the bands of death.

I close with my testimony of the truthfulness of the Book of Mormon and of Jesus Christ as the Son of the living God. In the name of Jesus Christ, amen.

# References
1. - See First Presidency letter, Feb. 15, 2023.
2. - Teachings of Presidents of the Church: Joseph Smith (2007), 49; emphasis added.
3. - N. T. Wright, Surprised by Hope: Rethinking Heaven, the Resurrection, and the Mission of the Church (2008), 256.
4. - Matthew 28:6.
5. - Teachings: Joseph Smith, 64.
6. - 3 Nephi 17:17.
7. - See 3 Nephi 11:1–17.
8. - Mosiah 3:20.