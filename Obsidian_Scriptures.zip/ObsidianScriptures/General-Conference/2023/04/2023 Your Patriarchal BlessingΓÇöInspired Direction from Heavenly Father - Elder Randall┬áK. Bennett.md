Elder Randall K. Bennett
Of the Seventy
04-2023
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2023/04/25bennett?lang=eng)

_My patriarchal blessing helped me understand my true eternal identity—who I really was and who I could become._

I was raised by wonderful parents who loved and faithfully taught us, their children, the gospel. Sadly, my beloved parents struggled in their marriage for years. I was a Primary child when I was told that they would likely divorce someday and my siblings and I would need to choose which parent to live with. As a result, for years I experienced significant anxiety; however, a gift from my Heavenly Father ultimately helped change everything for me—my patriarchal blessing.

At age 11, increasingly worried about my parents’ relationship, I deeply desired my patriarchal blessing. I knew that my Heavenly Father knew me perfectly and knew my specific circumstances. And I also knew I would receive direction from Him. Immediately after my 12th birthday, I received my patriarchal blessing. That was more than half a century ago, but I vividly remember the details of that sacred experience.

Gratefully, we have inspired direction about patriarchal blessings in the Church’s General Handbook:

“Every worthy, baptized member is entitled to receive a patriarchal blessing, which provides inspired direction from Heavenly Father.”

A member should be “mature enough to understand the significance and sacred nature of the blessing” and “understand the basic doctrine of the gospel.”

“Ideally the member should be young enough that many important decisions in life are still ahead. … Priesthood leaders should not establish a minimum age for a member to receive a patriarchal blessing. …

“Each patriarchal blessing is sacred, confidential, and personal. …

“A person who receives a patriarchal blessing should treasure its words, ponder them, and live to be worthy to receive the promised blessings in this life and in eternity.”1

Our beloved President Russell M. Nelson has repeatedly taught about the importance of a patriarchal blessing,2 that it gives each recipient “a declaration of lineage back to Abraham, Isaac, and Jacob”3 and that each blessing “is personal scripture to you.”4

My patriarchal blessing was critically important to me when I was young for numerous reasons. First, through the power of the Holy Ghost, my patriarchal blessing helped me understand my true eternal identity—who I really was and who I could become. It helped me know, as President Nelson has taught, that I was “a son of God,” “a [child] of the covenant,” and “a disciple of Jesus Christ.”5 I knew that I was known and loved by my Heavenly Father and my Savior and that They were personally involved in my life. This helped me desire to draw closer to Them and increase my faith and trust in Them.

A dear friend who joined the Church as a young adult shared: “When the patriarch placed his hands on my head and spoke my name, everything changed, … not just then but for the rest of my life. I immediately sensed that—through the power by which he spoke—I was known intimately and deeply. The words he spoke penetrated my entire being. I knew that Heavenly Father knew me, inside and out.”

Knowing who I really was helped me understand and desire to do what God expected of me.6

This led me to study the covenants I had made and the promised blessings in God’s covenant with Abraham.7 It gave me an eternal perspective that inspired me to more fully keep my covenants.

I studied my patriarchal blessing frequently and, as a youth, often daily, which helped me feel the comforting, guiding influence of the Holy Ghost, who helped reduce my anxiety as I followed His promptings. This increased my desire to actively invite light, truth, and the Holy Ghost by studying my scriptures and praying daily and trying to more diligently study and follow the teachings of God’s prophet and apostles. My patriarchal blessing also helped me desire to be more submissive to the will of my Heavenly Father, and that focus helped me experience great joy, despite my personal circumstances.8

I received spiritual strength each time I studied my patriarchal blessing. When my parents finally did divorce, my patriarchal blessing, as President Thomas S. Monson taught, had for me become “a precious and priceless personal treasure,” even “a personal Liahona.”9

Now, please don’t misunderstand. I wasn’t perfect. I made all sorts of mistakes. My eternal companion would confirm that I still do. But my patriarchal blessing helped me and continues to help me desire to do better and be better.10 Frequently studying my patriarchal blessing increased my desire to withstand temptation. It helped me have the desire and courage to repent, and repentance increasingly became a joyful process.

It was vital for me to receive my patriarchal blessing while I was young and while my testimony was still growing. And I am forever grateful that my parents and bishop understood that my desire indicated I was ready.

When I was 12, the world was far less confusing and distracting than the world today. President Nelson has described today as “a most complicated time in the history of the world,” a world that is “sin-saturated” and “self-centered.”11 Fortunately our youth today are much more mature than I was at 12, and they too have critically important decisions to make while they are young! They also need to know who they really are and that God loves them and is perfectly aware of them!

Not everyone will desire their patriarchal blessing when I did. But I pray that members who have not yet received their patriarchal blessing will prayerfully seek to know when they are ready. I promise that if you prepare spiritually, your experience, like mine, will be sacred to you. I also pray that those who have already received their patriarchal blessing will study it and treasure it. Cherishing my patriarchal blessing while I was young blessed me with courage when I was discouraged, comfort when I was fearful, peace when I felt anxious, hope when I felt hopeless, and joy when I needed it most. My patriarchal blessing helped increase my faith and trust in my Heavenly Father and my Savior. It also increased my love for Them—and it still does.12

I testify that patriarchal blessings do provide inspired direction from Heavenly Father. I bear my witness of the living reality of our Father in Heaven and His Son—our Savior, Jesus Christ—who know us, love us, and desire to bless us. I also know with certainty that President Russell M. Nelson is God’s prophet on the earth today. In the name of Jesus Christ, amen.

# References
1. - General Handbook: Serving in The Church of Jesus Christ of Latter-day Saints, 18.17, 18.17.1, ChurchofJesusChrist.org.
2. - See Russell M. Nelson, “Thanks for the Covenant” (Brigham Young University devotional, Nov. 22, 1988), speeches.byu.edu; “A More Excellent Hope” (Brigham Young University devotional, Jan. 8, 1995), speeches.byu.edu; “Identity, Priority, and Blessings” (Brigham Young University devotional, Sept. 10, 2000), speeches.byu.edu; “Roots and Branches,” Ensign or Liahona, May 2004, 27–29; “Covenants,” Ensign or Liahona, Nov. 2011, 86–89; “Youth of the Noble Birthright: What Will You Choose?” (Brigham Young University–Hawaii devotional, Sept. 6, 2013), broadcasts.ChurchofJesusChrist.org; “The Book of Mormon, the Gathering of Israel, and the Second Coming,” Ensign, July 2014, 26–31; Liahona, July 2014, 24–29; “Let God Prevail,” Ensign or Liahona, Nov. 2020, 92–95; “The Everlasting Covenant,” Liahona, Oct. 2022, 1–6.
3. - Russell M. Nelson, “Covenants,” 88.
4. - Russell M. Nelson, “Thanks for the Covenant,” speeches.byu.edu.
5. - Russell M. Nelson, “Choices for Eternity” (worldwide devotional for young adults, May 12, 2022), ChurchofJesusChrist.org; emphasis added.
6. - See Russell M. Nelson, “Covenants,” 86–89.
7. - See Genesis 17:1–10; see also Russell M. Nelson, “Children of the Covenant,” Ensign, May 1995, 32–34.
8. - See Russell M. Nelson, “Joy and Spiritual Survival,” Ensign or Liahona, Nov. 2016, 81–84.
9. - Thomas S. Monson, “Your Patriarchal Blessing: A Liahona of Light,” Ensign, Nov. 1986, 65–66.
10. - See Russell M. Nelson, “We Can Do Better and Be Better,” Ensign or Liahona, May 2019, 67–69.
11. - Russell M. Nelson, “Overcome the World and Find Rest,” Liahona, Nov. 2022, 95–96.
12. - Inspired by James E. Faust, “Priesthood Blessings,” Ensign, Nov. 1995, 62–64.