Elder Ronald A. Rasband
Of the Quorum of the Twelve Apostles
04-2023
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2023/04/53rasband?lang=eng)

_Jesus Christ’s triumphant entry into Jerusalem and the events of the week that followed exemplify doctrine we can apply in our lives today._

Today, as has been said, we join with Christians around the world to honor Jesus Christ on this Palm Sunday. Nearly 2,000 years ago, Palm Sunday marked the beginning of the last week of the mortal ministry of Jesus Christ. It was the most important week in human history.

What began with the heralding of Jesus as the promised Messiah in His triumphant entry into Jerusalem closed with His Crucifixion and Resurrection.1 By divine design, His atoning sacrifice concluded His mortal ministry, making it possible for us to live with our Heavenly Father for eternity.

Scriptures tell us that the week began with throngs standing at the gates of the city to see “Jesus the prophet of Nazareth of Galilee.”2 They “took branches of palm trees, and went forth to meet him, and cried: Hosanna: Blessed is the King of Israel that cometh in the name of the Lord.”3

That biblical account of so long ago reminds me of being on a Church assignment in Takoradi, Ghana. Remarkably, I was there on Palm Sunday.



I was to divide the Takoradi Ghana Stake to create the Mpintsin Ghana Stake. Today, there are over 100,000 members of the Church in Ghana.4 (We welcome the Ga Mantse, His Majesty King Nii Tackie Teiko Tsuru II of Accra, Ghana, who is with us today.) Meeting with these Saints, I felt their profound love and devotion to the Lord. I expressed my great love for them and that the President of the Church loved them. I referred to the Savior’s words recorded by John: “That ye love one another, as I have loved you.”5 They deemed it the “I love you conference.”6

  ImageElder Rasband in Africa

As I looked up and down the rows of those dear brothers and sisters and their families in the chapel, I could see in their faces the glow of testimony and faith in Jesus Christ. I felt their desire to be counted as part of His far-reaching Church. And when the choir sang, they sang like angels.

  ImageElder Rasband in Africa

  ImageElder Rasband in Africa

Like on Palm Sunday of old, these were disciples of Jesus Christ gathered to pay tribute to Him as did those at the gates of Jerusalem who, with palms in their hands, exclaimed, “Hosanna … : Blessed is he that cometh in the name of the Lord.”7

  ImagePalm Sunday procession at the start of Holy Week in Winneba, Ghana

Even the parishioners in a church nearby were honoring Palm Sunday. As I was speaking from the pulpit, I noticed out the window they were joyfully walking down the street waving palms in their hands, much like those in this photo. It was a sight I will never forget—all of us that day worshipping the King of kings.

President Russell M. Nelson has admonished us to make Palm Sunday “truly holy by remembering, not just the palms that were waved to honor the entrance of Jesus into Jerusalem, but by remembering the palms of His hands.” Then President Nelson referred to Isaiah, who spoke of the Savior’s promising, “I will never forget you,” with these words: “Behold, I have graven thee upon the palms of my hands.”8

The Lord knows firsthand that mortality is hard. His wounds remind us that He “descended below … all”9 that He might succor us when we suffer and be our example to “hold on thy way,”10 His way, that “God shall be with [us] forever and ever.”11

Palm Sunday was not just an event, another page in history with a date, time, and place. Jesus Christ’s triumphant entry into Jerusalem and the events of the week that followed exemplify doctrine we can apply in our lives today.

Let us look at some of the eternal doctrine that weaves through His ministry concluding in Jerusalem.

First, prophecy. For example, Old Testament prophet Zechariah prophesied of Jesus Christ’s triumphal entry into Jerusalem, even describing He would ride on a donkey.12 Jesus foretold His Resurrection as He prepared to enter the city, saying:

“Behold, we go up to Jerusalem; and the Son of man shall be betrayed unto the chief priests and unto the scribes, and they shall condemn him to death,

“And shall deliver him to the Gentiles to mock, and to scourge, and to crucify him: and the third day he shall rise again.”13

Second, the companionship of the Holy Ghost. Joseph Smith taught, “No man can know that Jesus is the Lord, but by the Holy Ghost.”14 The Savior promised His disciples15 at the Last Supper16 in the upper room,17 “I will not leave you comfortless.”18 They would not be alone to carry the truths of the gospel forward but would have the consummate gift of the Holy Ghost to guide them. “Peace I leave with you, my peace I give unto you,” He promised; “not as the world giveth, give I unto you.”19 With the gift of the Holy Ghost, we have that same assurance—that we “may always have his Spirit to be with [us]”20 and “by the power of the Holy Ghost [we] may know the truth of all things.”21

Third, discipleship. True discipleship is unfailing commitment, obedience to eternal laws, and love of God, first and foremost. Nothing wavering. The multitude who paid tribute with palms hailed Him as the Messiah. That was exactly who He was. They were drawn to Him, His miracles, and His teachings. But the adulation for many did not last. Some who earlier had shouted, “Hosanna,”22 soon turned and cried, “Crucify him.”23

Fourth, the Atonement of Jesus Christ.24 In His final days, following Palm Sunday, He carried out His remarkable Atonement, from the agony of Gethsemane to the mockery of His trial, His torture on the cross, and His burial in a borrowed tomb. But it did not stop there. With the majesty of His calling as the Redeemer of all of Heavenly Father’s children, three days later He stepped forth from that tomb, resurrected,25 as He had prophesied.

Are we continually grateful for the incomparable Atonement of Jesus Christ? Do we feel its purifying power, right now? That is why Jesus Christ, the Author and Finisher of our salvation, went to Jerusalem, to save us all. Do these words in Alma strike a chord: “If ye have experienced a change of heart, and if ye have felt to sing the song of redeeming love, I would ask, can ye feel so now?”26 I can truly say, the choir in Takoradi that Palm Sunday sang “the song of redeeming love.”

That last fateful week of His mortal ministry, Jesus Christ gave the parable of the ten virgins.27 He was teaching of His return to those prepared to receive Him, not with palms in their hands but with the light of the gospel within them. He used the image of lamps lit and burning, with extra oil to fuel the flame, as a description of a willingness to live His ways, embrace His truths, and share His light.

You know the story. The ten virgins represent members of the Church, and the bridegroom represents Jesus Christ.

The ten virgins took their lamps and “went forth to meet the bridegroom.”28 Five were wise, prepared with oil in their lamps and some to spare, and five were foolish, lamps dark with no oil in reserve. When the call came, “Behold, the bridegroom cometh; go ye out to meet him,”29 the five who were “wise and [had] received the truth, and [had] taken the Holy Spirit for their guide”30 were ready for “their king and their lawgiver,”31 that “his glory [would] be upon them.”32 The other five were frantically trying to find oil. But it was too late. The procession went forward without them. When they knocked and pleaded for entrance, the Lord responded, “I know you not.”33

How would we feel if He said to us, “I know you not!”

We, like the ten virgins, have lamps; but do we have oil? I fear there are some who are just getting by on a thin skiff of oil, too busy with worldly pressures to properly prepare. Oil comes from believing and acting on prophecy and the words of living prophets, President Nelson in particular, his counselors, and the Twelve Apostles. Oil fills our souls when we hear and feel the Holy Ghost and act on that divine guidance. Oil pours into our hearts when our choices show we love the Lord and we love what He loves. Oil comes from repenting and seeking the healing of the Atonement of Jesus Christ.

If some of you are looking to fill what some call “a bucket list,” this is it: fill your bucket with oil in the form of the living water of Jesus Christ,34 which is a representation of His life and teachings. In contrast, checking off a far-off place or a spectacular event will never leave your soul feeling whole or satisfied; living the doctrine taught by Jesus Christ will. I mentioned examples earlier: embrace prophecy and prophetic teachings, act on promptings of the Holy Ghost, become a true disciple, and seek the healing power of our Lord’s Atonement. That bucket list will take you somewhere you want to go—back to your Father in Heaven.

That Palm Sunday in Takoradi was a very special experience for me because I shared it with a faithful congregation of brothers and sisters. So it has been on continents and islands all around the world. My heart and soul, like yours, longs to shout, “Hosanna to the Most High God.”35

Though we do not stand at the gates of Jerusalem today with palms in our hands, the time will come when, as prophesied in Revelation, “a great multitude, which no man could number, of all nations, and kindreds, and people, and tongues, [will stand] before the throne, and before the Lamb, clothed with white robes, and palms in their hands.”36

I leave with you my blessing as an Apostle of Jesus Christ that you will diligently strive to live righteously and be among those who, with palms in their hands, will herald the Son of God, the great Redeemer of us all. In the name of Jesus Christ, amen.

# References
1. - All four of the Gospels—Matthew 21–28; Mark 11–16; Luke 19–24; and John 12–21—describe the last days of Jesus Christ’s ministry in mortality, which was divinely designed to make the blessings of salvation and exaltation available to all of God’s children. At times the authors differ in what they include but not in the Savior’s teachings and actions.
2. - See Matthew 21:10–11.
3. - John 12:13.
4. - Per Membership and Statistical Records, there are 102,592 members in Ghana.
5. - John 15:12.
6. - Every time I spoke with members, they would say to me, “Elder Rasband, our dear Apostle, I love you.” These people are so filled with the Spirit and the love of God that they share that love easily.
7. - Matthew 21:9.
8. - See Russell M. Nelson, “The Peace and Hope of Easter” (video), Apr. 2021, ChurchofJesusChrist.org/media; Isaiah 49:16.
9. - Doctrine and Covenants 122:8. In December 1838 the Prophet Joseph and a handful of other Church leaders were unjustly imprisoned in Liberty Jail. The conditions were dreadful. After months in wretched circumstances, he wrote to the members in March of 1839, including prayers where he had petitioned the Lord to have compassion on his situation and the “suffering saints.” He also shared the Lord’s response to those prayers as recorded in Doctrine and Covenants 121–23.
10. - Doctrine and Covenants 122:9. The Lord’s encouragement to Joseph Smith in Liberty Jail brought him comfort and spiritual understanding that adversity and trials can strengthen us, teach patience, and foster self-mastery. The Lord called for him to “hold on thy way,” which was the way of the Lord, enduring unjust treatment as had “the Son of [God, who] hath descended below them all. Art thou greater than he?” (Doctrine and Covenants 122:8).
11. - Doctrine and Covenants 122:9. The pledge that God “shall be with you” is a sure promise for those who hold fast to their faith and trust in the Lord.
12. - See Zechariah 9:9.
13. - Matthew 20:18–19. James E. Talmage writes in Jesus the Christ: “It is … an astounding fact that the Twelve failed to comprehend His meaning. … To them there was some dreadful incongruity, some dire inconsistency or inexplicable contradiction in the sayings of their beloved Master. They knew Him to be the Christ, the Son of the living God; and how could such a One be brought into subjection and be slain?” ([1916], 502–3).
14. - Joseph Smith made this declaration to the Female Relief Society of Nauvoo, April 28, 1842, as quoted in “History of Joseph Smith,” Deseret News, Sept. 19, 1855, 218. Referring to the twelfth chapter of 1 Corinthians, he clarified the third verse, “No man can say that Jesus is the Lord, but by the Holy Ghost,” revising it to say, “No man can know that Jesus is the Lord, but by the Holy Ghost.” (See The First Fifty Years of Relief Society: Key Documents in Latter-day Saint Women’s History [2016], 2.2, churchhistorianspress.org.)
15. - Jesus shared the Last Supper with His disciples (see Mark 14:12–18). The Twelve included Peter, Andrew, James, John, Matthew, Philip, Thomas, Bartholomew, James (son of Alphaeus), Judas Iscariot, Judas (brother of James), and Simon (see Luke 6:13–16).
16. - Jesus instituted the sacrament with His disciples at the Last Supper (see Matthew 26:26–29; Mark 14:22–25; Luke 22:19–20).
17. - The specific day/night in which Jesus instituted the sacrament in the “upper room” is actually disputed because of seeming discrepancies between Matthew, Mark, Luke, and John. Matthew, Mark, and Luke suggest that the Last Supper took place on “the first day of the feast of unleavened bread,” or the Passover meal (see Matthew 26:17; Mark 14:12; Luke 22:1, 7). John, however, suggests that Jesus was arrested before the Passover meal (see John 18:28), meaning that the Last Supper would have taken place one day earlier than the Passover meal. The Church’s curriculum materials and Latter-day Saint scholarship seem to agree that Jesus held the Last Supper with His disciples in the upper room on the evening before He was crucified. Christians who celebrate Holy Week recognize Thursday as the day of the Last Supper, Friday as the day of the Crucifixion, and Sunday as the day of Resurrection—according to the Gregorian calendar.
18. - John 14:18.
19. - John 14:27.
20. - Doctrine and Covenants 20:77.
21. - Moroni 10:5.
22. - The Bible Dictionary explains, hosanna means “save now.” The word is taken from Psalm 118:25. “The chanting of this psalm was connected at the Feast of the Tabernacles with the waving of palm branches; hence the use of the word by the multitudes at our Lord’s triumphal entry into Jerusalem” (Bible Dictionary, “Hosanna”). See Matthew 21:9, 15; Mark 11:9–10; John 12:13.
23. - Mark 15:14; Luke 23:21.
24. - The centerpiece of our Heavenly Father’s plan of salvation was an infinite atonement that would ensure immortality for all His children and exaltation for those worthy to receive that blessing. When the Father said, “Whom shall I send?” Jesus Christ stepped forward: “Here am I, send me” (Abraham 3:27). President Russell M. Nelson has taught: “[Jesus Christ’s] mission was the Atonement. That mission was uniquely His. Born of a mortal mother and an immortal Father, He was the only one who could voluntarily lay down His life and take it up again (see John 10:14–18). The glorious consequences of His Atonement were infinite and eternal. He took the sting out of death and made temporary the grief of the grave (see 1 Corinthians 15:54–55). His responsibility for the Atonement was known even before the Creation and the Fall. Not only was it to provide for the resurrection and immortality of all humankind, but it was also to enable us to be forgiven of our sins—upon conditions established by Him. Thus His Atonement opened the way by which we could be united with Him and with our families eternally” (“The Mission and Ministry of Jesus Christ,” Ensign, Apr. 2013, 34; Liahona, Apr. 2013, 20).
25. - Resurrection consists of reuniting the body and the spirit in an immortal state, the body and spirit being inseparable and no longer bound to maladies of mortality or death (see Alma 11:45; 40:23).
26. - Alma 5:26; see also Alma 5:14.
27. - The parable of the ten virgins is found in Matthew 25:1–12; Doctrine and Covenants 45:56–59. The surrounding chapters of Matthew 25 suggest that Jesus taught this parable during His last week, after entering Jerusalem in Matthew 21 and just before the Last Supper and His arrest in Matthew 26. In addition to the parable of the ten virgins given that last week, Jesus gave the parable of the fig tree (see Matthew 21:17–21; 24:32–33), parable of the two sons (see Matthew 21:28–32), and parable of the wicked husbandman (see Matthew 21:33–46).
28. - Matthew 25:1.
29. - Matthew 25:6.
30. - Doctrine and Covenants 45:57.
31. - Doctrine and Covenants 45:59.
32. - Doctrine and Covenants 45:59.
33. - Matthew 25:12. In the Sermon on the Mount, the Lord refers to those who presume to have “done many wonderful works,” saying, as suggested in the account of the five foolish virgins, “I know you not” (see Matthew 7:22–23).
34. - Just as water is critical to mortal life, Jesus Christ and His teachings (living water) are critical for eternal life (see Guide to the Scriptures, “Living Water,” scriptures.ChurchofJesusChrist.org; see also Isaiah 12:3; Jeremiah 2:13; John 4:6–15; 7:37; 1 Nephi 11:25; Doctrine and Covenants 10:66; 63:23).
35. - 3 Nephi 4:32.
36. - Revelation 7:9.