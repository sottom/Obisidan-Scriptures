President M. Russell Ballard
Acting President of the Quorum of the Twelve Apostles
04-2023
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2023/04/52ballard?lang=eng)

_What matters most is our relationships with Heavenly Father and His Beloved Son, our families, and our neighbors, and allowing the Spirit to guide us._

As we remember this weekend the Savior’s triumphal entry into Jerusalem shortly before His atoning sacrifice, I recall His words of hope and comfort: “I am the resurrection, and the life: he that believeth in me, though he were dead, yet shall he live.”1

I love Him. I believe Him. I testify that He is the Resurrection and the Life.

This testimony has comforted and strengthened me during the past four and a half years since my wife, Barbara, passed away. I miss her.

Often, I have been reflecting on our eternal marriage and our life together.

I previously have shared how I first met Barbara and how that experience taught me to use the skill of “following up” that I had learned on my mission. I had to follow up quickly with her after we first met because she was beautiful, popular, and had a very busy social calendar. I was smitten early because she was approachable and friendly. I admired her goodness. I felt that she and I belonged together. It seemed that simple in my mind.

Barbara and I dated, and our relationship began to grow, but she was uncertain that marriage to me was right for her.

It wasn’t enough for me to know; Barbara needed to know for herself. I knew if we spent time fasting and praying about the matter, Barbara could receive a confirmation from heaven.

We spent a weekend without dating so we could fast and pray individually to know for ourselves. Fortunately for me, she received the same confirmation that I did. The rest, as they say, is history.

When Barbara passed away, our children put on her headstone several lessons that Barbara wanted them to remember. One of those lessons is “what matters most is what lasts longest.”

Today I will share from my heart a few feelings and thoughts on what matters most.

First, a relationship with our Heavenly Father and His Son, the Lord Jesus Christ, is most important. This relationship matters most now and in eternity.

Second, family relationships are among those things that matter most.

Throughout my ministry, I have visited many individuals and families impacted by devastating natural disasters. Many were displaced, hungry, and frightened. They needed medical assistance, food, and shelter.

They also needed their families.

I recognize some may not have the blessings of a close family, so I include extended family, friends, and even ward families as “family.” These relationships are essential for emotional and physical health.

These relationships can also offer love, joy, happiness, and a sense of belonging.

Nurturing these important relationships is a choice. A choice to be part of a family requires commitment, love, patience, communication, and forgiveness.2 There may be times when we disagree with another person, but we can do so without being disagreeable. In courtship and marriage, we don’t fall in love or fall out of love as though we are objects being moved on a chessboard. We choose to love and sustain one another. We do the same in other family relationships and with friends who are like family to us.

The family proclamation states that “the divine plan of happiness enables family relationships to be perpetuated beyond the grave. Sacred ordinances and covenants available in holy temples make it possible for individuals to return to the presence of God and for families to be united eternally.”3

Another thing that matters most is following the promptings of the Spirit in our most important relationships and in our efforts to love our neighbors as ourselves, including in our private and public ministries. I learned this lesson early in my life while serving as a bishop.

Late one cold, snowy winter evening, I was leaving my bishop’s office when I had a strong impression to visit an elderly widow in the ward. I glanced at my watch—it was 10:00 p.m. I reasoned that it was too late to make such a visit. And besides, it was snowing. I decided to visit this dear sister first thing in the morning rather than disturbing her at such a late hour. I drove home and went to bed but tossed and turned throughout the night because the Spirit was stirring me.

Early the next morning, I drove straight to the widow’s home. Her daughter answered the door and tearfully said, “Oh, Bishop, thank you for coming. Mother passed away two hours ago”—I was devastated. I will never forget the feelings of my heart. I wept. Who more than this dear widow deserved to have her bishop hold her hand, comfort her, and perhaps give her a final blessing? I missed that opportunity because I reasoned away this strong prompting from the Spirit.4

Brothers and sisters, young men and young women, and Primary children, I testify that following the promptings of the Spirit is one of the things that matter most in all our relationships.

Finally, on this Palm Sunday weekend, I testify that being converted to the Lord, bearing testimony of Him, and serving Him are also among the things that matter most.

Faith in Jesus Christ is the foundation of our testimonies. A testimony is a witness or confirmation of eternal truth impressed upon individual hearts and souls through the Holy Ghost. A testimony of Jesus Christ, born of and strengthened by the Spirit, changes lives—it changes the way we think and how we live. A testimony turns us toward our Heavenly Father and His divine Son.

Alma taught:

“Behold, I testify unto you that I do know that these things whereof I have spoken are true. And how do ye suppose that I know of their surety?

“Behold, I say unto you they are made known unto me by the Holy Spirit of God. Behold, I have fasted and prayed many days that I might know these things of myself. And now I do know of myself that they are true; for the Lord God hath made them manifest unto me by his Holy Spirit.”5

Having a testimony alone is not enough. As our conversion to Jesus Christ grows, we naturally want to testify of Him—His goodness, love, and kindness.

Often in our testimony meetings on fast Sundays, we hear the phrases “I am thankful” and “I love” more than we hear the phrases “I know” and “I believe.”

I invite you to bear your testimony of Jesus Christ more often. Bear testimony of what you know and believe and what you feel, not just of what you are thankful for. Testify of your own experiences of coming to know and love the Savior, of living His teachings, and of His redemptive and enabling power in your life. As you bear testimony of what you know, believe, and feel, the Holy Ghost will confirm the truth to those who earnestly listen to your testimony. They will do so because they have watched you become a peaceful follower of Jesus Christ. They will see what it means to be His disciple. They will also feel something they may not have felt before. A pure testimony comes from a changed heart and can be carried by the power of the Holy Ghost into the hearts of others who are open to receive it.

Those who feel something as a result of your testimony may then ask the Lord in prayer to confirm the truth of your testimony. Then they can know for themselves.

Brothers and sisters, I testify and witness to you that I know that Jesus Christ is the Savior and Redeemer of the world. He lives. He is the resurrected Son of God, and this is His Church, led by His prophet and apostles. I pray that someday when I pass to the next world, I may do so with my testimony burning brightly.

In my ministry, I have learned what matters most is our relationships with Heavenly Father and His Beloved Son, our families, and our neighbors, and allowing the Spirit of the Lord to guide us in those relationships so we can testify of the things that matter most and last longest. In the name of Jesus Christ, amen.

# References
1. - John 11:25.
2. - See the articles “Family,” “Unity,” and “Love” in Gospel Topics in the Gospel Library (at ChurchofJesusChrist.org or on the mobile app) to read scriptures and talks from prophets, apostles, and other Church leaders on this topic.
3. - “The Family: A Proclamation to the World,” ChurchofJesusChrist.org.
4. - An account of this experience is in Susan Easton Black and Joseph Walker, Anxiously Engaged: A Biography of M. Russell Ballard (2021), 90–91.
5. - Alma 5:45–46.