President Russell M. Nelson
President of The Church of Jesus Christ of Latter-day Saints
04-2023
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2023/04/47nelson?lang=eng)

_You have your agency to choose contention or reconciliation. I urge you to choose to be a peacemaker, now and always._

My dear brothers and sisters, it is a joy to be with you. During these past six months, you have been constantly on my mind and in my prayers. I pray that the Holy Ghost will communicate what the Lord wants you to hear as I speak to you now.

During my surgical internship many years ago, I assisted a surgeon who was amputating a leg filled with highly infectious gangrene. The operation was difficult. Then, to add to the tension, one of the team performed a task poorly, and the surgeon erupted in anger. In the middle of his tantrum, he threw his scalpel loaded with germs. It landed in my forearm!

Everyone in the operating room—except the out-of-control surgeon—was horrified by this dangerous breach of surgical practice. Gratefully, I did not become infected. But this experience left a lasting impression on me. In that very hour, I promised myself that whatever happened in my operating room, I would never lose control of my emotions. I also vowed that day never to throw anything in anger—whether it be scalpels or words.

Even now, decades later, I find myself wondering if the contaminated scalpel that landed in my arm was any more toxic than the venomous contention that infects our civic dialogue and too many personal relationships today. Civility and decency seem to have disappeared during this era of polarization and passionate disagreements.

Vulgarity, faultfinding, and evil speaking of others are all too common. Too many pundits, politicians, entertainers, and other influencers throw insults constantly. I am greatly concerned that so many people seem to believe that it is completely acceptable to condemn, malign, and vilify anyone who does not agree with them. Many seem eager to damage another’s reputation with pathetic and pithy barbs!

Anger never persuades. Hostility builds no one. Contention never leads to inspired solutions. Regrettably, we sometimes see contentious behavior even within our own ranks. We hear of those who belittle their spouses and children, of those who use angry outbursts to control others, and of those who punish family members with the “silent treatment.” We hear of youth and children who bully and of employees who defame their colleagues.

My dear brothers and sisters, this should not be. As disciples of Jesus Christ, we are to be examples of how to interact with others—especially when we have differences of opinion. One of the easiest ways to identify a true follower of Jesus Christ is how compassionately that person treats other people.

The Savior made this clear in His sermons to followers in both hemispheres. “Blessed are the peacemakers,” He said.1 “Whosoever shall smite thee on thy right cheek, turn to him the other also.”2 And then, of course, He gave the admonition that challenges each of us: “Love your enemies, bless them that curse you, do good to them that hate you, and pray for them which despitefully use you, and persecute you.”3

Before His death, the Savior commanded His Twelve Apostles to love one another as He had loved them.4 And then He added, “By this shall all men know that ye are my disciples, if ye have love one to another.”5

The Savior’s message is clear: His true disciples build, lift, encourage, persuade, and inspire—no matter how difficult the situation. True disciples of Jesus Christ are peacemakers.6

Today is Palm Sunday. We are preparing to commemorate the most important and transcendent event ever recorded on earth, which is the Atonement and Resurrection of the Lord Jesus Christ. One of the best ways we can honor the Savior is to become a peacemaker.7

The Savior’s Atonement made it possible for us to overcome all evil—including contention. Make no mistake about it: contention is evil! Jesus Christ declared that those who have “the spirit of contention” are not of Him but are “of the devil, who is the father of contention, and [the devil] stirreth up the hearts of men to contend with anger, one with another.”8 Those who foster contention are taking a page out of Satan’s playbook, whether they realize it or not. “No man can serve two masters.”9 We cannot support Satan with our verbal assaults and then think that we can still serve God.

My dear brothers and sisters, how we treat each other really matters! How we speak to and about others at home, at church, at work, and online really matters. Today, I am asking us to interact with others in a higher, holier way. Please listen carefully. “If there is anything virtuous, lovely, or of good report or praiseworthy”10 that we can say about another person—whether to his face or behind her back—that should be our standard of communication.

If a couple in your ward gets divorced, or a young missionary returns home early, or a teenager doubts his testimony, they do not need your judgment. They need to experience the pure love of Jesus Christ reflected in your words and actions.

If a friend on social media has strong political or social views that violate everything you believe in, an angry, cutting retort by you will not help. Building bridges of understanding will require much more of you, but that is exactly what your friend needs.

Contention drives away the Spirit—every time. Contention reinforces the false notion that confrontation is the way to resolve differences; but it never is. Contention is a choice. Peacemaking is a choice. You have your agency to choose contention or reconciliation. I urge you to choose to be a peacemaker, now and always.11

Brothers and sisters, we can literally change the world—one person and one interaction at a time. How? By modeling how to manage honest differences of opinion with mutual respect and dignified dialogue.

Differences of opinion are part of life. I work every day with dedicated servants of the Lord who do not always see an issue the same way. They know I want to hear their ideas and honest feelings about everything we discuss—especially sensitive issues.

  ImageDallin H. Oaks and Henry B. Eyring

My two noble counselors, President Dallin H. Oaks and President Henry B. Eyring, are exemplary in the way they express their feelings—especially when they may differ. They do so with pure love for each other. Neither suggests that he knows best and therefore must rigorously defend his position. Neither evidences the need to compete with the other. Because each is filled with charity, “the pure love of Christ,”12 our deliberations can be guided by the Spirit of the Lord. How I love and honor these two great men!

Charity is the antidote to contention. Charity is the spiritual gift that helps us to cast off the natural man, who is selfish, defensive, prideful, and jealous. Charity is the principal characteristic of a true follower of Jesus Christ.13 Charity defines a peacemaker.

When we humble ourselves before God and pray with all the energy of our hearts, God will grant us charity.14

Those blessed with this supernal gift are long-suffering and kind. They do not envy others and are not caught up in their own importance. They are not easily provoked and do not think evil of others.15

Brothers and sisters, the pure love of Christ is the answer to the contention that ails us today. Charity propels us “to bear one another’s burdens”16 rather than heap burdens upon each other. The pure love of Christ allows us “to stand as witnesses of God at all times and in all things”17—especially in tense situations. Charity allows us to demonstrate how men and women of Christ speak and act—especially when under fire.

Now, I am not talking about “peace at any price.”18 I am talking about treating others in ways that are consistent with keeping the covenant you make when you partake of the sacrament. You covenant to always remember the Savior. In situations that are highly charged and filled with contention, I invite you to remember Jesus Christ. Pray to have the courage and wisdom to say or do what He would. As we follow the Prince of Peace, we will become His peacemakers.

At this point you may be thinking that this message would really help someone you know. Perhaps you are hoping that it will help him or her to be nicer to you. I hope it will! But I also hope that you will look deeply into your heart to see if there are shards of pride or jealousy that prevent you from becoming a peacemaker.19

If you are serious about helping to gather Israel and about building relationships that will last throughout the eternities, now is the time to lay aside bitterness. Now is the time to cease insisting that it is your way or no way. Now is the time to stop doing things that make others walk on eggshells for fear of upsetting you. Now is the time to bury your weapons of war.20 If your verbal arsenal is filled with insults and accusations, now is the time to put them away.21 You will arise as a spiritually strong man or woman of Christ.

The temple can help us in our quest. There we are endowed with God’s power, giving us the ability to overcome Satan, the instigator of all contention.22 Cast him out of your relationships! Note that we also rebuke the adversary every time we heal a misunderstanding or refuse to take offense. Instead, we can show the tender mercy that is characteristic of true disciples of Jesus Christ. Peacemakers thwart the adversary.

Let us as a people become a true light on the hill—a light that “cannot be hid.”23 Let us show that there is a peaceful, respectful way to resolve complex issues and an enlightened way to work out disagreements. As you demonstrate the charity that true followers of Jesus Christ manifest, the Lord will magnify your efforts beyond your loftiest imagination.

The gospel net is the largest net in the world. God has invited all to come unto Him, “black and white, bond and free, male and female.”24 There is room for everyone. However, there is no room for prejudice, condemnation, or contention of any kind.

My dear brothers and sisters, the best is yet to come for those who spend their lives building up others. Today I invite you to examine your discipleship within the context of the way you treat others. I bless you to make any adjustments that may be needed so that your behavior is ennobling, respectful, and representative of a true follower of Jesus Christ.

I bless you to replace belligerence with beseeching, animosity with understanding, and contention with peace.

God lives! Jesus is the Christ. He stands at the head of this Church. We are His servants. He will help us to become His peacemakers. I so testify in the sacred name of Jesus Christ, amen.

# References
1. - Matthew 5:9; see also 3 Nephi 12:9. The Savior’s promise to peacemakers is that they will “be called the children of God.”
2. - Matthew 5:39; see also 3 Nephi 12:39.
3. - Matthew 5:44; see also 3 Nephi 12:44.
4. - See John 13:34.
5. - John 13:35.
6. - See Moroni 7:3–4.
7. - See Mosiah 3:19.
8. - 3 Nephi 11:29. John the Revelator saw in vision that the devil would come to earth “having great wrath” (Revelation 12:12).
9. - 3 Nephi 13:24.
10. - Articles of Faith 1:13.
11. - See Moroni 7:3–4.
12. - Moroni 7:47.
13. - See Moroni 7:48.
14. - See Moroni 7:48.
15. - See Moroni 7:45; see also 1 Corinthians 13:4–5.
16. - Mosiah 18:8.
17. - Mosiah 18:9.
18. - Being a peacemaker does not require us to agree with the ideas or beliefs of others.
19. - See Helaman 3:33–36.
20. - See Alma 24:19; 25:14.
21. - See 1 Corinthians 13:11.
22. - See Doctrine and Covenants 109:22, 26.
23. - 3 Nephi 12:14.
24. - 2 Nephi 26:33.