Elder D. Todd Christofferson
Of the Quorum of the Twelve Apostles
04-2022
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2022/04/41christofferson?lang=eng)

_No matter what our mortal experience may entail, we can trust God and find joy in Him._

As Job in the Old Testament, in a time of suffering some might feel that God has abandoned them. Because we know that God has power to prevent or remove any affliction, we may be tempted to complain if He does not do it, perhaps questioning, “If God does not grant the help I pray for, how can I have faith in Him?” At one point in his intense trials, righteous Job said: 

“Then know that God has wronged me and drawn his net around me. 

“Though I cry, ‘I’ve been wronged!’ I get no response; though I call for help, there is no justice.”1

In His response to Job, God demands, “Wilt thou condemn me, that thou mayest be righteous?”2 Or in other words, “Will you even put me in the wrong? Will you condemn me that you may be justified?”3 Jehovah forcefully reminds Job of His omnipotence and omniscience, and Job in deepest humility admits he possesses nothing even close to the knowledge, power, and righteousness of God and cannot stand in judgment of the Almighty:

“I know that thou canst do every thing,” he said, “and that no thought can be withholden from thee.

“… I uttered that I understood not; things too wonderful for me, which I knew not. …

“Wherefore I abhor myself, and repent in dust and ashes.”4

In the end, Job was privileged to see the Lord, and “the Lord blessed the latter end of Job more than his beginning.”5

It truly is folly for us with our mortal myopia to presume to judge God, to think, for example, “I’m not happy, so God must be doing something wrong.” To us, His mortal children in a fallen world, who know so little of past, present, and future, He declares, “All things are present with me, for I know them all.”6 Jacob wisely cautions: “Seek not to counsel the Lord, but to take counsel from his hand. For behold, ye yourselves know that he counseleth in wisdom, and in justice, and in great mercy, over all his works.”7

Some misunderstand the promises of God to mean that obedience to Him yields specific outcomes on a fixed schedule. They might think, “If I diligently serve a full-time mission, God will bless me with a happy marriage and children” or “If I refrain from doing schoolwork on the Sabbath, God will bless me with good grades” or “If I pay tithing, God will bless me with that job I’ve been wanting.” If life doesn’t fall out precisely this way or according to an expected timetable, they may feel betrayed by God. But things are not so mechanical in the divine economy. We ought not to think of God’s plan as a cosmic vending machine where we (1) select a desired blessing, (2) insert the required sum of good works, and (3) the order is promptly delivered.8

God will indeed honor His covenants and promises to each of us. We need not worry about that.9 The atoning power of Jesus Christ—who descended below all things and then ascended on high10 and who possesses all power in heaven and in earth11—ensures that God can and will fulfill His promises. It is essential that we honor and obey His laws, but not every blessing predicated on obedience to law12 is shaped, designed, and timed according to our expectations. We do our best but must leave to Him the management of blessings, both temporal and spiritual.

President Brigham Young explained that his faith was not built on certain outcomes or blessings but on his witness of and relationship with Jesus Christ. He said: “My faith is not placed upon the Lord’s working upon the islands of the sea, upon his bringing the people here, … nor upon the favors he bestows upon this people or upon that people, neither upon whether we are blessed or not blessed, but my faith is placed upon the Lord Jesus Christ, and my knowledge I have received from him.”13

Our repentance and obedience, our service and sacrifices do matter. We want to be among those described by Ether as “always abounding in good works.”14 But it is not so much because of some tally kept in celestial account books. These things matter because they engage us in God’s work and are the means by which we collaborate with Him in our own transformation from natural man to saint.15 What our Heavenly Father offers us is Himself and His Son, a close and enduring relationship with Them through the grace and mediation of Jesus Christ, our Redeemer.

We are God’s children, set apart for immortality and eternal life. Our destiny is to be His heirs, “joint-heirs with Christ.”16 Our Father is willing to guide each of us along His covenant path with steps designed to our individual need and tailored to His plan for our ultimate happiness with Him. We can anticipate a growing trust and faith in the Father and the Son, an increasing sense of Their love, and the consistent comfort and guidance of the Holy Spirit.

Even so, this path cannot be easy for any of us. There is too much refining needed for it to be easy. Jesus said: 

“I am the true vine, and my Father is the husbandman. 

“Every branch in me that beareth not fruit [the Father] taketh away: and every branch that beareth fruit, he purgeth it, that it may bring forth more fruit.”17 

The process of God-directed purging and purifying will, of necessity, be wrenching and painful at times. Recalling Paul’s expression, we are “joint-heirs with Christ; if so be that we suffer with him, that we may be also glorified together.”18

So, in the midst of this refiner’s fire, rather than get angry with God, get close to God. Call upon the Father in the name of the Son. Walk with Them in the Spirit, day by day. Allow Them over time to manifest Their fidelity to you. Come truly to know Them and truly to know yourself.19 Let God prevail.20 The Savior reassures us:

“Listen to him who is the advocate with the Father, who is pleading your cause before him—

“Saying: Father, behold the sufferings and death of him who did no sin, in whom thou wast well pleased; behold the blood of thy Son which was shed, the blood of him whom thou gavest that thyself might be glorified;

“Wherefore, Father, spare these my brethren [and my sisters] that believe on my name, that they may come unto me and have everlasting life.”21

Consider some examples of faithful men and women who trusted God, confident that His promised blessings would be upon them in life or in death. Their faith was based not on what God did or did not do in a particular circumstance or moment in time but on knowing Him as their benevolent Father and Jesus Christ as their faithful Redeemer.

When Abraham was about to be sacrificed by the Egyptian priest of Elkenah, he cried out to God to save him, and God did.22 Abraham lived to become the father of the faithful through whose seed all the families of the earth would be blessed.23 Earlier, on this very same altar, that same priest of Elkenah had offered up three virgins who “because of their virtue … would not bow down to worship gods of wood or of stone.”24 They died there as martyrs.

Joseph of old, sold into slavery as a youth by his own brothers, in his anguish turned to God. Gradually, he rose to prominence in his master’s house in Egypt but then had all this progress ripped away because of the false accusations of Potiphar’s wife. Joseph could have thought, “So prison is what I get for keeping the law of chastity.” Instead he continued to turn to God and was prospered even in prison. Joseph suffered a further crushing disappointment when the prisoner he befriended, despite his promise to help Joseph, forgot all about him after being restored to his position in Pharaoh’s court. In due course, as you know, the Lord intervened to put Joseph in the highest position of trust and power next to Pharaoh, enabling Joseph to save the house of Israel. Surely Joseph could attest “that all things work together for good to them that love God.”25

Abinadi was intent on fulfilling his divine commission. “I finish my message,” he said, “and then it matters not [what happens to me], if it so be that I am saved.”26 He was not spared a martyr’s death, but assuredly he was saved in the kingdom of God, and his one precious convert, Alma, changed the course of Nephite history leading up to the coming of Christ.

Alma and Amulek were delivered from prison in Ammonihah in answer to their plea, and their persecutors were slain.27 Earlier, however, these same persecutors had cast believing women and their children into a raging fire. Alma, witnessing the horrific scene in agony, was constrained by the Spirit not to exercise the power of God to “save them from the flames,”28 that they might be received up to God in glory.29

The Prophet Joseph Smith languished in jail at Liberty, Missouri, powerless to help the Saints as they were pillaged and driven from their homes in the bitter cold of winter. “O God, where art thou?” Joseph cried. “How long shall thy hand be stayed?”30 In response, the Lord promised: “Thine adversity and thine afflictions shall be but a small moment; and then, if thou endure it well, God shall exalt thee on high. … Thou art not yet as Job.”31

In the end, Joseph could declare with Job, “Though [God] slay me, yet will I trust in him.”32

Elder Brook P. Hales related the story of Sister Patricia Parkinson, who was born with normal eyesight but by age 11 had gone blind. 

Elder Hales recounted: “I’ve known Pat for many years and recently told her that I admired the fact that she is always positive and happy. She responded, ‘Well, you have not been at home with me, have you? I have my moments. I’ve had rather severe bouts of depression, and I’ve cried a lot.’ However, she added, ‘From the time I started losing my sight, it was strange, but I knew that Heavenly Father and the Savior were with my family and me. … To those who ask me if I am angry because I am blind, I respond, ‘Who would I be angry with? Heavenly Father is in this with me; I am not alone. He is with me all the time.’”33

In the end, it is the blessing of a close and abiding relationship with the Father and the Son that we seek. It makes all the difference and is everlastingly worth the cost. We will testify with Paul “that the sufferings of this present [mortal] time are not worthy to be compared with the glory which shall be revealed in us.”34 I bear witness that no matter what our mortal experience may entail, we can trust God and find joy in Him. 

“Trust in the Lord with all thine heart; and lean not unto thine own understanding. 

“In all thy ways acknowledge him, and he shall direct thy paths.”35 

In the name of Jesus Christ, amen.

# References
1. - Job 19:6–7, New International Version Study Bible (2018).
2. - Job 40:8.
3. - Job 40:8, New Revised Standard Version.
4. - Job 42:2–3, 6.
5. - Job 42:12.
6. - Moses 1:6; see also Doctrine and Covenants 38:2.
7. - Jacob 4:10.
8. - King Benjamin taught that all God requires of us is to keep His commandments, “for which if ye do, he doth immediately bless you” (see Mosiah 2:22, 24). This does not mean, however, that all blessings come quickly. God’s blessings are immediate in the sense that His commandments carry their own reward. It also means that obedience to His commandments brings the blessing of living in His presence by having His Holy Spirit with us (see Alma 36:30).
9. - See Doctrine and Covenants 82:10.
10. - See Doctrine and Covenants 88:6.
11. - See Matthew 28:18.
12. - See Doctrine and Covenants 130:20–21.
13. - Brigham Young, “Instructions,” Deseret News, Nov. 21, 1855, 290; emphasis added.
14. - Ether 12:4.
15. - See Mosiah 3:19; see also Dallin H. Oaks, “The Challenge to Become,” Ensign, Nov. 2000, 32; Liahona, Jan. 2001, 40.
16. - Romans 8:17.
17. - John 15:1–2.
18. - Romans 8:17; emphasis added.
19. - See 1 Corinthians 13:12.
20. - See Russell M. Nelson, “Let God Prevail,” Ensign or Liahona, Nov. 2020, 92–95.
21. - Doctrine and Covenants 45:3–5; emphasis added.
22. - See Abraham 1:7, 15, 20.
23. - See Abraham 2:11.
24. - Abraham 1:11.
25. - Romans 8:28.
26. - Mosiah 13:9.
27. - See Alma 14:23–28.
28. - Alma 14:10.
29. - Alma 14:11: “The Spirit constraineth me that I must not stretch forth mine hand; for behold the Lord receiveth them up unto himself, in glory; and he doth suffer that they may do this thing, or that the people may do this thing unto them, according to the hardness of their hearts, that the judgments which he shall exercise upon them in his wrath may be just; and the blood of the innocent shall stand as a witness against them, yea, and cry mightily against them at the last day.”
30. - Doctrine and Covenants 121:1–2.
31. - Doctrine and Covenants 121:7–8, 10.
32. - Job 13:15.
33. - Brook P. Hales, “Answers to Prayer,” Ensign or Liahona, May 2019, 14.
34. - Romans 8:18.
35. - Proverbs 3:5–6.