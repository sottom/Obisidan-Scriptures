President Dallin H. Oaks
First Counselor in the First Presidency
04-2022
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2022/04/31oaks?lang=eng)

_We honor the daughters of God in this special session by concentrating on their concerns and those of their organizations._

My dear sisters, as we begin this unique women’s session of general conference, I am pleased to deliver this introductory message from the First Presidency.

Our Saturday sessions have a history of different purposes and different audiences. This evening we add to that history as we embark upon a new purpose and procedure for the foreseeable future. The gospel of Jesus Christ does not change. Gospel doctrine does not change. Our personal covenants do not change. But over the years, the meetings we hold to communicate our messages do change and very likely will continue to change over the years.

For now, this Saturday evening meeting is a session of general conference, not a session of any organization. Like all sessions of general conference, the planning, speakers, and music are designated by the First Presidency.

We have asked President Jean B. Bingham, General President of the Relief Society, to conduct this session. Future Saturday evening sessions may be conducted by one of the other General Officers of the Church, such as members of the General Presidencies of Relief Society, Young Women, and Primary, designated by the First Presidency.

Tonight this Saturday evening session of general conference will concentrate on the concerns of Latter-day Saint women. This will include the doctrine of The Church of Jesus Christ of Latter-day Saints, the policies of the Church that relate specially to women, and the general responsibilities and work of the organizations that include the women and girls of the Church. Though this session is deliberately broadcast to a worldwide audience like all sessions of general conference, the audience invited to be present in the Conference Center for this session is women and girls age 12 and older. We have included some priesthood leaders who preside over the participating organizations.

What we are initiating here is responsive to the communication resources currently available to the Lord’s worldwide Church leadership and membership. The doctrine of the gospel of Jesus Christ is for everyone, so that is our principal motive and extent of dissemination. We honor the daughters of God in this special session by concentrating on their concerns and those of their organizations.

We are grateful that broadcast technology now gives Church leaders the capacity to conduct detailed training by addressing specific audiences in the field. We also welcome the fact that current travel opportunities are increasing. That allows us to send Church leaders to conduct needed regular face-to-face leadership training in the field.

This is the work of the Lord Jesus Christ. We are His servants, directed by His Holy Spirit. We invoke the blessings of our Lord upon the leaders of these organizations and upon the faithful women and girls who serve the Lord in these organizations and in their individual lives. In the name of Jesus Christ, amen.

# References
