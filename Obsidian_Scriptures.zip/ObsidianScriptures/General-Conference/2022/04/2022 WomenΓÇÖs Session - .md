

04-2022
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2022/04/womens-session?lang=eng)

Record Your Impressions

        

      Create a Note

# References
