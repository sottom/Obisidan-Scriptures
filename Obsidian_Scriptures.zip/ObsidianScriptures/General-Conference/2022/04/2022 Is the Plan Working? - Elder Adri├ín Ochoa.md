Elder Adrián Ochoa
Of the Seventy
04-2022
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2022/04/27ochoa?lang=eng)

_I testify that the plan of happiness works. It was created by your Heavenly Father, who loves you._

Is the plan working?

Recently I had a conversation with a young adult who served a mission several years ago and was now involved in his professional work. In some ways, his life was going well. But his faith was in decline. He was sinking into a sea of doubt about the Savior and His Church. He explained that he wasn’t receiving the blessings he expected from the restored gospel. He didn’t feel that the plan of happiness was working in his life.

My message today is for all those who might have similar feelings. I speak to those who at one time “felt to sing the song of redeeming love” but do not “feel so now.”1

Our Heavenly Father has prepared a wonderful plan for our eternal happiness. But when life does not unfold the way we hoped, it might seem that the plan is not working.

Perhaps we feel the way Jesus’s disciples felt when they were in a ship “in the midst of the sea, tossed with waves: for the wind was contrary.”2

Then, very early in the morning:

“Jesus went unto them, walking on the sea.

“And when the disciples saw him walking on the sea, they were troubled, … and they cried out for fear.

“But straightway Jesus spake unto them, saying, Be of good cheer; it is I; be not afraid.

“And Peter answered him and said, Lord, if it be thou, bid me come unto thee on the water.

“And he said, Come. And when Peter was come down out of the ship, he walked on the water, to go to Jesus.

“But when he saw the wind boisterous, he was afraid; and beginning to sink, he cried, … Lord, save me.

“And immediately Jesus stretched forth his hand, and caught him, and said unto him, O thou of little faith, wherefore didst thou doubt?”3

Could I share with you three principles I learn from Peter? I pray that these principles might help anyone who feels that the plan of happiness isn’t working in their lives.

First, act in faith in Jesus Christ.

I am in awe of Peter’s faith. At Jesus’s simple invitation to “come,” he left his storm-tossed ship. He seemed to know that if Jesus Christ invited him to do something, he could do it.4 Peter trusted the Savior more than he trusted his boat. And that faith gave him power to act with courage during a stressful, frightening situation.

Peter’s faith reminds me of an experience that I heard from Elder José L. Alonso. Shortly after Elder Alonso’s son passed away, leaving a family with young children, Elder Alonso overheard the children talking.

“What are we going to do?” they asked.

A nine-year-old daughter answered, “Daddy is OK. He is preaching the gospel of Jesus Christ.”

Like Peter, this little girl saw beyond her challenges and trusted in Jesus Christ and His Atonement. Faith in the Savior brings peace and the strength to move forward.

If you look back on your life, I believe you will see that you have exercised faith many times. Joining the Church is an act of faith. Speaking with Heavenly Father in prayer is an act of faith. Reading the scriptures is an act of faith. Listening to my message in this general conference is an act of faith. As President Russell M. Nelson has said, “Do not minimize the faith you already have.”5

Another lesson I learn from Peter is this:

In times of trouble, turn to Jesus Christ right away.

As he walked toward the Savior, Peter was frightened by the wind and began to sink. But when Peter realized what was happening, he did not try to tread water on his own or swim back to the ship. Rather than let go of his faith in Christ, he held on more tightly, crying, “Lord, save me.”

“And immediately Jesus stretched forth his hand, and caught him.”6

All of us face boisterous winds that can shake our faith and cause us to sink. When this happens, please remember that Heavenly Father’s plan of happiness has another name—the plan of redemption. The plan was not for us to glide easily through life, never stumbling, never sinking, with a smile always on our face. Heavenly Father knew that we would need to be redeemed. This is why He prepared the plan of redemption.7 This is why He sent a Redeemer. When we struggle—for any reason—that does not mean the plan isn’t working. That is when we need the plan the most!

In those moments, follow the example of Peter. Turn to the Savior right away.

“Now is the time and the day of your salvation. … Do not procrastinate the day of your repentance.”8

No matter where we are and where we have been, repentance is the way forward. President Nelson has taught:

“Nothing is more liberating, more ennobling, or more crucial to our individual progression than is a regular, daily focus on repentance. …

“Whether you are diligently moving along the covenant path, have slipped or stepped from the covenant path, or can’t even see the path from where you are now, I plead with you to repent. Experience the strengthening power of daily repentance—of doing and being a little better each day.”9

Coming unto Christ means more than just thinking about Him or talking about Him or even loving Him. It means following Him. It means living the way He teaches us to live. And for all of us, that means repenting, without delay.

One of my daughters used to work at the missionary training center. She told me of an elder she taught who confided in her that he wasn’t sure the Book of Mormon was true. He had prayed and prayed for a spiritual witness, but he received no answer.

My daughter prayed to know what she should do to help this missionary. The impression she received was that the scriptures were not given only so we can read them and obtain a testimony; they were given also to teach us to keep the commandments of God. My daughter shared this thought with the missionary.

Later, she saw this missionary again, looking much happier. He told her that he had finally received a testimony that the Book of Mormon is true. He knew that this witness came because he was making a greater effort to do what the Book of Mormon teaches.

Let us follow Peter’s example of turning to the Savior during times of trouble. Follow Jesus Christ instead of relying on your own wisdom and strength. No matter how long you’ve been trying to tread water without Him, it’s never too late to reach out to Him. The plan works!

A third principle I learn from Peter and his experience is this:

Humble yourself before the Lord, and He will lift you up to greater things.

Peter had shown faith, both in walking on the water and in reaching out to the Savior when he needed help. Even so, the Savior saw in Peter the potential for so much more. “O thou of little faith,” He said, “wherefore didst thou doubt?”10

Peter could have resented this rebuke. But he accepted it humbly. He continued to seek greater faith in Jesus Christ. Through many additional faith-building experiences—some of them very, very difficult—Peter eventually became the rock-solid leader the Lord needed him to be. He accomplished great things in the Lord’s service.

What great things does the Lord want you to accomplish? In His Church and kingdom, there are many opportunities to serve and minister to others as the Savior did. He wants you to be part of His great work. Never will the plan of happiness become more real to you than when you are helping others to live it.

In building my own faith, these words of Alma were life-changing: “Blessed are they who humble themselves without being compelled to be humble.”11 Let us humbly put ourselves in a position where Jesus can lift us, lead us, and make the most of our abilities.12

I testify that the plan of happiness works. It was created by your Heavenly Father, who loves you. It works because Jesus Christ overcame sin and death through His Atonement. Come unto Him, follow Him, and “immediately shall the great plan of redemption be brought about unto you.”13 In the name of Jesus Christ, amen.

# References
1. - Alma 5:26.
2. - Matthew 14:24. There are many things about modern life that are contrary to the ways of a disciple of Jesus Christ. We live in the day that the Savior predicted, when “all things shall be in commotion; and surely, men’s hearts shall fail them” (Doctrine and Covenants 88:91; see also Doctrine and Covenants 45:26).
3. - Matthew 14:25–31.
4. - See 1 Nephi 3:7.
5. - Russell M. Nelson, “Christ Is Risen; Faith in Him Will Move Mountains,” Liahona, May 2021, 104.
6. - Matthew 14:30–31.
7. - Elder Lynn G. Robbins taught: “Repentance is God’s ever-accessible gift that allows and enables us to go from failure to failure without any loss of enthusiasm. Repentance isn’t His backup plan in the event we might fail. Repentance is His plan, knowing that we will. This is the gospel of repentance” (“Until Seventy Times Seven,” Ensign or Liahona, May 2018, 22).
8. - Alma 34:31, 33.
9. - Russell M. Nelson, “We Can Do Better and Be Better,” Ensign or Liahona, May 2019, 67.
10. - Matthew 14:31.
11. - Alma 32:16.
12. - The Lord has said, “No one can assist in this work except he shall be humble and full of love” (Doctrine and Covenants 12:8).
13. - Alma 34:31.