Elder Dieter F. Uchtdorf
Of the Quorum of the Twelve Apostles
04-2022
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2022/04/57uchtdorf?lang=eng)

_If we want the Savior to lift us heavenward, then our commitment to Him and His gospel can’t be casual or occasional._

An Offering unto Him



Just days before He gave His life for us, Jesus Christ was at the temple in Jerusalem, watching people make donations to the temple treasury. “Many that were rich cast in much,” but then, along came a poor widow, “and she threw in two mites.” It was such a small amount, it would hardly be worth recording.



And yet this seemingly inconsequential donation caught the Savior’s attention. In fact, it impressed Him so deeply that “he called unto him his disciples, and saith unto them, Verily I say unto you, That this poor widow hath cast more in, than all they which have cast into the treasury:

“For all they did cast in of their abundance; but she of her want did cast in all that she had, even all her living.”1

With this simple observation, the Savior taught us how offerings are measured in His kingdom—and it’s quite different from the way we usually measure things. To the Lord, the value of the donation was measured not by the effect it had on the treasury but by the effect it had on the heart of the donor.

In praising this faithful widow, the Savior gave us a standard to measure our discipleship in all of its many expressions. Jesus taught that our offering may be large or it may be small, but either way, it must be our heartfelt all.

This principle is echoed in the plea of the Book of Mormon prophet Amaleki: “Come unto Christ, who is the Holy One of Israel, and partake of his salvation, and the power of his redemption. Yea, come unto him, and offer your whole souls as an offering unto him.”2

But how is this possible? To many of us, such a standard of whole-souled commitment seems out of reach. We are already stretched so thin. How can we balance the many demands of life with our desires to offer our whole souls to the Lord?

Perhaps our challenge is that we think balance means dividing our time evenly among competing interests. Viewed in this way, our commitment to Jesus Christ would be one of many things we need to fit into our busy schedules. But perhaps there is another way to look at it.







Balance: Like Riding a Bicycle



My wife, Harriet, and I love to go bicycle riding together. It’s a wonderful way to get some exercise while also spending time together. While we’re riding, and I’m not huffing and puffing too much, we enjoy the beautiful world around us and even engage in a pleasant conversation. Rarely do we have to pay much attention to keeping our balance on our bicycles. We’ve been riding long enough that we don’t even think about that—it has become normal and natural for us.

But whenever I watch someone learning to ride a bike for the first time, I’m reminded that it’s not easy balancing yourself on those two narrow wheels. It takes time. It takes practice. It takes patience. It even takes falling down a time or two.

Most of all, those who succeed in balancing on a bicycle learn these important tips:

Don’t look at your feet.

Look ahead.

Keep your eyes on the road in front of you. Focus on your destination. And get pedaling. Staying balanced is all about moving forward.

Similar principles apply when it comes to finding balance in our lives as disciples of Jesus Christ. How to distribute your time and energy among your many important tasks will vary from person to person and from one season of life to another. But our common, overall objective is to follow the Way of our Master, Jesus Christ, and return to the presence of our beloved Father in Heaven. This objective must remain constant and consistent, whoever we are and whatever else is happening in our lives.3







Lift: Like Flying an Airplane



Now, for those who are avid bicyclists, comparing discipleship to riding a bike may be a helpful analogy. For those who are not, don’t worry. I have another analogy I’m sure every man, woman, and child will be able to relate to.

Discipleship, like most things in life, can also be compared to flying an airplane.

Have you ever stopped to think how amazing it is that a huge passenger jet can actually get off the ground and fly? What is it that keeps these flying machines soaring elegantly through the sky, crossing oceans and continents?

Put simply, an aircraft flies only when air is moving over its wings. That movement creates differences in air pressure that give the plane lift. And how do you get enough air moving over the wings to create lift? The answer is forward thrust.

The airplane gains no altitude sitting on the runway. Even on a windy day, enough lift isn’t created unless the airplane is moving forward, with enough thrust to counteract the forces holding it back.

Just as forward momentum keeps a bicycle balanced and upright, moving forward helps an aircraft overcome the pull of gravity and drag.

What does this mean for us as disciples of Jesus Christ? It means that if we want to find balance in life, and if we want the Savior to lift us heavenward, then our commitment to Him and His gospel can’t be casual or occasional. Like the widow at Jerusalem, we must offer Him our whole souls. Our offering may be small, but it must come from our heart and soul.

Being a disciple of Jesus Christ is not just one of many things we do. The Savior is the motivating power behind all that we do. He is not a rest stop in our journey. He is not a scenic byway or even a major landmark. He is “the way, the truth, and the life: no man cometh unto the Father, but by [Jesus Christ].”4 That is the Way and our ultimate destination.

Balance and lift come as we “press forward with a steadfastness in Christ, having a perfect brightness of hope, and a love of God and of all men.”5







Sacrifice and Consecration



And what about the many tasks and responsibilities that make our lives so busy? Spending time with loved ones, going to school or preparing for an occupation, earning a living, caring for family, serving in the community—where does it all fit in? The Savior reassures us:

“Your heavenly Father knoweth that ye have need of all these things.

“But seek ye first the kingdom of God and his righteousness, and all these things shall be added unto you.”6

But that doesn’t mean it’s easy.7 It requires both sacrifice and consecration.

It requires letting some things go and letting other things grow.

Sacrifice and consecration are two heavenly laws that we covenant to obey in the holy temple. These two laws are similar but not identical. To sacrifice means to give something up in favor of something more valuable. Anciently, God’s people sacrificed the firstlings of their flocks in honor of the coming Messiah. Throughout history, faithful Saints have sacrificed personal desires, comforts, and even their lives for the Savior.

We all have things, large and small, we need to sacrifice in order to follow Jesus Christ more completely.8 Our sacrifices show what we truly value. Sacrifices are sacred and honored by the Lord.9

Consecration is different from sacrifice in at least one important way. When we consecrate something, we don’t leave it to be consumed upon the altar. Rather, we put it to use in the Lord’s service. We dedicate it to Him and His holy purposes.10 We receive the talents that the Lord has given us and strive to increase them, manifold, to become even more helpful in building the Lord’s kingdom.11

Very few of us will ever be asked to sacrifice our lives for the Savior. But we are all invited to consecrate our lives to Him.







One Work, One Joy, One Purpose



As we seek to purify our lives and look unto Christ in every thought,12 everything else begins to align. Life no longer feels like a long list of separate efforts held in tenuous balance.

Over time, it all becomes one work.

One joy.

One holy purpose.

It is the work of loving and serving God. It is loving and serving God’s children.13

When we look at our lives and see a hundred things to do, we feel overwhelmed. When we see one thing—loving and serving God and His children, in a hundred different ways—then we can work on those things with joy.

This is how we offer our whole souls—by sacrificing anything that’s holding us back and consecrating the rest to the Lord and His purposes.







A Word of Encouragement and Testimony



My dear brothers and sisters and my dear friends, there will be times when you wish you could do more. Your loving Father in Heaven knows your heart. He knows that you can’t do everything your heart wants you to do. But you can love and serve God. You can do your best to keep His commandments. You can love and serve His children. And your efforts are purifying your heart and preparing you for a glorious future.

This is what the widow at the temple treasury seemed to understand. She surely knew that her offering would not change the fortunes of Israel, but it could change and bless her—because, though small, it was her all.

So, my dear friends and beloved fellow disciples of Jesus Christ, let us not be “weary in well-doing, for [we] are laying the foundation of a great work.” And out of our small things will proceed “that which is great.”14

I testify that this is true, as I also testify that Jesus Christ is our Master, our Redeemer, and our one and only Way back to our beloved Father in Heaven. In the sacred name of Jesus Christ, amen.

# References
1. - Mark 12:41–44.
2. - Omni 1:26.
3. - Our children and youth are invited to grow in a balanced way as they follow Jesus Christ, who as a young man “increased in wisdom and stature, and in favour with God and man” (Luke 2:52).
4. - John 14:6.
5. - 2 Nephi 31:20.
6. - 3 Nephi 13:32–33; see also Matthew 6:32–33. Joseph Smith Translation, Matthew 6:38 provides additional insight: “Seek not the things of this world but seek ye first to build up the kingdom of God, and to establish his righteousness” (in Matthew 6:33, footnote a).
7. - One example comes from our prophet, President Russell M. Nelson. When he was at the height of his professional career as a heart surgeon, he was called as stake president. Elders Spencer W. Kimball and LeGrand Richards extended the call. Recognizing the demands of his professional life, they said to him, “If you feel that you are too busy and shouldn’t accept the call, then that’s your privilege.” He answered that his decision about whether or not to serve when called was made long ago, when he and his wife made temple covenants with the Lord. “We made a commitment then,” he said, “to ‘seek … first the kingdom of God, and his righteousness’ [Matthew 6:33], feeling confident that everything else would be added unto us, as the Lord promised” (Russell Marion Nelson, From Heart to Heart: An Autobiography [1979], 114).
8. - President Nelson recently spoke of “the need for each of us to remove, with the Savior’s help, the old debris in our lives. … I invite you to pray,” he said, “to identify the debris you should remove from your life so you can become more worthy” (“Welcome Message,” Liahona, May 2021, 7).
9. - The scriptures say that, to God, our sacrifices are more sacred than our accomplishments (see Doctrine and Covenants 117:13). This may be one reason the Lord valued the widow’s mites more than the contribution of the wealthy. The former was a sacrifice, which has a purifying effect on the giver. The latter, while it may have accomplished more monetarily, was not a sacrifice, and it left the giver unchanged.
10. - Very few of us will ever be asked to sacrifice our lives for the Savior. But we are all invited to consecrate our lives to Him.
11. - See Matthew 25:14–30.
12. - See Doctrine and Covenants 6:36.
13. - In this way, we see in our lives a fulfillment of the prophecy of the Apostle Paul: “In the dispensation of the fulness of times [God will] gather together in one all things in Christ, both which are in heaven, and which are on earth: even in him” (Ephesians 1:10).
14. - Doctrine and Covenants 64:33.