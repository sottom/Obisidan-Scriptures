Barbara W. Winder
Relief Society General President
10-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/10/becoming-a-prepared-people?lang=eng)

“Make me an instrument of thy peace.” What meaningful words for the women of the Church!

Others, too, teach us of women. In Proverbs we read, “Who can find a virtuous woman? for her price is far above rubies.” (Prov. 31:10; Prov. 31:10–31.) The virtuous woman described in Proverbs was a woman who was prepared. She worked willingly, stretched out her hand to the poor, saw to the physical needs of her household, sought after knowledge. She had profound reverence for the Lord. While many of her tasks may appear to be temporal in nature, her blessings were eternal ones.

When we speak of preparedness, often our first thoughts center on temporal or physical preparations—food, clothing, shelter. While these preparations are important and necessary, they are not all-inclusive.

There is a crucial balance between the temporal and the spiritual aspects of this principle. The Lord has said, “All things unto me are spiritual, and not at any time have I given unto you a law which was temporal.” (D&C 29:34.)

The Lord taught us a very important lesson when he visited the home of his friends Mary and Martha. While Martha attended to the needs of her guest, Mary sat and listened to the words of the Savior.

We read: “But Martha was cumbered about much serving, and came to him, and said, Lord, dost thou not care that my sister hath left me to serve alone? Bid her therefore that she help me.

“And Jesus answered … , Martha, Martha, thou art careful and troubled about many things:

“But one thing is needful: and Mary hath chosen that good part, which shall not be taken away from her.” (Luke 10:40–42.)

In his counsel, “but one thing is needful,” could the Lord have been referring to one thing lacking in Martha’s preparation? Probably. There is need for balance. Our physical preparation—including a clean, orderly home—makes it possible for the Spirit to be present. Likewise, the Spirit of the Lord brings an atmosphere of peace and contentment to our orderly home.

One sister told of her preparation to receive a General Authority guest in her home for stake conference. Everything was to be perfect. Extensive cleaning and cooking were done. Her ten children were prepped as to what their roles should be. She worked hard! By the time he arrived she was exhausted and couldn’t enjoy his visit. Too late, she realized that spiritual preparation was “needful” also.

She stated, “It is because of our spiritual preparation that we can find answers to our everyday challenges. It is because of our spiritual preparation that we can find joy in enduring and overcoming our trials. It is because of our spiritual preparation that we can feel the greatest joy of all, a nearness and closeness to our Savior and Father in Heaven.”

How, then, do we prepare?

We prepare by developing a strong relationship with our Heavenly Father through prayer, scripture study, and obedience to the commandments; by knowing our own worth; and by sustaining the priesthood.

Qualities of spirituality do not come without effort. Like any other talent with which we are blessed, they must be constantly practiced. A famous pianist once said, “If I fail to practice for one day, I can tell the difference in my playing. If I fail to practice for two days, my family can tell the difference. If I fail for three days, the whole world can tell the difference.” This same principle applies to us in our quest for exaltation.

In applying the parable of the ten virgins to our lives, our modern prophets have explained that the oil of preparation is accumulated drop by drop through daily righteous living.

Consistently attending sacrament meetings adds oil to our lamps. So too will fasting, praying individually and as a family, visiting teaching, controlling our bodily appetites, teaching gospel principles, nourishing and nurturing, watching over one another, studying the scriptures, keeping the commandments. Each act of dedication and obedience is a drop of oil with which we can refuel our lamps. Keeping the commandments and following the words of the prophet may be the greatest preparation we can make for any eventuality to come.



A few years ago while we were serving in the mission field, a minister who was investigating the Church said, “I hear you talk about the benefit of a living prophet. What sort of pronouncements has he made lately?” We replied, “The prophet has taught us that we need to live frugally. We need to stay out of debt, fix up our homes, and plant gardens that we may enjoy the fruit of our labor.” The minister thought for a moment and then said, “That is not what I would have imagined a prophet to say, but as I consider it, what better advice could be given?”

Often the advice that is given by our prophets is so simple and practical that we overlook it and fail to heed it.

We are taught that we have great worth in the eyes of our Heavenly Father. The Primary children sing, “I am a child of God.” The Young Women recite their theme which begins, “We are daughters of our Heavenly Father, who loves us,” and the prophets have declared that virtuous women are more priceless than rubies.

Listen to this simple direction from our prophet to the young women of the Church, which applies to all of us: “Live up to your divine potential. Remember who you are and the divine heritage that is yours—you are literally the royal daughters of our Father in Heaven.” (Ensign, Nov. 1986, p. 85.)

“Don’t settle for less than what the Lord wants you to be.” (Ensign, Nov. 1986, p. 84.)

Unfortunately, many of us fail to recognize what the Lord wants us to be. A sister wrote to me recently, telling of some events that led her to realize how much her Heavenly Father loved her and had blessed her. She said:

“I have had very low self-esteem and have not felt ‘good enough’ to have a close relationship with [my Father in Heaven]. This has kept me self-centered and unable to serve as effectively as I could. During the last few months I have felt a yearning desire within me, an urgency, if you will, to draw nearer to my Father in Heaven. Lately I have felt his arm around me and his great love extending to me—a beautiful feeling of acceptance. With this have come many gifts: more patience, more self-control, [more understanding]. I know this is the Holy Ghost teaching me.

“I have learned when priorities are in order and I prepare personally each day with prayer, scripture study, and physical care, I am happier and a more profitable servant.”

We learn from this that we also prepare by serving, teaching, nurturing, and helping others prepare. As we work daily to attain righteousness and a spiritual way of life, we have a responsibility to elevate others, to help them realize their divine potential, and to be an instrument in the hands of God.

Yes, being a woman brings blessings and responsibilities. Often there are tasks which, when filled, are without visibility, acclaim, or attendant worldly power. Nonetheless they are vital to the progress of humankind. When we are diverted from our course, serious weaknesses may appear in our lives and in the lives of family members, as well as in society.

Because of “the subtle craftiness of men [who] lie in wait to deceive” (D&C 123:12), many, even of the very elect, are being deceived. How diligently, sisters, we must strive to reach out to those who “know not where to find [the truth” (D&C 123:12) and bring them home again unto the fold. No effort is too great, no endeavor too much.

Our preparation does not always proceed just as we had planned it. My own mother has shared with me some of her goals and aspirations. Often as she began a project, something would happen to change her course of action: a mother-in-law in her waning years needed a home and special care, a younger sister needed help to complete her schooling. There were those with whom she worked who also desperately needed help. She was always there to serve. She gave this service graciously, and though not all her own personal plans were accomplished, she looks back on her life and says that if she had it to do all over again, she wouldn’t change anything. Service to others brings that kind of satisfaction.

It is according to our natures, sisters, to have feelings of charity and benevolence. It isn’t always easy to put these feelings into action. But as women, we should pray for charitable desires and opportunities and then work to foster these godlike attributes.

I suppose that Emma Smith had more than her share of frustration and disappointment. Her life couldn’t have been easy as she suffered persecution along with her husband, the Prophet. It is reported that shortly before his martyrdom, Joseph sent a message to Emma in answer to her request for a blessing. He was not able to give her a blessing, but told her to write one, and when he saw her again he would sign it. I am impressed with the faith and the righteous intent revealed in her words:

“I desire the Spirit of God to know and understand myself. … I desire a fruitful, active mind, that I may be able to comprehend the designs of God, when revealed through His servants … I particularly desire wisdom to bring up all the children that are, or may be committed to my charge, in such a manner that they will be useful … in the Kingdom of God … I desire … that I may wear a cheerful countenance … and be a blessing to all. …

“I desire with all my heart to honor and respect my husband.” (Ms., Historical Department, The Church of Jesus Christ of Latter-day Saints.)

President Ezra Taft Benson has declared, “When we put God first, all other things fall into their proper place or drop out of our lives. Our love of the Lord will govern the claims for our affection, the demands on our time, the interests we pursue, and the order of our priorities.” (Ensign, May 1988, p. 4.)

We need to put God first and balance our spiritual and temporal preparations, that we might become virtuous women, righteous daughters, instruments in his hands to help prepare the way for his coming.

Sisters, “shall we not go on in so great a cause?” as we read in the Doctrine and Covenants. “Go forward and not backward. Courage … and on, on to the victory! Let your hearts rejoice, and be exceedingly glad.” (D&C 128:22.)

I pray, sisters, that we will rejoice and go on to victory as we prepare for the second coming of our Savior. I pray that we will not be led away by the subtle enticings of the world that sometimes come to us even from those near and dear to us—the enticings that say to us, “Seek for visibility; seek for power and influence; be sure your own needs are being met.” These are not the teachings of him whose coming we await. He says to us, rather, be the servant of all (see Mark 9:35; Matt. 20:26–27); “let your light so shine before men, that they may see your good works, and glorify your Father which is in heaven.” (Matt. 5:16.)

I pray that we will not be discouraged and not be led away, not be deceived—but “cheerfully do all things that lie in our power; and then may we stand still, with the utmost assurance, to see the salvation of God.” (D&C 123:17.)

I know our Father lives and that Jesus is the Christ. We are engaged in his work. I say these things in the name of Jesus Christ, amen.

# References
