President Thomas S. Monson
Second Counselor in the First Presidency
10-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/10/hallmarks-of-a-happy-home?lang=eng)

“Happiness is the object and design of our existence; and will be the end thereof, if we pursue the path that leads to it; and this path is virtue, uprightness, faithfulness, holiness, and keeping all the commandments of God.” (Joseph Smith, Teachings of the Prophet Joseph Smith, sel. by Joseph Fielding Smith, Salt Lake City: Deseret Book Co., 1938, pp. 255–56.)

This description of such a universal goal was provided by the Prophet Joseph Smith. It was relevant then. It is relevant now. With such a clear road map to follow, why then are there so many unhappy people? Frequently, frowns outnumber smiles and despair dampens joy. We live so far below the level of our divine possibilities. Some become confused by materialism, entangled by sin, and lost among the passing parade of humanity. Others cry out in the words of the convert of Philip of old: “How can I [find my way], except some man should guide me?” (Acts 8:31.)

Happiness does not consist of a glut of luxury, the world’s idea of a “good time.” Nor must we search for it in faraway places with strange-sounding names. Happiness is found at home.

All of us remember the home of our childhood. Interestingly, our thoughts do not dwell on whether the house was large or small, the neighborhood fashionable or downtrodden. Rather, we delight in the experiences we shared as a family. The home is the laboratory of our lives, and what we learn there largely determines what we do when we leave there.

Mrs. Margaret Thatcher, prime minister of Great Britain, expressed the profound philosophy: “The family is the building block of society. It is a nursery, a school, a hospital, a leisure centre, a place of refuge and a place of rest. It encompasses the whole of the society. It fashions our beliefs; it is the preparation for the rest of our life.” (London Times, 26 May 1988.)

“Home is where the heart is.” It does take “a heap o’ livin’” to make a house a home (Edgar A. Guest, “Home,” in The Family Book of Best-Loved Poems, ed. David L. George, Garden City, N.Y.: Doubleday, 1952, p. 151–52.) “Home, home, sweet, sweet home, Be it ever so humble, there’s no place like home.” (Hymns, 1948, no. 185.) We turn from the reverie of such pleasant recollections. We contemplate parents gone, family grown, childhood vanished. Slowly but surely we face the truth: We are responsible for the home we build. We must build wisely, for eternity is not a short voyage. There will be calm and wind, sunlight and shadows, joy and sorrow. But if we really try, our home can be a bit of heaven here on earth. The thoughts we think, the deeds we do, the lives we live influence not only the success of our earthly journey; they mark the way to our eternal goals.

Happy homes come in a variety of appearances. Some feature large families with father, mother, brothers, and sisters living together in a spirit of love. Others consist of a single parent with one or two children, while other homes have but one occupant. There are, however, identifying features which are to be found in a happy home, whatever the number or description of its family members. I refer to these as “Hallmarks of a Happy Home.” They consist of:





A pattern of prayer.





A library of learning.





A legacy of love.





A treasury of testimony.





“Prayer is the soul’s sincere desire, Uttered or unexpressed.” (Hymns, 1985, no. 145.) So universal is its application, so beneficial its result, that prayer qualifies as the number-one hallmark of a happy home. As parents listen to the prayer of a child, they too draw close to God. These little ones, who so recently have been with their Heavenly Father, have no inhibitions in expressing to Him their feelings, their wishes, their thanks.

Family prayer is the greatest deterrent to sin, and hence the most beneficent provider of joy and happiness. The old saying is yet true: “The family that prays together stays together.”

“It is not possible for a married couple to reach happiness with eyes fixed on different stars; … they must set up a single ideal and work toward [it]. … Cease cherishing impossible fancies of impossible futures. Take the best of [your] dreams and fit them to life as it comes every day.” (Temple Bailey, “The Bride Who Makes Her Dreams Come True,” in Ladies’ Home Journal, 1912.)

On October 7, my wife, Frances, and I will have been married forty years. Our marriage took place just to the east of us in the holy temple. He who performed the ceremony, Benjamin Bowring, counseled us: “May I offer you newlyweds a formula which will ensure that any disagreement you may have will last no longer than one day? Every night kneel by the side of your bed. One night, Brother Monson, you offer the prayer, aloud, on bended knee. The next night you, Sister Monson, offer the prayer, aloud, on bended knee. I can then assure you that any misunderstanding that develops during the day will vanish as you pray. You simply can’t pray together and retain any but the best of feelings toward one another.”

When I was called to the Council of the Twelve just twenty-five years ago this weekend, President McKay asked me concerning my family. I related to him this guiding formula of prayer and bore witness to its validity. He sat back in his large leather chair and, with a smile, responded, “The same formula that has worked for you has blessed the lives of my family during all the years of our marriage.”

Prayer is the passport to spiritual power.

A second hallmark of a happy home is discovered when home is a library of learning. An essential part of our learning library will be good books.





Books are keys to wisdom’s treasure;

Books are gates to lands of pleasure;

Books are paths that upward lead;

Books are friends. Come, let us read.





(Emilie Poulsson.)





Reading is one of the true pleasures of life. In our age of mass culture, when so much that we encounter is abridged, adapted, adulterated, shredded, and boiled down, it is mind-easing and mind-inspiring to sit down privately with a congenial book.

James A. Michener, prominent author, suggests, “A nation becomes what its young people read in their youth. Its ideals are fashioned then, its goals strongly determined.”

The Lord counseled, “Seek ye out of the best books words of wisdom; seek learning, even by study and also by faith.” (D&C 88:118.)

The standard works offer the library of learning of which I speak. We must be careful not to underestimate the capacity of children to read and to understand the word of God.

A few months ago we took our grandchildren on an escorted tour of the Church printing facilities. There, all of us saw the missionary edition of the Book of Mormon coming off the delivery line—printed, bound, and trimmed, ready for reading. I said to a young grandson, “The operator says that you can remove one copy of the Book of Mormon to be your very own. You select the copy, and it will then be yours.”

Removing one finished copy of the book, he clutched it to his breast and said with sincerity, “I love the Book of Mormon. This is my book.”

I really don’t remember other events of that day, but none of us who was there will ever forget the honest expression from the heart of a child.

As parents, we should remember that our lives may be the book from the family library which the children most treasure. Are our examples worthy of emulation? Do we live in such a way that a son or a daughter may say, “I want to follow my dad,” or “I want to be like my mother”? Unlike the book on the library shelf, the covers of which shield the contents, our lives cannot be closed. Parents, we truly are an open book.

A third hallmark of a happy home is a legacy of love.

As a small boy, I enjoyed visiting the home of my grandmother on Bueno Avenue here in Salt Lake City. Grandmother was always so happy to see us and to draw us close to her. Seated on her lap, we listened as she read to us.

Her youngest son and his wife now occupy that same home. I visited there recently. The fireplug on the curb seemed so small compared to its size when I climbed its lofty heights those long years ago. The friendly porch was the same, the quiet, peaceful atmosphere not altered. Hanging on the kitchen wall was a framed expression which my aunt had embroidered. It carried a world of practical application: “Choose your love; love your choice.” She who prepared that message is now in frail health. Her husband, Ray, cares for her constantly and is the epitome of faithful and enduring love. She reciprocates in her own way. They live the lesson they framed.

Seemingly little lessons of love are observed by children as they silently absorb the examples of their parents. My own father, a printer, worked long and hard practically every day of his life. I’m certain that on the Sabbath he would have enjoyed just being at home. Rather, he visited elderly family members and brought cheer into their lives.

One was his uncle, who was crippled by arthritis so severe that he could not walk or care for himself. On a Sunday afternoon Dad would say to me, “Come along, Tommy; let’s take Uncle Elias for a short drive.” Boarding the old 1928 Oldsmobile, we would proceed to Eighth West, where, at the home of Uncle Elias, I would wait in the car while Dad went inside. Soon he would emerge from the house, carrying in his arms like a china doll his crippled uncle. I then would open the door and watch how tenderly and with such affection my father would place Uncle Elias in the front seat so he would have a fine view while I occupied the rear seat.

The drive was brief and the conversation limited, but oh, what a legacy of love! Father never read to me from the Bible about the good Samaritan. Rather, he took me with him and Uncle Elias in that old 1928 Oldsmobile along the road to Jericho.

When our homes carry the legacy of love, we will not receive Jacob’s chastisement as recorded in the Book of Mormon: “Ye have broken the hearts of your tender wives, and lost the confidence of your children, because of your bad examples before them; and the sobbings of their hearts ascend up to God against you.” (Jacob 2:35.)

Let us not be discouraged by the many newspaper and television accounts of discord—and sometimes cruelty—between companions and assume that virtue has vanished and love’s lamp no longer glows. Two of my dearest friends now lie in poor health and helpless. They are not alone. Their faithful companions minister to them in tender love. My friend Pres, who rarely leaves the side of his wife, said of her, “Christine is weaker but still beautiful. I love her so.” What a noble tribute to fidelity, to love, to marriage!

Another, a wife named Gertrude, makes comfortable her husband, Mark, in his room. Everything is just as he would want the room to be. She reads to him. She chats with him about the family. She once said to me during this long vigil, “I love him more than ever.”

For a beautiful example of “love at home,” we need not look beyond the family of President and Sister Benson. My wife and I were privileged to attend the Bensons’ sixty-second wedding anniversary party just three weeks ago. Children, grandchildren, and great-grandchildren rejoiced as the President and his companion held hands and led the group in singing “Keep the Home Fires Burning,” “Love’s Old Sweet Song,” and “I Love You Truly.” The entire Church can well emulate the Bensons’ example of studying the scriptures, attending the temple, and enjoying life together.

These are pictures which portray a legacy of love as a hallmark of a happy home.

A fourth hallmark of a happy home is a treasury of testimony. “The first and foremost opportunity for teaching in the Church lies in the home,” observed President David O. McKay. “A true Mormon home is one in which if Christ should chance to enter, he would be pleased to linger and to rest.” (Gospel Ideals, Salt Lake City: Improvement Era, 1953, p. 169.)

What are we doing to ensure that our homes meet this description? It isn’t enough for parents alone to have strong testimonies. Children can ride only so long on the coattails of a parent’s conviction.

President Heber J. Grant declared: “It is our duty to teach our children in their youth. I may know that the gospel is true, and so may my wife; but I want to tell you that our children will not know that the gospel is true unless they study it and gain a testimony for themselves.”

A love for the Savior, a reverence for His name, and genuine respect one for another will provide a fertile seedbed for a testimony to grow.

Learning the gospel, bearing a testimony, leading a family are rarely if ever simple processes. Life’s journey is characterized by bumps in the road, swells in the sea—even the turbulence of our times.

Some years ago, while visiting the members and missionaries in Australia, I witnessed a sublime example depicting how a treasury of testimony can bless and sanctify a home. The mission president, Horace D. Ensign, and I were traveling the long distance from Sydney to Darwin, where I was to break ground for our first chapel in that city. En route we had a scheduled stop at a mining community named Mt. Isa. As we entered the small airport at Mt. Isa, a woman and her two children approached. She said, “I am Judith Louden, a member of the Church, and these are my two children. We thought you might be on this flight, so we have come to visit with you during your brief stopover.” She explained that her husband was not a member of the Church and that she and the children were indeed the only members in the entire area. We shared lessons and bore testimony.

Time passed. As we prepared to reboard, Sister Louden looked so forlorn, so alone. She pleaded, “You can’t go yet; I have so missed the Church.” Suddenly the loudspeaker announced a thirty-minute mechanical delay of our flight. Sister Louden whispered, “My prayer has just been answered.” She then asked how she might influence her husband to show an interest in the gospel. We counseled her to include him in their home Primary lesson each week and be to him a living testimony of the gospel. I mentioned we would send to her a subscription to The Children’s Friend and additional helps for her family teaching. We urged that she never give up on her husband.

We departed Mt. Isa, a city to which I have never returned. I shall, however, always hold dear in memory that sweet mother and those precious children extending a tear-filled expression and a fond wave of gratitude and good-bye.

Several years later, while speaking at a priesthood leadership meeting in Brisbane, Australia, I emphasized the significance of gospel scholarship in the home and the importance of living the gospel and being examples of the truth. I shared with the men assembled the account of Sister Louden and the impact her faith and determination had made on me. As I concluded, I said, “I suppose I’ll never know if Sister Louden’s husband ever joined the Church, but he couldn’t have found a better model to follow.”

One of the leaders raised his hand, then stood and declared, “Brother Monson, I am Richard Louden. The woman of whom you speak is my wife. The children [his voice quavered] are our children. We are a forever family now, thanks in part to the persistence and the patience of my dear wife. She did it all.” Not a word was spoken. The silence was broken only by sniffles and muffled sobs and marked by the sight of tears streaming from every eye.

My brothers and sisters, let us determine, whatever our circumstance, to make of our houses happy homes. Let us open wide the windows of our hearts, that each family member may feel welcome and “at home.” Let us open also the doors of our very souls, that the dear Christ may enter. Remember His promise: “Behold, I stand at the door, and knock: if any man hear my voice, and open the door, I will come in to him.” (Rev. 3:20.)

How welcome He will feel, how joyful will be our lives, when the “Hallmarks of a Happy Home” greet Him, even:





A pattern of prayer;





A library of learning;





A legacy of love;





A treasury of testimony.





That our loving Heavenly Father may bless all of us in our quest for such happy homes is my prayer, in the name of Jesus Christ, amen.

# References
