President Thomas S. Monson
Second Counselor in the First Presidency
10-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/10/goal-beyond-victory?lang=eng)

Years ago, many of us participated as players or observers in the all-Church basketball tournaments and later in the softball tournaments. The most coveted prize was not to be adjudged first-place winner, but rather to receive the sportsmanship award. The applause of the audience was louder and longer, the smiles broader and more universal. A goal beyond victory had been won.

Lately we have received at the Office of the First Presidency letters which tell of serious arguments on the sports floor or playing field, namecalling by parents, abuse of referees, and all that characterizes poor sportsmanship. We have room for improvement, brethren, and improve we must.

In the videotape produced by the Church and entitled The Church Sports Official, there is featured this truth from the First Presidency: “Church sports activities have a unique central purpose much higher than the development of physical prowess, or even victory itself. It is to strengthen faith, build integrity, and develop in each participant the attributes of his maker.”

Brethren, it is difficult to achieve this objective if winning overshadows participation. The recreation halls in our many buildings are constructed through the tithes of the members of the Church. It is only fair that all worthy young men and young women have an opportunity to play, to learn, to develop, and to achieve.

It is not our objective to produce clones of Larry Bird or Magic Johnson—or even John Wooden or Pat Riley. When you put a player in a suit, put him in the game. Basketball begins soon. Let our teams of young men and young women be counseled appropriately. And a word or two for the spectators and coaches would not be amiss.

If I might add a personal touch, I share with you an experience that embarrassed, a game that was lost, and a lesson in not taking ourselves too seriously.

First, in a basketball game when the outcome was in doubt, the coach sent me onto the playing floor right after the second half began. I took an in-bounds pass, dribbled the ball toward the key, and let the shot fly. Just as the ball left my fingertips, I realized why the opposing guards did not attempt to stop my drive: I was shooting for the wrong basket! I offered a silent prayer: “Please, Father, don’t let that ball go in.” The ball rimmed the hoop and fell out.

From the bleachers came the call: “We want Monson, we want Monson, we want Monson—out!” The coach obliged.

I never was a basketball star. What timing—to be a freshman at the University of Utah when All-Americans Arnie Ferrin and Vern Gardner dominated the boards.

I fared much better at fast-pitch softball. My most memorable experience in softball was a thirteen-inning game I pitched in Salt Lake City on a hot Memorial Day. The game was scheduled for just seven innings, but the tied score could not be broken. In the last of the thirteenth, with two men out and a runner on third, the batter hit a high pop fly to left field. The catch was certain, I thought. And yet the ball fell through the hands of the left fielder. For thirty-eight years I have teased my friend who dropped the ball. I have promised myself I will never do so again. I’m not even going to mention his name. After all, he, too, remembers. It was only a game.

On another occasion, while pitching a game at Pioneer Park, I was absolutely stunned to see that the other team had placed a one-armed batter at the plate. Now how does a pitcher deliver the pitch to such an opponent? I tossed a gentle lob over the plate. To my amazement, the batter knocked a single, right over the second baseman’s head. My temper flared. The next batter was a returned missionary from Mexico, Homer Proctor, six foot two and about 210 pounds. I pitched him fast, high, and inside. On the first pitch, he lifted the ball right out of the park for a home run. I shall ever remember the smile of that one-armed runner, Bernell Hales, as he passed second and third and gleefully streaked for home. I felt like crying, but I broke out laughing, as did each player on both sides. We had a wonderful time.

Brethren, let’s take the necessary steps to rekindle sportsmanship, to emphasize participation, and to strive for the development of a Christlike character in each individual.

Now, there are other phases of the Lord’s work in which all members can participate, in which the growth of character is assured and the promise of life eternal bestowed. One such endeavor is referred to as the welfare program. Actually, the language of King Benjamin from the book of Mosiah provides a perfect scriptural description, even a solemn charge to each of us:

“For the sake of retaining a remission of your sins from day to day, that ye may walk guiltless before God—I would that ye should impart of your substance to the poor, every man according to that which he hath, such as feeding the hungry, clothing the naked, visiting the sick and administering to their relief, both spiritually and temporally.” (Mosiah 4:26.)

President Marion G. Romney spoke concerning the funding of caring for the needy when he said: “It has been, and now is, the desire and the objective of the Church to obtain from fast offerings the necessary funds to meet the cash needs of the welfare program. … At the present time we are not meeting this objective. We can, we ought, and we must do better. If we will double our fast offerings, we shall increase our own prosperity, both spiritually and temporally. This the Lord has promised, and this has been the record.” (“Basics of Church Welfare,” talk given to the Priesthood Board, 6 Mar. 1974, p. 10.)

Are we generous in the payment of our fast offerings? That we should be so was taught by President Joseph F. Smith. He declared that it is incumbent upon every Latter-day Saint to give to his bishop on fast day an amount equivalent to the food that he and his family would consume for the day and, if possible, a liberal donation to be so reserved and donated to the poor. (See Improvement Era, Dec. 1902, p. 148.)

President Spencer W. Kimball suggested that, in our generosity, we go beyond a minimum amount. He urged that we “give, instead of the amount we saved by our two meals of fasting, perhaps much, much more—ten times more where we are in a position to do it.” (In Conference Report, Apr. 1974, p. 184.)

The generous response of the Latter-day Saints in times of crisis is legendary. Many will remember the emergency aid provided our needy Saints in Europe following World War II. President Ezra Taft Benson directed this effort.

More recently, this generosity helped to avert starvation in Africa. Irrigation projects, producing wells, and improved agricultural methods are all part of a dream come true. Similarly, at the time of the Teton Dam disaster in Idaho, the response of the members to the call of need was overwhelming.

Today, in lands far away and right here in Salt Lake City, there are those who suffer hunger, who know want and are acquainted with poverty. Ours is the opportunity and the sacred privilege to relieve this hunger, to meet this want, to eliminate this poverty.

The Lord provided the way when He declared, “And the storehouse shall be kept by the consecrations of the church; and widows and orphans shall be provided for, as also the poor.” (D&C 83:6.) Then the reminder, “But it must needs be done in mine own way.” (D&C 104:16.)

In the vicinity where I once lived and served, we operated a poultry project. Most of the time it was an efficiently operated project, supplying to the storehouse thousands of dozens of fresh eggs and hundreds of pounds of dressed poultry. On a few occasions, however, the experience of being volunteer city farmers provided not only blisters on the hands, but also frustration of heart and mind.

For instance, I shall ever remember the time we gathered together the Aaronic Priesthood young men to really give the project a spring cleaning treatment. Our enthusiastic and energetic throng assembled at the project and in a speedy fashion uprooted, gathered, and burned large quantities of weeds and debris. By the light of the glowing bonfires, we ate hot dogs and congratulated ourselves on a job well done. The project was now neat and tidy. However, there was just one disastrous problem: The noise and the fires had so disturbed the fragile and temperamental population of five thousand laying hens that most of them went into a sudden molt and ceased laying. Thereafter we tolerated a few weeds, that we might produce more eggs.



No member of the Church who has canned peas, topped beets, hauled hay, or watered corn in such a cause ever forgets or regrets the experience of helping provide for those in need.

Sharing with others that which we have is not new to our generation. We need but to turn to the account found in 1 Kings to appreciate anew the principle that when we follow the counsel of the Lord, when we care for those in need, the outcome benefits all. There we read that a most severe drought had gripped the land. Famine followed. Elijah the prophet received from the Lord what to him must have been an amazing instruction: “Get thee to Zarephath: … behold, I have commanded a widow woman there to sustain thee.” (1 Kgs. 17:9.) When he had found the widow, Elijah declared: “Fetch me, I pray thee, a little water in a vessel, that I may drink.

“And as she was going to fetch it, he called to her, and said, Bring me, I pray thee, a morsel of bread in thine hand.” (1 Kgs. 17:10–11.)

Her response described her pathetic situation as she explained that she was preparing a final and scanty meal for her son and for herself, and then they would die. (See 1 Kgs. 17:12.)

How implausible to her must have been Elijah’s response:

“Fear not; go and do as thou hast said: but make me thereof a little cake first, and bring it unto me, and after make for thee and for thy son.

“For thus saith the Lord God of Israel, The barrel of meal shall not waste, neither shall the cruse of oil fail, until the day that the Lord sendeth rain upon the earth.

“And she went and did according to the saying of Elijah: and she, and he, and her house, did eat many days.

“And the barrel of meal wasted not, neither did the cruse of oil fail.” (1 Kgs. 17:13–16.) This is the faith that has ever motivated and inspired the welfare plan of the Lord.

Industry, thrift, self-reliance continue as guiding principles of this effort. As a people, we should avoid unreasonable debt. In a message which Elder Ezra Taft Benson delivered at a general conference more than thirty years ago, he instructed: “In the book of Kings we read about a woman who came weeping to … the prophet [of the Lord]. Her husband had died, and she owed a debt that she could not pay; and the creditor was on his way to take her two sons and sell them as slaves.

“By a miracle, [the prophet] enabled her to acquire a goodly supply of oil. And he said to her:

“‘Go, sell the oil, and pay thy debt, and live.’” (In Conference Report, Apr. 1957, p. 53.)

“Pay thy debt, and live.” (2 Kgs. 4:7.) What wise counsel for us today! Remember, the wisdom of God may appear as foolishness to men, but the greatest single lesson we can learn in mortality is that when God speaks and a man obeys, that man will always be right.

We should remember that the best storehouse system would be for every family to have a year’s supply of needed food, clothing, and, where possible, the other necessities of life. In the early Church, Paul wrote to Timothy, “If any provide not for his own, and specially for those of his own house, he hath denied the faith, and is worse than an infidel.” (1 Tim. 5:8.)

It is our sacred duty to care for our families. Often we see what might be called “parent neglect.” Too frequently the emotional, social, and, in some instances, even the material essentials of life are not provided by children to their aged parents. This is displeasing to the Lord.

The Lord’s storehouse includes the time, talents, skills, compassion, consecrated material, and financial means of faithful Church members. These resources are available to the bishop in assisting those in need. Our bishops have the responsibility to learn how to use properly these resources.

May I suggest in summary form five basic guidelines:





A bishop is to seek out the poor, as the Lord has commanded, and administer to their needs.





In caring for the needy, a bishop exercises discernment, sound judgment, balance, and compassion. Church resources represent a sacred trust.





Those receiving welfare assistance are to work to the extent of their ability for that which is received.





The assistance given by the bishop is temporary, rather than ongoing.





The bishop assists with basic life-sustaining goods and services. He sustains lives rather than life-styles.





Let me illustrate with a sacred experience which brought these guidelines together in blessing the lives of those in need.

While serving as a bishop, one cold winter day I visited an elderly couple who lived in a two-room duplex. The modest home was heated by a small coal-burning Heatrola. As I approached the home, I met the 82-year-old husband, his aged body bent in the driving snow as he gathered a few pieces of wet coal from his exposed supply of fuel. I helped him with his burden but made a solemn resolve to do more.

I prayed and pondered, seeking a solution. Step by step the inspiration came. In the ward was an unemployed carpenter. He had no fuel for his furnace but was too proud to receive the stoker slack he needed to keep his house warm. I suggested to the carpenter a way he could work for the help he received. Would he build a coal shed for a couple in need? “Of course,” he replied.

Now where were we to obtain the materials? I approached the proprietors of a local lumberyard from whom we frequently purchased products. I remember saying to the men, “How would the two of you like to paint a bright spot on your souls this winter day?” Not knowing exactly what I meant, they agreed readily. They were invited to donate the lumber and hardware for the coal shed.

Within days the project was completed. I was invited to inspect the outcome. The coal shed was simply beautiful in its sleek covering of battleship-gray paint. The carpenter, who was a high priest, testified that he had actually felt inspired as he labored on this modest shed.

My older friend, with obvious appreciation, stroked the wall of the sturdy structure. He pointed out to me the wide door, the shiny hinges, and then opened to my view the supply of dry coal which filled the shed. In a voice filled with emotion, he said in words I shall ever treasure, “Bishop, take a look at the finest coal shed a man ever had.” Its beauty was only surpassed by the pride in the builder’s heart. And the elderly recipient labored each day at the ward chapel, dusting the benches, vacuuming the carpet runners, arranging the hymnbooks. He, too, worked for that which he had received.

Once again, the welfare plan of the Lord had blessed the lives of His children.

May our Heavenly Father guide the priesthood of this church, that we may be obedient to the revelation of the Lord to the Prophet Joseph in which we are charged to “remember in all things the poor and the needy, the sick and the afflicted, for he that doeth not these things, the same is not my disciple.” (D&C 52:40.)

We will qualify as His disciples when we hear and heed the counsel from Isaiah describing the true fast, the spirit and the promise of the welfare effort:

“Is it not to deal thy bread to the hungry, and that thou bring the poor that are cast out to thy house? when thou seest the naked, that thou cover him; and that thou hide not thyself from thine own flesh?

“Then shall thy light break forth as the morning, and thine health shall spring forth speedily: and thy righteousness shall go before thee; the glory of the Lord shall be thy rereward.

“Then shalt thou call, and the Lord shall answer; thou shalt cry, and he shall say, Here I am. …

“And the Lord shall guide thee continually, and satisfy thy soul in drought, … and thou shalt be like a watered garden, and like a spring of water, whose waters fail not.” (Isa. 58:7–9, 11.)

May this be our blessing is my prayer, in the name of Jesus Christ, amen.

# References
