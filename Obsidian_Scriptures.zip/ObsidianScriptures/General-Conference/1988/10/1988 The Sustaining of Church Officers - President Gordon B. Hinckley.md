President Gordon B. Hinckley
First Counselor in the First Presidency
10-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/10/the-sustaining-of-church-officers?lang=eng)

My brothers and sisters, as requested by President Benson, I shall now present to you the General Authorities and general officers of the Church for your sustaining vote.

It is proposed that we sustain President Ezra Taft Benson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Gordon B. Hinckley as First Counselor in the First Presidency; and Thomas S. Monson as Second Counselor in the First Presidency.

Those in favor may manifest it. Those opposed may manifest it.

We pay tribute to President Marion G. Romney, who passed away on May 20, 1988. Following President Romney’s death, President Howard W. Hunter was called and set apart as the President of the Council of the Twelve Apostles.

It is therefore proposed that we sustain President Hunter as President of the Council of the Twelve Apostles and the following as members of that Council: Howard W. Hunter, Boyd K. Packer, Marvin J. Ashton, L. Tom Perry, David B. Haight, James E. Faust, Neal A. Maxwell, Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, Joseph B. Wirthlin, and Richard G. Scott. Those in favor, please manifest it. Any opposed may so manifest it.

It is proposed that we sustain the Counselors in the First Presidency and the Twelve Apostles as prophets, seers, and revelators.

All in favor, please manifest it. Any who may feel otherwise may so indicate.

In view of Elder Scott’s call as a member of the Council of the Twelve, we release him as a member of the Presidency of the First Quorum of the Seventy.

It is proposed that we sustain Elder J. Richard Clarke as a member of the Presidency of the First Quorum of the Seventy. Those in favor may manifest it. Any opposed may so indicate.

It is also proposed that we sustain Monte J. Brough; Albert Choules, Jr.; Lloyd P. George; and Gerald E. Melchin as additional members of the First Quorum of the Seventy to serve for a period of five years and that we sustain all other General Authorities and general officers of the Church as presently constituted. Those in favor please manifest it. Any opposed may so manifest it.

President Benson, it appears that the voting has been unanimous in the affirmative. We invite the newly sustained member of the Twelve and members of the Seventy to take their places on the stand.

# References
