President Gordon B. Hinckley
First Counselor in the First Presidency
10-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/10/to-the-bishops-of-the-church?lang=eng)

We have just listened to President Thomas S. Monson, Second Counselor in the First Presidency. President Benson, who gave a wonderful message this morning in opening the conference, has indicated that he will not speak this evening. We are honored with his presence and express to him our great love and loyalty as brethren in the priesthood. He has asked that I speak to you at this time.

My beloved brethren of the priesthood, I look into the faces of you many thousands who are assembled here in the Tabernacle on Temple Square in Salt Lake City. This magnificent old building is filled to capacity. Then I realize that there are tens of thousands of others like you who are meeting in various church halls across the continent and in other areas of the world. I sense the great strength that can come of our unity. There is little we cannot accomplish if we will go forward with united hearts to do so.

I sense the strength of the homes where you brethren preside as worthy husbands and fathers, and where you boys live as sons blessed with the Aaronic Priesthood. I am grateful for your faith and prayers, for your loyalty and love, for your steadfastness and devotion. You become a great witness for the truth and validity of this work. There is nothing like it in all the earth—hundreds of thousands of men who speak in different tongues, but all of whom are ordained to the priesthood of God with authority to speak in His sacred name.

I remember when President J. Reuben Clark, Jr., as a counselor in the First Presidency, would stand at this pulpit and plead for unity among the priesthood. I think he was not asking that we give up our individual personalities and become as robots cast from a single mold. I am confident he was not asking that we cease to think, to meditate, to ponder as individuals. I think he was telling us that if we are to assist in moving forward the work of God, we must carry in our hearts a united conviction concerning the great basic foundation stones of our faith, including the truth and validity of the First Vision as the record of this singular event is found in the history of Joseph Smith; of the truth and validity of the Book of Mormon as a voice speaking from the dust in testimony of Jesus the Christ, an ancient record written by inspired prophets and brought forth in this the dispensation of the fulness of times by the gift and power of God; of the reality and power of the priesthood which was restored under the hands of those who held it anciently—John the Baptist in the case of the Aaronic Priesthood, and Peter, James, and John in the case of the Melchizedek Priesthood. If we are to assist in moving forward the work of God, we must carry in our hearts a united conviction that the ordinances and covenants of this work are eternal and everlasting in their consequences; that this kingdom was established in the earth through the instrumentality of the Prophet Joseph Smith and that every man who has succeeded him in the office of President has been and is a prophet of the living God; and that there is incumbent upon each of us an obligation to live and teach the gospel as interpreted and taught by the prophet of our day. If we will be united in these basic and fundamental elements, this work will continue to grow in power and strength to touch for good the whole world. Of that I am satisfied and bear solemn testimony.

Now, this evening I desire to talk with you concerning the bishops of the Church, many of whom are present.

A young man said to me one day, “Do you belong to a ward and have a bishop?” I replied, “Of course I do.” He asked further, “Do you attend tithing settlement with your local ward bishop?” I replied that I do, that I, even though serving as a member of the Presidency of the Church, have an accountability to my local ward bishop just as every other man and woman in this church is accountable either to a bishop or to a branch president.

He was somewhat amazed. I was surprised to think that he would even raise such questions. I thought of the genius of the Lord’s work and the wisdom of the organization of His church. I have heard President Benson speak with appreciation for his bishop. I feel a kinship with my bishop. I hope that each of you feels similarly.

We have more than eleven thousand bishops in the Church. Every one is a man who has been called by the spirit of prophecy and revelation and set apart and ordained by the laying on of hands. Every one of them holds the keys of the presidency of his ward. Each is a high priest, the presiding high priest of his ward. Each carries tremendous responsibilities of stewardship. Each stands as a father to his people.

None receives money for his service. No ward bishop is compensated by the Church for his work as a bishop.

The requirements of a bishop today are as they were in the days of Paul, who wrote to Timothy:

“A bishop then must be blameless, the husband of one wife, vigilant, sober, of good behaviour, given to hospitality, apt to teach;

“Not given to wine, no striker [that is, not a bully or a violent person], … not a brawler, not covetous;

“One that ruleth well his own house, having his children in subjection with all gravity;

“(For if a man know not how to rule his own house, how shall he take care of the church of God?)

“Not a novice, lest being lifted up with pride he fall into the condemnation of the devil.” (1 Tim. 3:2–6.)

In his letter to Titus, Paul adds that “a bishop must be blameless, as the steward of God; …

“Holding fast the faithful word as he hath been taught, that he may be able by sound doctrine both to exhort and to convince the gainsayers.” (Titus 1:7, 9.)

Those words aptly describe a bishop today in The Church of Jesus Christ of Latter-day Saints.

I saw all of those elements in the life of the bishop of the ward in which I grew up. He served for a quarter of a century. The ward over which he presided had more than 1,100 members, but he seemed to know and love us all. He was our friend, our counselor, our presiding officer, our confidante, our teacher. He knew us boys by our first names and so addressed us. We respectfully addressed him as “Bishop.” He was no martinet who ruled with a heavy hand. He could laugh with us. He could sympathize with us. He understood us, and we knew it. We knew also that he loved us.

Since then I have had a number of bishops. They have been men who have come from different backgrounds, varied in their natures and personalities, but every one has been a wonderful man, dedicated to his work and to the people of his ward.

Let me now speak directly to the thousands of bishops who are in attendance tonight. Let me say first that I love you for your integrity and goodness. You must be men of integrity. You must stand as examples to the congregations over which you preside. You must stand on higher ground, so that you can lift others. You must be absolutely honest for you handle the funds of the Lord, the tithes of the people, the offerings that come of their fasting, and the contributions which they make from their own strained resources. How great is your trust as the keepers of the purse of the Lord!

Your goodness must be as an ensign to your people. Your morals must be impeccable. The wiles of the adversary may be held before you because he knows that if he can destroy you, he can injure an entire ward. You must be wise with inspired wisdom in all of your relationships lest someone read into your observed actions some taint of moral sin. You cannot succumb to the temptation to read pornographic literature, to see pornographic films, even in the secrecy of your own chamber to view pornographic videotapes. Your moral strength must be such that if ever you are called upon to sit in judgment on the questionable morals of others, you may do so without personal compromise or embarrassment.

You cannot use your office as bishop to further your own business interests lest through some ensuing financial mishap accusation be placed against you by those who succumbed to your persuasiveness.

You cannot compromise your qualifications to sit as a common judge in Israel. It is a fearsome and awesome responsibility to stand as a judge of the people. You must be their judge in some instances as to worthiness to hold membership in the Church, worthiness to enter the house of the Lord, worthiness to be baptized, worthiness to receive the priesthood, worthiness to teach and to serve as officers in the organizations. You must be the judge of their eligibility in times of distress to receive help from the fast offerings of the people and commodities from the storehouse of the Lord. None for whom you are responsible must go hungry or without clothing or shelter though they be reluctant to ask. You must know something of the circumstances of all of the flock over whom you preside.

You must be their counselor, their comforter, their anchor and strength in times of sorrow and distress. You must be strong with that strength which comes from the Lord. You must be wise with that wisdom which comes from the Lord. Your door must be open to hear their cries and your back strong to carry their burdens, your heart sensitive to judge their needs, your godly love broad enough and strong enough to encompass even the wrongdoer and the critic. You must be a man of patience, willing to listen though it takes hours to do so. You are the only one to whom some can turn. You must be there when every other source has failed. Permit me to read you a few lines from a letter sent to a bishop.

“Dear Bishop:

“It has been almost two years since I desperately called you asking for help. At that time I was ready to kill myself. I had no one else to turn to—no money, no job, no friends. My house had been taken, and I had no place to live. The Church was my last hope.

“As you know, I had left the Church at the age of seventeen and had broken just about every rule and commandment that there was in my search for happiness and fulfillment. Instead of happiness, my life was filled with misery, anguish, and despair. There was no hope or future for me. I even pleaded with God to let me die, to take me out of my misery. Not even he wanted me. I felt that he had rejected me, too.

“That’s when I turned to you and the Church. …

“You listened with understanding, you counseled, you guided, you helped.

“I began to grow and develop in understanding and knowledge of the gospel. I found that I had to make certain basic changes in my life that were terribly difficult, but that within me I had the worth and strength to do so.

“I learned that as I lived the gospel and repented, I had no more fear. I was filled with an inner peace. The clouds of anguish and despair were gone. Because of the Atonement, my weaknesses and sins were forgiven through Jesus Christ and His love for me.

“He has blessed and strengthened me. He has opened pathways for me, given me direction, and kept me from harm. I have found that as I overcame each obstacle, my business began to grow, enabling my family to benefit and making me feel as though I had accomplished something.

“Bishop, you have given me understanding and support through these past two years. I never would have reached this point if not for your love and patience. Thank you for being what you are as the servant of the Lord to help me, his wandering child.”

You stand as a watchman on the tower of the ward over which you preside. There are many teachers in that ward. But you must be the chief teacher among them. You must see that there is no false doctrine creeping in among the people. You must see that they grow in faith and testimony, in integrity and righteousness and a sense of service. You must see that their love for the Lord strengthens and manifests itself in greater love for one another.

You must be their confessor, privy to their deepest secrets, holding absolutely inviolate the confidences placed in you. Yours is a privileged communication that must be guarded and respected against all intruders. There may be temptations to tell. You cannot succumb.

You as an individual preside over the Aaronic Priesthood of the ward. You are their leader, their teacher, their example, whether you wish to be such or not. You are the presiding high priest, the father to the ward family, to be called upon as arbiter in disagreements, as defender of the accused.

You preside in meetings where the doctrine is taught. You are accountable for the spiritual nature of those meetings and for the administration of the sacrament to the members, that all may be reminded of sacred covenants and obligations incumbent upon those who have taken upon them the name of the Lord.

You must stand as the strong friend of the widow and the orphan, the weak and the beleaguered, the attacked and the helpless.

The sound of your trumpet must be certain and unequivocal. In your ward you stand as the head of the army of the Lord, leading them on to victory in the conquest against sin, indifference, and apostasy.



I know that the work is hard at times. There are never enough hours to get it done. The calls are numerous and frequent. You have other things to do. That is true. You must not rob your employer of the time and energy that are rightfully his. You must not rob your family of time which belongs to them. But as most of you have come to know, as you seek for divine guidance, you are blessed with wisdom beyond your own and strength and capacity you did not know you had. It is possible to budget your time so that you neglect neither your employer, your family, nor your flock.

God bless the bishops of The Church of Jesus Christ of Latter-day Saints. You may on occasion be inclined to complain about the burdens of your office. But you also know the joys of your service. Heavy as the load may be, you know this is the sweetest, the most rewarding, the most important thing you have ever done. You know that yours is the power to shape young lives, yours the right to recommend for missions, yours the authority to open the doors of the temple to your people, yours the calling to feed the hungry and clothe the naked and minister to those in distress, yours the obligation to teach and lead and inspire, yours the mandate to judge with equity and truth and mete out with love and understanding, with charity and faith.

I thank the Lord for you. I thank the Lord for good bishops in this Church throughout the world. I pray for you, all eleven thousand of you. I plead with you to be strong. I plead with you to be true. I plead with you to be uncompromising in your own lives and in the goals you set for others. Though your days be long and wearisome, may your rest be sweet and in your hearts may you know that peace which comes alone from God to those who serve Him through service to His children.

I again look back to the bishop of my boyhood. He was there when I was given a name and a blessing by my good father. He it was who interviewed me and found me worthy of baptism into the Lord’s church. He it was who interviewed me and found me worthy to be ordained a deacon. He called me to my first Church responsibility as a member of the presidency of the deacons quorum. He it was who presided over the quorum of priests to which I once belonged. He it was who recommended me to the stake president as worthy to receive the Melchizedek Priesthood. He it was who recommended me to the President of the Church as one worthy to serve as a missionary. He it was who welcomed me home and who subsequently signed my recommend as one worthy to be married in the house of the Lord.

He grew old in the service and died, and it was my honor to speak at his funeral. A great congregation filled the chapel where he had presided for so long. I spoke out of the heart of a boy whom he had befriended and helped, out of the heart of a youth whom he had guided and counseled, out of the experience of an adult whose life he had blessed in many ways.

I bear testimony of the strength and goodness of the bishops of this church. I pay tribute to counselors who help them and to all who serve under their direction in response to the calls they make. I invoke the blessings of the Lord upon you good men that you may be possessed of strength and vitality to carry the burdens of the day, that you may have wisdom given of God in the delicate and sensitive situations with which you must deal, that you may have generous hearts in meeting the needs of the poor, that you may judge, not as men judge, but with that wisdom which comes from above, and that as the years pass there may come into your hearts the sweet satisfaction of knowing that you have served your Father well through service to His children.

Someday you will be released. It will be a time of sadness for you. But there will be comfort as your people thank you. Nor will they ever forget you. They will remember you and speak with appreciation through years to come, for among all Church officers you are nearest to them. You have been called, ordained, and set apart as shepherds to the flock. You have been endowed with discernment, judgment, and love to bless their lives. In the process, you will bless your own.

I bear testimony of the divine nature of your calling and of the magnificent way in which you fulfill it. May you, your counselors, your wives, your children be blessed as you serve the children of the Lord, I humbly pray in the name of Jesus Christ, amen.

# References
