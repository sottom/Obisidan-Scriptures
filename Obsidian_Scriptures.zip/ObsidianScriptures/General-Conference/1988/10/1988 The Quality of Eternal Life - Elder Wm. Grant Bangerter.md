Elder Wm. Grant Bangerter
Of the Presidency of the First Quorum of the Seventy
10-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/10/the-quality-of-eternal-life?lang=eng)

Coming near the end of the conference, I feel advance approval for my remarks, since much of what I had planned to say has already been used by previous speakers.

The great preoccupation of humanity is with dying. The general tendency, of course, is to try to avoid it. From time immemorial, the dream has been to extend life indefinitely. There have been potions and elixirs which would supposedly protect a person from death. Legends of the fountain of youth have led men to the ends of the earth.

Things are not so different today. From wrinkle creams to vitamins to exercise programs; from preoccupation with cholesterol, climate control, or health resorts to innovations in clothing and food preparations and supplements—all promise an extension of our years.

The medical profession is dedicated to saving human life, as are the countless laws, regulations, and customs of our society.

It is true that many of these lifesaving efforts have a beneficial effect on the quality of life. The end result, however, is that we die anyway. From Adam to Abraham, from Peter and Paul to Henry VIII, George Washington and the rest—all have departed with their generations, and so will we.

Where did they go, this countless flowering of humanity?

Is there a purpose in such a temporary existence? Some say there is not. The great question of Job haunts us all: “If a man die, shall he live again?” (Job 14:14.) Of course he will! The answer is found in the doctrine of eternal life. It is the gospel of Jesus Christ, the good news, the glad tidings.

Even those who don’t think they will live again or who don’t want to live again will nevertheless arise from the grave and live again. There is nothing they can do to stop it, since life is eternal.

A dear friend told of the passing away of his atheistic father. As he bid good-bye to his family who had gathered around, he expressed no hope of any future, saying, “No, this is the end.”

Then, as the last moment came, he suddenly opened his eyes and said distinctly, “Mother, how good to see you! Sister, you look lovely. How beautiful it all is!” Then he died. What a surprise it must have been for him! I hope he was happy about it.

Now, in view of the almost universal concern over the quality of mortal life, and since some people seem to be happier than others, we might ask the question about eternal life: “How can I be sure to have a happy experience there?” And remember, eternity is a long, long time. Well, you can listen to those who know about it. Atheists don’t know about it. Careless, worldly, materialistic people don’t know about it or, at best, they are unconcerned.

Who does know? Well, God knows. He is the Eternal Father. And Christ knows. He controls the plan which can bring the quality of happiness. And his prophets know. And so do those who listen to the prophets and understand the scriptures. Even in the Church the doctrine of eternal life is not always well understood or appreciated. If it were, many members would do more about it. After all, the quality of that eternal existence is in our own hands. Lehi said in the Book of Mormon:

“Wherefore, how great the importance to make these things known unto the inhabitants of the earth, that they may know that there is no flesh that can dwell in the presence of God, save it be through the merits, and mercy, and grace of the Holy Messiah.” (2 Ne. 2:8.)

For the Savior said, “I am the way, the truth, and the life: no man cometh unto the Father, but by me.” (John 14:6.)

The night the angel Moroni appeared to Joseph Smith “he said there was a book deposited, written upon gold plates, giving an account of the former inhabitants of this continent, and the source from whence they sprang. He also said that the fulness of the everlasting Gospel was contained in it, as delivered by the Savior to the ancient inhabitants.” (JS—H 1:33–34.)

You would think that everyone would want to know what the Savior said to the inhabitants on the American continent. The truth is, however, that many don’t. They don’t want to hear revelations, and they don’t want the gospel to be restored.

I had an interesting experience years ago as we were returning from South America on a ship. Three ministers were on board, and soon each one came to me and asked if there might be an opportunity to talk together to learn what the Mormons believed. One was a Methodist, one a Presbyterian, and one a Disciple of Christ.

We arranged a visit together and spent a pleasant hour, they asking questions and I giving answers. Our visit was warm, friendly, and congenial. After about the first ten minutes, they began to look at each other and say: “Isn’t it interesting—he has an answer for every question.” And they repeated this comment over and over.

A day or two later the Methodist brother stopped to talk with me, saying, “I have been thinking of what you told us the other day. I think you know too much. I wonder if God wants us to know everything.” I could tell that he was offended at my knowledge of the revelations.

Other people are simply not interested, having been carried away by selfish interests and material possessions.

Elder ElRay Christiansen told of a wealthy man in Denmark who was converted to the gospel and had migrated to Utah. His commitment caused the loss of much of his fortune, but, after settling here, he again had the ability to amass riches and, in the process, lost his faith and testimony. As his brethren tried to counsel him about his eternal purpose, he would not listen. Finally one of them said to him, “Lars, it is not good to think only of money. You cannot take it with you, you know.”

Lars answered, “Vat is that you say?” and he was told again, “I say you cannot take it with you.”

Lars responded, “Vell, den, I vill not go.”

Elder Christiansen’s report was that he had gone anyway. And we will go as well.

Joseph Smith tells us that “happiness is the object and design of our existence; and will be the end thereof, if we pursue the path which leads to it.” (Teachings of the Prophet Joseph Smith, sel. Joseph Fielding Smith, Salt Lake City: Deseret Book Co., 1938, p. 255.)

There are several fundamentals which those who seek to enjoy quality in their eternal existence would want to consider.

We begin by knowing of Jesus Christ and determining to follow him. Peter said: “Repent, and be baptized every one of you in the name of Jesus Christ for the remission of sins, and ye shall receive the gift of the Holy Ghost. …

“And with many other words did he testify and exhort, saying, Save yourselves from this untoward generation.

“Then they that gladly received his word were baptized: … three thousand souls.” (Acts 2:38–41.)

Then, we “press forward with a steadfastness in Christ … and endure to the end, [and] thus saith the Father: Ye shall have eternal life.” (2 Ne. 31:20.) We are to take upon us His name and always remember Him and keep His commandments. (See Moro. 4; Moro. 5; D&C 20:77–79.) That seems to be keeping our repentance up to date.

Now comes the call to serve. We serve God and our fellowmen. The parable of the Good Samaritan came in answer to the lawyer’s question: “What shall I do to obtain eternal life? … Thou shalt love the Lord thy God … and thy neighbour as thyself.” (Luke 10:25, 27.)

In the portrayal of the Judgment Day in the twenty-fifth chapter of Matthew, we are called to serve those who are





an hungred





thirsty,





a stranger





naked





sick





or in prison. (See Matt. 25:35–36.)





Evidently those who do not undertake this service will not qualify. As the Lord says, “Inasmuch as ye did it not to one of the least of these, ye did it not to me.

“And these shall go away into everlasting punishment: but the righteous into life eternal.” (Matt. 25:45–46.)

To receive the blessings that accompany this service we are given the priesthood and its power. It has been called “the Holy Priesthood, after the Order of the Son of God.” (D&C 107:3.) “And without the ordinances thereof, and the authority of the priesthood, … no man can see the face of God, even the Father, and live.” (D&C 84:21–22.)

And furthermore, “Wo unto all those who come not unto this priesthood.” (D&C 84:42.)

Now, the way of God leads us to the temple. In the past eight years the number of temples in the Church has increased from seventeen to forty-one, with six more in the process of preparation. These sacred edifices fulfill an eternal purpose.

Just as the ancient Israelites looked to the temple for their salvation, even so will those who are in earnest find in the temple the pathway to the presence of the Father and the Son. There they receive holy ordinances as they covenant to keep the commandments.

The doctrine of salvation teaches us that we do not step into the vestibule of the gospel merely by confessing Christ or by being baptized. If we take it seriously, we will reach for all the blessings. Remember, Laman and Lemuel turned their back on the tree of life. They joined the world and lost the promise.

Finally, understanding the doctrine of salvation makes it clear that the plan of God is to redeem all his children on the basis of their repentance—even those who died without a knowledge of the truth.

And so, once again, we come to the temple and, according to the promise of Malachi, we provide the ordinances by proxy for those who did not have the privilege of knowing the gospel on earth. We know that the teaching of the gospel and the opportunity to repent and be worthy of baptism is provided for those who are now in the world of spirits.

The privilege of returning to the temple helps us to obtain the spirit of the work performed there. We perform this service especially for our ancestors. Moroni also said to Joseph Smith, quoting the words of Malachi, “I will reveal unto you the Priesthood, by the hand of Elijah the prophet.” (JS—H 1:38.) The hearts of us, the living children, will turn to our fathers—those ancestors who have died—and will provide them with the ordinances without which their redemption would not be possible.

Immortality or the resurrection will happen to us all. It is an unearned benefit made possible through the grace or free gift of Christ. Eternal life in happiness and glory in association with those we love will be the reward only of those who exercise faith in Jesus Christ through obedience to his commandments.

I have known of Jesus Christ since before I can remember. I was taught to pray to God in his name since infancy. I don’t believe there has been a single day of my life when I have not openly sought for his blessings, his spirit, and his protection. I want his type of eternal life. It has come to mean everything to me. I know that the gospel is true, since I have heard the voice of God through his Spirit confirm and witness it to me. In the name of Jesus Christ, the Lord, amen.

# References
