Elder David B. Haight
Of the Quorum of the Twelve Apostles
10-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/10/a-call-to-serve?lang=eng)

As we all stood a few moments ago and joined in singing “The Spirit of God like a fire is burning” (Hymns, 1985, no. 2), I could visualize that beautiful little temple in Kirtland, Ohio, built by valiant Saints during their poverty and relentless persecution but sustained by their abundant faith in God. In my mind’s eye I could see the temple filled with devout Saints awaiting the moment of dedication, and many gathered outside hoping to hear the inspired prayer of their prophet, for they knew “the authority of God was upon him.” (Matthias Cowley, Wilford Woodruff: History of His Life and Labors, Salt Lake City: Bookcraft, 1964, p. 68.) And then that moment of joy that must have filled their hearts as they joined in singing a new hymn, “The Spirit of God like a Fire Is Burning,” which was hastily scribbled on the back of an envelope by Brother Phelps, so as not to lose the spirit of heaven that he felt.

We, as did they, have sung today:





The visions and blessings of old are returning,

And angels are coming to visit the earth. …

The knowledge and power of God are expanding;

The veil o’er the earth is beginning to burst.

We’ll sing and we’ll shout with the armies of heaven,

Hosanna, hosanna to God and the Lamb!





(Hymns, 1985, No. 2.)





The Spirit filled their hearts then, as we have been blessed this afternoon.

How grateful we are for our pioneer heritage and early history as the gospel has been revealed and restored in purity and truth. Only 150 years separate the sacrifices and struggles of Kirtland from today’s anxieties and personal challenges.

“I suppose every Mormon [man and] woman [have] measured [themselves] at one time or another against [their pioneer ancestors],” wrote Laurel Thatcher Ulrich. “Am I as stalwart? As self-reliant? As devoted to the gospel? As willing to sacrifice?” Could I leave my wife and children without food or means to support themselves while I responded to a call to serve a mission abroad, or take these same innocent ones, dependent solely upon me for their survival, into hostile territory to set up housekeeping and provide a livelihood for them? Or, were I a woman, “could I crush my best china to add glitter to a temple, bid loving farewell to a missionary husband as I lay in a wagon bed with fever and chills, leave all that I possessed and walk across the plains to an arid wilderness?” (Ensign, June 1978, p. 54.)

Some may feel that their lives of relative ease and convenience lack the vigor and fortitude of those who survived the pioneer days, that they can never measure up to the toil, struggles, and challenges our pioneer ancestors faced and emerge the victor.

Yet, “Our challenges are just as important as those of the past. Our testing is as crucial; our contributions may be as great. …

“An essential quality of the first pioneers was optimism, an ability to see new possibilities in a strange and unsettling environment. To beautify the desert, they needed faith in God, but they also needed faith in themselves and in their ability to help shape the world. The need for that faith has not diminished. …

“A pioneer is not [necessarily] a woman who makes her own soap” or a man who grubs sagebrush from the land. Pioneers are those who take up their burdens and walk toward the future. With vision and with courage they make the desert blossom and they press on toward new frontiers. (Ibid., p. 55.)

The Lord emphasized one such frontier when he declared, “purify your hearts before me; and then go ye into all the world, and preach my gospel unto every creature who has not received it.” (D&C 112:28.)

An inspired prophet, David O. McKay, expanded this fundamental principle in 1959 while at the Hyde Park chapel in London, England. He proclaimed these four simple words: “Every member a missionary.”

In 1974 another prophet, Spencer W. Kimball, broadened our vision as he encouraged us to serve more diligently by lengthening our stride.

Our living prophet today, President Ezra Taft Benson, declared: “Missionary work—the preaching of the gospel—has been the major activity of the true Church of Christ whenever the gospel has been upon the earth.” (Improvement Era, June 1970, p. 95.)

Each of us has a sacred duty to personally assist the accomplishment of the mission of the Church in proclaiming the gospel of our Lord Jesus Christ, perfecting the Saints to receive the ordinances of the gospel, and the teaching of the doctrines of salvation and the temple.

“All three are part of one work—to assist our Father in Heaven and His Son … in Their grand and glorious mission ‘to bring to pass the immortality and eternal life of man’ (Moses 1:39).” (Spencer W. Kimball, Ensign, May 1981, p. 5).

In the spirit of these prophetic watchwords, there is a continuing but growing need to extend the frontiers of new member conversion, fellowshipping, and activating the lost or the offended or ignored far beyond our previous levels.

In the past few months remarkable indications of interest in the Church have emerged in nations that have had restrictions. We sense providential opportunities beginning to appear where mature couples who have the experience, sensitivity, and insight into old-world customs and respect for tradition may be able to begin planting seeds of the restored gospel in good soil to flower and bloom.

For some time we have been encouraging qualified mature couples to serve full-time missions. President Kimball and President Benson have stated that the goal of physically able couples and some women who may now be single is to serve a mission. The need remains. Indeed, the requests from mission presidents for more —many more—couples are becoming more pressing.

While firefighters were battling roaring forest fires in the West recently, two grandmothers—Altha Clark, from Texas, and Hazel Stills, from Florida—kindled countless spiritual flames by creating new “interest of people who [had] investigated the Church for years, but who needed a firm, loving nudge to accept baptism,” and with caring fellowshipping, reached out to the less-active members.

“They don’t take no for an answer,” the second counselor in the Altamont Utah Stake presidency said, “and they [teach] without offending anyone.” They combine the Spirit with hard work.

A rancher said the two sisters “have kept us so busy I don’t have time to get my hay in. We … keep them [booked with people] to teach. In this stake, the full-time missionaries teach very few discussions without a stake missionary or fellowshipper going along.”

The two grandmothers travel about one hundred miles a day on unpaved country roads, and the dust and ruts don’t slow them down.

While visiting a member’s home, these remarkable missionaries asked if she knew someone they could teach.

The sister replied, “my husband.”

Directed by the Spirit how to approach this husband, they taught him the gospel and rejoiced with his wife at his baptism.

Fourteen families have now become active and will go to the temple this year because of the efforts of these full-time grandmother missionaries coordinating with the stake missionaries and properly following a plan in fellowshipping new members. A change has come about in the whole stake that has influenced the less active as well as nonmembers. (See Church News, 10 September 1988, pp. 8, 9, 12.)

When people are taught and then fellowshipped with warmth and continued interest until they are integrated into the mainstream of the Church, they are “remembered and nourished by the good word of God, to keep them in the right way.” (Moro. 6:4.) By working together, stake missionaries and full-time missionaries are able to keep new converts involved as they gain gospel knowledge and a needed testimony. They are also bringing back into fellowship the less active.

In stressing the need for mature men and women to be about the work of the Lord, President Benson related the experience of his two widowed sisters. One was the mother of ten children and the other the mother of eight. After they had sent their children on missions, they approached their bishops about going on missions themselves. President Benson relates that he remembers well the day a number of years ago when they called him and said, “Guess what? We have received our missionary calls.” President Benson said, “What missionary calls?” And they replied, “We’re both going to your old field of labor in England.” (See Ensign, May 1984, p. 45.)

They did go to England and served as companions for twenty months.

Thousands of devoted mature couples and single sisters have touched the lives of many for good. We are grateful for their dedication and courage and oftentimes great personal sacrifice. One couple indicated on their missionary form that they would be ready to go just as soon as they were able to find a home for their eighty hives of bees.

There is an unusual opportunity for qualifed individuals to do their utmost to fulfill the Lord’s injunction to preach his gospel to the ends of the earth and not only to teach but convert, as Alma said, that as many “as believed in their preaching, and were converted unto the Lord, never did fall away.” (Alma 23:6.)

The Lord’s work is blessed to have more than eleven hundred couples now serving throughout the world. In Latin America—including Mexico, all of Central America, and South America—there are now fifty-one missionary couples. From the Rio Grande in Texas to the southern tip of South America there are fifty-eight missions, and only fifty-one couples—less than one couple per mission, or, stated another way, one missionary couple to work with more people than live in the entire state of Utah.

For one couple to be assigned to every stake in this vast Latin America area, 278 couples would be needed. Even better would be to have a couple assigned to help two or three wards. To do this we would need another 1,900 couples—just in Latin America. Imagine, 51 now serving where we could effectively use nearly 2,000!

Leaders from our overseas areas indicate similar needs in most parts of the world. One of our pressing challenges is to keep the local leadership trained and ahead of the new members.

It has been estimated that within the United States and Canada there are at least one hundred thousand Church couples between the ages of fifty-five and seventy. Some researchers estimate that six thousand couples could serve missions now. The addition of many of these qualified, experienced couples would bring untold blessings not only to precious people waiting to hear the heavenly invitation to “come unto the Christ” and feel of his goodness, but those who answer the call will be blessed also.

The Lord instructed in the Doctrine and Covenants, “If ye have desires to serve God ye are called to the work.” (D&C 4:3.) Many of you undoubtedly have the desire but may need some gentle encouragement to complete your decision.

I challenged eight couples in my former home stake in California to set aside their comfortable lives of planned retirement and to bless the Scottish Saints with their gospel knowledge and service.

Arthur Thulin had been a bishop, his wife Myra a skilled teacher. Arthur anxiously wrote that he was nearing seventy and might die in Scotland. I replied, “Arthur, you are going to die somewhere; Scotland is a great place to die—but when you die, die with your boots on, not in a comfortable rocking chair.” The Thulins came, blessed the lives of many, and Arthur lived several years after their two-year mission.

Many couples have concerns about leaving their homes and families, or they picture themselves being sent to a developing area of the world or struggling to learn a new language or trying to keep up with the younger missionaries’ tracting and work pace.

These concerns are generally unwarranted. Missionary couples are not expected to work at the same pace or follow the schedule of the younger missionaries. Mission presidents are sensitive to each couple’s special need and establish activity and assignments that make the best use of abilities, experience, and talents.

With very few exceptions, couples are not assigned to developing areas or to missions requiring a new language without some experience or a willingness to accept such an assignment.

Emma Lou and Joseph Slagowski could not speak Spanish but were called to the Peru Lima South Mission. They participated in a trial pre-mission language project for mature couples that assists them in learning language skills in their own homes prior to entering the Missionary Training Center for their training. Sister Slagowski writes:

“When our stake president asked us [if] we would be willing to take part in [a new] pre-mission … language learning project, we were concerned, but accepted,” she said. “I am now 66 years old, and school was [never easy] for me.

“Without the pre-Missionary Training Center Spanish program, it would have been impossible … [but] before [we arrived at] the Missionary Training Center I could read Spanish quite well, … could pray, and bear testimony of God the Father and Jesus Christ. To me it’s a miracle.

“We plan on another Spanish-speaking mission after this one if health permits.”

There are few things that invite the blessings of the Lord into our own lives and into the lives of our family members more powerfully than does missionary service—the broadening of knowledge of gospel principles, a deeper spirituality, a strengthening of one’s faith in the Lord, a greater understanding of the workings of the Spirit, and the expanding of one’s talents, as promised by the Savior in the parable of the talents.

Though you may have had many years of married life together, you will never work more closely and more intensely with one another in a more rewarding effort. Your love will deepen, and you will discover wonderful new dimensions of your companion’s inner soul. You will have a greater feeling of unity, and a heavenly relationship will be strengthened.

If you as a couple meet the personal qualifications, don’t wait to be asked. Go to your bishop. He is probably waiting for you. Humbly and prayerfully talk about your plans and desires, even though you may not be quite ready. He will counsel and guide you.

Study the scriptures daily, take care of your health, and start your own mission savings account, just as you have encouraged your children and grandchildren to do. You might even begin learning a second language.

Eternal justice requires that all of God’s children have adequate opportunity to hear and receive the gospel message. Christ taught, “And this gospel of the kingdom shall be preached in all the world for a witness unto all nations; and then shall the end come.” (Matt. 24:14.)

Now, my dear friends, as we near the closing moments of this historic conference and receive counsel from our prophet, I add my witness of his divine calling to lead this church as God’s holy prophet upon the earth today. We sustain and love him dearly. Our philosophy of life is in accord with divine purposes and, if followed in our actions, will lead us unerringly to eternal life. I leave you this witness and my blessings as you move forward to fulfill your commitments and to live the Lord’s commandments. This work is true, in the name of Jesus Christ, amen.

# References
