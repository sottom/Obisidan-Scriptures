President Ezra Taft Benson
President of the Church
10-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/10/i-testify?lang=eng)

My beloved brethren and sisters, my heart is full and my feelings tender as we conclude this great general conference of the Church.

We have been richly blessed as we have listened to the counsel and testimonies of those who have spoken to us.

As a special witness of Jesus Christ, and as His humble servant, it is now my obligation and privilege, as the Spirit dictates, to bear pure testimony and witness to that which I know to be true. (See Alma 4:19.) This I will do.

I testify that we are the spirit offspring of a loving God, our Heavenly Father (see Acts 17:29; 1 Ne. 17:36). He has a great plan of salvation whereby His children might be perfected as He is and might have a fulness of joy as He enjoys. (See 1 Ne. 10:18; 2 Ne. 2:25; Alma 24:14; Alma 34:9; 3 Ne. 12:48; 3 Ne. 28:10.)

I testify that in our premortal state our Elder Brother in the spirit, even Jesus Christ, became our foreordained Savior in the Father’s plan of salvation. (See Mosiah 4:6–7; Alma 34:9.) He is the captain of our salvation and the only means through whom we can return to our Father in Heaven to gain that fulness of joy. (See Heb. 2:10; Mosiah 3:17; Alma 38:9.)

I testify that Lucifer was also in the council of heaven. He sought to destroy the agency of man. He rebelled. (See Moses 4:3.) There was a war in heaven, and a third of the hosts were cast to the earth and denied a body. (See Rev. 12:7–9; D&C 29:36–37.) Lucifer is the enemy of all righteousness and seeks the misery of all mankind. (See 2 Ne. 2:18, 27; Mosiah 4:14.)

I testify that all those who come into mortality accepted our Father’s plan. (See Abr. 3:26.) Having proved faithful in their first estate in heaven, they are now subject to the test of mortality in this second estate. That test entails doing all things whatsoever the Lord requires. (See Abr. 3:25.) Those who prove faithful in this second estate will have glory added upon their heads forever and ever. (See Abr. 3:26.)

I testify that God reveals His will to all men through the Light of Christ. (See Moro. 7:16; D&C 93:2; John 1:9.) They receive the additional light of the gift of the Holy Ghost through the laying on of hands by God’s authorized servants following baptism. (See A of F 1:4; D&C 20:41.)

I testify that throughout the ages God has spoken to His children through His prophets. (See Amos 3:7; Hel. 8:13–20.) Only when His children rejected the prophets were the prophets taken out of their midst, and then tragedy followed. (See 1 Ne. 3:17–18; 1 Ne. 7:14; Hel. 13:24–27.)

I testify that Christ was born into mortality with Mary as His mother and our Heavenly Father as His father. (See 1 Ne. 11:18–21; Mosiah 3:8.) He lived a sinless life, providing us a perfect example. (See D&C 45:4; 3 Ne. 12:48; 3 Ne. 27:27.) He worked out the great Atonement, which, through His grace, provides for every soul a resurrection and, for the faithful, the means to become exalted in the celestial kingdom. (See A of F 1:3; 2 Ne. 25:23; Mosiah 4:6–7; Alma 11:41–45; D&C 76:50–70; D&C 132:19.)

I testify that during His mortal ministry Christ established His church on the earth. (See Matt. 16:18; Acts 2:47; 3 Ne. 21:22.) He called and ordained men to be Apostles and prophets with authority so that what they bound on earth would be bound in heaven. (See Matt. 16:19; John 15:16.) They received revelation, which provided new scripture. (See 2 Pet. 1:20–21; D&C 68:4.)

I testify that a world so wicked that it killed the Son of God soon began killing the Apostles and prophets and so plunged itself into a spiritual dark age. (See 2 Thes. 2:2–7.) Scripture ended, apostasy spread, and the church that Christ established during His earthly ministry ceased to exist. (See 2 Ne. 27:4–5.)

I testify that God the Father and His Son, Jesus Christ, appeared to Joseph Smith in the spring of 1820, thus bringing to an end the long night of apostasy (JS—H 1:15–20). To Joseph Smith appeared other beings, including John the Baptist and Peter, James, and John, who ordained him with authority to act in the name of God (see JS—H 1:68–72; D&C 27:5–13). The church and kingdom of God was restored in these latter days, even The Church of Jesus Christ of Latter-day Saints, with all the gifts, rights, powers, doctrines, officers, and blessings of the former-day Church. (See D&C 65; D&C 115:3–4.)

I testify that through the Book of Mormon God has provided for our day tangible evidence that Jesus is the Christ and that Joseph Smith is His prophet. (See D&C 20:8–33.) This other testament of Jesus Christ is a scriptural account of the early inhabitants of America. It was translated by Joseph Smith through the gift and power of God. (See D&C 135:3.) Those who will read and ponder the Book of Mormon and ask our Eternal Father in the name of Christ if it is true may know for themselves of its truthfulness through the power of the Holy Ghost, provided they will ask with a sincere heart, with real intent, having faith in Christ. (See Moro. 10:3–5.)

I testify that America is a choice land. (See 2 Ne. 1:5.) God raised up the founding fathers of the United States of America and established the inspired Constitution. (See D&C 101:77–80.) This was the required prologue for the restoration of the gospel. (See 3 Ne. 21:4.) America will be a blessed land unto the righteous forever and is the base from which God will continue to direct the worldwide latter-day operations of His kingdom. (See 2 Ne. 1:7.)

I testify that there has been, and there is now, and there will be legal successors to the Prophet Joseph Smith who hold the keys of the kingdom of God on earth, even the President of The Church of Jesus Christ of Latter-day Saints. (See D&C 21:1–7; D&C 107:91–92; D&C 112:15.) He receives revelation from God to direct His kingdom. Associated with him are others who are prophets, seers, and revelators, even those who make up the presiding quorums of the Church, namely the First Presidency and the Quorum of the Twelve Apostles. (See D&C 112:30.)

I testify that wickedness is rapidly expanding in every segment of our society. (See D&C 1:14–16; D&C 84:49–53.) It is more highly organized, more cleverly disguised, and more powerfully promoted than ever before. Secret combinations lusting for power, gain, and glory are flourishing. A secret combination that seeks to overthrow the freedom of all lands, nations, and countries is increasing its evil influence and control over America and the entire world. (See Ether 8:18–25.)

I testify that the church and kingdom of God is increasing in strength. Its numbers are growing, as is the faithfulness of its faithful members. It has never been better organized or equipped to perform its divine mission.

I testify that as the forces of evil increase under Lucifer’s leadership and as the forces of good increase under the leadership of Jesus Christ, there will be growing battles between the two until the final confrontation. As the issues become clearer and more obvious, all mankind will eventually be required to align themselves either for the kingdom of God or for the kingdom of the devil. As these conflicts rage, either secretly or openly, the righteous will be tested. God’s wrath will soon shake the nations of the earth and will be poured out on the wicked without measure. (See JS—H 1:45; D&C 1:9.) But God will provide strength for the righteous and the means of escape; and eventually and finally truth will triumph. (See 1 Ne. 22:15–23.)

I testify that it is time for every man to set in order his own house both temporally and spiritually. It is time for the unbeliever to learn for himself that this work is true, that The Church of Jesus Christ of Latter-day Saints is the kingdom which Daniel prophesied God would set up in the latter days, never to be destroyed, a stone that would eventually fill the whole earth and stand forever. (See Dan. 2:34–45; D&C 65:2.) It is time for us, as members of the Church, to walk in all the ways of the Lord, to use our influence to make popular that which is sound and to make unpopular that which is unsound. We have the scriptures, the prophets, and the gift of the Holy Ghost. Now we need eyes that will see, ears that will hear, and hearts that will hearken to God’s direction.

I testify that not many years hence the earth will be cleansed. (See D&C 76:41.) Jesus the Christ will come again, this time in power and great glory to vanquish His foes and to rule and reign on the earth. (See D&C 43:26–33.) In due time all men will gain a resurrection and then will face the Master in a final judgment. (See 2 Ne. 9:15, 41.) God will give rewards to each according to the deeds done in the flesh. (See Alma 5:15.)

I testify to you that a fulness of joy can only come through the atonement of Jesus Christ and by obedience to all of the laws and ordinances of the gospel, which are found only in The Church of Jesus Christ of Latter-day Saints. (See A of F 1:3.)

To all these things I humbly testify and bear my solemn witness that they are true, and I do so in the name of Him who is the head of this church, even Jesus Christ, amen.

# References
