Elder Boyd K. Packer
Of the Quorum of the Twelve Apostles
10-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/10/funerals-a-time-for-reverence?lang=eng)

Elder Scott, we welcome you to the quorum. Elder Richard Scott is a man in whom the Spirit is, and he is sustained by his lovely wife, Jeanene, who is not one whit less a spiritual power.

And to these four brethren who have joined the First Quorum of the Seventy we say, your fellowship will be enjoyed and your help very much appreciated.

A neighbor once told me that as a missionary in earlier days he and his companion were walking along a ridge in the mountains of the South. They saw people gathering in a clearing near a cabin some distance down the hillside. They had come for a funeral. A little boy had drowned, and his parents had sent for the preacher to “say words.” The minister, who rode a circuit on horseback, would rarely visit these isolated families. But when there was trouble, they would send for him.

The little fellow was to be buried in a grave opened near the cabin. The elders stayed in the background as the minister stood before the grieving family and began his sermon.

If the parents had hoped for consolation from this man of the cloth, they were disappointed. He scolded them severely because the little boy had not been baptized. He told them bluntly that their little son was lost in endless torment, and it was their fault.

After the grave was covered and the neighbors had gone, the elders approached the grieving parents. “We are servants of the Lord,” they told the sobbing mother, “and we’ve come with a message for you.”

As the grief-stricken parents listened, the elders unfolded the plan of redemption. They quoted from the Book of Mormon, “Little children need no repentance, neither baptism” (Moro. 8:11) and then bore testimony of the restoration of the gospel.

I have sympathy for that itinerant preacher, for he was doing the best he could with the light and knowledge he had. But there is more than he had to give.

What comfort the truth brings at times of sorrow! Since death is ever present with us, a knowledge of how essential it is to the plan of salvation is of immense, practical value. Every one of us should know how and why it came to be in the beginning.

Mortal death came into the world at the Fall.

It is easier for me to understand that word fall in the scriptures if I think both in terms of location and of condition. The word fall means to descend to a lower place.

The fall of man was a move from the presence of God to mortal life on earth. That move down to a lower place came as a consequence of a broken law.

Fall may also describe a change in condition. For instance, one can fall in reputation or from prominence. The word fall well describes what transpired when Adam and Eve were driven from the garden. A transformation took place in their bodies. The bodies of flesh and bone became temporal bodies. Temporal means temporary. The scriptures say, “the life of all flesh is the blood thereof.” (Lev. 17:14; see also Deut. 12:23; Joseph Fielding Smith, comp., Teachings of the Prophet Joseph Smith, Salt Lake City: Deseret Book Co., 1976, pp. 199–200, 367.)

President Kimball explained, “Blood, the life-giving element in our bodies, replaced the finer substance which coursed through their bodies before. They and we became mortal, subject to illness, pains, and even the physical dissolution called death.” (Ensign, Sept. 1978, p. 5).

After the transformation of the Fall, bodies of flesh and bone and blood (unlike our spirit bodies) could not endure. Somehow the ingredient of blood carried with it a limit to life. It was as though a clock were set and a time given. Thereafter, all living things moved inexorably toward mortal death.

Temporal, I repeat, means temporary. And so, death is the reality of life. When conditions develop because of age or illness or accident, the spirit is separated from the body.

Death can be tragic with the loss of one upon whom others depend for happiness, for many die too young. Sometimes it is slow in coming to one who yearns to join the loved ones who have gone before. Some sleep peacefully away, while others endure long-suffering. And we know that death can be terrible and violent. To threaten or to take life, even our own in suicide, is to offend God, for He “in all things hath forbidden it, from the beginning of man.” (Ether 8:19.)



It is my conviction that in the spirit world prior to mortal birth, we waited anxiously for our time to enter mortality. I also believe that we were willing to accept whatever conditions would prevail in life. Perhaps we knew that nature might impose limits on the mind or on the body or on life itself. I believe that we nevertheless anxiously awaited our turn.





Funerals



One of the most solemn and sacred meetings of the Church is the funeral for a departed member. It is a time of caring and support when families gather in a spirit of tender regard for one another. It is a time to soberly contemplate doctrines of the gospel and the purposes for the ministry of the Lord Jesus Christ.

Except where burial is prohibited by law, we are counseled to bury our dead. There are important symbolic references to burial in the ordinance of baptism and elsewhere in the doctrines of the Church.

Where required by law, alternate methods of disposing of the remains do not nullify the Resurrection. On occasion a body will be lost through accident or military action. A funeral is nevertheless very important. For we take comfort in the promises in the scriptures of a complete restoration of both the body and the spirit.

A comforting, spiritual funeral is of great importance. It helps console the bereaved and establishes a transition from mourning to the reality that we must move forward with life. Whether death is expected or a sudden shock, an inspirational funeral where the doctrines of resurrection, the mediation of Christ, and certainty of life after death are taught strengthens those who must now move on with life.

Many attend funerals who do not come to church regularly. They come subdued in spirit and are teachable. How sad when an opportunity for conversion is lost because a funeral is less than it might have been.







Reason to Be Concerned about Funerals



There is reason to fear that we are drifting from the sacred spirit of reverence which should characterize funerals. The Brethren have discussed this in council meetings and are concerned.

I have read what the revelations teach us concerning mortal death, and the instructions given by the Brethren concerning funerals.

May I review some of that counsel. I hope that bishops will pay attention because the responsibility for arranging and conducting funerals in the Church rests upon the bishopric.







Funerals Are Church Meetings



Funerals held under the direction of the priesthood are Church meetings. They have been likened to sacrament meetings. I quote from a priesthood bulletin:

“It is requested that henceforth all funerals conducted under the auspices of the officials of the Church follow the general format of the sacrament meeting with respect to music, speaking, and prayers. Music should be used at the beginning of the service prior to the opening prayer and possibly after the invocation also, as in our Sunday meetings. The closing portion of the funeral likewise should follow our customary pattern of having a final musical number immediately before the concluding prayer. Where feasible, a choir could very well be used on the musical program.

“With respect to speaking, it should be kept in mind that funeral services provide an excellent opportunity for teaching the basic doctrines … in a positive manner. …

“Following these suggestions will help to keep our services in line with our established pattern and will avoid practices now so commonly followed elsewhere.” (Priesthood Bulletin, Apr. 1972.)

Bishops always show tender regard for the family of the deceased, and insofar as their requests accord with established policy, they may willingly be met. On occasion a family member has suggested, sometimes even insisted, that some innovation be added to the funeral service as a special accommodation to the family. Within reason, of course, a bishop may honor such a request. However, there are limits to what may be done without disturbing the spirituality and causing it to be less than it might be. We should remember, too, that others attending the funeral may suppose that innovation is an accepted procedure and introduce it at other funerals. Then, unless we are careful, an innovation which was allowed as an accommodation to one family in one funeral may come to be regarded as expected in every funeral.

Occasionally a mortician, out of a desire to be of help and not understanding the doctrines and procedures of the Church, will alter a funeral service. Bishops should remember that when funerals are held under priesthood auspices the service should conform to the instructions given by the Church. We should regard the bishop rather than the family or the mortician as the presiding authority in these matters.

In recent years, there has been a tendency to stray from the accepted pattern for funerals. Sometimes the casket is kept open during the funeral, and members are expected to file by at the close of the funeral. And, instead of the simple family prayer, talks, and even musical numbers, have been added at the closing of the casket or at the cemetery before the grave is dedicated. I do not refer to graveside services which may on occasion take the place of a formal funeral. I refer to those alterations of the approved simple agenda for funerals.

When innovations are suggested by family members, morticians, or others, which are quite out of harmony with that agenda, the bishop should quietly persuade them to follow the established pattern. It is not a rigid pattern and allows sufficient flexibility to have each funeral personally appropriate for the deceased.







Family Speaker



There now seems to be the expectation that members of the immediate family must speak at funerals. While that may not be out of order, it should not be regarded as required. Family members ordinarily give the family prayer and dedicate the grave.

If family members do speak, and I repeat, it is not a requirement, they are under the same obligation to speak with reverence and to teach the principles of the gospel.

Sometimes family members tell things that would be appropriate at a family reunion or at some other family gathering but not on an occasion that should be sacred and solemn. While quiet humor is not out of order in a funeral, it should be wisely introduced. It should be ever kept in mind that the funeral should be characterized by spirituality and reverence.

One statement from the instructions refers to events other than the funeral service itself. I quote:

“The bishop should urge members to maintain a spirit of reverence, dignity, and solemnity at gatherings connected with funerals.” (General Handbook of Instructions, Oct. 1985, pp. 2-6; italics added.)

That should be kept in mind if a viewing is to be held. Viewings are not mandatory.

Funerals generally bring relatives and friends from distant places. There is the tendency to greet one another joyfully and, unfortunately, at times noisily. Some visit at length, showing little regard for others who are waiting to pay their respects. Both the irreverence and the delay are discourtesies from which the spirituality of the occasion suffers.

Renewing of friendships should appropriately be made outside the room where the viewing is taking place. Local leaders need to caution us gently on this matter. Surely we do not want to be known as an irreverent people.

There is the need to reestablish the spirit of reverence at funerals whether in a chapel, a mortuary, or at other locations.

We should always have a tender regard for the feelings of the bereaved.

We are close, very close, to the spirit world at the time of death. There are tender feelings, spiritual communications really, which may easily be lost if there is not a spirit of reverence.

At times of sorrow and parting one may experience that “peace … which passeth all understanding” (Philip. 4:7) which the scriptures promise. That is a very private experience. Many have come to marvel in their hearts that such a feeling of peace, even exaltation, can come at the time of such grief and uncertainty.

Testimonies are strengthened by such inspiration, and we come to know, personally know, what is meant when the Lord said, “I will not leave you comfortless: I will come to you.” (John 14:18.)

The Comforter works, as far as I have experience, in moments of reverence and quiet and solemnity. How sad if our own conduct is irreverent at a time when others are seeking so desperately for spiritual strength.

The revelations tell us that “thou shalt live together in love, insomuch that thou shalt weep for the loss of them that die, and more especially for those that have not hope of a glorious resurrection.” (D&C 42:45.)

A funeral may be a happy-sad occasion when death comes as a welcome release. Nevertheless, it is a sacred occasion and should be characterized by solemnity and reverence.

Alma’s son thought that death was unfair. In his remarkable sermon on repentance, Alma taught his son about death, saying:

“Now behold, it was not expedient that man should be reclaimed from this temporal death, for that would destroy the great plan of happiness.” (Alma 42:8.)

Alma did not say that setting mortal death aside would merely delay or disturb the plan of happiness; he said it would destroy it.

The words death and happiness are not close companions in mortality, but in the eternal sense they are essential to one another. Death is a mechanism of rescue. Our first parents left Eden lest they partake of the tree of life and live forever in their sins. The mortal death they brought upon themselves, and upon us, is our journey home.

Three elements combine in a funeral as in no other meeting: the doctrines of the gospel, the spirit of inspiration, and families gathered in tender regard for one another.

May we reintroduce the attitude of reverence each time we gather to memorialize one who has moved through the veil to that place where one day each of us will go.

No consolation in parting compares with that “peace … which passeth all understanding.” That is fostered by reverence. Reverence, please, brothers and sisters, reverence, I pray in the name of Jesus Christ, amen.

# References
