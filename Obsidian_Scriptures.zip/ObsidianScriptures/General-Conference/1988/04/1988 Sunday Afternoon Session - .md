

04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/sunday-afternoon-session?lang=eng)



# References
