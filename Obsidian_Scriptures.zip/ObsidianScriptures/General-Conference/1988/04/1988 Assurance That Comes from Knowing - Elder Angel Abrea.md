Elder Angel Abrea
Of the First Quorum of the Seventy
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/assurance-that-comes-from-knowing?lang=eng)

The story is told that on one occasion, a traveler asked a farmer who was seated in the doorway of his humble cabin, “How’s the cotton crop going to be this year?”

The farmer replied, “There won’t be any. I didn’t bother to plant it because I was afraid of the boll weevil.”

Upon hearing this, the traveler asked further, “Well, are you going to harvest a big corn crop?”

“It’s the same,” came the response. “I was afraid we wouldn’t get enough rain for the kernels to mature.”

The traveler pursued, “At least you will have a good potato harvest!”

“Nope. Not any; I didn’t dare plant them because I was afraid of insects.”

With frustration, and somewhat impatiently, the traveler then asked, “Well, what is it that you have planted?”

“Nothing, my good man,” came the answer. “I’d rather be safe than sorry.”

The response from the farmer is a good example of a false security arising from fear and lack of conviction. It is an illusion of security resulting from uncertainty and confusion, an imaginary safe route definitely confused and distorted.

Certainly this is one of the evils which afflicts this generation—the security of not doing, the security of not being. It is the same type of evil that the Savior referred to when he pointed out the uselessness of the unprofitable servant (see Matt. 25:30), of the fig tree that didn’t bear fruit (see Matt. 21:19–22), of the light that did not shine (see Luke 11:33–36), and of the salt that had lost its savor (see Luke 14:34–35).

Jesus Christ did not alter concepts in order to make incorrect actions compatible with a false sense of reality; he always clarified them in order to eliminate neutrality and ambiguity and to expose hypocrisy and deviant actions, thereby setting the standard by which the children of God will be judged.

He described things as they were and lived his life as a clear example to us all of how to live and how to act, even saying, “For I have given you an example” (John 13:15).

Today there are many people, just as the farmer in our story, who, out of fear, create within themselves mental scarecrows and eventually end up believing that these scarecrows are real. In this manner they base their lives on false principles. It is unimportant to them that their ideas are not true; these ideas are the trenches they dig to defend themselves from fear, the commotion they make to drive away the truth. For example, the “scarecrow” of security is a confused and distorted imitation of true security. It provides these people with the illusion they need to weigh different situations and act as they want, using as their yardstick precepts totally apart from reality.

In the face of this distorted understanding of the truth, Latter-day Saints who have received the assignment through revelation to “take upon you the name of Christ, and speak the truth in soberness” (D&C 18:21) could appear to be proud and lacking humility to those who hold to incorrect concepts. This is because faithful members of the Church are filled with a deep assurance that comes from a firm testimony of the gospel, a sure knowledge of the divinity of the work in which we have embarked, received through revelation from the Holy Ghost.

This assurance and firm commitment “to stand as witnesses of God at all times and in all things, and in all places that ye may be in, even until death” (Mosiah 18:9) could appear as boastful pride before those accustomed to using mental scarecrows.

But it is not that way. To confuse pride with safety, and vanity with testimony, shows lack of understanding by those who have not allowed the tempering of the Spirit to enter their hearts, who have not had the experience Nephi did when he said, “I did cry unto the Lord; and behold he did visit me, and did soften my heart that I did believe all the words which had been spoken by my father” (1 Ne. 2:16).

So in most cases the problem is not with the sower, but with the soil where the seed is planted, and very often those who are insecure challenge the self-confident person, not necessarily because of his self-confidence but because, by comparison, their own insecurity becomes evident.

The important point is not to look for causes of insecurity, but rather to look for reasons why faithful members of the Church of Jesus Christ have such a deep assurance in their lives.



A powerful example of this is the Prophet Joseph Smith, who searched for an explanation for the persecution he endured, yet at the same time testified to the truthfulness of his vision:

“I had actually seen a light, and in the midst of that light I saw two Personages, and they did in reality speak to me; and though I was hated and persecuted for saying that I had seen a vision, yet it was true; and while they were persecuting me, reviling me, and speaking all manner of evil against me falsely for so saying, I was led to say in my heart: Why persecute me for telling the truth? I have actually seen a vision; and who am I that I can withstand God, or why does the world think to make me deny what I have actually seen? For I had seen a vision; I knew it, and I knew that God knew it, and I could not deny it, neither dared I do it; at least I knew that by so doing I would offend God, and come under condemnation.

“I had now got my mind satisfied so far as the sectarian world was concerned” (JS—H 1:25–26).

What better way could he express the reality of his vision than to say, “I knew it, and I knew that God knew it”?

From this powerful and firm testimony, this knowledge from on high, came the assurance as portrayed by the words of the Prophet. How could it be otherwise since Joseph Smith had the sure knowledge that he knew that God knew what he knew?

Is this pride? Definitely not. This is assurance that comes from knowing. This is a sure knowledge which, through the Holy Ghost, “shall come upon you and which shall dwell in your heart” (D&C 8:2).

This is the assurance found in the lives of faithful Latter-day Saints, coming from a change brought about by the power of the Spirit, that prompts them to bear testimony of the divinity of the work. It is that same conversion, that same power, that same Spirit which Alma experienced when he called the people to repentance. In his search to remove scarecrows from the people he said, “Do ye not suppose that I know of these things myself? Behold, I testify unto you that I do know that these things whereof I have spoken are true. And how do ye suppose that I know of their surety?

“Behold, I say unto you they are made known unto me by the Holy Spirit of God. Behold, I have fasted and prayed many days that I might know these things of myself. And now I do know of myself that they are true; for the Lord God hath made them manifest unto me by his Holy Spirit; and this is the spirit of revelation which is in me” (Alma 5:45–46).

The world may claim that this is pride, but members of the Lord’s kingdom, those who do not live by borrowed light, those who have gained a testimony for themselves that this work is true, call it assurance.

It is the testimony, it is the true knowledge that “God hath not given us the spirit of fear; but of power, and of love, and of a sound mind” (2 Tim. 1:7). This gives us the courage, the strength, and the commitment to testify of Christ and his gospel regardless of circumstances or external factors. But for the weak, the unsure, or those who question that the Latter-day Saints are Christians, these circumstances and external factors prove to be more important than learning of Christ and gaining a testimony.

The assurance seen in faithful members of The Church of Jesus Christ of Latter-day Saints is the result of being “doers of the word, and not hearers only” (James 1:22); it is the result of striving to “live by every word that proceedeth forth from the mouth of God” (D&C 84:44) instead of talking of God yet not conforming actions to His word, as do those who are insecure. It is this assurance, the firm testimony of thousands of missionaries who are “occupied” with all their “heart, might, mind and strength” (D&C 4:2) in serving their fellowmen, as contrasted with millions who are “preoccupied” with worldly involvements and give only lip service.

It is important, then, in our determination to proclaim the gospel, in our desire to clarify the thinking of confused and insecure people, in our decision to be part of that great work of our Father in Heaven “to bring to pass the immortality and eternal life of man” (Moses 1:39), that we should remember, as King Benjamin admonished his people, to “always retain in remembrance, the greatness of God, and your own nothingness, … and humble yourselves even in the depths of humility, calling on the name of the Lord daily, and standing steadfastly in the faith” (Mosiah 4:11). “No one can assist in this work except he shall be humble” (D&C 12:8).

There is no guarantee of a great reward for anyone; there is no way that any of God’s children can be assured of blessings from the Most High without worthy actions in their lives. The Lord’s blessings are the fruits of obedience to the laws on which they are predicated.

Therefore, since we do have the truth, it is fundamental that we do not be boastful about it. Our pride, if it should exist at all, along with our eternal gratitude, should arise from how we make use of that truth and the manner in which we apply it in our lives.

We can pass through this mortal existence listening attentively and patiently to the best of instructions, or we can be spectators watching the expounding of great and profound principles without allowing these principles to crystalize within us by applying them in daily living.

We are saved only in direct proportion to the knowledge we gain, but the simple accumulation of facts will in no way save us if we do not possess wisdom.

Wisdom is not to be proclaimed or exhibited, but rather, it is to be sought, to be treasured; we need to pray for it and then express it by living a worthy life, according to the knowledge we have obtained. Change and the development of talents and hidden qualities in each of us are produced by putting into practice the knowledge we have obtained.

What is most important, then, is what we do with our lives. For faithful members of The Church of Jesus Christ of Latter-day Saints, the truth is not an end in itself. Our lives are a constant quest and example of a dynamic relationship between truth and knowledge, between living and being.

As President Joseph F. Smith said, “Pure intelligence comprises not only knowledge, but also the power to properly apply that knowledge” (Gospel Doctrine, 5th ed., Salt Lake City: Deseret Book Co., 1939, p. 58).

In majestic clarity the Savior declared concerning this subject, “My doctrine is not mine, but his that sent me.

“If any man will do his will, he shall know of the doctrine, whether it be of God, or whether I speak of myself” (John 7:16–17).

It is from this principle that Latter-day Saints receive the strength of their testimonies, the assurance of their convictions, as they practice what they preach in their daily lives.

To all those faithful Latter-day Saints who share their testimonies concerning the truthfulness of this work in the four corners of the earth, I wish to add mine, with the assurance that I know that God knows I know that The Church of Jesus Christ of Latter-day Saints has the power to administer the saving ordinances that crown the efforts of all those who, through an obedient and faithful life, come unto Christ. In the name of Jesus Christ, amen.

# References
