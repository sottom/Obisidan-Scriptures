Bishop Henry B. Eyring
First Counselor in the Presiding Bishopric
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/because-of-your-steadiness?lang=eng)

From the islands of the Pacific to the highlands of South America, I’ve seen boys working to turn dreams into reality. In fact, I’ve seen it so often that it merges into one image, one picture. It’s of a small boy, maybe nine or ten, in shorts, barefoot, and with a torn shirt. He’s on a patch of dirt, alone, and he’s looking down at a white-and-black-checkered ball. He takes a step toward it, his leg swings through, and the ball shoots off, about seven feet above the ground, where it might zip past a goalie into the net—except there’s no goalie and no net; there’s just the boy and the ball. And then he runs to the ball, puts it in place with his foot, and kicks it. And he does it over and over again.

You don’t know where he lives, but you know that he’ll take the ball home with him and that more than likely he keeps it near the place he sleeps. He sees it when he gets up and when he goes to bed. He may even dream about that ball shooting toward the goal.

You know that because you’ve done something like it yourself. It may have been a basketball. I can remember looking down at the ball in my hands on one freezing winter day and seeing my bloody fingerprints on the ball. I’d been outside so long that the cold had cracked the skin on my fingertips, but my mind and my eye were on the orange rim. I can still remember it, including the chipped paint on the front edge of the rim where you’d lock your eye and know the ball would fall just past that spot into the dirt-stained net. I can still remember the mark on the driveway I’d dribble to and know I was at the top of the key. I’d spin and jump for that last second shot, with the score tied. And I’d do it again and again, sometimes for hours, feeling neither time nor the cold.

You may have learned endurance playing a trumpet, or throwing a football, or riding a bucking horse, or drawing a picture. But you learned what we all did. Effort only “now and then” didn’t take you far. The dreams that turned into reality stuck with you nearly all the time. You worked at them, either in fact or in your thoughts, every day and almost every hour.

It shouldn’t surprise us, then, that the Lord has said to you and to me, “Watch over the church always, and be with and strengthen them” (D&C 20:53). God loves us, and he intends for us to become like him. He doesn’t ask us now to worry about all his children in all the world, as he does. Instead, he begins with a call to watch over just a few families, just a few people. But he knows that to visit thirty minutes every month with the same lesson for every family would never produce the progress he wants for us.

And so he commands, “Watch over [them] always, and be with and strengthen them.” You can’t be with them twenty-four hours a day. That would be “always,” wouldn’t it? But they can be in your heart always. If you’ll think about the families you visit, those of you who are blessed to be called home teachers, you know the help they need is beyond your casual effort.

In my experience, I’ve been assigned to watch over people who struggled with divorce, with financial ruin, with children who would not respond to all that parents had done, or with disease that would not respond to all that faith and medicine could do. I’ve gone to a home where little twin girls were sent to the screen door to tell us that Mommy and Daddy were sleeping and couldn’t we come another time.

I knew in my heart that effort “now and then” wasn’t enough, that “going out home teaching” or even “giving a good lesson” wouldn’t do it. God called us to watch over and help people in all their struggles for physical and spiritual well-being. He called us to help by the Spirit. He called us to teach by the Spirit. He called us to live what we teach. He called us to bear testimony. He called us to love them.

Now, he didn’t make it that hard just to test you. He gave you so high a calling because he loves you. He wants you home again, and to get there you have to become like him. So he gives you a calling that can only be done with persistence and endurance.

Let’s talk tonight as if you and I were companions. I know we may not have gotten together often to prepare, but let’s do it tonight. Let’s imagine that you and I are at my house. You’ve come over for a few minutes, and we’re sitting at my kitchen table.

We won’t talk about home teaching visits or lessons first. We’ll talk about our families for a while. We’ll find that some of them are struggling. And that will humble us, knowing that the Lord is counting on us. We might talk about what we know the bishop and the Relief Society and some neighbors are doing to help. And we might talk about some things we have done and could do.

Then, we’ll get around to talking about one family and what we might teach them. I’ll push the April Ensign across the table to you, opened to the First Presidency message from President Benson. You look down and see the title, “Seek the Spirit of the Lord.” That looks like the perfect lesson, doesn’t it? There’s only the mom and dad at home. They worry about her health problems, wondering if they’re doing all they can and should. On top of that, they probably aren’t sleeping much because of their son. He’s still in the same town, but he’s living with his friends. He won’t be there when we call, but he’ll be in their minds, and what he’s doing and not doing will be tearing at their hearts. They’ll be wondering what they can do for him. If people ever wanted and needed the Spirit of the Lord, these folks do.

Let’s agree that we’ll both prepare the lesson. But I think they have such respect for you that you ought to take the lead. We can’t do them any good unless the Holy Ghost is with us, so I guess we’d better do more than prepare the lesson. We’d better prepare ourselves.

First, the Holy Ghost can’t be with us unless we’re clean. I admire the way you try to watch what you say and do, even what you think. I guess when the Lord tells us to watch over the Church, that means watching over ourselves too. Let’s read this quotation from President George Q. Cannon I keep handy. And let’s agree that we’ll try to follow it:

“Some people have an idea that because they have entered the waters of baptism and repented of their sins then that is an end of it. What a mistake! We need to have this spirit of repentance continually; we need to pray to God to show us our conduct every day. Every night before we retire to rest we should review the thoughts, words, and acts of the day and then repent of everything we have done that is wrong or that has grieved the Holy Spirit. Live this way every day and endeavor to progress every day” (Gospel Truth, Jerreld L. Newquist, ed., Salt Lake City: Deseret Book Co., 1987, p. 129).

Second, let’s pray both for forgiveness and to get answers about what to do for the family. It would help if, when we go, we tell them that the Holy Ghost can guide them; it has already guided us to do something for them. If we pray and then feel that prompting and act on it, what we do may be more important than anything we say. Maybe our finding out how to help them will lead them to find out what more they can do for their son.

Let’s agree that we’ll include both the parents and their children in our personal prayers, and we’ll plead for the Holy Ghost to help us teach. You remember the promise, “And the Spirit shall be given unto you by the prayer of faith; and if ye receive not the Spirit ye shall not teach” (D&C 42:14). That really fits us, doesn’t it?

Third, we’re going to be teaching a gospel principle, so we’d better study and ponder the scriptures. You remember that the Lord said, “Teach the principles of my gospel, which are in the Bible and the Book of Mormon, in the which is the fulness of the gospel” (D&C 42:12). I know you’ve been reading the Book of Mormon regularly. So have I. Why don’t we think about our family and the gifts of the Spirit while we read? If we do, I’m sure that we’ll understand and feel some things that are new to us. And we’ll teach and bear testimony in their home with more power.

It won’t hurt to bear testimony from our own experience that we felt the Spirit while we read the scriptures. Then they may try reading and pondering. If they do, they’ll get the prompting of the Holy Ghost for themselves. And that will help them more than just feeling it when we’re there.

Then we’ll have a prayer together before you leave. In the next day or two we may stop by the house to do something for the family before we get there for a lesson.

The night we teach them, things will seem about as they have before, with a few exceptions. An idea and a scripture will come into your mind as you teach. You’ll bear testimony of the Savior with more feeling. Perhaps we will both find our hearts drawn out to the people more. And they may linger at the door a little longer than usual as we go.

Maybe only some of that will happen. But that won’t discourage us. We thought it would take repeated, steady effort. The desire of our hearts is to help others taste the fruit of the gospel. We know it won’t come quickly or easily after a single effort, for them or for us. But in that visit, or in one that will come later, you will feel a warmth in your heart and truth will come into your mind. And that will bring you joy. It may go away, but you will remember it. Then you will be able to imagine what it would be like to have the Holy Ghost for your constant companion in this life and to feel the love and approval of the Savior and your Father in Heaven for eternity.

Alma knew what having that desire in our hearts and visualizing it with faith would mean to us. It would keep us going when the going was hard. Here’s what he said: “And thus, if ye will not nourish the word, looking forward with an eye of faith to the fruit thereof, ye can never pluck of the fruit of the tree of life.

“But if ye will nourish the word, yea, nourish the tree as it beginneth to grow, by your faith with great diligence, and with patience, looking forward to the fruit thereof, it shall take root; and behold it shall be a tree springing up unto everlasting life” (Alma 32:40–41).

By the power of the Holy Ghost and with the eye of faith, we have glimpsed and we can look forward to the fruit of the gospel. That is the desire of our hearts. And wanting it will give us the power to keep going, with great diligence and patience.

The little boy in my memory keeps kicking that ball, over and over again. I can’t see a goalpost or a goalie. I can’t hear the roar of the crowd. But in his mind, he can. And so he kicks the ball, over and over again.

I pray that we will take the great opportunity God has given us to prepare ourselves. He has trusted us as watchmen of the souls of his children. He has given us a way to look forward to the fruit of the gospel by giving us a calling that requires our whole hearts. As the boy’s dreams of kicking the winning goal draw him back to persistent practice with that ball, so our vision of the fruits of the gospel will draw us back to persistent repentance and prayer and study and service.

I pray that the Lord may say of us, as Alma said of his son Shiblon: “And now, my son, I trust that I shall have great joy in you, because of your steadiness and your faithfulness unto God; for as you have commenced in your youth to look to the Lord your God, even so I hope that you will continue in keeping his commandments; for blessed is he that endureth to the end” (Alma 38:2).

I bear testimony that in time and in eternity God will bless our steadiness as we invite his children to come unto Christ. In the name of Jesus Christ, amen.

# References
