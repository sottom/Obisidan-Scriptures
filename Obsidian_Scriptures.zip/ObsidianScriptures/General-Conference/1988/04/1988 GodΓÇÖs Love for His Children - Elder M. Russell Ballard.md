Elder M. Russell Ballard
Of the Quorum of the Twelve Apostles
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/gods-love-for-his-children?lang=eng)

Brothers and sisters, this is a beautiful time of year with spring beginning to burst forth in many parts of the world, bringing all of its colors, scents, and cheerful sounds. The miracle of the changing seasons, with the reawakening and rebirth in nature, inspires feelings of love and reverence within us for God’s marvelous, creative handiwork.

The Easter season is a good time for people everywhere to appreciate the wonders of nature and give thanks to the Creator of this beautiful world. Men and women in all parts of the world have a desperate need to take time from their demanding routines of everyday life and to quietly observe God’s miracles taking place all around them. Think of what would happen if all of us took time to look carefully at the wonders of nature that surround us and devoted ourselves to learning more about this world that God created for us!

My family and I recently had a simple but impressive experience with one of God’s creations. I gave my wife, Barbara, a dozen roses for a valentine. They were a delicate shade of peach in color and had a rich scent. Barbara put them in a vase and placed them on the table in our family room. As the days passed, the family watched the blossoms unfold from buds to full flower.

As I watched this miracle, I became curious about roses. I was amazed to learn from a botanist friend that there are thousands of different varieties of roses. Inside each rose is a giant storehouse of genetic coding that develops a seed or a slip into roots, stems, thorns, leaves, colors, and blooms.

Each rose is a compact chemical-processing factory. Using sunlight, the green leaves take carbon dioxide from the air and replace it with oxygen, which we breathe. When other chemicals within the plant react with sunlight, it produces starch that becomes food. As you know, this process is called photosynthesis, and without it the earth’s atmosphere would soon be devoid of oxygen, and most living things would disappear from the earth. My friend told me that the chemical energy and the electrical energy our brains were using at that very moment were once sunlight that was absorbed by the chlorophyll in green vegetation we previously had eaten.

This experience led me to consider the myriad forms of plant and animal life that thrive in astounding balance upon the earth. My esteem for our little roses took on an element of wonder and reverence. I pondered the power of the creative genius who lovingly provided such marvels for his children. I thought then how important it is for every human soul to see and appreciate the glory and grandeur of God in everything about us. Into my mind came the words and message of a beautiful hymn:





When thru the woods and forest glades I wander,

And hear the birds sing sweetly in the trees,

When I look down from lofty mountain grandeur

And hear the brook and feel the gentle breeze,

Then sings my soul, my Savior God, to thee,

How great thou art! How great thou art!





(Hymns, 1985, no. 86)





I felt a deep reverence for both the creation and the Creator. Reverence may be defined as a profound respect mingled with love and awe. Other words that add to our understanding of reverence include gratitude, honor, veneration, and admiration. The root word revere also implies an element of fear. Thus, reverence might be understood to mean an attitude of profound respect and love with a desire to honor and show gratitude, with a fear of breaking faith or offending.

In the book of Moses we read, “And behold, all things have their likeness, and all things are created and made to bear record of me, both things which are temporal, and things which are spiritual; things which are in the heavens above, and things which are on the earth, and things which are in the earth, and things which are under the earth, both above and beneath: all things bear record of me” (Moses 6:63).

Truly, the heavens and the earth and all things in them evidence the handiwork of God, their Creator. In the Book of Mormon we learn of Korihor, an anti-Christ who was brought to the Prophet Alma. He asked for a sign of God’s existence before he would believe. “But Alma said unto him: Thou hast had signs enough; will ye tempt your God? Will ye say, Show unto me a sign, when ye have the testimony of all these thy brethren, and also all the holy prophets? The scriptures are laid before thee, yea, and all things denote there is a God; yea, even the earth, and all things that are upon the face of it, yea, and its motion, yea, and also all the planets which move in their regular form do witness that there is a Supreme Creator” (Alma 30:44). These eternal evidences continue to testify to us today.

Astronauts viewing the earth from space have stated how incredibly beautiful it is and how alive it appears. United States Senator Jake Garn wrote of his experience in space: “It is impossible for me to describe the beauty of the earth. It is a breathtaking, awe-inspiring, spiritual experience to view the earth from space while traveling at twenty-five times the speed of sound. I could also look into the blackness of the vacuum of space and see billions of stars and galaxies millions of light-years away. The universe is so vast as to be impossible to comprehend. But I did comprehend the hand of God in all things. I felt his presence throughout my seven days in space. I know that God created this earth and the universe. I know that we are his children wherever we live on the earth, without regard to our nationality or the color of our skin. Most important, I know that God lives and is the Creator of us all” (letter to M. Russell Ballard, 3 March 1988).

Again, the words of the hymn came to mind:





O Lord my God, when I in awesome wonder

Consider all the worlds thy hands have made,

I see the stars, I hear the rolling thunder,

Thy pow’r thruout the universe displayed;

Then sings my soul, my Savior God, to thee,

How great thou art! How great thou art!





(Hymns, 1985, no. 86)





The psalmist wrote, “When I consider thy heavens, the work of thy fingers, the moon and the stars, which thou hast ordained;

“What is man, that thou art mindful of him? and the son of man, that thou visitest him?

“For thou hast made him a little lower than the angels, and hast crowned him with glory and honour” (Ps. 8:3–5).

The Lord gave an answer to the psalmist’s question; it is recorded in the book of Moses: “For mine own purpose have I made these things. …

“And by the word of my power, have I created them. …

“For behold, this is my work and my glory—to bring to pass the immortality and eternal life of man” (Moses 1:31–32, 39).

When we look to see the evidence of creation all around us, from a grain of sand to the majestic planets, we begin to realize that we are the greatest of all God’s creations; we are created in his image. I was joyfully reminded of this fact three weeks ago when our twenty-fourth grandchild was born. I was again filled with wonder and love to hold this precious infant in my arms, to contemplate the miracle of birth, and to see a child born into mortality who had come so recently from the presence of our Father in Heaven.

The gift of new life brings a profound feeling of reverence. Parents and other family members are drawn closer together. Even little children sense a feeling of awe and wonder. They want to hold the baby, touch it, run their hands over its warm, soft head, or extend a finger for it to grasp and hold.

Welcoming this new little spirit into our family circle brought home once more to me an incredible truth. I realized again that God created the earth in all its magnificent glory, not as an end in itself, but for us, his children. Indeed, we are his children, his offspring, and he is the Father of our spirits.

We sometimes feel great respect and reverence for creative genius as expressed in great art or music. How much more should we revere the power and majesty of our Divine Creator? We may stand in awe of man’s creations of beautiful buildings or bridges. But remember the Apostle Paul’s words to the Hebrews: “He who hath builded the house hath more honour than the house.

“For every house is builded by some man; but he that built all things is God” (Heb. 3:3–4).

Those who feel no reverence for the creations and the divine attributes of God likely will have little appreciation for other sacred things. Such a lack of veneration for God’s creations may diminish until a person becomes totally insensitive to the feelings of others. This, I am afraid, is the condition in some parts of the world.

When we consider people who are irreverent, we may think of those who lack manners, sensitivity, and courtesy, and who show little or no respect for the finer things or for sacred things. Perhaps some lack reverence for life and for their fellowmen because they do not understand who they are and what they have the potential to become.

God expresses his love for us by providing the guidance we need to progress and reach our potential. Perhaps a simple story will illustrate this point. Recently, a young man purchased a used computer but could not get it to work properly. Soon he became discouraged. His temper grew short and he threatened the inanimate object with painful destruction unless its performance improved. A wise father intervened and took his son to a local vendor, where they obtained an instruction manual. After all, who would know more about a complex computer than the person or company that created it? Who would know most about its capacity and potential? Who would better know the safeguards required to avoid damaging or ruining this fine instrument? Soon the boy enjoyed the full potential of his computer by working within the guidelines given in the instruction book provided by its creator.

Likewise in our lives, he who knows most about us, our potential, and our eternal possibilities has given us divine counsel and commandments in his instruction manuals—the holy scriptures. When we understand and follow these instructions, our lives have purpose and meaning. We learn that our Maker loves us and desires our happiness. In an incomparable manifestation of this divine love for us, he sent his Only Begotten Son, Jesus Christ.

“For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life.

“For God sent not his Son into the world to condemn the world; but that the world through him might be saved” (John 3:16–17).

Jesus was born into mortality. He led a perfect life and, in so doing, marked the path for us to follow. He taught his disciples: “I am the light of the world: he that followeth me shall not walk in darkness, but shall have the light of life” (John 8:12).

His gospel is a gospel of love—love for God and love for one another. He directs us to follow his example. Our discipleship is measured by how well we comply.

“A new commandment I give unto you, That ye love one another; as I have loved you, that ye also love one another.

“By this shall all men know that ye are my disciples, if ye have love one to another” (John 13:34–35).

Can you imagine what an impact following this instruction would have on society today?

Many people, I fear, never come to understand that the commandments of God are for our benefit and that as we sow, so shall we reap.

Our return to our Heavenly Father is through his Son, Jesus Christ. Jesus told his disciples, “I am the way, the truth, and the life: no man cometh unto the Father, but by me” (John 14:6). He instructed us to keep his commandments if we love him (John 14:15). He taught further that “He that hath my commandments, and keepeth them, he it is that loveth me: and he that loveth me shall be loved of my Father, and I will love him, and will manifest myself to him” (John 14:21).

In the atonement and the resurrection of Jesus Christ, we can glimpse the reality of his divine mission to redeem all who will come unto him and will honor and reverence God, our Eternal Father.

We may begin to understand the depths of Christ’s love for us when we consider that he was willing to atone and suffer the pain for our sins, “which suffering caused [him], even God, the greatest of all, to tremble because of pain, and to bleed at every pore, and to suffer both body and spirit” (D&C 19:18). Nevertheless, he gave glory to his Father and partook and finished his preparations unto the children of men (D&C 19:19).

The crowning words of the inspired hymn continue:





And when I think that God, his Son not sparing,

Sent him to die, I scarce can take it in,

That on the cross my burden gladly bearing

He bled and died to take away my sin,

Then sings my soul, my Savior God, to thee,

How great thou art! How great thou art!





(Hymns, 1985, no. 86)





Brothers and sisters, on this Easter Sunday, let us give special thanks to God for the atonement and resurrection of his beloved Son, Jesus Christ. For in him, by him, and through him, this temporary mortal condition can be made into a permanent, perfect existence, for which words cannot express our joy.

To truly reverence the Creator, we must appreciate his creations. We need to plan to take time to observe the marvels of nature. Today, we can easily become surrounded by brick buildings and asphalt surfaces that shelter us from real life around us. Plan to share with your family the miracle of buds changing to fragrant blossoms. Take time to sit on a hillside and feel the tranquillity of the evening when the sun casts its last golden glow over the horizon. Take time to smell the roses.

All the marvels of nature are glimpses of his divine power and expressions of his love. Yet the greatest of all miracles awaits us. It will occur when, by his power, we will come forth from death and the grave to a new world that will not pass away, where, if we are worthy, we will be with him and our Father in Heaven forever and ever.

With humility but with firm conviction, we declare to all the world that we know for a surety that God the Father and Jesus Christ, his Son, live. We know that they visited the Prophet Joseph Smith in the spring of 1820. They spoke to Joseph and, through him, they revealed wonderful, true doctrines and restored the fulness of the gospel of Jesus Christ that had been lost from the world.

We invite all men and women everywhere to know of the restoration of the gospel, for in so doing they will develop a deep reverence and love for God, his beloved Son, Jesus Christ, and their creations. I bear testimony that true reverence will bring peace, joy, and happiness to us all. In the sacred name of Jesus Christ, amen.

# References
