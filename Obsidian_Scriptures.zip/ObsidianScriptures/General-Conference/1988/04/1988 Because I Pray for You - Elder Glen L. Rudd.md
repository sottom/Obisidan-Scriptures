Elder Glen L. Rudd
Of the First Quorum of the Seventy
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/because-i-pray-for-you?lang=eng)

When I was a young man in the Aaronic Priesthood, we boys used to stand in our quorum meetings and repeat in unison, “Priesthood means service. Bearing the priesthood, I will serve.” This was our weekly pledge. It was part of every quorum meeting. Most of us began to understand that honoring the priesthood required our being active and serving in the Church.

In those days we played a lot of tennis. We knew that, in tennis, if we didn’t serve well, we usually didn’t win. Our priesthood leaders taught us the same concept insofar as the Church was concerned. They helped us learn to serve at the proper time and in the proper way.

No boy or man fully possesses the priesthood until he learns to serve others and the Lord. It is true that someone with authority may bestow the priesthood by the laying on of hands, but until we do something by way of service to others, the priesthood lies dormant within us and is of little value. We must not fail to magnify the callings we receive.

During the past few months, I have felt that I might best serve by encouraging and helping all members to feel the necessity of keeping the simple doctrines of the gospel simple. I strongly feel that the gospel was given to us in a simple, plain, and clear manner. My mission president taught us that the gospel of Jesus Christ is beautifully simple and simply beautiful. The tendency of many is to complicate these lovely, simple requirements that the Lord has given to us.

Nothing is more simple than prayer. The Savior, while upon the earth, gave the example and commanded all to follow in His footsteps. If we have faith that our Heavenly Father lives and that we can commune with Him in a very direct way, then prayer becomes one of the most beautiful, lovely, simple acts that we can do.

I have a strong testimony that the Lord does hear and answer prayers. We are obligated to thank Him. We are obligated to converse with Him in such a way that there are no obstacles between us and our Father in Heaven. From the very beginning, the Lord has instructed His earthly children to remember Him in prayer.

One morning a good many years ago, a member of the Council of the Twelve came to my office and told me of a beautiful, touching experience that had happened to him that day. He had gone to the old Deseret Gym to enjoy the steam bath for a while. As he sat there in the heavy steam, he heard the door open and looked upward toward the door to see who was entering. He could not see anyone, but he had a feeling someone else was there in the room with him. After a few minutes he saw a young Primary-age boy about eight or nine years old who had seated himself two or three feet away. The boy gradually slid closer to the Apostle, and they finally said “hello” to each other. Then the boy moved even closer until he could look up into the face of the Church leader. The little boy said, “Mister, I think I know who you are.” The Apostle said, “Who am I?” The boy said, “I think you are one of the Apostles of the Church. I think you are the one who travels all over the ocean on big boats and little boats and all kinds of airplanes—and you are the one who never gets sick or hurt in any wrecks.” The Apostle acknowledged that he was the one who was having those great experiences. The boy then said to him, “Do you know why it is you don’t ever get killed or get hurt?” The Apostle said, “No, why is that?” The little Primary boy said, “That’s because I pray for you.”

What a touching, lovely expression of faith in a simple, wonderful way! This experience happened forty years ago, but I think of it frequently. There is far more power in simple prayer than many of us think possible.

My brothers and sisters, thousands, and even hundreds of thousands, of people pray for their loved ones each and every day. Great numbers pray for the leaders of the Church, particularly for our prophet, President Benson. I am convinced that the Lord hears the simple prayers of all people. I am sure He hears the prayer of the aged widow as well as the little child who prays with simple, plain, and understandable faith. I am also certain that a loving Heavenly Father appreciates the sincere, regular prayers of the faithful much more than the hurried, urgent appeals given only in times of crisis.

May the Lord bless and help us all to have the courage to pray with our families. Nothing is more wonderful than for parents to gather their children around them and enjoy the special, tender moments of communing with our Heavenly Father in family prayer. Nothing binds a family together more; and nothing puts us in a position to receive His blessings more than compliance with that wonderful commandment and privilege. Even for those of us who no longer have children at home, the blessing of praying together as companions is wonderful. The faithful person living alone is also lifted up and richly rewarded through humble, secret prayer.

Jesus said, “Except ye be converted, and become as little children, ye shall not enter into the kingdom of heaven” (Matt. 18:3).

May the Lord bless us and help us all to serve Him with simple, childlike faith, simple forgiveness and repentance, and especially with simple prayer, that we may enjoy the strength, power, and beauty that come from the plain and simple things of the gospel, I pray in the name of Jesus Christ, amen.

# References
