President Thomas S. Monson
Second Counselor in the First Presidency
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/an-invitation-to-exaltation?lang=eng)

Everywhere, people are in a hurry. Jet-powered planes speed their precious human cargo across broad continents and vast oceans. Appointments must be kept, tourist attractions beckon, and friends and family await the arrival of a particular flight. Modern freeways with multiple lanes carry millions of automobiles, occupied by more millions of people, in a seemingly endless stream.

Does this pulsating, mobile ribbon of humanity ever come to a halt? Is the helter-skelter pace of life ever punctuated with moments of meditation—even thoughts of timeless truths?

When compared to eternal verities, the questions of daily living are really rather trivial. What shall we have for dinner? Is there a good movie playing tonight? Have you seen the television log? Where shall we go on Saturday? These questions pale in their significance when times of crisis arise, when loved ones are wounded, when pain enters the house of good health, or when life’s candle dims and darkness threatens. Then, truth and trivia are soon separated. The soul of man reaches heavenward, seeking a divine response to life’s greatest questions: Where did we come from? Why are we here? Where do we go after we leave this life?

Answers to these questions are not discovered within the covers of academia’s textbooks, by dialing Information, in tossing a coin, or through random selection of multiple-choice responses. These questions transcend mortality. They embrace eternity.

Where did we come from? This query is inevitably thought, if not spoken, by every parent or grandparent when a tiny infant utters its first cry. One marvels at the perfectly formed child. The tiny toes, the delicate fingers, the beautiful head, to say nothing of the hidden but marvelous circulatory, digestive, and nervous systems all testify to the truth of a divine Creator.

The Apostle Paul told the Athenians on Mars’ Hill that we are “the offspring of God” (Acts 17:29). Since we know that our physical bodies are the offspring of our mortal parents, we must probe for the meaning of Paul’s statement. The Lord has declared that “the spirit and the body are the soul of man” (D&C 88:15). It is the spirit which is the offspring of God. The writer of Hebrews refers to Him as “the Father of spirits” (Heb. 12:9). The spirits of all men are literally His “begotten sons and daughters” (D&C 76:24).

We note that inspired poets have, for our contemplation of this subject, written moving messages and recorded transcendent thoughts. William Wordsworth penned the truth:





Our birth is but a sleep and a forgetting:

The soul that rises with us, our life’s Star,

Hath had elsewhere its setting,

And cometh from afar:

Not in entire forgetfulness,

And not in utter nakedness,

But trailing clouds of glory do we come

From God, who is our home:

Heaven lies about us in our infancy!





(“Ode: Intimations of Immortality from Recollections of Early Childhood”)





Another writer described a newborn infant as “a sweet, new blossom of humanity, fresh fallen from God’s own home to flower here on earth.”

Parents, gazing down at a tiny infant or taking the hand of a growing child, ponder their responsibility to teach, to inspire, and to provide direction. While parents ponder, children and, particularly, youth ask the penetrating question: “Why are we here?” Usually, it is spoken silently to the soul and phrased: “Why am I here?”

How grateful we should be that a wise Creator fashioned an earth and placed us here, with a veil of forgetfulness of our previous existence, so that we might experience a time of testing, an opportunity to prove ourselves, and qualify for all that God has prepared for us to receive.

Clearly, one primary purpose of our existence upon the earth is to obtain a body of flesh and bones. In a thousand ways, we are privileged to choose for ourselves. Here we learn from the hard taskmaster of experience. We discern between good and evil. We differentiate as to the bitter and the sweet. We discover that decisions determine destiny.

While Paul taught the Philippians that man is called upon to “work out [his] own salvation with fear and trembling” (Philip. 2:12), the Master provided a guide we know as the Golden Rule: “Whatsoever ye would that men should do to you, do ye even so to them” (Matt. 7:12).

By obedience to God’s commandments, we can qualify for that “house” spoken of by Jesus when He declared: “In my Father’s house are many mansions. … I go to prepare a place for you … that where I am, there ye may be also” (John 14:2–3).

Contemplating such far-reaching matters, we reflect upon the helplessness of a newborn child. No better example can be found for total dependency. Needed is nourishment for the body and love for the soul. Mother provides both. She who, with her hand in the hand of God, descended into “the valley of the shadow of death” (Ps. 23:4), that you and I might come forth to life, is not in her maternal mission abandoned by God.

Several years ago, the Salt Lake City newspapers published an obituary notice of a close friend—a mother and wife taken by death in the prime of her life. I visited the mortuary and joined a host of persons gathered to express condolence to the distraught husband and motherless children. Suddenly the smallest child, Kelly, recognized me and took my hand in hers.

“Come with me,” she said; and she led me to the casket in which rested the body of her beloved mother. “I’m not crying, Brother Monson, and neither must you. My mommy told me many times about death and life with Heavenly Father. I belong to my mommy and my daddy. We’ll all be together again.”

Through tear-moistened eyes, I recognized a beautiful and faith-filled smile. To my young friend, whose tiny hand yet clasped mine, there would never be a hopeless dawn. Sustained by her unfailing testimony, knowing that life continues beyond the grave, she, her father, her brothers, her sisters, and indeed all who share this knowledge of divine truth, can declare to the world, “Weeping may endure for a night, but joy cometh in the morning” (Ps. 30:5).

Life moves on. Youth follows childhood, and maturity comes ever so imperceptibly.

We treasure the inspired thought:





God is a Father.

Man is a brother.

Life is a mission

And not a career.





(In Stephen L Richards, Where Is Wisdom? Addresses of Stephen L Richards, Salt Lake City: Deseret Book Co., 1955, p. 74)





God, our Father, and Jesus Christ, our Lord, have marked the way to perfection. They beckon us to follow eternal verities and to become perfect, as they are perfect (see Matt. 5:48; 3 Ne. 12:48). We remember the inquiring lawyer who asked:

“Master, which is the great commandment in the law?

“Jesus said unto him, Thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy mind.

“This is the first and great commandment.

“And the second is like unto it, Thou shalt love thy neighbour as thyself” (Matt. 22:36–39).

The Apostle Paul likened life to a race with a clearly defined goal. To the Saints at Corinth he urged:

“Know ye not that they which run in a race run all, but one receiveth the prize? So run, that ye may obtain” (1 Cor. 9:24).

In our zeal, let us not overlook the sage counsel from Ecclesiastes: “The race is not to the swift, nor the battle to the strong” (Eccl. 9:11). Actually the prize belongs to him who endures to the end.

When I reflect on the race of life, I remember another type of race, even from childhood days. When I was about ten, my boyfriends and I would take pocketknives in hand and, from the soft wood of a willow tree, fashion small toy boats. With a triangular-shaped cotton sail in place, each would launch his crude craft in the race down the relatively turbulent waters of the Provo River. We would run along the river’s bank and watch the tiny vessels sometimes bobbing violently in the swift current and at other times sailing serenely as the water deepened.

During such a race, we noted that one boat led all the rest toward the appointed finish line. Suddenly, the current carried it too close to a large whirlpool, and the boat heaved to its side and capsized. Around and around it was carried, unable to make its way back into the main current. At last it came to an uneasy rest at the end of the pool, amid the flotsam and jetsam that surrounded it.

The toy boats of childhood had no keel for stability, no rudder to provide direction, and no source of power. Inevitably their destination was downstream—the path of least resistance.

Unlike toy boats, we have been provided divine attributes to guide our journey. We enter mortality not to float with the moving currents of life, but with the power to think, to reason, and to achieve.

Our Heavenly Father did not launch us on our eternal voyage without providing the means whereby we could receive from Him guidance to ensure our safe return. Yes, I speak of prayer. I speak, too, of the whisperings from that still, small voice within each of us; and I do not overlook the holy scriptures, written by mariners who successfully sailed the seas we too must cross.

At some period in our mortal mission, there appears the faltering step, the wan smile, the pain of sickness—even the fading of summer, the approach of autumn, the chill of winter, and the experience we call death.

Every thoughtful person has asked himself the question best phrased by Job of old: “If a man die, shall he live again?” (Job 14:14). Try as we may to put the question out of our thoughts, it always returns. Death comes to all mankind. It comes to the aged as they walk on faltering feet. Its summons is heard by those who have scarcely reached midway in life’s journey, and often it hushes the laughter of little children.

But what of an existence beyond death? Is death the end of all? Such a question was asked of me by a young husband and father who lay dying. I turned to the Book of Mormon and, from the book of Alma, read to him these words:

“Now, concerning the state of the soul between death and the resurrection—Behold, it has been made known unto me by an angel, that the spirits of all men, as soon as they are departed from this mortal body, yea, the spirits of all men, whether they be good or evil, are taken home to that God who gave them life.

“And then shall it come to pass, that the spirits of those who are righteous are received into a state of happiness, which is called paradise, a state of rest, a state of peace, where they shall rest from all their troubles and from all care, and sorrow” (Alma 40:11–12).

My young friend through moist eyes and with an expression of profound gratitude whispered a silent, but eloquent, “Thank you.”

After the body of Jesus had lain in the tomb for three days, the spirit again entered, and the resurrected Redeemer walked forth clothed with an immortal body of flesh and bones.

The answer to Job’s question, “If a man die, shall he live again?” came when Mary and others approached the tomb and saw two men in shining garments who spoke to them: “Why seek ye the living among the dead?

“He is not here, but is risen” (Luke 24:5–6).

Testimonies of the resurrected Lord provide comfort and understanding:

First, from the Apostle Paul:

“Christ died for our sins according to the scriptures; … he was buried, and … he rose again the third day: … he was seen of Cephas, then of the twelve: … he was seen of above five hundred brethren at once … he was seen of James; then of all the apostles. And last of all he was seen of me also, as of one born out of due time” (1 Cor. 15:3–8).

Second, from the combined testimony of twenty-five hundred of his other sheep, as recorded in the Book of Mormon, Another Testament of Jesus Christ, the resurrected Lord “spake unto them saying:

“Arise and come forth unto me, that ye may thrust your hands into my side, and also that ye may feel the prints of the nails in my hands and in my feet, that ye may know that I am the God of Israel, and the God of the whole earth, and have been slain for the sins of the world. …

“And when they had all gone forth and had witnessed for themselves, they did cry out with one accord, saying:

“Hosanna! Blessed be the name of the Most High God! And they did fall down at the feet of Jesus, and did worship him” (3 Ne. 11:13–14, 16–17).

Third, from Joseph Smith: “After the many testimonies which have been given of him, this is the testimony, last of all, which we give of him: That He lives!

“For we saw him, even on the right hand of God; and we heard the voice bearing record that he is the Only Begotten of the Father—

“That by him, and through him, and of him, the worlds are and were created, and the inhabitants thereof are begotten sons and daughters unto God” (D&C 76:22–24).

As the result of Christ’s victory over the grave, we shall all be resurrected. This is the redemption of the soul. Paul wrote:

“There are … celestial bodies, and bodies terrestrial: but the glory of the celestial is one, and the glory of the terrestrial is another.

“There is one glory of the sun, and another glory of the moon, and another glory of the stars: for one star differeth from another star in glory.

“So also is the resurrection of the dead” (1 Cor. 15:40–42).

It is the celestial glory which we seek. It is in the presence of God we desire to dwell. It is a forever family in which we want membership. Such blessings must be earned.

Where did we come from? Why are we here? Where do we go after this life? No longer need these universal questions remain unanswered. Our Heavenly Father rejoices for those who keep His commandments. He is concerned also for the lost child, the tardy teenager, the wayward youth, the delinquent parent. Tenderly the Master speaks to these, and indeed to all: “Come back. Come home. Come unto me.” What eternal joy awaits when we accept His divine invitation to exaltation.

I testify He is a teacher of truth—but He is more than a teacher. He is the exemplar of the perfect life—but He is more than an exemplar. He is the great physician—but He is more than a physician. He is the literal Savior of the World, the Son of God, the Prince of Peace, the Holy One of Israel, even the risen Lord, who declared: “I am Jesus Christ, whom the prophets testified shall come into the world. …

“I am the light and the life of the world” (3 Ne. 11:10–11).

“I am the first and the last; I am he who liveth, I am he who was slain; I am your advocate with the Father” (D&C 110:4).

As his witness I testify to you that He lives, in the name of Jesus Christ, amen.

# References
