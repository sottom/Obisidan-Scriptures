Dwan J. Young
Recently Released Primary General President
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/teach-children-the-gospel?lang=eng)

Holly loved the towering pine tree in front of her home. Its branches shaded her favorite place to play.

The day of the accident, there were three younger children listening to Holly read under the tree. Suddenly, in her mind, something whispered to her. Holly’s heart started to thump as the command echoed in her head, “Move!” She responded at once. Scrambling to her feet, she shouted to the children to run. She grabbed the smallest one, and the rest followed. The children thought it was a game until they heard a terrible crash.

A driver had lost control of his car and hit the big pine tree where the children had been reading only minutes before. They would have been badly hurt if they hadn’t moved. Some of the children were so frightened that they started to cry. But not Holly. She was thinking about the small voice she had heard in her mind and heart that told her to move. She knew that the warning had come to her from the Holy Ghost. The gift that she had received from Heavenly Father after she had been baptized and confirmed had helped her, just as she had been promised (see Elaine Cannon, Baptized and Confirmed: Your Lifeline to Heaven, Salt Lake City: Bookcraft, 1986, pp. 36–37).

Now, there are many Hollys among us—children who have been taught to be sensitive to the Spirit. Who are these children? Our beloved President Benson told us not long ago, “God has saved for the final inning some of His stronger and most valiant children, who will help bear off the kingdom triumphantly” (Ensign, April 1987, p. 73). They are all sons and daughters of God, each with a special mission to perform. Their self-esteem grows as they learn who they truly are.

But many of our children today are learning under less than ideal circumstances. Even in elementary schools, some of the children are confronted with drugs, alcohol, profane language, and even immorality among their classmates. In many cases, family members are involved in so many activities away from home that there is no time for parents and children to develop meaningful relationships with one another. Fewer families are praying together and eating their meals together. Fewer fathers are spending time with their children, and more mothers are too tired at the end of the day to share an hour of reading or visiting with their children. Time that could be spent with family members is often spent watching television. By the age of eighteen, a child has typically spent more time in front of the television set than in school.

In this kind of an environment, we must take time to teach the children about the important things of life—about Heavenly Father, the Savior, and the Holy Ghost. We must teach them about repentance, baptism, honesty, and doing good to others. Now, you might say, “I’m not a parent; I don’t teach children.” Actually, we are all teachers of children—parents, aunts, uncles, grandparents, priesthood leaders, ward members, neighbors. Children are always watching and learning. We teach them through our behavior as well as by what we say. They watch how we treat each other. They listen to the voices of their parents and to the voices at church. Unfortunately, they also listen to voices on television and elsewhere which sometimes teach values contrary to gospel principles. We must teach them at an early age to listen to the right voices, as Holly did.

Over the years, I’ve learned certain truths about children I’d like to share with you.

First, children want to be taught. This was brought home to me when I was visiting a Primary in Bolivia. I planned to visit an older class when three little girls tugged at my sleeve. They had been to their classroom, but they came back because there was no teacher. “Please, will you teach us?” they asked. “We need a teacher.” This was one of the sweetest teaching experiences I have ever had because those children were thirsty for gospel truths.

Second, children understand quiet whisperings of the Spirit, as Holly understood.

Third, as children learn, they can have a great influence for good. One young girl was taught a lesson about temples and eternal families. She went home and asked her father what would happen to her, because her family wasn’t sealed. Would she be given to another family? The faith of this tender soul touched her father and moved him to action. Within a year their family was sealed in the temple.

Fourth, parents are commanded to teach their children gospel principles. In Doctrine and Covenants 68:25 [D&C 68:25], the Lord instructs parents to teach their children “the doctrine of repentance, faith in Christ the Son of the living God, and of baptism and the gift of the Holy Ghost by the laying on of the hands.”

The Savior also teaches parents something more—that they should be as teachable as their children. He said, “Teach parents that they must repent and be baptized, and humble themselves as their little children, and they shall all be saved with their little children” (Moro. 8:10).

Fifth, gospel truths make a difference in the lives of children. Over the past few years, I’ve seen countless examples of children who have been taught gospel principles. When they learn these truths, they build a reservoir of strength to draw from throughout their lives. Let me share two examples with you.

Eight-year-old Annie spent a night at her friend’s house. When they finally settled down, their conversation turned to serious things. Were the scriptures true? They each asked Heavenly Father in their prayers and felt a strong witness from the Spirit that, yes, the scriptures are true. The next day Annie told her mother about that witness of the Spirit and made a commitment to start regular scripture study.

Now, like most eleven-year-old boys, Steven loved basketball. One afternoon he went with his friends to watch a game on television. Thirty minutes later, he returned home. His mother was surprised because she knew the game wasn’t over. When she questioned Steven, he said the boys had decided to watch a different program, but the program made him feel dark inside. That feeling had helped Steven recognize he was in a setting where the Spirit could not be present, and he was too uncomfortable to stay.

Although it is our responsibility to teach the children, they often teach us.

I shall be eternally grateful for my Primary experience and for all that the children have taught me.

I am also grateful for loving parents and dedicated Primary leaders, including those who have served by my side, who faithfully teach eternal principles of the gospel of Jesus Christ to our children. May each of us recognize the importance of teaching children.

On this beautiful Easter Sunday I bear witness that Jesus Christ lived and died for us, and that he lives again. He is my Savior, my example, my friend, and I love him. I pledge my continued devotion and service to him, in the name of Jesus Christ, amen.

# References
