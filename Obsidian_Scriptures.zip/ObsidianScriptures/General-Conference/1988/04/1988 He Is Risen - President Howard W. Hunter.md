President Howard W. Hunter
Acting President of the Quorum of the Twelve Apostles
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/he-is-risen?lang=eng)

On this beautiful and sacred Easter weekend, surely no doctrine will be the subject of more sermons nor the object of more praise than that of the atoning sacrifice and the literal resurrection of the Lord, Jesus Christ. And so it should be at Easter and at every other season of the year, for no doctrine in the Christian canon is more important to all mankind than the doctrine of the resurrection of the Son of God. Through him came the resurrection of all men, women, and children who have ever been—or ever will be—born into the world.

In spite of the great importance we place upon the Resurrection in our doctrine, perhaps many of us may not yet have fully glimpsed its spiritual significance and eternal grandeur. If we had, we would marvel at its beauty as did Jacob, the brother of Nephi, and we would shudder at the alternative we would have faced had we not received this divine gift. Jacob wrote:

“O the wisdom of God, his mercy and grace! For behold, if the flesh should rise no more our spirits must become subject to that angel who fell from before the presence of the Eternal God, and became the devil, to rise no more” (2 Ne. 9:8).

Surely the Resurrection is the center of every Christian’s faith; it is the greatest of all of the miracles performed by the Savior of the world. Without it, we are indeed left hopeless. Let me borrow the words of Paul: “If there be no resurrection of the dead, … then is our preaching vain, … and we are found false witnesses of God; because we have testified of God that he raised up Christ. … If Christ be not raised, your faith is vain; ye are yet in your sins” (1 Cor. 15:13–15, 17).

Go with me back in time to those final scenes in the Holy Land. The end of our Lord’s mortal life was near. He had healed the sick, raised the dead, and expounded the scriptures, including those prophecies of his own death and resurrection. He said to his disciples:

“Behold, we go up to Jerusalem; and the Son of man shall be betrayed unto the chief priests and unto the scribes, and they shall condemn him to death,

“And shall deliver him to the Gentiles to mock, and to scourge, and to crucify him: and the third day he shall rise again” (Matt. 20:18–19).

There in Jerusalem, the Sadducees accosted him and questioned him concerning the resurrection. They had conspired to trap him, but he taught them the simple truths of the living gospel.

“Have ye not read that which was spoken unto you by God?” he asked.

“I am the God of Abraham, and the God of Isaac, and the God of Jacob? God is not the God of the dead, but of the living.

“And when the multitude heard this, they were astonished at his doctrine” (Matt. 22:31–33).

Later, as they met to celebrate the Passover, Jesus and his Apostles partook of the sacramental emblems that he initiated in this last supper together, and then walked to the Mount of Olives.

Always the teacher to the very end, he continued his discourse on the theme of the sacrificial lamb. He told them he would be smitten, and that they would be scattered as sheep without a shepherd (see Matt. 26:31). “But after I am risen again,” he said, “I will go before you into Galilee” (Matt. 26:32).

In the hours that followed, he sweat drops of blood, was scourged by the very leaders who claimed to be custodians of his law, and was crucified in the company of thieves. It was as King Benjamin in the Book of Mormon prophesied: “He shall suffer temptations, and pain of body, hunger, thirst, and fatigue, even more than man can suffer, except it be unto death; for behold, blood cometh from every pore, so great shall be his anguish for the wickedness and the abominations of his people. …

“… He cometh unto his own, that salvation might come unto the children of men; … and even after all this they shall consider him a man, and say that he hath a devil, and shall scourge him, and shall crucify him” (Mosiah 3:7, 9).

We are indebted to the prophet Alma for our knowledge of the full measure of His suffering: “He shall go forth, suffering pains and afflictions and temptations of every kind; and this that the word might be fulfilled which saith he will take upon him the pains and the sicknesses of his people.

“And he will take upon him death, that he may loose the bands of death which bind his people; and he will take upon him their infirmities, that his bowels may be filled with mercy, according to the flesh, that he may know according to the flesh how to succor his people according to their infirmities” (Alma 7:11–12).

Think of it! When his body was taken from the cross and hastily placed in a borrowed tomb, he, the sinless Son of God, had already taken upon him not only the sins and temptations of every human soul who will repent, but all of our sickness and grief and pain of every kind. He suffered these afflictions as we suffer them, according to the flesh. He suffered them all. He did this to perfect his mercy and his ability to lift us above every earthly trial.

But there remained one more set of chains to be broken before the Atonement could be complete: the bands of death. The prophets of the Old Testament had taught that the Resurrection would be certain and would be universal. Also, the Book of Mormon prophets taught the doctrine of the Resurrection with great plainness. Nephi wrote:

“Behold, they will crucify him; and after he is laid in a sepulchre for the space of three days he shall rise from the dead, with healing in his wings; and all those who shall believe on his name shall be saved in the kingdom of God” (2 Ne. 25:13).

And Samuel the Lamanite prophesied to the Nephites:

“For behold, he surely must die that salvation may come; yea, it behooveth him and becometh expedient that he dieth, to bring to pass the resurrection of the dead, that thereby men may be brought into the presence of the Lord” (Hel. 14:15).

Enoch was shown in a vision the day of the coming of the Son of Man:

“And the Lord said unto Enoch: Look, and he looked and beheld the Son of Man lifted up on the cross, after the manner of men;

“And he heard a loud voice; and the heavens were veiled; and all the creations of God mourned; and the earth groaned; and the rocks were rent; and the saints arose, and were crowned at the right hand of the Son of Man, with crowns of glory;

“And as many of the spirits as were in prison came forth, and stood on the right hand of God; and the remainder were reserved in chains of darkness until the judgment of the great day” (Moses 7:55–57).

As the dawn of that third day was beginning, Mary Magdalene and “the other Mary” had come to the sepulchre in which his lifeless body had been laid. Earlier, the chief priests and the Pharisees had gone to Pilate and persuaded him to place a guard at the door of the sepulchre, “lest his disciples come by night, and steal him away, and say unto the people, He is risen from the dead” (Matt. 27:64). But two mighty angels had rolled the stone from the door of the tomb, and the would-be guards had fled in terror at the sight.

When the women came to the tomb, they found it open and empty. The angels had tarried to tell them the greatest news ever to fall on human ears: “He is not here: for he is risen, as he said” (Matt. 28:6).

The resurrection of Jesus was followed immediately by the resurrection of other righteous souls. Matthew records that “the graves were opened; and many bodies of the saints which slept arose,

“And came out of the graves after his resurrection, and went into the holy city, and appeared unto many” (Matt. 27:52–53).

In the days that followed his resurrection, the Lord appeared unto many. He displayed his five special wounds to them. He walked and talked and ate with them, as if to prove beyond a doubt that a resurrected body is indeed a physical body of tangible flesh and bones. Later he ministered to the Nephites, whom he commanded to “arise and come forth unto me, that ye may thrust your hands into my side, and also that ye may feel the prints of the nails in my hands and in my feet, that ye may know that I am the God of Israel, and the God of the whole earth, and have been slain for the sins of the world.

“And … the multitude went forth, and thrust their hands into his side, and did feel the prints of the nails in his hands and in his feet; and this they did do, going forth one by one until they had all gone forth, and did see with their eyes and did feel with their hands, and did know of a surety and did bear record, that it was he, of whom it was written by the prophets, that should come” (3 Ne. 11:14–15).

It is the responsibility and joy of all men and women everywhere to “seek this Jesus of whom the prophets and apostles have [testified]” (Ether 12:41) and to have the spiritual witness of his divinity. It is the right and blessing of all who humbly seek, to hear the voice of the Holy Spirit, bearing witness of the Father and his resurrected Son.

As one called and ordained to bear witness of the name of Jesus Christ to all the world, I testify at this Easter season that he lives. He has a glorified, immortal body of flesh and bones. He is the Only Begotten Son of the Father in the flesh. He is the Savior, the Light and Life of the world. Following his crucifixion and death, he appeared as a resurrected being to Mary, to Peter, to Paul, and to many others. He showed himself to the Nephites. He has shown himself to Joseph Smith, the boy prophet, and to many others in our dispensation. This is his church; he leads it today through his prophet, Ezra Taft Benson. Of this I testify in the name of Jesus Christ, amen.

# References
