Elder Boyd K. Packer
Of the Quorum of the Twelve Apostles
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/atonement-agency-accountability?lang=eng)

The Lord had come from Gethsemane; before Him was His crucifixion. At the moment of betrayal, Peter drew his sword against Malchus, a servant of the high priest. Jesus said:

“Put up again thy sword into his place. …

“Thinkest thou that I cannot now pray to my Father, and he shall presently give me more than twelve legions of angels?” (Matt. 26:52–53).

During all of the taunting, the abuse, the scourging, and the final torture of crucifixion, the Lord remained silent and submissive. Except, that is, for one moment of intense drama which reveals the very essence of Christian doctrine.

That moment came during the trial. Pilate, now afraid, said to Jesus: “Speakest thou not unto me? knowest thou not that I have power to crucify thee, and have power to release thee?” (John 19:10).

One can only imagine the quiet majesty when the Lord spoke. “Thou couldest have no power at all against me, except it were given thee from above” (John 19:11).

What happened thereafter did not come because Pilate had power to impose it, but because the Lord had the will to accept it.

“I lay down my life,” the Lord said, “that I might take it again.

“No man taketh it from me, but I lay it down of myself. I have power to lay it down, and I have power to take it again” (John 10:17–18).

Before the Crucifixion and afterward, many men have willingly given their lives in selfless acts of heroism. But none faced what the Christ endured. Upon Him was the burden of all human transgression, all human guilt.

And hanging in the balance was the Atonement. Through His willing act, mercy and justice could be reconciled, eternal law sustained, and that mediation achieved without which mortal man could not be redeemed.

He, by choice, accepted the penalty for all mankind for the sum total of all wickedness and depravity; for brutality, immorality, perversion, and corruption; for addiction; for the killings and torture and terror—for all of it that ever had been or all that ever would be enacted upon this earth.

In choosing, He faced the awesome power of the evil one who was not confined to flesh nor subject to mortal pain. That was Gethsemane!

How the Atonement was wrought, we do not know. No mortal watched as evil turned away and hid in shame before the light of that pure being.

All wickedness could not quench that light. When what was done was done, the ransom had been paid. Both death and hell forsook their claim on all who would repent. Men at last were free. Then every soul who ever lived could choose to touch that light and be redeemed.

By this infinite sacrifice, through this atonement of Christ, all mankind may be saved by obedience to the laws and ordinances of the gospel.

Atonement is really three words: At-one-ment, meaning to set at one, one with God; to reconcile, to conciliate, to expiate.

But did you know that the word atonement appears only once in the English New Testament? Only once! I quote from Paul’s letter to the Romans:

“Christ died for us. …

“We were reconciled to God by the death of his Son, much more, being reconciled, we shall be saved by his life.

“And not only so, but we also joy in God through our Lord Jesus Christ, by whom we have now received the atonement” (Rom. 5:8, 10–11; italics added).

Only that once does the word atonement appear in the English New Testament. Atonement, of all words! It was not an unknown word, for it had been used much in the Old Testament in connection with the law of Moses, once only in the New Testament. I find that to be remarkable.

I know of only one explanation. For that we turn to the Book of Mormon.

Nephi testified that the Bible once “contained the fulness of the gospel of the Lord, of whom the twelve apostles bear record” (1 Ne. 13:24) and that “After [the words] go forth by the hand of the twelve apostles of the Lamb, from the Jews unto the Gentiles, thou seest the formation of that great and abominable church, which is most abominable above all other churches; for behold, they have taken away from the gospel of the Lamb many parts which are plain and most precious; and also many covenants of the Lord have they taken away” (1 Ne. 13:26).

Jacob defined the great and abominable church in these words:

“Wherefore, he that fighteth against Zion, both Jew and Gentile, both bond and free, both male and female, shall perish; for they are they who are the whore of all the earth; for they who are not for me are against me, saith our God” (2 Ne. 10:16).

Nephi said, “Because of the many plain and precious things which have been taken out of the book, … an exceedingly great many do stumble, yea, insomuch that Satan hath great power over them” (1 Ne. 13:29).

He then prophesied that the precious things would be restored (see 1 Ne. 13:34–35).

And they were restored. In the Book of Mormon the word atone in form and tense appears fifty-five times. I quote but one verse from Alma: “And now, the plan of mercy could not be brought about except an atonement should be made; therefore God himself atoneth for the sins of the world, to bring about the plan of mercy, to appease the demands of justice, that God might be a perfect, just God, and a merciful God also” (Alma 42:15; italics added).

Only once in the New Testament—fifty-five times in the Book of Mormon. What better witness that the Book of Mormon is indeed another testament of Jesus Christ?

And that is not all. The words atone, atonement, atoneth, appear in the Doctrine and Covenants eleven times and in the Pearl of Great Price three. Sixty-nine references of transcendent importance. And that is not all! Hundreds of other verses help to explain it.

The cost of the Atonement was borne by the Lord without compulsion, for agency is a sovereign principle. According to the plan, agency must be honored. It was so from the beginning, from Eden.

“The Lord said unto Enoch: Behold these thy brethren; they are the workmanship of mine own hands, and I gave unto them their knowledge, in the day I created them; and in the Garden of Eden, gave I unto man his agency” (Moses 7:32).

Whatever else happened in Eden, in his supreme moment of testing, Adam made a choice.

After the Lord commanded Adam and Eve to multiply and replenish the earth and commanded them not to partake of the tree of knowledge of good and evil, He said: “Nevertheless, thou mayest choose for thyself, for it is given unto thee; but, remember that I forbid it, for in the day thou eatest thereof thou shalt surely die” (Moses 3:17).

There was too much at issue to introduce man into mortality by force. That would contravene the very law essential to the plan. The plan provided that each spirit child of God would receive a mortal body and each would be tested. Adam saw that it must be so and made his choice. “Adam fell that men might be; and men are, that they might have joy” (2 Ne. 2:25).

Adam and Eve ventured forth to multiply and replenish the earth as they had been commanded to do. The creation of their bodies in the image of God, as a separate creation, was crucial to the plan. Their subsequent fall was essential if the condition of mortality was to exist and the plan proceed.

Jacob described what would happen to our bodies and our spirits except an atonement, an infinite atonement, were made. We should, he said, have become “like unto [the devil]” (see 2 Ne. 9:7–9).

I seldom use the word absolute. It seldom fits. I use it now—twice. Because of the Fall, the Atonement was absolutely essential for resurrection to proceed and overcome mortal death.

The Atonement was absolutely essential for men to cleanse themselves from sin and overcome the second death, which is the spiritual death, which is separation from our Father in Heaven. For the scriptures tell us, seven times they tell us, that no unclean thing may enter the presence of God.



Those scriptural words, “Thou mayest choose for thyself, for it is given unto thee” (Moses 3:17), introduced Adam and Eve and their posterity to all the risks of mortality. In mortality men are free to choose, and each choice begets a consequence. The choice Adam made energized the law of justice, which required that the penalty for disobedience would be death.

But those words spoken at the trial, “Thou couldest have no power at all against me, except it were given thee from above” (John 19:11), proved mercy was of equal rank. A redeemer was sent to pay the debt and set men free. That was the plan.

Alma’s son Corianton thought it unfair that penalties must follow sin, that there need be punishment. In a profound lesson Alma taught the plan of redemption to his son, and so to us.

Alma spoke of the Atonement and said, “Now, repentance could not come unto men except there were a punishment” (Alma 42:16).

If punishment is the price repentance asks, it comes at bargain price. Consequences, even painful ones, protect us. So simple a thing as a child’s cry of pain when his finger touches fire can teach us that. Except for the pain, the child might be consumed.

I readily confess that I would find no peace, neither happiness nor safety, in a world without repentance. I do not know what I should do if there were no way for me to erase my mistakes. The agony would be more than I could bear. It may be otherwise with you, but not with me.

An atonement was made. Ever and always it offers amnesty from transgression and from death if we will but repent. Repentance is the escape clause in it all. Repentance is the key with which we can unlock the prison from inside. We hold that key within our hands, and agency is ours to use it.

How supernally precious freedom is; how consummately valuable is the agency of man.

Lucifer in clever ways manipulates our choices, deceiving us about sin and consequences. He, and his angels with him, tempt us to be unworthy, even wicked. But he cannot, in all eternity he cannot, with all his power he cannot completely destroy us; not without our own consent. Had agency come to man without the Atonement, it would have been a fatal gift.

We are taught in Genesis, in Moses, in Abraham, in the Book of Mormon, and in the endowment that man’s mortal body was made in the image of God in a separate creation. Had the Creation come in a different way, there could have been no Fall.

If men were merely animals, then logic favors freedom without accountability.

How well I know that among learned men are those who look down at animals and stones to find the origin of man. They do not look inside themselves to find the spirit there. They train themselves to measure things by time, by thousands and by millions, and say these animals called men all came by chance. And this they are free to do, for agency is theirs.

But agency is ours as well. We look up, and in the universe we see the handiwork of God and measure things by epochs, by eons, by dispensations, by eternities. The many things we do not know we take on faith.

But this we know! It was all planned before the world was. Events from the Creation to the final, winding-up scene are not based on chance; they are based on choice! It was planned that way.

This we know! This simple truth! Had there been no Creation, no Fall, there should have been no need for any Atonement, neither a Redeemer to mediate for us. Then Christ need not have been.

At Gethsemane and Golgotha the Savior’s blood was shed. Centuries earlier the Passover had been introduced as a symbol and a type of things to come. It was an ordinance to be kept forever (see Ex. 12).

When the plague of death was decreed upon Egypt, each Israelite family was commanded to take a lamb, firstborn, male, without blemish. This paschal lamb was slain without breaking any bones, its blood to mark the doorway of the home. The Lord promised that the angel of death would pass over the homes so marked and not slay those inside. They were saved by the blood of the lamb.

After the crucifixion of the Lord, the law of sacrifice required no more shedding of blood. For that was done, as Paul taught the Hebrews, “once for all, … one sacrifice for sins for ever” (Heb. 10:10, 12). The sacrifice thenceforth was to be a broken heart and a contrite spirit—repentance.

And the Passover would be commemorated forever as the sacrament, in which we renew our covenant of baptism and partake in remembrance of the body of the Lamb of God and of His blood, which was shed for us.

It is no small thing that this symbol reappears in the Word of Wisdom. Beyond the promise that Saints in this generation, who obey, will receive health and great treasures of knowledge is this: “I, the Lord, give unto them a promise, that the destroying angel shall pass by them, as the children of Israel, and not slay them” (D&C 89:21).

I cannot with composure tell you how I feel about the Atonement. It touches the deepest emotion of gratitude and obligation. My soul reaches after Him who wrought it, this Christ, our Savior of whom I am a witness. I testify of Him. He is our Lord, our Redeemer, our advocate with the Father. He ransomed us with His blood.

Humbly I lay claim upon the atonement of Christ. I find no shame in kneeling down in worship of our Father and His son. For agency is mine, and this I choose to do!

In the name of Jesus Christ, amen.

# References
