President Thomas S. Monson
Second Counselor in the First Presidency
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/the-sustaining-of-church-officers?lang=eng)

My brothers and sisters, I shall now present to you the General Authorities and general officers of the Church for your sustaining vote.

It is proposed that we sustain President Ezra Taft Benson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Gordon B. Hinckley as First Counselor in the First Presidency; and Thomas S. Monson as Second Counselor in the First Presidency. Those in favor may manifest it. Those opposed may manifest it.

It is proposed that we sustain President Marion G. Romney as President of the Council of the Twelve Apostles, Howard W. Hunter as Acting President of the Council of the Twelve Apostles, and the following as members of that council: Marion G. Romney, Howard W. Hunter, Boyd K. Packer, Marvin J. Ashton, L. Tom Perry, David B. Haight, James E. Faust, Neal A. Maxwell, Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, and Joseph B. Wirthlin.

Those in favor, please manifest it. Any opposed.

It is proposed that we sustain the Counselors in the First Presidency and the Twelve Apostles as prophets, seers, and revelators. All in favor, please manifest it. Contrary, if there be any, by the same sign.

It is proposed that we sustain Robert Edward Sackley and Larry Lionel Kendrick as additional members of the First Quorum of the Seventy to serve for a period of five years and sustain all other General Authorities as at present constituted. All in favor, please signify. Those opposed may manifest it.

Sister Dwan J. Young has accepted a call to accompany her husband to his assignment as president of the Canada Calgary Mission. It is therefore necessary to release her as general president of the Primary Association. We also release her counselors, Virginia B. Cannon and Michaelene P. Grassli, and all members of the Primary General Board. All who wish to join in an expression of appreciation to these sisters for their dedicated, effective service may now do so by the uplifted hand.

It is proposed that we sustain Sister Michaelene P. Grassli as general president of the Primary Association with Betty Jo Nelson Jepsen as first counselor and Ruth Broadbent Wright as second counselor. Those in favor, please manifest it. Any opposed, by the same sign.

It is proposed that we sustain all of the other General Authorities and general officers of the Church as at present constituted.

Those in favor, please manifest it. Those opposed, by the same sign.

President Benson, it appears that the voting has been unanimous in the affirmative. We invite the newly sustained General Authorities and General Primary Presidency to take their places on the stand.

# References
