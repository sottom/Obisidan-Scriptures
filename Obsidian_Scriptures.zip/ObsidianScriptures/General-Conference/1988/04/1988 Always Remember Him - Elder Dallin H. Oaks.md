Elder Dallin H. Oaks
Of the Quorum of the Twelve Apostles
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/always-remember-him?lang=eng)

In April 1830 the Lord commanded the members of his newly restored Church to “meet together often to partake of bread and wine in the remembrance of the Lord Jesus” (D&C 20:75). This was the same instruction he gave when he introduced this ordinance nearly 2,000 years ago. Luke writes:

“And he took bread, and gave thanks, and brake it, and gave unto them, saying, This is my body which is given for you: this do in remembrance of me” (Luke 22:19).

When we partake of the sacrament, we witness unto God the Eternal Father that we “do always remember” his Son (see D&C 20:77, 79; 3 Ne. 18:7, 11). Each Sabbath day millions of Latter-day Saints make this promise. What does it mean to “always remember” our Savior?

To remember means to keep in memory. In the scriptures, it often means to keep a person in memory, together with associated emotions like love, loyalty, or gratitude. The stronger the emotion, the more vivid and influential the memory. Here are some examples:





Most of us have the clearest memories of our mortal parents, who gave us birth and nurtured us through childhood. This kind of memory does not dim with the passing years, but with wisdom and perspective becomes ever more meaningful. As I grow older, I think more frequently of my father and my mother. I will always remember them.





Shortly before my wife was to give birth to our first child, we learned that the baby must be born by cesarean section. I was then a student at Brigham Young University, going to school full time and working almost full time. From my meager earnings, a little over $1.00 an hour, we had saved enough money for the hospital and doctor bills, but nothing in our plans or emotions had prepared us for this shocking announcement. We scarcely knew what a cesarean birth was, and we feared the worst.

A few days later we faced our ordeal. After what seemed an eternity, I stood at a window in the hospital hallway, looking into a basket containing our firstborn. The joy of seeing her and knowing that my beloved companion had survived the operation was inexpressible. As I experienced that moment, I became aware of a stranger standing beside me. He introduced himself as Dr. N. Frederick Hicken, the surgeon who had come from Salt Lake City to perform the operation. His presence reminded me that a surgeon’s fee had not been in our plans, and I began to ask him if I could pay his fee over a period of time. “Don’t worry about that, young man,” he said in a kindly way. “This is one from the Hickens to the Oakses.” Before I could stammer a thank-you, he was gone.

I was filled with wonder at this unexpected gift. Our benefactor must have known my father, a young medical doctor who died when I was a boy. He must have given us this gift because of something my father had done. I marveled at the goodness of this man who had come to us in our crisis and had, without recompense, used his powers to preserve the lives of those I loved. The emotion of that moment made the memory indelible. The name of that doctor is precious to me. I will always remember him.





Some time ago, someone praised me for something I had done. Even as I received that compliment I knew I did not deserve it. The credit belonged to wise and wonderful teachers who had taught me what to do and how to do it. My teachers were memorable. I shudder to think what I would have lost if teachers had not helped me want to learn and then taught me what I needed to know. I will always be grateful to my teachers. I will always remember them.





By now you must surely realize that I have given these three examples because the reasons why I will always remember these persons are related to the reasons why we should always remember Jesus Christ: He is our Creator, our Redeemer, and our Teacher.





Our Creator, Our Redeemer, Our Teacher



Under the direction and according to the plan of God the Father, his Son Jehovah “created the heavens and the earth, and all things that in them are” (3 Ne. 9:15). He gave us life in the beginning of this world, and through the power of his resurrection he will give each of us life again after we have died in mortality. Jesus Christ is the life of the world.

He is our Redeemer. According to the Father’s plan, he provided the atoning sacrifice that can rescue us from the extremity of spiritual death. As a free-will offering, the Only Begotten Son of God came to earth and shed his blood for the remission of our sins (see D&C 27:2).

Our Creator and our Redeemer is also our teacher. He taught us how to live. He gave us commandments, and if we follow them, we will receive blessings and happiness in this world and eternal life in the world to come.

And so we see that He whom we should always remember is He who gave us mortal life, He who showed us the way to a happy life, and He who redeems us so we can have immortality and eternal life.

If we keep our covenant that we will always remember him, we can always have his Spirit to be with us (see D&C 20:77, 79). That Spirit will testify of him, and it will guide us into truth.

His teachings and his example will guide and strengthen us in the way we should live. The effect was described in the words of the once popular song, “Try to remember, and if you remember, then follow” (“Try to Remember,” words by Tom Jones).

I will now refer to some of these teachings we should remember and follow.







Serve as Called



Follow is the word the Savior used when he called his helpers to the ministry. As he was walking by the Sea of Galilee, he saw two fishermen, Simon Peter and his brother Andrew, at work in their vocation. “And he saith unto them, Follow me, and I will make you fishers of men” (Matt. 4:19). “And straightway they forsook their nets, and followed him” (Mark 1:18).

Here the Savior established a pattern for those he calls to do his work. Acting through his servants, for he has said that “by mine own voice or by the voice of my servants, it is the same” (D&C 1:38), he calls us to take time from our daily activities to follow him and serve our fellowmen. Even the greatest among us should be the servant of all (see Mark 10:43–44). Those who always remember him will straightway assume and faithfully fulfill the responsibilities to which they are called by his servants.







Forgive Others



Among the things we should remember about the Savior is that there are things we should forget about our fellowmen—the wrongs they have done us. “Lord,” the Apostle Peter asked the Master, “how oft shall my brother sin against me, and I forgive him? till seven times?” (Matt. 18:21). In response, Jesus taught the parable of the unforgiving servant. This man owed a large debt to his king. When he begged for mercy, the king was moved with compassion and forgave the debt. But when a fellow servant owed him a debt, this man took his debtor by the throat and cast him into prison until he should pay it. When the unforgiving servant was brought to judgment, the king said:

“Shouldest not thou also have had compassion on thy fellowservant, even as I had pity on thee?

“And his lord was wroth, and delivered him to the tormentors, till he should pay all that was due unto him.

“So likewise shall my heavenly Father do also unto you,” Jesus concluded (Matt. 18:33–35; see also Matt. 6:14–15; 3 Ne. 13:14–15).

As the Lord has told us in modern revelation, “He that forgiveth not his brother his trespasses standeth condemned before the Lord; for there remaineth in him the greater sin” (D&C 64:9). If we always remember our Savior, we will forgive and forget grievances against those who have wronged us.







Receive Ordinances



At the beginning of his ministry, Jesus sought out John the Baptist, who was preaching the baptism of repentance for the remission of sins (see Mark 1:4).

“Then cometh Jesus from Galilee to Jordan unto John, to be baptized of him.

“But John forbade him, saying, I have need to be baptized of thee, and comest thou to me?

“And Jesus answering said unto him, Suffer it to be so now: for thus it becometh us to fulfil all righteousness” (Matt. 3:13–15).

Those who seek to follow the Savior will understand the importance of the ordinance of baptism. The Lamb without Blemish saw fit to submit himself to baptism by one holding the authority of the priesthood in order to “fulfil all righteousness.” How much more each of us has need of the cleansing and saving power of this ordinance and the other ordinances of the gospel.

As we always remember him, we should strive to assure that we and our family members and, indeed, all the sons and daughters of God everywhere follow our Savior into the waters of baptism. This reminds each of us of our duties to proclaim the gospel, perfect the Saints, and redeem the dead.







Endure Afflictions



Remembering the Savior can also help us understand and endure the inevitable afflictions of this life. The Savior taught:

“Blessed are ye, when men shall revile you, and persecute you, and shall say all manner of evil against you falsely, for my sake.

“Rejoice, and be exceeding glad: for great is your reward in heaven: for so persecuted they the prophets which were before you” (Matt. 5:11–12).







Minister to the Sick and the Afflicted



When the Risen Lord appeared to the people on this continent, he taught them and called leaders and gave them the authority of his priesthood. Next he healed the sick, the lame, the blind, and all others who were afflicted in any manner. Then “he commanded that their little children should be brought” (3 Ne. 17:11). And he “blessed them, and prayed unto the Father for them” (3 Ne. 17:21).

As I remember this inspiring example, I also remember visits and letters I have had from persons caring for loved ones who are sick or who are afflicted with the infirmities of old age. I also remember loved ones grieving over little children with life-shortening or crippling physical or emotional disabilities. How their hearts ache for their little ones! How they need our love and support! I also remember the words, “Inasmuch as ye have done it unto one of the least of these my brethren, ye have done it unto me” (Matt. 25:40). Here our Savior gives an assurance of blessings for those who carry such burdens and a challenge for others who can lend them support.







Love Our Neighbors



We should always remember how the Savior taught us to love and do good to one another. Loving and serving one another can solve so many problems!

I recently received a letter from a sister in another country. She wrote about the plight of single adult members of the Church. “Where do I fit in?” she asked. She longed to join in church social activities, but she said they were always designed for couples. She felt herself the “odd one out,” forced by circumstances rather than choice to forego these wholesome associations “rather than risk breaking up even numbers.”

She wrote of the trauma of being single, especially when this resulted from a companion’s desertion, divorce, or death. When she was a married woman, she said, “I never once gave much thought to the plight of the single sisters, except experiencing a kind of helpless pity for them.” Now in that circumstance herself, she felt that the married sisters of her acquaintance tended to shun the sisters who were single. She asked me what could be done to help the single adult members of the Church with what she described as their “feelings of rejection, nonacceptance, and noncaring by their fellow Church members.” Judging from the letters we receive, I believe there are many thousands of single adult members, our brothers and sisters, with similar feelings.

Our Savior gave us the parable of the good shepherd who left the multitude and went out in search of a single sheep who was lost (see Luke 15:3–6). Doesn’t that same principle require couples who enjoy loving companionship to go out of their way to include in their social circles brothers and sisters who have been deprived of that companionship? “Try to remember, and if you remember, then follow.”

A few years ago I spoke by assignment to a chamber of commerce group in Salt Lake City. During a question-answer period, I listened to a fine woman who was not of our faith. She spoke movingly of the pain her children had experienced when they were shunned by LDS youth in school and social activities. More recently, a Utah convert to the Church has written of his concern at the way some non-LDS adults with good basic values come to Utah with high expectations for a life among good neighbors and then, as he wrote, “find themselves excluded at best and ostracized at worst.”

Of course, there will be differences in the personal standards and social activities of faithful Latter-day Saints and members of other groups. But these differences are no excuse for ostracism, arrogance, or unkindness by LDS people. As my convert friend wrote, “I personally believe that Satan is as active among the Saints in turning them away from their neighbors as he is in turning disaffected persons against the Church.”

As we covenant that we will always remember our Savior, we must not forget Jehovah’s command to Israel:

“But the stranger that dwelleth with you shall be unto you as one born among you, and thou shalt love him as thyself” (Lev. 19:34; see Ex. 22:21; Deut. 10:19).

We should always remember how Jesus commanded us to love our neighbor as ourselves. He illustrated that great teaching with the example of the Good Samaritan, who crossed the social barriers of his day to perform acts of kindness and mercy. Then the Savior said, “Go, and do thou likewise” (Luke 10:37).

A decade ago President Spencer W. Kimball said, “Let us fellowship the students from all nations as they come to our land, so that we, above all other people, treat them as brothers and sisters in true friendship, whether or not they are interested in the gospel” (Regional Representatives’ seminar, 29 Sept. 1978).

That prophetic instruction should guide our relationships with all of our neighbors.







Much Given, Much Required



As we remember our Lord and Savior, we should contemplate the great blessings we have as members of The Church of Jesus Christ of Latter-day Saints. We have been taught by the Lord Jesus Christ. We have been led by his prophets. We have received the sealing ordinances of his gospel. He has blessed us bounteously.

As we remember all of this, we should also remember the divine caution: “For of him unto whom much is given much is required” (D&C 82:3; see also Luke 12:48). That eternal principle of law and justice is a measure of what God expects of us.

May we always remember, as we covenant to do, is my humble prayer in the name of Jesus Christ, amen.

# References
