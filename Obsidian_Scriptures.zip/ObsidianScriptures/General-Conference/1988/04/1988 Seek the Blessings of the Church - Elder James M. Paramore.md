Elder James M. Paramore
Of the Presidency of the First Quorum of the Seventy
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/seek-the-blessings-of-the-church?lang=eng)

My beloved brothers and sisters, I love you very much. A few days ago, I attended a program celebrating the 146th anniversary of the Relief Society established by the Prophet Joseph Smith, Jr. Until then, I did not have a feeling or inspiration about what I wanted to say at conference. As I sat in that meeting attended by over three hundred sisters and saw the outstanding presentation—the choir of mothers and children singing and the testimonies of half a dozen of those sisters about the joys and goodness that had come into their lives because of Relief Society—I knew what I wanted to say to you today. And that is to seek the blessings of The Church of Jesus Christ of Latter-day Saints. Listen to some of their comments in that meeting about the Church and its organization.

One sister said, “I will never forget the first time the missionaries took me to church in the little branch in my home town of Santa Rosa, Philippines. I had never heard of Relief Society before, but those dear sisters encircled me in the arms of love.”

Another sister said, “Sisterhood has taken on a whole new meaning for me. Several years ago my husband died suddenly, and I felt as if my world had collapsed around me. But just as suddenly, I was surrounded by a wonderful circle of sisters who helped bear my burden. They are always there. Our weekly trips to the temple bring such peace and comfort into my life. I rejoice in this sweet sisterhood.”

Truly, they were no more strangers, but fellow citizens with the Saints (see Eph. 2:19). They were members of His church—the kingdom of God on earth.

As I sat in that meeting, I thought about what the Church had done for me, my wife, my family, the people in wards I had lived in, the poor and the needy among us, and the whole human race. Those few minutes that day touched my spirit, and I felt like a child who had discovered a treasure. There were feelings within me that I cannot fully explain, but I recognized what the Church had done to bless my life and everyone around me who had truly accepted it and become involved in it.

Central to everything that Christ would have us understand and receive is the great power that comes to us when we draw close to Him through our acts, our compassion, and our personal change in becoming like Him. Our passage here on this earth is a proving ground, a period of growth and choice, and a time “to prepare to meet God” (Alma 12:24). He has given us His Spirit to guide us and His truth and His church to influence us to recognize these powers and use them. One great man in Book of Mormon days who fought against these principles and teachings of the church was Alma the Younger, who was struck dumb and, after the Church spent days of fasting and prayer, was revived and spoke these words:

“For, said he, I have repented of my sins, and have been redeemed of the Lord; behold I am born of the Spirit.

“And the Lord said unto me: Marvel not that all mankind, yea, men and women, all nations, kindreds, tongues and people, must be born again; yea, born of God, changed from their carnal and fallen state, to a state of righteousness, being redeemed of God, becoming his sons and daughters;

“And thus they become new creatures; and unless they do this, they can in nowise inherit the kingdom of God” (Mosiah 27:24–26).

Alma had become a new creature, born of the spirit. He then went forth with conviction to build the kingdom of God upon the earth through the teachings of Christ and the establishment of His church—the very Church of Christ that he had condemned and ridiculed. The Church is necessary to help us to change our lives, to become new creatures.

As I contemplate the blessings of the Church in the lives of the sons and daughters of God, a hundred memories flood through my mind—memories such as—





The times I personally spent in Primary, Sunday School, priesthood, MIA, and seminary with young men and women growing up where activities were always within the bounds the Lord had established and where eternal truths were taught and retaught to strengthen and to truly provide us with a means to measure truth and error.





The time, years ago, when we lived in a large ward with many young families—an area called Morningside Heights. (We actually renamed it Morning Sickness Heights because there were so many young families.) As bishop, I had the blessing of interviewing between sixty and seventy eight-year-old children for baptism. I don’t remember one child who didn’t love the Savior or who didn’t understand and live the law of tithing. This was one of the blessings bestowed by faithful parents and wonderful teachers from Primary and Sunday School in the Church.





The time I heard about an LDS police chief who was honored as the outstanding police officer in California, who said, “All I know about organization is what I’ve learned in the Church. I’ve organized my police force just like my stake. I have a high council and bishoprics organized all over the city. I don’t call them by that name, but they are there just the same.”





The experiences in the Church when I saw my wife and daughter and dozens of other women go into a home on a regularly scheduled basis to help an autistic child learn how to crawl.





The time I saw a weeping father, who had been activated, stand in our stake conference with his arms around two sons and say, “Where would we be without the Church?”





On and on and on it goes. The Church of Jesus Christ is the organization that the Savior established when He personally walked upon the earth in Palestine and later in America and in 1830 when He reestablished it upon the earth to perfect and exalt all mankind. The Church and its functions are indispensable to the plan of God.





The Church provides all of the teachings of the Savior.





The Church exercises the authority from heaven, beginning with a prophet of God and extending down to every family.





The Church provides the saving ordinances of the gospel, including holy, eternal endowments and sealings in the house of God, a fulness of all that the Father has.





The Church provides brotherhood and sisterhood with others, wherever they are upon this earth. A member of the Church is immediately a part of a community of God with friends. It is a refuge from the world, with watchcare and accountability for every member.





The Church helps us to overcome selfishness and uncertainty by serving others in dozens of ways over a lifetime. Some of our fondest memories go back to those associations we have had in service together.





The Church is a way of life and has established organizations and cultural and developmental opportunities for ourselves and our children that are the envy of this world. Loving leaders and teachers provide warmth, security, activities, music, theater, and athletics, as well as the teachings of the Savior to help us to learn how to love Him, to try to be like Him, and to serve others. Our seven-year-old grandson has, through the Primary and the example of his father, found the wonder and blessing of the New Testament and now carries his little edition around, reading it often.





Our young women are trying to put faith, prayer, individual worth, knowledge, choice, accountability, integrity, the divine nature, and good works into their lives to get understanding about their future roles in this world and forever. Through many service projects they share their lives, their testimonies, and their influence to help others come unto Christ.

A young man in Michigan several years ago fell in love with an LDS girl. He was told forthrightly and with great love that she wanted the power of the priesthood in her home and the blessings of an eternal family, and she would only marry someone who could give her those blessings. The teachings she had received had taken root, and the seeds of faith, knowledge, and choice had grown, and she knew that they were true. The young man felt her spirit and agreed to be taught the gospel.

And after he had learned that the gospel was true, his father would not approve his baptism. A great shepherd, a bishop of the young girl, went to the father and helped him to see the value of that young woman, her standards, the Church, and the really truly important things in life. The father was touched that day as he attended the baptism and saw about twenty young men and women of the Church. Following the service, he asked that the missionaries come teach him. A young woman had taken on the divine nature and was able to share the priceless truths with others.





And what about our young men, all men actually, as they learn how to exercise the priesthood of God? George Romney, former governor of Michigan and former president of American Motors, once said this to young men in a stake conference:

“Boys, I want to tell you something. I have never had a degree in business administration from any business school. What success I have had in the business world I owe to the training I have received in this church.”





Recently, we learned a very valuable lesson from our President, Ezra Taft Benson, about the value of the Church in his own life and in the lives of boys. He spent many years early in his married life teaching our young boys as a Scoutmaster, learning and sharing with them in a hundred ways. And we saw the results a few months ago as nearly all of those Scouts he had led assembled and stood in this Tabernacle—a witness of what had been done for them in this church. Yes, the Church is the instrumentality of God. It is essential to the salvation of mankind.

Listen to what President David O. McKay said about the Church: “Every phase of [the Church] seems to me applicable to the welfare of the human family. When I consider the quorums of priesthood, I see in them an opportunity for developing that fraternity and brotherly love which is essential to the happiness of mankind. In these quorums and in the auxiliaries of the Church, I see opportunities for intellectual development, for social efficiency. In the judicial phase of the Church I see ample means of settling difficulties, of establishing harmony in society, of administering justice, and of perpetuating peace among individuals and groups. In the ecclesiastical organization, I see an opportunity for social welfare such as cannot be found in any other organization in the world.

“Thus does Christ and His Church become my ideal, my inspiration in life. I think it is the highest ideal for which man can strive. …

“I know of nothing else in the world that can even approach Christ’s Church as an anchor for the soul” (Treasures of Life, comp. Clare Middlemiss, Salt Lake City: Deseret Book Co., 1962, pp. 3–4).

Now, may I invite all within the sound of my voice to seek the blessings of The Church of Jesus Christ of Latter-day Saints—its important, eternal blessings, its programs and activities, its opportunities to serve and to be of one heart and one mind—and to seek the peace the Savior promised. The First Presidency has extended a special invitation to all who, for whatever reason, may have gone astray from the Church, to come back, to come home, for you are needed and we love you. The Lord and His church will bless you and your families—even into eternity.

Let us all seize every opportunity to serve in His church, with full intent and with great desire, for that is what expands and perfects and sanctifies the soul. The words of the Lord given in February 1829 capture the spirit and heart of how to serve in the Church:

“Therefore, O ye that embark in the service of God, see that ye serve him with all your heart, might, mind and strength, that ye may stand blameless before God at the last day” (D&C 4:2).

Beloved brothers and sisters, this is the Lord’s church, to which we are highly privileged to belong. We are part of it. It blesses our lives. May we capture the true spirit intended by the Lord and be anxiously engaged with others in seeking the blessings of the Church. I know with all the strength of my soul that it is true, that it is God’s instrument to help us to become like His Son, in the name of Jesus Christ, amen.

# References
