Elder Russell M. Nelson
Of the Quorum of the Twelve Apostles
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/with-god-nothing-shall-be-impossible?lang=eng)

I echo the testimony of our beloved associate, Elder Dallin H. Oaks. With him and the other Brethren, I applaud the efforts of Latter-day Saints throughout the world who willingly serve in building the kingdom of God. Likewise, I respect those who quietly do their duty though deepening trials come their way. And I admire those who strive to be more worthy by overcoming a personal fault or who work to achieve a difficult goal.

I feel impressed to counsel those engaged in personal challenges to do right. In particular, my heart reaches out to those who feel discouraged by the magnitude of their struggle. Many shoulder heavy burdens of righteous responsibility which, on occasion, seem so difficult to bear. I have heard those challenges termed impossible.

As a medical doctor, I have known the face of adversity. I have seen much of death and dying, suffering and sorrow. I also remember the plight of students overwhelmed by their studies and of those striving to learn a foreign language. And I recall the fatigue and frustration felt by young parents with children in need. Amidst circumstances seemingly impossible, I have also experienced the joyous relief that comes when one’s understanding is deepened by scriptural insight.

The Lord has often chosen to instruct His people in their times of trial. Scriptures show that some of His lasting lessons have been taught with examples terrible as war, commonplace as childbearing, or obvious as hazards of deep water. His teachings are frequently based on common understanding, but with uncommon results. Indeed, one might say that to teach His people, the Lord employs the unlikely.

Warfare, for example, has been known since time began. Even in that ugly circumstance, the Lord has helped those obedient to His counsel. Going into battle, all would assume the obvious advantage of outnumbering an enemy. But when God’s disciple Gideon was leading an army against the Midianites, “the Lord said unto Gideon, The people that are with thee are too many … , lest Israel vaunt themselves … , saying, Mine own hand hath saved me” (Judg. 7:2).

So the Lord directed Gideon to reduce his numbers. He first decreased the troops from twenty-two thousand to ten thousand.

Then the Lord said to Gideon, “The people are yet too many” (Judg. 7:4). So another reduction was made. Finally, only three hundred remained. Then the Lord delivered the victory to the outnumbered few (see Judg. 7:5–25).

Even more widely known than war is an understanding of childbearing. Everyone “knows” that old women do not bear children. So upon whom did the Lord call to bear Abraham’s birthright son? Sarah, at age ninety! When told this was to be, she asked a logical question: “Shall I [which am old] of a surety bear a child?” (Gen. 18:13). From heaven came this reply: “Is any thing too hard for the Lord?” (Gen. 18:14).

So decreed, she gave birth to Isaac, to carry the crucial Abrahamic covenant into the second generation (see Gen. 26:1–4, 24).

Later, for one of the most important events ever to occur, the other extreme was chosen. As all knew that an elderly woman could not bear children, it was just as obvious that a virgin could not have children. But Isaiah had made this prophetic utterance:

“The Lord himself shall give you a sign; Behold, a virgin shall conceive, and bear a son, and shall call his name Immanuel” (Isa. 7:14).

When Mary was notified of her sacred responsibility, the announcing angel reassured, “For with God nothing shall be impossible” (Luke 1:37).

The expression deep water means danger! That very hazard challenged the Israelites led by Moses at the Red Sea (see Ex. 14). Later, they were led by Joshua to the river Jordan at flood time (see Josh. 3). In each instance, deep water was divinely divided to allow the faithful to reach their destination safely. To teach His people, the Lord employs the unlikely.

Turning to our day, have you ever wondered why the Master waited so long to inaugurate the promised “restitution of all things” (Acts 3:21)? Any competitor knows the disadvantage of allowing an opponent to get too far ahead. Wouldn’t the work of the restoration of the Church have been easier if begun earlier?

Suppose for a moment you are a member of a team. The coach beckons you from the bench and says: “You are to enter this contest. I not only want you to win; you shall win. But the going will be tough. The score at this moment is 1,143,000,000 to six, and you are to play on the team with the six points!”

That large number was the approximate population of the earth in the year 1830 when the restored church of Jesus Christ was officially organized with six members (see James Avery Joyce, sel., World Population Basic Documents, 4 vols., Dobbs Ferry, New York: Oceana Publications, Inc., 1976, 4:2214). The setting was remote and rural. By standards of the world, its leaders were deemed to be unlearned. Their followers seemed so ordinary. But with them, the work was begun. Assignments had been revealed:





The gospel was to be preached to every kindred, nation, tongue, and people.





Ordinary folk were to become Saints.





Redemptive work was to be done for all who had ever lived.





The great dispensation of the latter days had commenced, and they were the ones to usher it forth!

Furthermore, the Prophet Joseph Smith was unjustly held in the unspeakable isolation of a distant prison. In such obscurity, then and there, he was told by the Lord that “the ends of the earth shall inquire after thy name” (D&C 122:1).

If any tasks ever deserved the label impossible, those would seem to qualify. But, in fact, our Lord had spoken: “With men this is impossible; but with God all things are possible” (Matt. 19:26; see also Mark 10:27; Luke 18:27). To teach His people, the Lord employs the unlikely.

A century and a half later, the burdening baton of that opportunity has now been passed to us. We are children of the noble birthright, who must carry on in spite of our foredetermined status to be broadly outnumbered and widely opposed. Challenges lie ahead for the Church and for each member divinely charged toward self-improvement and service.

How is it possible to achieve the “impossible”? Learn and obey the teachings of God. From the holy scriptures, heaven-sent lift will be found for heaven-sent duties. To so achieve, at least three basic scriptural themes loom repeatedly as requirements.





Faith



The foremost requisite is faith. It is the first principle of the gospel (see A of F 1:4). In his epistle to the Hebrews, Paul so taught. He concluded that by faith the great deeds of Noah, Abraham, Sarah, Isaac, Jacob, Joseph, Moses, Joshua, and others were accomplished (see Heb. 11:4–34).

Prophets on the American hemisphere similarly taught the fundamental importance of faith. Moroni said it included things “hoped for and not seen” and then warned his skeptics, “Dispute not because ye see not, for ye receive no witness until after the trial of your faith” (Ether 12:6). Then he spoke of leaders whose faith preceded their miraculous deeds, including Alma, Amulek, Nephi, Lehi, Ammon, the brother of Jared, and the three who were promised that they should not taste of death (see Ether 12:13–20).

The Lord personally taught this truth to his disciples: “If ye have faith,” he said, “nothing shall be impossible unto you” (Matt. 17:20).

Faith is nurtured through knowledge of God. It comes from prayer and feasting upon the words of Christ through diligent study of the scriptures.







Focus



The second requisite I have classified as focus. Imagine, if you will, a pair of powerful binoculars. Two separate optical systems are joined together with a gear to focus two independent images into one three-dimensional view. To apply this analogy, let the scene on the left side of your binoculars represent your perception of your task. Let the picture on the right side represent the Lord’s perspective of your task—the portion of His plan He has entrusted to you. Now, connect your system to His. By mental adjustment, fuse your focus. Something wonderful happens. Your vision and His are now the same. You have developed an “eye single to the glory of God” (D&C 4:5; see also Morm. 8:15). With that perspective, look upward—above and beyond mundane things about you. The Lord said, “Look unto me in every thought” (D&C 6:36). That special vision will also help clarify your wishes when they may be a bit fuzzy and out of focus with God’s hopes for your divine destiny. Indeed, the precise challenge you regard now as “impossible” may be the very refinement you need, in His eye.

Recently I visited the home of a man terminally ill. The stake president introduced me to the man’s family. His wife demonstrated such focus when she asked for a blessing for her dying husband—not for healing, but for peace, not for a miracle, but for ability to abide to the end. She could see from an eternal viewpoint, not merely from the perspective of one weighted with the responsibilities of her husband’s day-to-day care.

Elsewhere, a mother with focus nurtures her son, crippled for the whole of this life. Daily she thanks her Heavenly Father for the privilege of laboring in love with a child for whom mortality’s vale of tears will be mercifully brief. Her focus is fixed on eternity. With celestial sight, trials impossible to change become possible to endure.







Strength and Courage



A third theme in the scriptures requisite for significant accomplishment is difficult to summarize in one word, so I shall link two to describe it—strength and courage. Repeatedly, scriptures yoke these attributes of character together, especially when difficult challenges are to be conquered (see Deut. 31:6, 7, 23; Josh. 1:6, 7, 9, 18; Josh. 10:25; 1 Chr. 22:13; 1 Chr. 28:20; 2 Chr. 32:7; Ps. 27:14; Ps. 31:24; Alma 43:43; Alma 53:20).

Perhaps this is more easily illustrated than defined. Our pioneer forefathers are good examples. They sang, “Gird up your loins; fresh courage take” (“Come, Come, Ye Saints,” Hymns, 1985, no. 30). They feared no toil and no labor. Among them were Johan Andreas Jensen and his wife, Petra, who left their native Norway in 1863. Their family included six-week-old tiny twin daughters. As handcarts were pulled in their rugged journey, one of those little girls died along the way. The child who survived grew up to become my Grandmother Nelson!

There are pioneers in the Church today just as strong and courageous. Recently, I interviewed a married couple three days after their release as full-time missionaries in a large metropolis. “We are converts,” they said. “We joined the Church ten years ago. Even though we just completed a mission, we want to go again! But this time, we would like to volunteer for a more difficult assignment. We want to teach and serve children of God who live in remote areas of the world!”

As I countered with the grim realities of their request, they continued their expression of commitment. “Our three children and their spouses will assist with our expenses. Two of those couples have joined the Church already, and the third is equally supportive. Please send us among humble people who love the Lord and desire to know that His Church has again been restored to the earth.” Needless to say, their petition was gratefully heard, and now they have received their second call to missionary service.

Strength and courage also characterize another couple. As faithful members of the Church, they had always upheld its doctrines, including the twelfth article of faith. When their country went to war, military conscription called the dutiful husband away from his wife before either had learned she was to bear their child. He was captured by enemy troops and taken as a prisoner of war. Months elapsed. Their baby came. Still no word to know whether the new father was alive. A year after his capture, he was permitted to write to his wife.

Meanwhile, though countries apart, they each remained faithful to covenants made at baptism. Even though clothed in prisoner’s stripes and able to speak the language of his captors’ country only in a limited way, he became Sunday School superintendent of the branch. He baptized four fellow prisoners during their confinement. Three years after the war ended, he returned home to his wife and a son he had never seen. Later, he served for ten years as the first stake president of his country. Now he is a member of the presidency of one of our temples! His wife stands faithfully beside him in the privilege of that sacred assignment.

You who may be momentarily disheartened, remember, life is not meant to be easy. Trials must be borne and grief endured along the way. As you remember that “with God nothing shall be impossible” (Luke 1:37), know that He is your Father. You are a son or daughter created in His image, entitled through your worthiness to receive revelation to help with your righteous endeavors. You may take upon you the holy name of the Lord. You can qualify to speak in the sacred name of God (see D&C 1:20). It matters not that giants of tribulation torment you. Your prayerful access to help is just as real as when David battled his Goliath (see 1 Sam. 17).

Foster your faith. Fuse your focus with an eye single to the glory of God. “Be strong and courageous” (2 Chr. 32:7), and you will be given power and protection from on high. “For I will go before your face,” the Lord declared. “I will be on your right hand and on your left, and my Spirit shall be in your hearts, and mine angels round about you, to bear you up” (D&C 84:88).

The great latter-day work of which we are a part shall be accomplished. Prophecies of the ages shall be fulfilled. “For with God all things are possible” (Mark 10:27), I testify in the name of Jesus Christ, amen.

# References
