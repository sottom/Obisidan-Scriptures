President Gordon B. Hinckley
First Counselor in the First Presidency
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/the-aaronic-priesthood-a-gift-from-god?lang=eng)

There are thousands of boys here in the Tabernacle tonight, and I think I would like to talk to you. Some of you are twelve years of age.

When I was twelve, two things of great significance occurred in my life.

I became a Boy Scout. We did not have the Cub Scout program then, and a boy had to be twelve to be a Scout. This was 1922, only nine years after the Church adopted the Scout program. I lived in a very large ward by today’s standards. There were more than eleven hundred people in that ward. We had a large troop, and we met in the cultural hall of the old First Ward. We made a lot of noise. The floors were of hardwood; the walls were hard and smooth, and the sound bounced around them. Our Scoutmaster had a whistle which he blew frequently to get order.

I filled out an application and paid the fifty-cent registration fee, which seemed like a lot of money at the time. I learned the Scout motto: “Be Prepared.” I learned the Scout slogan: “Do a Good Turn Daily.” I learned the Scout Oath: “On my honor I will do my best to do my duty to God and my country and to obey the Scout Law; to help other people at all times; to keep myself physically strong, mentally awake, and morally straight.”

I learned the Scout Law: “A Scout is trustworthy, loyal, helpful, friendly, courteous, kind, obedient, cheerful, thrifty, brave, clean, reverent.” (We said it just about that fast.) And when we recited the law, one of the boys always added, “A Scout is hungry.” I think it was literally true. He came from a very large family, and getting enough to eat was always a challenge.

When I was twelve, I also became a deacon in the Aaronic Priesthood. My name was presented to the entire congregation of our ward. Everyone was asked to sustain me if they felt me worthy of the office. All hands in the large congregation went up. I was honored to think that all of the members of my ward raised their hands in my behalf.

Then two men, good and true and faithful—one of them my father—placed their hands upon my head and conferred upon me the Aaronic Priesthood and ordained me to the office of deacon. I did not have any oath, slogan, motto, or law to memorize in connection with this. But I did memorize section 13 of the Doctrine and Covenants, and I have remembered it ever since. These are the words of an angel. They are the words of John the Baptist when he conferred the Aaronic Priesthood upon Joseph Smith and Oliver Cowdery on May 15, 1829:

“Upon you my fellow servants, in the name of Messiah I confer the Priesthood of Aaron, which holds the keys of the ministering of angels, and of the gospel of repentance, and of baptism by immersion for the remission of sins; and this shall never be taken again from the earth, until the sons of Levi do offer again an offering unto the Lord in righteousness.” [D&C 13]

Unlike Scouting, we did not have one large deacons quorum that met in the cultural hall. Rather, we were divided into four quorums, with up to twelve boys in each. I thought it was a good arrangement because there were fewer of us in a group, with less noise and a more intimate relationship between us and our priesthood leader. I later learned that this number had been wisely designated by the Lord in revelation. He said, “And again, verily I say unto you, the duty of a president over the office of a deacon is to preside over twelve deacons, to sit in council with them, and to teach them their duty, edifying one another” (D&C 107:85).

Now I am not in any way disparaging Scouting. It is a wonderful program. It is the Church’s activity program for boys in many areas of the world.

But I feel that the most important program for boys in the Church is that of the Aaronic Priesthood.

Scouting is an excellent and wonderful program that has come of the wisdom of men. The Aaronic Priesthood is a gift from God.

Now, as a boy I knew from what I had learned in Sunday School that John the Baptist had been killed by a wicked ruler, that he had been beheaded to satisfy the lustful desire of an evil woman. And in 1829 it was this same John who had come and given the priesthood to Joseph Smith and Oliver Cowdery. He spoke to them. He placed his hands upon their heads. They heard his voice and they felt his hands. This meant that he had to have been resurrected. That was a wonderful thing and a very impressive thing to me. Here was living evidence of the reality of the Resurrection, which had come through the divine power of the Lord Jesus Christ—the same who earlier had been baptized by John in the river Jordan.

John told Joseph and Oliver that he was acting under the direction of Peter, James, and John, the Apostles who had been ordained by the Lord and who held what we call the Melchizedek, or the higher, Priesthood, as distinguished from the Aaronic, or the lesser, Priesthood.

Joseph Smith was then twenty-three and a half years of age. Oliver Cowdery was about the same. They were young men, and I thought when I was ordained a deacon what a wonderful thing it was that John the Baptist, who was a great man in the New Testament and who lived nearly two thousand years earlier, had come as a resurrected being and that he should address Joseph and Oliver as “my fellow servants.”

Even though he came as a servant of God and acted under the direction of Peter, James, and John, he did not place himself above Joseph and Oliver. He put them on his same level when he addressed them as “my fellow servants.” If they were his fellow servants, then perhaps I, as a twelve-year-old boy, could also be his fellow servant.

He spoke in the name of Messiah, or, as we would say it, “in the name of Jesus Christ.” He set the pattern, and since then, the ordinances which we perform are administered in the name of Jesus Christ. This is something we should never forget, and never overlook, for in the exercise of our priesthood, we are acting in behalf of God our Eternal Father and Jesus Christ, His Son.

In the authority that was John’s, he conferred the Priesthood of Aaron. Why did he use that expression? Who was Aaron?

Aaron was the brother of Moses. He was three years older than Moses. When the Lord called Moses as the leader of the children of Israel while they were in Egypt, Moses protested that he had a stammering tongue and that he was not capable of leadership. The Lord did not accept his excuse, but, rather, He told Moses that he should be the leader and that his brother Aaron should be his voice.

Moses and Aaron went together to ask Pharaoh to let the children of Israel leave Egypt. Pharaoh was angry each time they went. Aaron had a rod, and when he dropped it on the floor before the ruler, it became a serpent.

When the children of Israel eventually fled Egypt under Moses’ leadership, Aaron was his assistant. He was of the tribe of Levi and was given the holy priesthood, with the promise that certain elements of that priesthood should be given to and be exercised by those of his tribe through all of the generations to come. This priesthood, or this lesser portion of the higher priesthood, came to be known as the Aaronic or Levitical Priesthood.

Aaron lived to the good age of 123, and his authority was passed to his son to be passed down through those generations who would be worthy of it.

Now what are the elements of this priesthood which were restored to the earth by John the Baptist?

He said that this priesthood of Aaron “holds the keys of the ministering of angels” (D&C 13:1). It is a tremendous thing to have the right to the ministering of angels.

When President Wilford Woodruff was an elderly man, he said to the young men of the Church:

“I desire to impress upon you the fact that it does not make any difference whether a man is a Priest or an Apostle, if he magnifies his calling. A Priest holds the keys of the ministering of angels. Never in my life, as an Apostle, as a Seventy, or as an Elder, have I ever had more of the protection of the Lord than while holding the office of a Priest. The Lord revealed to me by visions, by revelations, and by the Holy Spirit, many things that lay before me” (Millennial Star, 5 Oct. 1891, p. 629).

On Sunday, February 28, 1897, ninety-one years ago, a great meeting was held here in this Salt Lake Tabernacle. It was to honor President Woodruff on his ninetieth birthday. The Tabernacle was beautifully decorated. There was appropriate music with talks of tribute. Then President Woodruff, old and somewhat crippled, stood to speak, and he said to the young men:

“I have passed through the periods of boyhood, early manhood and old age. I cannot expect to tarry a great while longer with you, but I want to give to you a few words of counsel. You occupy a position in the Church and Kingdom of God and have received the power of the holy priesthood. The God of heaven has appointed you and called you forth in this day and generation. I want you to look at this. Young men, listen to the counsel of your brethren. Live near to God; pray while young; learn to pray; learn to cultivate the Holy Spirit of God; link it to you and it will become a spirit of revelation unto you, inasmuch as you nourish it” (Matthias Cowley, Wilford Woodruff, 2d ed., Salt Lake City: Deseret News, 1916, pp. 602–3).

President Woodruff had an inspired view of this remarkable and wonderful blessing which may be enjoyed by every boy who holds the Aaronic Priesthood and lives worthy of it. That key is the gift of the ministering of angels. I am convinced that the Lord would not have given it to us had he not desired that we have it so that we might enjoy the wonderful gifts, guidance, and protection which come therefrom.

John the Baptist went on to say to Joseph Smith and Oliver Cowdery that this priesthood, which he bestowed upon them, included the keys of the gospel of repentance. What a marvelous and wonderful thing this is! It is our privilege, yours and mine, as those who hold this priesthood, to repent of evil with the expectation that we will be forgiven if we live worthy of the forgiveness of the Lord. Furthermore, it is our privilege to preach repentance, as the Lord has made clear in section 20 of the Doctrine and Covenants. He there sets forth the duties of deacons, teachers, and priests. It is their responsibility to watch over the Church and see that there is no iniquity and to invite all to come unto Christ. That involves repentance from sin and obedience to the principles and laws of the gospel.

This Aaronic Priesthood, bestowed by John the Baptist, also includes the keys of baptism by immersion for the remission of sins. It is one thing to repent. It is another to have our sins remitted or forgiven. The power to bring this about is found in the Aaronic Priesthood.

Baptism is the primary ordinance of the gospel. It is the gate through which all come into the Church. It is so important that it is performed not only for the living but also for the dead, because those who are beyond the veil of death cannot move forward on the way to eternal life without this ordinance having been administered in their behalf.

I want to emphasize, boys, that the holding of the Aaronic Priesthood, and the exercise of its power, is not a small or unimportant thing. The bestowal of these keys in this dispensation was one of the greatest and most significant things incident to the entire Restoration. It was the first bestowal of divine authority in this, the dispensation of the fulness of times. It is the priesthood of God, with authority to act in the name of the Savior of mankind.

It is the authority under which the emblems of the Lord’s Supper are administered to the membership of the Church. That great and important sacrament was instituted by the Savior himself shortly before His crucifixion. It was He who first gave to those He loved the emblems of His flesh and blood and commanded that all should partake of them in remembrance of Him and as a token of a covenant between God and man.

When you priests of the Aaronic Priesthood administer the sacrament, you are doing what Jesus did while He was yet in the flesh, and which He also did when He ministered among the Nephites following His resurrection.

When you, as a priest, kneel at the sacrament table and offer up the prayer, which came by revelation, you place the entire congregation under covenant with the Lord. Is this a small thing? It is a most important and remarkable thing.

Now, my dear young brethren, if we are to enjoy the ministering of angels, if we are to teach the gospel of repentance, if we are to baptize by immersion for the remission of sins, if we are to administer to the membership of the Church the emblems of the sacrifice of our Lord, then we must be worthy to do so.

You cannot consistently so serve on the Sabbath and fail to live the standards of the Church during the week. It is totally wrong for you to take the name of the Lord in vain and indulge in filthy and unseemly talk at school or at work, and then kneel at the sacrament table on Sunday. You cannot drink beer or partake of illegal drugs and be worthy of the ministering of angels. You cannot be immoral in talk or in practice and expect the Lord to honor your service in teaching repentance or baptizing for the remission of sins. As those holding His holy priesthood, you must be worthy fellow servants.

I would not wish to leave the impression that these abhorrent practices are common among the young men of the Church, but I know that they are not entirely absent. Most of you are trying to do the right thing, and I compliment you most warmly. But if there be any here who are not doing the right thing, then I plead with you, and I invoke upon you the spirit of repentance, the keys of which you hold as those endowed with the Aaronic Priesthood. Make yourselves worthy in every respect, and the Lord will bless you. You will have peace in your hearts and a greater sense of the remarkable power which has been given to you under this greatest of all programs for young men, this program which has come from the Lord Himself for the blessing of young men and those to whom they minister.

I bear my witness and testimony of these things as I invoke the blessings of the Lord upon you, His servants, who have been endowed with His power. In the name of Jesus Christ, amen.

# References
