Elder Richard G. Scott
Of the Presidency of the First Quorum of the Seventy
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/to-help-a-loved-one-in-need?lang=eng)

It is Easter morning, that sacred season when the heart of each devout Christian turns in humble gratitude to our beloved Savior. It is a season that should bring peace and joy to all. Yet many of you have heavy hearts because a son or daughter, husband or wife, has turned from righteousness to pursue evil. My message is for you.

Your life is filled with anguish, pain, and, at times, despair. I will tell you how you can be comforted by the Lord.

First, you must recognize two foundation principles:





While there are many things you can do to help a loved one in need, there are some things that must be done by the Lord.





Also, no enduring improvement can occur without righteous exercise of agency. Do not attempt to override agency. The Lord himself would not do that. Forced obedience yields no blessings (see D&C 58:26–33).





I will suggest seven ways you can help.

First—Love without limitations. When in a dream Lehi partook of the fruit of the tree of life and was filled with joy, his first thought was to share it with each member of his family, including the disobedient (see 1 Ne. 8:3–4, 12–13).

Second—Do not condone the transgressions, but extend every hope and support to the transgressor. To his missionary son Corianton, who had violated the law of chastity, Alma said, “Behold, O my son, how great iniquity ye brought upon the Zoramites; for when they saw your conduct, they would not believe in my words” (Alma 39:11). Then he clarified in careful detail principles which his son had improperly used to justify his acts. Subsequently, that loving father gave this counsel:

“O, my son, I desire that ye should deny the justice of God no more. Do not endeavor to excuse yourself in the least point because of your sins, … but do you let the justice of God, and his mercy, and his long-suffering have full sway in your heart; and let it bring you down to the dust in humility. …

“And now, my son, go thy way, declare the word with truth and soberness” (Alma 42:30–31). Corianton repented and became a powerful servant.

Third—Teach truth. Nephi taught his brothers: “Whoso would hearken unto the word of God, and would hold fast unto it, they would never perish; neither could the temptations and the fiery darts of the adversary overpower them unto blindness, to lead them away to destruction” (1 Ne. 15:24).

Then he gave this example of how to teach: “I did exhort them with all the energies of my soul, and with all the faculty which I possessed, that they would give heed to the word of God and remember to keep his commandments always in all things” (1 Ne. 15:25).

Fourth—Honestly forgive as often as is required. The Lord declared: “If he … repenteth in the sincerity of his heart, him shall ye forgive, and I will forgive him also. …

“And as often as my people repent will I forgive them” (Mosiah 26:29–30).

Fifth—Pray trustingly. “The … fervent prayer of a righteous man availeth much” (James 5:16).

The Master taught: “Whatsoever ye shall ask the Father in my name, which is right, believing that ye shall receive, behold it shall be given unto you” (3 Ne. 18:20). “Pray always, and I will pour out my Spirit upon you, and great shall be your blessing” (D&C 19:38).

Sixth—Keep perspective. When you have done all that you can reasonably do, rest the burden in the hands of the Lord.

When I take a small pebble and place it directly in front of my eye, it takes on the appearance of a mighty boulder. It is all I can see. It becomes all-consuming—like the problems of a loved one that affect our lives every waking moment. When the things you realistically can do to help are done, leave the matter in the hands of the Lord and worry no more. Do not feel guilty because you cannot do more. Do not waste your energy on useless worry. The Lord will take the pebble that fills your vision and cast it down among the challenges you will face in your eternal progress. It will then be seen in perspective. In time, you will feel impressions and know how to give further help. You will find more peace and happiness, will not neglect others that need you, and will be able to give greater help because of that eternal perspective.



Abraham labored that his own father would overcome transgression. Despite his best efforts, his father turned to idolatry. Had Abraham let that proper concern for a father consume his every thought, he could not have received this promise: “In thy seed shall all the kindreds of the earth be blessed” (3 Ne. 20:25).

Some who have overcome serious sin in their own lives blame themselves because of that prior disobedience when a loved one does not respond as desired. Such promptings come from Satan, not from the Lord. Alma could help his son, Corianton, because Alma spoke from a position of strength, knowing that his own sins had been entirely forgiven through repentance.

This is not a doctrinal discourse; rather, it is a personal witness of what I know to be true. At times my wife, Jeanene, and I have had challenges that seemed more difficult than we could possibly face alone. Once she lost a baby girl and nearly her life. Within six weeks, another beloved son was taken home. We pled for help, and it came.

When other challenges have brought us to our knees, we have had confidence that we would receive comfort and guidance, and they came. The Lord opens doors of opportunity and provides the strength each of us needs at difficult times in our life.

This Easter, as we remember the Resurrection and the price paid and the gift given through the Atonement, let us ponder what the scriptures teach of those sacred events. Our personal witness of their reality will be strengthened. They must be more than principles we memorize. They must be woven into the very fiber of our being as a bulwark in time of need.

Nephi taught: “For ye have not come thus far save it were by the word of Christ with unshaken faith in him, relying wholly upon the merits of him who is mighty to save.

“Wherefore, ye must press forward with a steadfastness in Christ, having a perfect brightness of hope, and a love of God and of all men. Wherefore, if ye shall press forward, feasting upon the word of Christ, and endure to the end, behold, thus saith the Father: Ye shall have eternal life” (2 Ne. 31:19–20).

He could well have added, “and shall have peace and happiness now.” Happiness comes from understanding and living the teachings of the Lord. It comes from not being critical of ourselves when we don’t accomplish all we want to do.

One last suggestion—Never give up on a loved one, never! I know we have a loving Father in Heaven. He asks us to worship him that we may feel his love. He entreats us to love his Son that we may be comforted and strengthened.

Sometimes, we foolishly recite facts about the Father and the Son, mechanically, and—forgive us—preach to them, preen before them, and display our ignorance and pride. Yet they continue to love us perfectly, each one of us, individually. Yes, they are all-powerful and all-knowing; their works extend eternally, yet their love for each of us is personal, knowing, uncompromising, endless, perfect.

I know they live. I know that Jesus is the Christ, our Savior and Redeemer. I love him with all my soul. He gave his life that we might overcome errors to live eternally. I don’t understand how he did it. In my own imperfect way, I try to imagine the incomprehensible burden he felt as he entered into the closing hours of his ministry on earth, knowing that his life had to be completely sinless, without error. He had to provide the perfect atonement for all mankind, each individual, without exception, or not one soul could ever return to the presence of God. He did it. He did it perfectly. Neither he nor his Father will ever fail us—never in all eternity. I bear that witness, in the name of Jesus Christ, amen.

# References
