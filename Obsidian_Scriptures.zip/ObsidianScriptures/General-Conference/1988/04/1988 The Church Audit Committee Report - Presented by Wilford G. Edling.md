Presented by Wilford G. Edling
Chairman, Church Audit Committee
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/the-church-audit-committee-report?lang=eng)

_To the First Presidency of The Church of Jesus Christ of Latter-day Saints_

For the purpose of evaluating the adequacy of controls over receipts and expenditures of the general funds of the Church and its controlled organizations, we have reviewed the system of budgeting, accounting, and auditing, and the related financial statements of the Church for the year ended December 31, 1987, and the manner in which funds are received and expenditures are controlled.

Expenditures of general Church funds for the year were authorized by the First Presidency and were made in compliance with budgetary procedures. The budget is authorized by the Council on Disposition of Tithes composed of the First Presidency, the Council of the Twelve, and the Presiding Bishopric. The Appropriations Committee, in weekly meetings, administers major expenditures under the budget.

The general fund accounts of the Church are maintained by its Finance and Records Department, which uses modern accounting technology and equipment to keep abreast of the rapidly expanding and varied activities of the Church.

The Auditing Department, which is comprised of a staff of certified public accountants and similarly qualified auditors, and which is independent of all other departments, performs financial audits, operational audits, and audits of computer systems employed by the Church. These auditing services are performed on a continuing basis for Church departments and other Church-controlled organizations engaged in worldwide operations, including missions, schools, administrative offices, and departmental activities. The extent and scope of the Auditing Department services in safeguarding the resources of the Church are expanding to encompass the growth and widening activities of the Church.

The audits of local funds of wards and stakes are performed by stake auditors. The audit procedures are established and the audit reports are reviewed by the Church Auditing Department. Incorporated businesses owned or controlled by the Church for which accounts are not maintained in the Finance and Records Department are audited by the Church’s internal auditors, independent professional auditing firms, or government regulatory agencies.

Based on our review of the system of financial controls within the Church, together with continuing discussions with personnel of the Finance and Records and Auditing departments, we are of the opinion that budgeting, accounting, and auditing controls are adequate for Church needs and purposes, and that in all material respects the general funds of the Church received and expended during the year ended December 31, 1987, have been controlled and accounted for in accordance with established Church policy and procedures.



Respectfully submitted,

Church Audit Committee

Wilford G. Edling

David M. Kennedy

Warren E. Pugh

Merrill J. Bateman

Ted E. Davis

# References
