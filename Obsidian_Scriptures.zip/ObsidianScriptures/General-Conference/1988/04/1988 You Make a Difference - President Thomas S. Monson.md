President Thomas S. Monson
Second Counselor in the First Presidency
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/you-make-a-difference?lang=eng)

David declares in one of his beautiful and moving psalms, “O Lord our Lord, how excellent is thy name in all the earth! …

“When I consider thy heavens, the work of thy fingers, the moon and the stars, which thou hast ordained;

“What is man, that thou art mindful of him?” (Ps. 8:1, 3–4).

Job, that righteous man of old, joined in the question when he asked, “What is man, that thou shouldest magnify him? and that thou shouldest set thine heart upon him?” (Job 7:17).

One need not grope for answers to these penetrating questions when in your presence here in the historic Tabernacle or with you in the many meeting places throughout the world where you have assembled. “Ye are a chosen generation, a royal priesthood, an holy nation” (1 Pet. 2:9). “Ye … are … a spiritual house, an holy priesthood” (1 Pet. 2:5).

As bearers of the priesthood, we have been placed on earth in troubled times. We live in a complex world with currents of conflict everywhere to be found. Political machinations ruin the stability of nations, despots grasp for power, and segments of society seem forever downtrodden, deprived of opportunity and left with a feeling of failure.

We who have been ordained to the priesthood of God can make a difference. When we qualify for the help of the Lord, we can build boys, we can mend men, we can accomplish miracles in His holy service. Our opportunities are without limit.

Though the task looms large, we are strengthened by the truth: “The greatest force in this world today is the power of God as it works through man.” If we are on the Lord’s errand, we are entitled to the Lord’s help. That divine help, however, is predicated upon our worthiness. To sail safely the seas of mortality, to perform a human rescue mission, we need the guidance of that eternal mariner—even the great Jehovah. We reach out, we reach up, to obtain heavenly help.

Are our reaching hands clean? Are our yearning hearts pure? Looking backward in time through the pages of history, we glean a lesson of worthiness from the words of the dying King Darius.

“Darius, through the proper rites had been recognized as legitimate King of Egypt. His rival Alexander the Great had been declared legitimate son of Ammon. He, too, was Pharaoh. Alexander, finding the defeated Darius on the point of death, laid his hands upon his head to heal him, commanding him to arise and resume his kingly power, concluding, “I swear unto thee, Darius, by all the gods, that I do these things truly and without fakery.” Darius replied with a gentle rebuke, “Alexander, my boy, … do you think you can touch heaven with those hands of yours?” (quoted by Hugh Nibley, Abraham in Egypt Salt Lake City: Deseret Book Co., 1981, p. 192).

An inspiring lesson is learned from a “Viewpoint” article which appeared recently in the Church News section of the Deseret News. May I quote:

“To some it may seem strange to see ships of many nations loading and unloading cargo along the docks at Portland, Oregon. That city is 100 miles from the ocean. Getting there involves a difficult, often turbulent passage over the bar guarding the Columbia River and a long trip up the Columbia and Willamette Rivers.

“But ship captains like to tie up at Portland. They know that as their ships travel the seas, a curious salt water shellfish called a barnacle fastens itself to the hull and stays there for the rest of its life, surrounding itself with a rock-like shell. As more and more barnacles attach themselves, they increase the ship’s drag, slow its progress, decrease its efficiency.

“Periodically, the ship must go into dry dock, where with great effort the barnacles are chiseled or scraped off. It’s a difficult, expensive process that ties up the ship for days. But not if the captain can get his ship to Portland. Barnacles can’t live in fresh water. There, in the sweet, fresh waters of the Willamette or Columbia, the barnacles loosen and fall away, and the ship returns to its task lightened and renewed.

“Sins are like those barnacles. Hardly anyone goes through life without picking up some. They increase the drag, slow our progress, decrease our efficiency. Unrepented, building up one on another, they can eventually sink us.

“In His infinite love and mercy, our Lord has provided a harbor where, through repentance, our barnacles fall away and are forgotten. With our souls lightened and renewed, we can go efficiently about our work and His” (“Harbor of Forgiveness,” 30 Jan. 1988, p. 16).

A loving Heavenly Father has provided for our guidance models to follow, men who made a difference in their own times. I choose to call these noble souls “pioneers.” Webster defines a pioneer: “One who goes before, showing others the way to follow.”

With faith as their moving power, they sailed upstream against the currents of doubt which surrounded them. We cannot help but be inspired in our efforts as we remember their examples.

From Nephi: “I will go and do the things which the Lord hath commanded” (1 Ne. 3:7).

From Samuel: “To obey is better than sacrifice, and to hearken than the fat of rams” (1 Sam. 15:22).

From Paul: “For I am not ashamed of the gospel of Christ: for it is the power of God unto salvation” (Rom. 1:16).

From Job: “I know that my redeemer liveth” (Job 19:25).

From Joseph: “I am calm as a summer’s morning; I have a conscience void of offense towards God, and towards all men” (D&C 135:4).

These noble leaders made a difference in their own times. What about today? How about me?

The world felt the quickening pace of activity when President Spencer W. Kimball declared, “We must lengthen our stride.” He stepped forward and the Church followed.

When President Ezra Taft Benson warned that we had neglected the Book of Mormon and urged every member to read and study this sacred volume, new printing presses were required to produce more and more copies of the book, as boys and girls and men and women followed the prophet in his own reading and in his inspired declaration. Every day letters arrive at the President’s office which testify to the enrichment of lives which comes from reading the Book of Mormon. They tell of families united, goals attained, and souls saved. Such is the power of a prophet.

We do not have a monopoly on goodness. There are God-fearing men and women in all nations who influence for good those with whom they associate. I think of the founder of Scouting, even Lord Baden-Powell, and those who teach and live the principles he advocated. Who can measure the far-reaching effect on human lives of the Scout oath:



“On my honor I will do my best to do my duty to God and my country and to obey the Scout Law; to help other people at all times; to keep myself physically strong, mentally awake and morally straight.”

Impossible of calculation is the result for good when men and boys observe the Scout law: trustworthy, loyal, helpful, friendly, courteous, kind, obedient, cheerful, thrifty, brave, clean and reverent.

The influence of your personal testimonies is ever so far-reaching. The Lord instructed: “The testimony which ye have borne is recorded in heaven for the angels to look upon; and they rejoice over you, and your sins are forgiven you” (D&C 62:3).

He also cautioned us: “With some I am not well pleased, for they will not open their mouths, but they hide the talent which I have given unto them, because of the fear of man” (D&C 60:2).

You never know when your turn will come to comply with the admonition of Peter to “be ready always to give an answer to every man that asketh you a reason of the hope that is in you” (1 Pet. 3:15).

Some years ago I had the opportunity to address a business convention in Dallas, Texas, sometimes called “the city of churches.” After the convention, I took a sightseeing bus ride about the city’s suburbs. Our driver would comment, “On the left you see the Methodist church,” or “There on the right is the Catholic cathedral.”

As we passed a beautiful red brick building situated upon a hill, the driver exclaimed, “That building is where the Mormons meet.” A lady from the rear of the bus asked, “Driver, can you tell us something more about the Mormons?” The driver steered the bus to the side of the road, turned about in his seat, and replied, “Lady, all I know about the Mormons is that they meet in that red brick building. Is there anyone on this bus who knows anything about the Mormons?”

I gazed at the expression on each person’s face for some sign of recognition, some desire to comment. I found nothing—not a sign. Then I realized the truth of the statement, “When the time for decision arrives, the time for preparation is past.” For the next fifteen minutes I had the privilege of sharing with others my testimony concerning The Church of Jesus Christ of Latter-day Saints.

The seeds of testimony frequently do not at once take root and flower. Bread cast upon the water returns, at times, only after many days.

I answered the ring of my telephone one evening to hear a voice ask, “Are you related to an Elder Monson who years ago served in the New England Mission?” I answered that such was not the case. The caller introduced himself as a Brother Leonardo Gambardella and then mentioned that an Elder Monson and an Elder Bonner called at his home long ago and bore their personal testimonies to him. He had listened but had done nothing further to apply their teachings. Subsequently he moved to California where, after thirteen years, he again found the truth and was converted and baptized. Brother Gambardella then asked if there were a way he could reach these elders who had first visited with him, that he might express to them his profound gratitude for their testimonies, which had remained with him.

I checked the records. I located the elders. Can you imagine their surprise when, now married with families of their own, I telephoned them and told them the good news—even the culmination of their early efforts. They remembered Brother Gambardella and, at my suggestion, telephoned him to extend their congratulations and welcome him into the Church.

You can make a difference. Whom the Lord calls, the Lord qualifies. This promise extends not only to missionaries, but also to home teachers, quorum leaders, presidents of branches, and bishops of wards. When we qualify ourselves by our worthiness, when we strive with faith nothing wavering to fulfill the duties appointed to us, when we seek the inspiration of the Almighty in the performance of our responsibilities, we can achieve the miraculous.

Brethren, let us hearken to the hymn, “Improve the Shining Moments”:





Time flies on wings of lightning;

We cannot call it back.

It comes, then passes forward

Along its onward track.





And if we are not mindful,

The chance will fade away,

For life is quick in passing.

’Tis as a single day.





(Hymns, 1985, no. 226)





As we leave this general priesthood meeting, let us all determine to shed any barnacles of sin, to prepare for our time of opportunity, and to honor the priesthood we bear through the service we render, the lives we bless, and the souls we are privileged to help save. You are “a chosen generation, a royal priesthood, an holy nation” (1 Pet. 2:9), and you can make a difference. To these truths I testify, in the name of Jesus Christ, amen.

# References
