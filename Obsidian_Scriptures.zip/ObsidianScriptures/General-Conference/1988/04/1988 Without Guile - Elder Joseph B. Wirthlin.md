Elder Joseph B. Wirthlin
Of the Quorum of the Twelve Apostles
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/without-guile?lang=eng)

My beloved brethren and sisters, I pray for that same spirit that we’ve enjoyed so much during this most beautiful and inspirational conference.

Early in his mortal ministry, the Savior soon had a multitude of disciples drawn to him by the power of his presence and the spirit of his message. From among these disciples, he chose twelve to be his special witnesses. “And when it was day, he called unto him his disciples: and of them he chose twelve, whom also he named apostles” (Luke 6:13).

Clearly, Jesus had chosen them; he said, “Ye have not chosen me, but I have chosen you, and ordained you” (John 15:16). These twelve were common men from various walks of life. The Savior selected them because he could see far beyond their earthly appearance and look into their hearts, recognizing their potential.

After the Savior called Peter, Andrew, and Philip, Philip introduced Jesus to Nathanael, whom some scholars believe to be Bartholomew, the Apostle. Philip said to Nathanael, “We have found him, of whom Moses in the law, and the prophets, did write, Jesus of Nazareth, the son of Joseph” (John 1:45). In this statement, Philip testified that Jesus is the Messiah. Nathanael wondered whether any good thing could come out of Nazareth, indicating the relatively bad reputation of Nazareth in those days. Philip asked him to come and see. This is the perfect answer to all who seek to know the truth about Christ. Impartial investigators are converted when they come and see.

When Jesus saw Nathanael coming toward him, he exclaimed of Nathanael, “Behold an Israelite indeed, in whom is no guile!” (John 1:47). At that moment, Nathanael recognized that Jesus could see into his heart and asked, in surprise, “Whence knowest thou me?” (John 1:48). The Savior’s reply demonstrated an even greater power of perception. He told Nathanael that before Philip had called him to come and see, Jesus saw him under a fig tree.

Nathanael apparently had undergone some surpassing spiritual experience while praying, or meditating, or worshipping under a fig tree. The Lord, though absent in body, had been present with Nathanael in spirit. Nathanael then recognized the Savior as the Christ and said, “Rabbi, thou art the Son of God; thou art the King of Israel” (John 1:49).

Nathanael spoke without guile. The words came from his heart. They expressed a deep conviction of truth. He followed the Savior.

To be without guile is to be free of deceit, cunning, hypocrisy, and dishonesty in thought or action. To beguile is to deceive or lead astray, as Lucifer beguiled Eve in the Garden of Eden. A person without guile is a person of innocence, honest intent, and pure motives, whose life reflects the simple practice of conforming his daily actions to principles of integrity.

The psalmist wrote, “Blessed is the man unto whom the Lord imputeth not iniquity, and in whose spirit there is no guile” (Ps. 32:2), and then admonished, “Keep thy tongue from evil, and thy lips from speaking guile” (Ps. 34:13).

In the New Testament, we learn that the Savior was without guile (see 1 Pet. 2:22) and that “he that will love life, and see good days, let him refrain his tongue from evil, and his lips that they speak no guile” (1 Pet. 3:10).

In latter-day scriptures, we read that the Lord called Edward Partridge to be bishop for the Church because “his heart is pure before me, for he is like unto Nathanael of old, in whom there is no guile” (D&C 41:11). In another revelation to the Prophet Joseph Smith the Lord said, “My servant George Miller is without guile; he may be trusted because of the integrity of his heart; and for the love which he has to my testimony I, the Lord, love him” (D&C 124:20).

These passages of scripture help me understand what the Lord could see in Nathanael, Edward Partridge, and George Miller, and give me some insight into what he expects of the Saints. I believe the Savior was seeking purity of soul in those he called to be his twelve Apostles. When he spoke of being without guile, he referred to something far deeper than outward appearance. He was reaching into the soul, to the very heart of righteousness. He was touching the key to goodness and to the Christlike life.

To be without guile is to be pure in heart—an essential virtue of those who would be counted among true followers of Christ. He taught in the Sermon on the Mount, “Blessed are the pure in heart: for they shall see God” (Matt. 5:8; see also 3 Ne. 12:8). He revealed to the Prophet Joseph Smith that Zion is the pure in heart (see D&C 97:21) and that a house is to be built in Zion in which the pure in heart shall see God (see D&C 97:10–16).

If we are without guile, we are honest, true, and righteous. All of these are attributes of Deity and are required of the Saints. Those who are honest are fair and truthful in their speech, straightforward in their dealings, free of deceit, and above stealing, misrepresentation, or any other fraudulent action. Honesty is of God and dishonesty of the devil; the devil was a liar from the beginning. Righteousness is living a life that is in harmony with the laws, principles, and ordinances of the gospel.

As parents know, little children are, by their nature, without guile. They speak the thoughts of their minds without reservation or hesitance as we have learned as parents when they embarrass us at times. They do not deceive. They set an example of being without guile. The Savior taught of this attribute of little children when his disciples asked, “Who is the greatest in the kingdom of heaven?

“And Jesus called a little child unto him, and set him in the midst of them,

“And said, Verily I say unto you, Except ye be converted, and become as little children, ye shall not enter into the kingdom of heaven.

“Whosoever therefore shall humble himself as this little child, the same is greatest in the kingdom of heaven” (Matt. 18:1–4).

On another occasion, he referred again to the purity of children:

“Then were there brought unto him little children, that he should put his hands on them, and pray: and the disciples rebuked them.

“But Jesus said, Suffer little children, and forbid them not, to come unto me: for of such is the kingdom of heaven” (Matt. 19:13–14).

To the Nephites the Savior said, “Ye must repent, and be baptized in my name, and become as a little child, or ye can in nowise inherit the kingdom of God” (3 Ne. 11:38).

“He commanded that their little children should be brought.

“So they brought their little children and set them down upon the ground … and Jesus stood in the midst; and the multitude gave way till they had all been brought unto him. …

“He took their little children, one by one, and blessed them, and prayed unto the Father for them. …

“And … angels did minister unto them” (3 Ne. 17:11–12, 21, 24).

What a great responsibility rests with parents to be certain that they do nothing to alter or destroy the guileless innocence of their little ones!

I believe the necessity for the members of the Church to be without guile may be more urgent now than at other times because many in the world apparently do not understand the importance of this virtue or are indifferent to it. We see and hear reports of fraud and deception in all levels of our society. A few citizens of some nations betray their country by exchanging sensitive information for money, information they have stolen or with which they have been entrusted. The entertainment industry seems to have lost, in large measure, the concept of moral values. Employees falsify expense accounts. These few examples of guile illustrate how pervasive it is.

Of far greater concern than the outward acts of guile are the inner feelings and the attitudes that motivate them. Fraud and deception appear to be increasingly acceptable; the only wrongdoing seems to be in being caught. The objective often is to get gain or to profit, regardless of the injury, loss, or damage to others. This attitude is totally contrary to the principles of the gospel. It hinders or thwarts the spiritual progress of anyone afflicted by it. The practice of guile prevents the Holy Ghost from prompting, guiding, and instructing us, leaving us ever more susceptible to the buffetings of Satan. When we break the commandments, we close ourselves to God’s influence and open ourselves to Satan’s influence.

If we practice guile in small matters, we soon can find ourselves entangled in an ever-increasing, unending spiral, because each lie or other deception often requires a larger one to cover the first. Moreover, the practice of guile often leads to hypocrisy, which is the false pretense of virtue or righteousness and pretending to be something that we are not. If we know what is right and profess to live by that knowledge but, in fact, do not, we are hypocrites. The Savior denounced hypocrites in unmistakable language. He declared:

“Woe unto you, scribes and Pharisees, hypocrites! for ye are like unto whited sepulchres, which indeed appear beautiful outward, but are within full of … all uncleanness.

“Even so ye also outwardly appear righteous unto men, but within ye are full of hypocrisy and iniquity” (Matt. 23:27–28).

To the Prophet Joseph Smith, the Lord revealed: “Wo unto them that are deceivers and hypocrites, for, thus saith the Lord, I will bring them to judgment. …

“[They] shall be detected and shall be cut off, … and wo unto them who are cut off from my church, for the same are overcome of the world” (D&C 50:6, 8).

What are the Latter-day Saints to do? The answer is plain. The Saints are to be absolutely without guile in every aspect of their lives: in their homes and families, Church callings, all business dealings, and, especially, the private and personal parts of their lives into which only they and the Lord see.

I suggest that we look into our hearts and see whether our motives and actions are pure and above reproach and to see whether we are free of deceit and fraud. Perhaps we can ask ourselves a few questions.

Are we totally free of guile in our conversations and associations with our spouses and children so they always know what to expect and always have unquestioning trust and confidence in us?

Are we forthright in our interviews with our bishops and other priesthood leaders?

Are we true to ourselves, our classmates, and our teachers in our schoolwork, even if a little cheating might improve our grades?

Do we do more work than our employers expect or require, and are we always alert for ways to do our work better?

Do we pay our employees fairly for their labors?

Do we file accurate tax returns?

Are we scrupulous in all business transactions to the extent that our associates always know they are being treated fairly and would feel secure if they had no contract?

Are we satisfied with our personal standards of integrity, morality, and honesty? Can we say of ourselves, as Jesus said of Nathanael, that we are without guile?

Some may think the idea of a society without guile is preposterous in this day. If so, it is because of the power Satan has over the hearts of men. With the Lord’s help, the Saints can be without guile. Being honest and fair helps rather than hinders success and prosperity. One man of my acquaintance was in a very competitive business for thirty-six years. He always gave full value in service, quality, and quantity. He paid every debt in full. He never sued anyone and never was sued during those years.

During a recent visit to the land of Chile, we visited people who were without guile almost to the point of possessing the naive innocence of little children. We were humbled and refreshed to be among them. They strengthened our faith in mankind and our hope for the future.

Yes, the Saints can be free of guile—and must be, to be prepared for the Savior’s second coming. The Saints can provide a leavening influence and can demonstrate the value of guileless living. As we develop this divine attribute, we can become a shining light to the world. Certainly, we can teach the principles of the gospel and bless the families of the earth by following the perfect example of the Savior as one who is without guile.

Visualize in your mind a society in which all are pure in heart and completely free of deceit and dishonesty. Can you imagine a total absence of contention and disputes, with no one ever attempting to deceive another? How would life be if we always were certain, without question, that what others represent to us is true? Theft would be unknown. We would have little use for jails or prisons, and litigation would be rare. The greatest blessing that would come to a society without guile is the individual, personal inner peace that comes to those who know they are doing right and know their lives are acceptable to the Lord.

A society without guile is possible. I cite two examples from the scriptures. The first is the City of Holiness, even Zion, a city in which the inhabitants were pure in heart and dwelt in righteousness. In fact, Zion is the name given by the Lord to his Saints. That city, referred to as the city of Enoch, was taken up into heaven (see Moses 7:18–21). The second example is the society of the Nephites that lasted for about two hundred years after the resurrected Lord visited and taught them. The following words of inspiration from the Book of Mormon describe this society:

“There were no contentions and disputations among them, and every man did deal justly one with another.

“And there were no envyings, nor strifes, nor tumults, nor whoredoms, nor lyings, nor murders, nor any manner of lasciviousness; and surely there could not be a happier people. …

“There were no robbers, nor murderers, … but they were in one, the children of Christ, and heirs to the kingdom of God. …

“And how blessed were they! For the Lord did bless them in all their doings; yea, even they were blessed and prospered” (4 Ne. 1:2, 16–18).

These are examples of the goal of perfection that we should strive for, even though we know that we must perfect our lives grace upon grace and line upon line (see John 1:16, 2 Ne. 28:30).

I look to President Ezra Taft Benson as one whose life of service exemplifies the virtue of being without guile.

In closing, I add my testimony at this Easter season to the testimonies of my brethren that the Atonement and Resurrection are real. I am grateful for the blessing they provide of immortality for all and for the possibility of eternal life it offers those who are faithful.

I testify to you that our Heavenly Father lives and that he is the father of our spirits. Jesus is the Christ, the Son of God. He stands at the head of this Church. Joseph Smith was the prophet of God through whom the gospel of Jesus Christ was restored in these, the latter days. President Ezra Taft Benson is the Lord’s prophet today. He directs this Church by revelation. I bear this testimony humbly in the name of our Lord and Savior, Jesus Christ, amen.

# References
