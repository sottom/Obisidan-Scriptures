Elder George R. Hill III
Of the First Quorum of the Seventy
04-1988
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/1988/04/solutions-from-the-scriptures?lang=eng)

My beloved fellow servants of our Lord and Savior, Jesus Christ, since receiving this special call to full-time service for the Master, I have studied and pondered and prayed, as do all of you, to determine how best to serve.

It has been my privilege during the forty years prior to last April conference to search for truth through research in the physical sciences, an endeavor which blends some inspiration with a lot of perspiration, but which leads to the discovery of facts and principles which bring much benefit to mankind. I am most grateful for that privilege, as well as for the simultaneous privilege of discovering the principles of truth revealed directly from the Lord to his chosen prophets, as recorded in the scriptures. To the many young people of the Church who have the privilege of discovering truth through the scientific method, let me add my testimony to those of Elders James E. Talmage and John A. Widtsoe (author of a choice book, In Search of Truth) that there is no conflict between the facts and truths of science and those given to us by direct revelation. Rather than conflicting, the facts and truths in each area complement each other, each supplying answers to basic questions which we must know, eventually, if we are to fulfill our destiny as sons and daughters and copartners with our Father in his eternal plan.

Apparent conflicts arise when the theories of science—which serve as a scaffolding erected to try to understand relationships among observed facts—are mistaken for the experimentally verified facts.

Occasionally also, some people subject the scriptures to personal interpretation. This can give rise to differences in perception as well. I have learned to say, “I don’t know,” when confronted with choices which seem to be in conflict. No true scientist will say that we have final, exact answers through scientific research; it is an ongoing, learning process. The Articles of Faith teach us that the Lord “will yet reveal many great and important things pertaining to the Kingdom of God” (A of F 1:9). As members of the Lord’s church our blessing is to believe all that is true and to diligently seek learning “by study and also by faith” (D&C 88:118).

In our assignment in the Philippines, we have found it necessary to go to the scriptures for solutions to the challenges accompanying the wonderfully high conversion rate of a very spiritually sensitive people who need guidance in Church administrative procedures.

This is occurring in a land with an extremely high unemployment rate. We find food and materials shortages which remind us of the conditions that must have followed the destruction of the Nephite cities at the time of the Savior’s crucifixion. At that time, the resurrected Savior gave the surviving Nephites some direction they needed to reestablish their civilization. He quoted His own words to Malachi of the need for their being faithful in their tithes and offerings:

“Will a man rob God? Yet ye have robbed me. But ye say: Wherein have we robbed thee? In tithes and offerings. …

“Bring ye all the tithes into the storehouse, that there may be meat in my house; and prove me now herewith, saith the Lord of Hosts, if I will not open you the windows of heaven, and pour you out a blessing that there shall not be room enough to receive it. …

“And all nations shall call you blessed, for ye shall be a delightsome land, saith the Lord of Hosts” (3 Ne. 24:8, 10, 12).

The marvelous fulfillment of that promise within three years is described in 4 Nephi 1:2–5 [4 Ne. 1:2–5].

The members of the Church in the Philippines are becoming aware that sacrifice precedes the blessing and that they must live the law of tithing and the law of the fast if they are to receive the promises given those who do, as described in Isaiah 58:

“Is not this the fast that I have chosen? to loose the bands of wickedness, to undo the heavy burdens, and to let the oppressed go free … ?

“Is it not to deal thy bread to the hungry, and that thou bring the poor that are cast out to thy house? …

“Then shall thy light break forth as the morning, and thine health shall spring forth speedily. …

“Then shalt thou call, and the Lord shall answer; thou shalt cry, and he shall say, Here I am. …

“And the Lord shall guide thee continually, and satisfy thy soul in drought, and make fat thy bones: and thou shalt be like a watered garden, and like a spring of water, whose waters fail not” (Isa. 58:6–9, 11).

Mosiah 4:26 reinforces this counsel.

We are finding it very important to follow the advice given by the First Presidency—to get back to basics and to practice the new version of the three Rs. Because the flood of new members exceeds the normal friendshipping capacity in wards and branches, our perceptive mission presidents and stake presidents are cooperating in the “Retaining and Reactivating, by Recording the participation and growth in Church service,” of each current and recent convert to the Church. The marked increase in continuing activity of new members is most encouraging and satisfying.

The need for leaders who understand the principles of the gospel and who can carry out the detailed administrative responsibilities in their new callings, while ministering to the individual, reminds us of the challenges faced by the Prophet Joseph in the Kirtland era of the early Church. Then, as now, there was a need for intense instruction in the Lord’s way of doing things. The Lord’s direction then was to institute the “school of the prophets, established for their instruction in all things that are expedient for them, even for all the officers of the church, … even down to the deacons” (D&C 88:127). The stake priesthood leadership meeting provides a forum for the pretraining of potential leaders, to supplement the learning-by-observing method followed in established areas of the Church. What a blessing it is to be able to go to the scriptures to find the answers to virtually any challenge we face in our Church callings.

Let me close by expressing my love and gratitude for goodly parents, to my choice wife and companion, and to our children and grandchildren, who sustain us so well with their prayers and the lives they lead. To them and to you I testify that the gospel of Jesus Christ is true, that Jesus lives and loves each of us with an unbounded love, and that Ezra Taft Benson is His chosen prophet today, in the name of Jesus Christ, amen.

# References
