Presented by Brook P. Hales
Secretary to the First Presidency
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/statistical-report-2012?lang=eng)

For the information of the members of the Church, the First Presidency has issued the following statistical report regarding the growth and status of the Church as of December 31, 2012.





Church Units





Stakes



3,005



Missions



347



Districts



591



Wards and Branches



29,014









Church Membership





Total Membership



14,782,473



New Children of Record during 2012



122,273



Converts Baptized during 2012



272,330









Missionaries





Full-Time Missionaries



58,990



Church-Service Missionaries



22,961









Temples





Temples Dedicated during 2012 (Kansas City Missouri, Manaus Brazil, Brigham City Utah, and Calgary Alberta)



4



Temples Rededicated during 2012 (Buenos Aires Argentina and Boise Idaho)



2



Temples in Operation



140

# References
