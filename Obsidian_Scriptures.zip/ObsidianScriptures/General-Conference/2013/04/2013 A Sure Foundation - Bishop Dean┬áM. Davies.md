Bishop Dean M. Davies
Second Counselor in the Presiding Bishopric
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/a-sure-foundation?lang=eng)

_Let us accept the Savior’s invitation to come unto Him. Let us build our lives upon a safe and a sure foundation._

On October 17, 1989, while driving home after work, I was approaching a stoplight at the intersection of Market and Beale Streets in San Francisco, California. At that moment I felt the car shake and thought, “I must have a flat tire.” As the car continued to shake, I noticed a bus quite close to me and thought, “That bus just hit me!” Then the car shook more and more, and I thought, “I must have four flat tires!” But it wasn’t flat tires or the bus—it was a powerful earthquake! As I stopped at the red light, there were ripples in the pavement like waves of the sea rolling down Market Street. In front of me a tall office building was swaying from side to side, and bricks began falling from an older building to my left as the earth continued to shake.

The Loma Prieta earthquake struck the San Francisco Bay Area at 5:04 p.m. that day and left as many as 12,000 people homeless.

The earthquake caused severe damage in the San Francisco Bay Area, most notably on unstable soil in San Francisco and Oakland. In San Francisco, the Marina District had been “built on a landfill made of a mixture of sand, dirt, rubble, … and other materials containing a high percentage of groundwater. Some of the fill was rubble dumped into San Francisco Bay after the 1906 San Francisco earthquake.”1

In about 1915, apartment buildings were erected on the landfill. In the 1989 earthquake, the water-saturated unconsolidated mud, sand, and rubble converted to a liquid-like mass, causing the buildings to collapse. The buildings were not built on a sure foundation.

The Loma Prieta earthquake impacted many lives, including my own. Pondering the events of that day reaffirms in my mind and heart that in order to successfully withstand the tempests, earthquakes, and calamities of life, we must build upon a sure foundation.

The Nephite prophet Helaman gave unmistakable clarity to the importance of building our lives on a sure foundation, even the foundation of Jesus Christ: “And now, my sons, remember, remember that it is upon the rock of our Redeemer, who is Christ, the Son of God, that ye must build your foundation; that when the devil shall send forth his mighty winds, yea, his shafts in the whirlwind, yea, when all his hail and his mighty storm shall beat upon you, it shall have no power over you to drag you down to the gulf of misery and endless wo, because of the rock upon which ye are built, which is a sure foundation, a foundation whereon if men build they cannot fall” (Helaman 5:12).

In the development of modern-day temples, careful attention is given to the design, engineering, and use of building materials. Thorough testing of the soils and geology takes place on the site where a temple will be built. Studies of wind, rain, and changes in the weather for the area are considered so that the completed temple can withstand not only storms and climate common to an area, but the temple is designed and positioned to withstand the unexpected earthquakes, typhoons, floods, and other natural calamities that may occur. In many temples, concrete or steel piles are driven deep into the earth to anchor the temple foundation.

Like the designers and builders of our time, our loving and kind Father in Heaven and His Son have prepared plans, tools, and other resources for our use so that we can build and frame our lives to be sure and unshaken. The plan is the plan of salvation, the great plan of happiness. The plan lays out for us a clear picture and understanding of the beginning and the end and the essential steps, including ordinances, which are necessary for each of Father’s children to be able to return to His presence and dwell with Him forever.

Faith, repentance, baptism, the gift of the Holy Ghost, and enduring to the end are part of the “blueprints” of life. They help to form the appropriate building blocks that will anchor our lives to the Atonement of Christ. These shape and frame the supporting structure of a person’s life. Then, just as temple plans have specifications that give detailed instructions about how to form and integrate essential components, praying, reading the scriptures, partaking of the sacrament, and receiving essential priesthood ordinances become the “specifications” that help integrate and bind together the structure of life.

Balance in the application of these specifications is vital. For example, in the process of making concrete, precise amounts of sand, gravel, cement, and water are used in order to achieve maximum strength. An incorrect amount or exclusion of any portion of these elements would make the concrete weak and not able to perform its important function.

In like manner, if we do not provide for an appropriate balance in our lives of daily personal prayer and feasting from the scriptures, weekly strengthening from partaking of the sacrament, and frequent participation in priesthood ordinances such as temple ordinances, we too are at risk of being weakened in our spiritual structural strength.

Paul, in a letter to the Ephesians, said it this way, which we can apply to the need for a balanced and integrated development of our character and soul: “In whom all the building fitly framed together groweth unto an holy temple in the Lord” (Ephesians 2:21).

Prayer is one of the most basic and important foundational building blocks of our faith and character. Through prayer we are able to express our gratitude, love, and devotion to God. Through prayer we can submit our will to His and in return receive the strength to conform our lives to His teachings. Prayer is the avenue we can follow to seek His influence in our lives, even revelation.

Alma taught, “Counsel with the Lord in all thy doings, and he will direct thee for good; yea, when thou liest down at night lie down unto the Lord, that he may watch over you in your sleep; and when thou risest in the morning let thy heart be full of thanks unto God; and if ye do these things, ye shall be lifted up at the last day” (Alma 37:37).

Sharing our thoughts, feelings, and desires with God through sincere and heartfelt prayer should become to each of us as important and natural as breathing and eating.

Searching the scriptures on a daily basis will also fortify our faith and character. Just as we need food to nourish our physical bodies, our spirits and souls will be replenished and strengthened by feasting upon the words of Christ as contained in the writings of the prophets. Nephi taught, “Feast upon the words of Christ; for behold, the words of Christ will tell you all things what ye should do” (2 Nephi 32:3).

While reading the scriptures is good, reading by itself is insufficient to capture the full breadth and depth of the Savior’s teachings. Searching, pondering, and applying the words of Christ as taught in the scriptures will bring wisdom and knowledge beyond our mortal understanding. This will strengthen our commitment and provide the spiritual reserves to do our best in all situations.

One of the most important steps we can take to strengthen our lives and remain firmly attached to the foundation of the Savior is to worthily partake of the sacrament each week. The sacrament ordinance affords every Church member the opportunity to ponder his or her life in advance, to consider the actions or nonactions that may need to be repented of, and then to partake of the bread and water as sacred emblems in remembrance of the body and blood of Jesus Christ, a witness of His Atonement. If we partake with sincerity and in humility, we renew eternal covenants, are cleansed and sanctified, and receive the promise that we will have His Spirit to be with us always. The Spirit acts as a type of mortar, a welding link that not only sanctifies but also brings all things to our remembrance and testifies again and again of Jesus Christ. Worthily partaking of the sacrament strengthens our personal connection to the foundation rock, even to Jesus Christ.

During His ministry the Savior taught with love and clarity the doctrines, principles, and necessary actions that would preserve our lives and strengthen our character. At the end of the Sermon on the Mount, He stated:

“Therefore, whoso heareth these sayings of mine and doeth them, I will liken him unto a wise man, [which] built his house upon a rock—

“And the rain descended, and the floods came, and the winds blew, and beat upon that house; and it fell not, for it was founded upon a rock.

“And every one that heareth these sayings of mine and doeth them not shall be likened unto a foolish man, [which] built his house upon the sand—

“And the rain descended, and the floods came, and the winds blew, and beat upon that house; and it fell, and great was the fall of it” (3 Nephi 14:24–27; see also Matthew 7:24–27).

Brothers and sisters, none of us would knowingly construct our homes, places of work, or sacred houses of worship on sand or rubble or without appropriate plans and materials. Let us accept the Savior’s invitation to come unto Him. Let us build our lives upon a safe and a sure foundation.

I humbly testify that by anchoring our lives to Jesus Christ and to His Atonement and by carefully following His plans for our happiness, including daily prayer, daily scripture study, and weekly partaking of the sacrament, we will be strengthened, we will experience real personal growth and a lasting conversion, we will be better prepared to successfully withstand the storms and calamities of life, we will experience the joy and happiness promised, and we will have the confidence that our lives have been built upon a sure foundation—a foundation that will never fall. In the sacred name of Jesus Christ, amen.

# References
1. - See “1989 Loma Prieta Earthquake,” wikipedia.org/wiki/1989_Loma_Prieta_earthquake.