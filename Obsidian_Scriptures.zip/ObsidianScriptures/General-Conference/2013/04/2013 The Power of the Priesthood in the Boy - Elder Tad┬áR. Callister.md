Elder Tad R. Callister
Of the Presidency of the Seventy
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/the-power-of-the-priesthood-in-the-boy?lang=eng)

_The priesthood in the boy is just as powerful as the priesthood in the man when exercised in righteousness._

In 1878 my great-grandfather George F. Richards was 17 years of age. As was sometimes the case in those days, he had already been ordained an elder. One Sunday his mother was groaning in intense pain. As his father was not available, the bishop and several others were invited to give her a blessing, but no relief came. Accordingly, she turned to her son George and asked him to lay hands on her head. He wrote in his diary, “In the midst of my tears for my mother’s suffering and the task of performing an administration such as I had never yet done, I retired to another room where I wept and prayed.”

When he became composed, he laid his hands on her and gave her a very simple blessing. He later noted, “My mother ceased her groaning and received relief from her suffering while my hands were yet on her head.” He then recorded in his diary this most insightful observation. He said he had always felt that the reason his mother did not get relief from the bishop’s blessing was not because the Lord failed to honor the bishop’s blessing but because the Lord had reserved this blessing for a boy, to teach him a lesson that the priesthood in the boy is just as powerful as the priesthood in the man when exercised in righteousness.

Tonight I would like to speak about that power. Though I will refer to deacons quorum presidents, the principles discussed apply to all Aaronic Priesthood youth and their respective leaders, including our teachers quorum presidents and assistants to the priests quorum president.

While serving as a mission president, I observed that there was a dramatic increase in the spirituality and leadership skills of young men during their mission years. If we could somehow quantify these qualities over their Aaronic Priesthood and mission years, perhaps they would look something like the blue line you see on this graph. In my mind there are at least three key factors that contribute to such dramatic growth in the mission years: (1) we trust these young men as never before, (2) we have high but loving expectations of them, and (3) we train and retrain them so they can fulfill those expectations with excellence.



  Imagegraph



Spirituality and Leadership





One might appropriately ask, “Why could not these same principles be employed with deacons quorum presidents?” If that were done, perhaps the growth would commence much earlier and look more like the green line on the graph. For a moment, may I address how these principles might apply to a deacons quorum president.

First—trust. We can entrust our deacons quorum presidents with great responsibility. The Lord certainly does—as demonstrated by His willingness to give them keys, meaning the right to preside over and direct the work in their quorum. As an evidence of this trust, we call deacons quorum presidents by revelation, not solely by seniority or any other similar factor. Every leader in this Church, including the deacons quorum president, has the right to know, and should know, that he has been called by revelation. This assurance helps him know that God both trusts him and sustains him.

The second and third attributes are interconnected—high expectations and the related training to fulfill them. I learned a great lesson in the mission field: missionaries generally rise or fall to the mission president’s level of expectation, and so it is with deacons quorum presidents. If they are expected only to conduct quorum meetings and attend bishopric youth committee meetings, then that is all they will do. But you leaders can give them a greater vision—the Lord’s vision. And why is vision so critical? Because with increased vision comes increased motivation.

Inherent in every calling in this Church is the right to receive revelation. Hence, these deacons quorum presidents need to know they have the right to receive revelation to recommend their counselors, the right to receive revelation concerning rescue of the lost, and the right to receive revelation to train the quorum members in their duties.

A wise leader will teach the deacons quorum president those principles that will be helpful in obtaining revelation. He may teach him the unequivocal promise of the Lord: “If thou shalt ask, thou shalt receive revelation upon revelation” (D&C 42:61). The Lord is most generous in giving revelation. Did He not remind Joseph Smith and Oliver Cowdery, “As often as thou hast inquired thou hast received instruction of my Spirit” (D&C 6:14)? And so it can be with you deacons quorum presidents. The Lord loves you and wants to reveal to you His mind and will. Could you ever imagine the Lord having a problem He could not solve? I can’t. Because you are entitled to revelation, He can help you solve every concern you have as president of your quorum if you will but seek His help.

You wonderful leaders might teach this deacons quorum president that revelation is not a substitute for hard work and homework. President Henry B. Eyring once asked President Harold B. Lee, “How do I get revelation?” President Lee responded, “If you want to get revelation, do your homework.”1 The wise leader might discuss with his deacons quorum president some of the spiritual homework he might do in preparing to recommend his counselors. He might need to ask and answer questions such as: Who would be a good example that could lift the other boys? Or who would be sensitive to the needs of those who face special challenges?

And finally this wise leader might teach him how to recognize and act upon revelation when it comes. We live in an action-packed, fast-paced world where bright lights and high-volume speakers are the norm. But this young man needs to know that this is the world’s way, not the Lord’s way. The Savior was born in the relative anonymity of a manger; He performed the most magnificent and incomparable act of all time in the quiet of a garden; and Joseph received his First Vision in the seclusion of a grove. God’s answers come by the still, small voice—feelings of peace or comfort, impressions to do good, enlightenment—sometimes in the form of tiny seeds of thoughts which if reverenced and nourished can grow into spiritual redwoods. Sometimes these impressions or thoughts might even cause you deacons quorum presidents to recommend as a counselor or extend an assignment to a young man who is currently less active.

Years ago as a stake presidency, we felt impressed to call a good man as stake clerk. At the time he was temporarily struggling with regular Church attendance. We knew, however, that if he accepted the calling, he would do a marvelous job.

We extended the call, but he replied, “No, I don’t think I can do it.”

Then an impression came. I said, “Well, I guess the Glendale stake won’t have a stake clerk then.”

Shocked, he responded, “What are you talking about? You have to have a stake clerk.”

I replied, “Do you want us now to call someone else to serve as stake clerk when the Lord impressed us to call you?”

“OK,” he said, “I’ll do it.”

And do it he did. There are not only many men but also many boys who will respond to a call when they know the Lord is calling them and that the Lord needs them.

Next you can let this deacons quorum president know that one of the Lord’s expectations of him is to rescue the lost, both less active and nonmember. The Lord declared His central mission in these terms: “For the Son of man is come to save that which was lost” (Matthew 18:11). If it is a priority of the Savior to rescue the lost, if it is a priority of President Thomas S. Monson to do so, as demonstrated by his entire life, should it not be a priority of every leader, every deacons quorum president in this Church to do likewise? At the core of our leadership, as a central part of our ministry, should be the burning, driving, unrelenting resolve to go get the lost and bring them back.

One young man who was visited by his quorum members said: “It was surprising today when … 30 people just came up to my house. … It makes me want to go to church now.” How can a youth resist love and attention like that?

I am thrilled when I hear the many stories of deacons quorum presidents who have caught the vision and occasionally are teaching all or part of the lesson in their quorum meetings. Several weeks ago I attended a deacons quorum class. A 12-year-old boy gave a 25-minute lesson on the Atonement. He commenced by asking his fellow deacons what they thought the Atonement was. Then he shared some meaningful scriptures and asked thoughtful questions, to which they responded. Realizing, however, there was more time than remaining lesson material, he had enough presence of mind and perhaps some forewarning from his father to ask the leaders who were present what questions they had been asked about the Atonement on their missions and their responses. He then concluded with his testimony. I listened in awe. I thought to myself, “I don’t recall ever giving a significant part of a lesson when I was an Aaronic Priesthood youth.” We can raise the bar and vision for these young men, and they will respond.

You leaders lift these deacons quorum presidents best when you let them lead out and you step back from the spotlight. You have magnified your calling best not when you give a great lesson but when you help them give a great lesson, not when you rescue the one but when you help them do so.

There is an old saying: do not die with your music still in you. In like manner I would say to you adult leaders, do not get released with your leadership skills still in you. Teach our youth at every opportunity; teach them how to prepare an agenda, how to conduct meetings with dignity and warmth, how to rescue the one, how to prepare and give an inspired lesson, and how to receive revelation. This will be the measure of your success—the legacy of leadership and spirituality you leave ingrained in the hearts and minds of these young men.

If you deacons quorum presidents will magnify your calling, you will be instruments in God’s hands even now, for the priesthood in the boy is just as powerful as the priesthood in the man when exercised in righteousness. And then when you make temple covenants and become the missionaries and future leaders of this Church, you will know how to receive revelation, how to rescue the one, and how to teach the doctrine of the kingdom with power and authority. Then you will have become the youth of the noble birthright. Of this I so testify in the name of Jesus Christ, who is the Savior and Redeemer of the world, amen.

# References
1. - In Henry B. Eyring, “Waiting Upon the Lord,” in Brigham Young University 1990–91 Devotional and Fireside Speeches (1991), 17.