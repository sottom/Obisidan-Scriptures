Elder L. Whitney Clayton
Of the Presidency of the Seventy
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/marriage-watch-and-learn?lang=eng)

_The promises of the Lord are extended to all those who follow the pattern of life that builds happy, holy marriage relationships._

One evening several years ago, my wife and I were visiting the home of one of our sons and his wife and children for dinner. It was a typical event for a family with small children: there was much noise and even more fun. Shortly after dinner our four-year-old granddaughter, Anna, and I were still sitting at the table. Realizing that she had my full attention, she stood up straight on a bench and fixed her eyes on me. When she was sure that I was looking at her, she solemnly ordered me to “watch and learn.” She then danced and sang a song for me.

Anna’s instruction to “watch and learn” was wisdom from the mouth of a babe. We can learn so much by watching and then considering what we have seen and felt. In that spirit, let me share with you a few principles I have observed by watching and learning from wonderful, faithful marriages. These principles build strong, satisfying marriages that are compatible with heavenly principles. I invite you to watch and learn with me.

First, I have observed that in the happiest marriages both the husband and wife consider their relationship to be a pearl beyond price, a treasure of infinite worth. They both leave their fathers and mothers and set out together to build a marriage that will prosper for eternity. They understand that they walk a divinely ordained path. They know that no other relationship of any kind can bring as much joy, generate as much good, or produce as much personal refinement. Watch and learn: the best marriage partners regard their marriages as priceless.

Next, faith. Successful eternal marriages are built on the foundation of faith in the Lord Jesus Christ and adherence to His teachings.1 I have observed that couples who have made their marriages priceless practice the patterns of faith: they attend sacrament and other meetings every week, hold family home evening, pray and study the scriptures together and as individuals, and pay an honest tithing. Their mutual quest is to be obedient and good. They do not consider the commandments to be a buffet from which they can pick and choose only the most appealing offerings.



Faith is the foundation of every virtue that strengthens marriage. Strengthening faith strengthens marriage. Faith grows as we keep the commandments, and so do the harmony and joy in marriage. Thus, keeping the commandments is fundamental to establishing strong eternal marriages. Watch and learn: faith in the Lord Jesus Christ is the foundation of happy eternal marriages.

Third, repentance. I have learned that happy marriages rely on the gift of repentance. It is an essential element in every good marital relationship. Spouses who regularly conduct honest self-examination and promptly take needed steps to repent and improve experience a healing balm in their marriages. Repentance helps restore and maintain harmony and peace.

Humility is the essence of repentance. Humility is selfless, not selfish. It doesn’t demand its own way or speak with moral superiority. Instead, humility answers softly2 and listens kindly for understanding, not vindication. Humility recognizes that no one can change someone else, but with faith, effort, and the help of God, we can undergo our own mighty change of heart.3 Experiencing the mighty change of heart causes us to treat others, especially our spouses, with meekness.4 Humility means that both husbands and wives seek to bless, help, and lift each other, putting the other first in every decision. Watch and learn: repentance and humility build happy marriages.

Fourth, respect. I have observed that in wonderful, happy marriages, husbands and wives treat each other as equal partners. Practices from any place or any time in which husbands have dominated wives or treated them in any way as second-class partners in marriage are not in keeping with divine law and should be replaced by correct principles and patterns of behavior.

Husbands and wives in great marriages make decisions unanimously, with each of them acting as a full participant and entitled to an equal voice and vote.5 They focus first on the home and on helping each other with their shared responsibilities.6 Their marriages are based on cooperation, not negotiation. Their dinner hour and the family time that follows become the center of their day and the object of their best efforts. They turn off electronics and forgo personal entertainment in order to help with household duties. To the extent possible, they read with their children every night and both participate in putting the little ones to bed. They retire to their bed together. As their duties and circumstances permit, husbands and wives work side by side in doing the most important work there is—the work we do in our own homes.

Where there is respect, there is also transparency, which is a key element of happy marriages. There are no secrets about relevant matters in marriages based on mutual respect and transparency. Husbands and wives make all decisions about finances together, and both have access to all information.

Loyalty is a form of respect. Prophets teach that successful marriage partners are “fiercely loyal” to each other.7 They keep their social media use fully worthy in every way. They permit themselves no secret Internet experiences. They freely share with each other their social network passwords. They do not look at the virtual profiles of anyone in any way that might betray the sacred trust of their spouse. They never do or say anything that approaches the appearance of impropriety, either virtually or physically. Watch and learn: terrific marriages are completely respectful, transparent, and loyal.

Fifth, love. The happiest marriages I have seen radiate obedience to one of the happiest commandments—that we “live together in love.”8 Speaking to husbands, the Lord commanded, “Thou shalt love thy wife with all thy heart, and shalt cleave unto her and none else.”9 A Church handbook teaches: “The word cleave means to be completely devoted and faithful to someone. Married couples cleave to God and one another by serving and loving each other and by keeping covenants in complete fidelity to one another and to God.” Both the husband and wife “leave behind their single life and establish their marriage as [their] first priority. … They allow no other person or interest to have greater priority … than keeping the covenants they have made with God and each other.”10 Watch and learn: successful couples love each other with complete devotion.

There are those whose marriages are not as happy as they would wish, as well as those who have never married, are divorced, are single parents, or for various reasons are not in a position to marry. These circumstances can be full of challenge and heartbreak, but they need not be eternal. To those of you in such situations who nevertheless “cheerfully do all things that lie in [your] power”11 to persevere, may heaven bless you richly. Seek after the ideal of forming an eternal marriage, including by striving or preparing to be a worthy spouse. Keep the commandments, and trust the Lord and His perfect love for you. One day every promised blessing concerning marriage will be yours.12

One of the sweetest verses in the Book of Mormon states simply, “And they were married, and given in marriage, and were blessed according to the multitude of the promises which the Lord had made unto them.”13 The promises of the Lord are extended to all those who follow the pattern of life that builds happy, holy marriage relationships. Such blessings come as the delightful, predictable consequences of faithfully living the gospel of Jesus Christ.

I am grateful for my wonderful wife, Kathy, who is the love of my life.

Marriage is a gift from God to us; the quality of our marriages is a gift from us to Him. I bear testimony of the marvelous plan of our loving Heavenly Father, which provides for eternal, wondrous marriage. In the name of Jesus Christ, amen.

# References
1. - See “The Family: A Proclamation to the World,” Ensign or Liahona, Nov. 2010, 129.
2. - See Proverbs 15:1.
3. - See Alma 5:11–12, 26–31.
4. - See Moroni 7:43–48; 8:25–26.
5. - See Doctrine and Covenants 107:27–31.
6. - See “The Family: A Proclamation to the World,” 129.
7. - See Thomas S. Monson, “Priesthood Power,” Ensign or Liahona, May 2011, 68; Gordon B. Hinckley, “Life’s Obligations,” Ensign, Feb. 1999, 4; Liahona, May 1999, 4.
8. - Doctrine and Covenants 42:45.
9. - Doctrine and Covenants 42:22.
10. - Handbook 2: Administering the Church (2010), 1.3.1.
11. - Doctrine and Covenants 123:17.
12. - See Handbook 2, 1.3.3.
13. - 4 Nephi 1:11.