Ann M. Dibb
Second Counselor in the Young Women General Presidency
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/your-holy-places?lang=eng)

_Whether [your holy places] are geographic or moments in time, they are equally sacred and have incredible strengthening power._

Our 2013 Mutual theme comes from the 87th section of the Doctrine and Covenants. This instruction is found in three separate sections; obviously the admonition is important. It explains how we can receive protection, strength, and peace in unsettling times. The inspired instruction is to “stand ye in holy places, and be not moved.”1

As I have pondered this theme, I can’t help but wonder, “What are the ‘holy places’ Heavenly Father is referring to?” President Ezra Taft Benson counseled, “Holy places include our temples, our chapels, our homes, and the stakes of Zion, which are … ‘for a defense, and for a refuge.’”2 In addition to these, I believe we can each find many more places. We might first consider the word place as a physical environment or a geographic location. However, a place can be “a distinct condition, position, or state of mind.”3 This means holy places can also include moments in time—moments when the Holy Ghost testifies to us, moments when we feel Heavenly Father’s love, or moments when we receive an answer to our prayers. Even more, I believe any time you have the courage to stand for what is right, especially in situations where no one else is willing to do so, you are creating a holy place.

Throughout Joseph Smith’s short but magnificent life, he truly “[stood] in holy places” and was not moved. As a young teenager, he was troubled by the religious turmoil in his community and wanted to know which of all the churches was true. The wooded area close to his home became a holy place as he knelt among the trees and offered his first vocal prayer. His prayer was answered, and today Latter-day Saints refer to these woods as the Sacred Grove.



Young women around the world stand in holy places in nature at Young Women camp. A leader shared with me the story of one young woman’s experience. This girl was less active and was a bit skeptical about having a spiritual experience in the woods. After the first day, she reported to the leader, “I’m having a great time, but could we please cut out all of the talk about the Spirit? I’m here to camp, enjoy nature, be with my friends, and have some fun!” However, at the concluding testimony meeting, this same girl tearfully admitted, “I don’t want to go home. How can I have what I am feeling right now, this Spirit, with me all the time?” She had discovered a holy place.

Another holy place in Joseph Smith’s life was his own bedroom. This may be hard to believe because, like many of you, he shared his bedroom with siblings. It became a holy place when he prayed with great faith, humility, and need. He explained, “After I had retired to my bed for the night, I betook myself to prayer and supplication to Almighty God for forgiveness of all my sins and follies.”4 The three years which had passed since Joseph had the vision in the Sacred Grove had not been easy. Seventeen-year-old Joseph had endured endless mockery, ridicule, and bullying. But that night in Joseph’s bedroom, the angel Moroni appeared in answer to his pleadings. Joseph received knowledge and comfort. That night, his bedroom became a holy place.

While watching a Mormon Message for Youth, I witnessed another bedroom that had become a holy place. The video shows Ingrid Delgado, a young woman from El Salvador, sharing her feelings about the temple. She says, “It is good to know we have a place where we can get away from the things of the world and receive sacred ordinances and help those who couldn’t receive them in this life.” As she speaks, the video shows Ingrid reading her scriptures, surrounded by Mormonads, quotations, a Personal Progress book, pictures of her family and the temple, and yes, her favorite stuffed animals.5 Perhaps without even realizing it, she has created her holy place away from the things of the world. I wonder how many times Ingrid has read her scriptures, felt the Spirit, and received answers to her prayers in her holy place.

Yet another unexpected holy place in Joseph Smith’s life was Liberty Jail. Elder Jeffrey R. Holland said, “There was no more burdensome time in Joseph’s life than this cruel, illegal, and unjustified incarceration.” Elder Holland went on to explain that Liberty Jail has been referred to as a “prison-temple” because of the sacred experiences the Prophet Joseph Smith had there.6

Some of you young women may be experiencing your own Liberty Jail, a place where you face humiliation, a place where you feel no loving-kindness, a place where you are mocked, bullied, or even physically harmed. To you young women I offer Elder Holland’s words: “You can have sacred, revelatory, profoundly instructive experiences with the Lord in the most miserable experiences of your life … , while enduring the most painful injustices, when facing the most insurmountable odds and opposition you have ever faced.”7 In other words, just like the Prophet Joseph Smith, you can create and stand in holy places even in the hardest times you have ever experienced.

A young adult, Kirsten, shared with me her painful experience. High school had been her Liberty Jail. Fortunately, the band room provided relief. She said: “When I stepped into this room, it was as if I stepped into a safe place. There were no degrading or belittling remarks, no profanity. Instead, we heard words of encouragement and love. We exercised kindness. It was a happy place. The band room was filled with the Spirit as we practiced and performed music. The room was like this in large measure because of the influence of the band instructor. He was a good Christian man. Looking back, high school was a refining place. It was difficult, but I learned resilience. I will forever be grateful for my refuge, my holy place, the band room.”8

Tonight, have you been reflecting upon your holy places? I’ve asked hundreds of young women to share their holy places with me. Whether they are geographic or moments in time, they are equally sacred and have incredible strengthening power. Here are nine of their tender responses:







One: “I was in the hospital, holding my new baby brother.”





Two: “Each time I read my patriarchal blessing, I feel I am known and loved by my Heavenly Father.”





Three: “The day I turned 12, the young women in the ward decorated my door with paper hearts.9 I felt loved, accepted, and happy!”





Four: “As I was reading my scriptures one day, a phrase ‘popped out.’ I had found an answer to my prayers.”





Five: “I walked into a party where people were drinking and participating in other unacceptable activities. The Spirit told me to turn around and go home. I did, and yes, there were social consequences. However, that moment gave me the confidence I needed to know that I could live the gospel.”





Six: “During the sacrament, I was thinking about the Atonement. I recognized I needed to forgive someone I was angry with. My choosing to forgive was a positive action that would bring the Atonement into my daily life.”





Seven: “After attending New Beginnings with my mom, she kissed me on the cheek and told me she loved me. This was the first time I could remember her doing this.”





Eight: “With my bishop’s assurance, I knew that the promise the scriptures provided was true: ‘Though your sins be as scarlet, they shall be as white as snow.’10 I felt hope and knew I could begin my lengthy process of repentance.”





Lastly: “One evening, I summoned the courage to share my feelings about the gospel and a Book of Mormon with my best friend. Later, it was a privilege to attend her baptism. Now we attend church together.”





May I share with you one of my holy places? Once, I was feeling overwhelmed, fearful, and completely alone. Silently, I prayed: “Heavenly Father, I do not know how to do this. Please, please, help me!” Soon, an individual unexpectedly came forward, placed a hand on my shoulder, and offered sincere, encouraging words. In that moment, I felt peace. I felt acknowledged. Everything had changed. The words of President Spencer W. Kimball came to mind: “God does notice us, and he watches over us. But it is usually through another person that he meets our needs.”11 For me, that moment, that place, had become holy.

Dear young women, there are countless other holy places I wish we could share with one another. When you return home tonight, I encourage you to record in your journal those places which you are recognizing and remembering. It is clear to me that thousands of you are standing in holy places. These places are providing you with protection, strength, and peace in unsettling times. Your testimonies are becoming stronger because you are standing for truth and righteousness in glorious ways.

You, the noble youth of the Church, are my heroes. I love you. I feel Heavenly Father’s incredible love for you, and I bear you my testimony that the gospel of Jesus Christ is true. He is waiting, ready to buoy you up as you “stand … in holy places, and be not moved.” I love and sustain President Thomas S. Monson, our true and encouraging prophet. I say these things in the name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 87:8; see also Doctrine and Covenants 45:32; 101:22.
2. - Ezra Taft Benson, “Prepare Yourself for the Great Day of the Lord,” New Era, May 1982, 50; see also Doctrine and Covenants 115:6.
3. - Merriam-Webster Online, “place,” merriam-webster.com/dictionary/place.
4. - Joseph Smith—History 1:29.
5. - See “Practice, Celebration, Dedication: Temple Blessings in El Salvador,” lds.org/youth/video.
6. - Jeffrey R. Holland, “Lessons from Liberty Jail,” Ensign, Sept. 2009, 26, 28.
7. - Jeffrey R. Holland, “Lessons from Liberty Jail,” 28.
8. - Personal conversation with author.
9. - Sometimes referred to in the United States as a “heart attack.”
10. - Isaiah 1:18.
11. - Spencer W. Kimball, “The Abundant Life,” Ensign, July 1978, 4; Tambuli, June 1979, 3.