Elder M. Russell Ballard
Of the Quorum of the Twelve Apostles
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/this-is-my-work-and-glory?lang=eng)

_God has freely given His power to those who accept and honor His priesthood, which leads to the promised blessings of immortality and eternal life._

President Packer, we’re all looking forward to the 98 version of that wonderful poem. What a wonderful instruction he gave to us.

A few weeks ago, on a cold, dark winter’s night, my wife, Barbara, and I looked in awe up at the sky. The millions of stars seemed exceptionally bright and beautiful. I then turned to the Pearl of Great Price and read again with wonder what the Lord God said to Moses: “And worlds without number have I created; and I also created them for mine own purpose; and by the Son I created them, which is mine Only Begotten” (Moses 1:33).

In our day the Hubble deep-space telescope has confirmed the magnitude of what Moses saw. Hubble scientists say the Milky Way galaxy, of which our earth and sun are just a tiny part, is estimated to be only one of over 200 billion similar galaxies. For me it is difficult to comprehend, impossible to fathom, so large and so vast are God’s creations.

Brothers and sisters, the power by which the heavens and earth were and are created is the priesthood. Those of us who are members of the Church know that the source of this priesthood power is God Almighty and His Son, Jesus Christ. Not only is the priesthood the power by which the heavens and the earth were created, but it is also the power the Savior used in His mortal ministry to perform miracles, to bless and heal the sick, to bring the dead to life, and, as our Father’s Only Begotten Son, to endure the unbearable pain of Gethsemane and Calvary—thus fulfilling the laws of justice with mercy and providing an infinite Atonement and overcoming physical death through the Resurrection.

It is the keys of this priesthood authority and resultant power that He gave to Peter, James, and John and His other Apostles to bless others and to bind in heaven that which is bound on earth.

The power of the priesthood is a sacred and essential gift of God. It is different from priesthood authority, which is the authorization to act in God’s name. The authorization or ordination is given by the laying on of hands. The power of the priesthood comes only when those who exercise it are worthy and acting in accordance with God’s will. As President Spencer W. Kimball declared, “The Lord has given to all of us, as holders of the priesthood, certain of his authority, but we can only tap the powers of heaven on the basis of our personal righteousness” (“Boys Need Heroes Close By,” Ensign, May 1976, 45).

During the glorious days of the Restoration and the reestablishment of the Church of Jesus Christ in the world today, John the Baptist; Peter, James, and John; Moses; Elias; and Elijah came to the earth and restored through the Prophet Joseph Smith all of the keys and authority of the priesthood for the work of God in these latter days.

It is by these keys, this authority, and this power that the Church of Jesus Christ is organized today, with Christ at the head directing His living prophet, Thomas S. Monson, and assisted by duly called and ordained Apostles.

In our Heavenly Father’s great priesthood-endowed plan, men have the unique responsibility to administer the priesthood, but they are not the priesthood. Men and women have different but equally valued roles. Just as a woman cannot conceive a child without a man, so a man cannot fully exercise the power of the priesthood to establish an eternal family without a woman. In other words, in the eternal perspective, both the procreative power and the priesthood power are shared by husband and wife. And as husband and wife, a man and a woman should strive to follow our Heavenly Father. The Christian virtues of love, humility, and patience should be their focus as they seek the blessings of the priesthood in their lives and for their family.

It is crucial for us to understand that Heavenly Father has provided a way for all of His sons and His daughters to have access to the blessings of and be strengthened by the power of the priesthood. Central to God’s plan for His spirit children is His own declaration: “This is my work and my glory—to bring to pass the immortality and eternal life of man” (Moses 1:39).

In the revelation given to the Prophet Joseph Smith in section 81 of the Doctrine and Covenants, the Lord explains that the power of the priesthood is to be used to “succor the weak, lift up the hands which hang down, and strengthen the feeble knees” (verse 5).

“And in doing [such] things thou wilt do the greatest good unto thy fellow beings, and wilt promote the glory of him who is your Lord” (D&C 81:4).

As we think about the imagery of succoring the weak, lifting up the hands which hang down, and strengthening feeble knees, I am reminded of a sweet seven-year-old showing her grandfather a small tomato plant she had started from seed as part of a second-grade school project.



She explained that from one tiny seed would come a plant. And if the plant were cared for, it would grow many tomatoes that would each have many seeds.

She said, “And if all of those seeds were planted and grew more tomatoes, and you planted all of those seeds, in a few seasons you would have millions of tomatoes.”

“All,” she said in amazement, “from one little seed.”

But then she said, “I almost killed my plant. I left it in a dark room and forgot to water it. When I remembered the plant, it was all wilted and dead looking. I cried because I thought of all of those millions of tomatoes that would never grow.”

She was then excited to tell her grandfather about the “miracle” that happened.

She explained, “Momma said maybe the plant wasn’t dead. Maybe all it needed was some water and some light to bring life back.

“And she was right. I gave the plant some water, and I put it in the window for light. And guess what?” she asked. “It came back to life, and now it’s going to grow millions of tomatoes!”

Her small tomato plant, so full of potential but so weakened and wilted from unintentional neglect, was strengthened and revived through the simple ministration of water and light by the little girl’s loving and caring hands.

Brothers and sisters, as the literal spirit children of our loving Heavenly Father, we have unlimited, divine potential. But if we are not careful, we can become like the wilted tomato plant. We can drift away from the true doctrine and gospel of Christ and become spiritually undernourished and wilted, having removed ourselves from the divine light and living waters of the Savior’s eternal love and priesthood power.

Those who hold the priesthood and fail to constantly strive to honor it by serving our families and others will be like those who do not receive the blessings inherent in the power of the priesthood and will surely wilt spiritually, having deprived themselves of the essential spiritual nutrients, light, and power of God in their lives—much like the tomato plant so full of potential but neglected and wilted.

The same priesthood power that created worlds, galaxies, and the universe can and should be part of our lives to succor, strengthen, and bless our families, our friends, and our neighbors—in other words, to do the things that the Savior would do if He were ministering among us today.

And the primary purpose of this priesthood power is to bless, sanctify, and purify us so we can live together with our families in the presence of our heavenly parents, bound by priesthood sealings, participating in the marvelous work of God and Jesus Christ in forever expanding Their light and glory.

To this end, a few months ago I had the opportunity to participate in making a video-based worldwide leadership training presentation called Strengthening the Family and the Church through the Priesthood.

This innovative and instructive DVD is translated into 66 languages. It teaches how the power of the priesthood can bless, vitalize, and revitalize our lives, the lives of our families, and the lives of all the members of the Church.

It shows us all—men, women, children; married, widowed, or single; no matter what our circumstances—how we can be partakers of the blessings of the priesthood. There are several 8- to 12-minute segments that explain the keys, authority, and power of the priesthood and how it strengthens individuals, families, and the Church.

One special scene was filmed in the very small pioneer home of my mother’s great-grandmother Mary Fielding Smith. She was the widow of Hyrum, the Prophet Joseph’s older brother. As a single parent, through her strong faith in the priesthood, she called upon and relied on that power to raise and bless her children in love and the light of the gospel. Today her posterity of thousands of faithful leaders and members of the Church thank her for her faith, courage, and example.

This new leadership training is now available on the Internet at LDS.org for all to see and experience (wwlt.lds.org). You can stream it live from LDS.org, or you can download it to your computer, smartphone, or tablet devices.

The First Presidency has asked “stake presidencies and bishoprics to dedicate one or more stake or ward council meetings to viewing the [entire] DVD. Stake and ward councils should discuss how to implement the teachings that are presented” (First Presidency letter, Feb. 1, 2013).

The content will inspire and motivate members in priesthood quorums, Relief Society, Sunday School, Young Women, Young Men (especially those preparing for missions), and in Primary meetings or combined fifth-Sunday gatherings. Council members will then be able to encourage individuals and parents to use this presentation with their families. Brothers and sisters, this leadership training is for every member of the Church. Parents, review, share, and discuss what you learn and feel with your children, and let them watch and do the same with you, that your families may be strengthened through the priesthood.

Jesus said:

“If any man thirst, let him come unto me, and drink” (John 7:37).

“Whosoever drinketh of the water that I shall give him shall never thirst; but the water that I shall give him shall be in him a well of water springing up into everlasting life” (John 4:14).

“I am the light of the world: he that followeth me … shall have the light of life” (John 8:12).

If any one of you feels your faith or your testimony of Heavenly Father’s plan is less than you know it should be, then turn more fully to the Savior. Let His light and His living water do for you and your family what a little water and light did in bringing life back to the weakened tomato plant.

Now, I began with the wonder and awe in the creations of God through the power of the priesthood. I stand here wondering, as I suppose most of you also do, if God’s power to instruct and bless us can ever be fully comprehended. It is so great, so majestic, so powerful.

Joseph Smith said, “The Priesthood is an everlasting principle, and existed with God from eternity, and will to eternity, without beginning of days or end of years” (Teachings of Presidents of the Church: Joseph Smith [2007], 104).

God has freely given His power to those who accept and honor His priesthood, which leads to the promised blessings of immortality and eternal life.

I testify that the work of Jesus Christ is accomplished through the priesthood. It is the power by which our Heavenly Father and His Beloved Son created this earth and set in motion the great plan of happiness for our sakes. May we be wise and seek to strengthen our own lives, the lives of our families, and The Church of Jesus Christ of Latter-day Saints through the power of the priesthood of God is my humble prayer in the name of Jesus Christ, amen.

# References
