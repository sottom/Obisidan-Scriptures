President Henry B. Eyring
First Counselor in the First Presidency
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/we-are-one?lang=eng)

_I pray that wherever we are and whatever duties we have in the priesthood of God, we will be united in the cause to bring the gospel to all the world._

The Lord made it clear at the very start of this last dispensation that we were to take the gospel to all the world. What He said to the few priesthood holders in 1831 He says to the many now. Whatever our age, capacity, Church calling, or location, we are as one called to the work to help Him in His harvest of souls until He comes again. He said to those first laborers in the vineyard:

“And again, I say unto you, I give unto you a commandment, that every man, both elder, priest, teacher, and also member, go to with his might, with the labor of his hands, to prepare and accomplish the things which I have commanded.

“And let your preaching be the warning voice, every man to his neighbor, in mildness and in meekness.

“And go ye out from among the wicked. Save yourselves. Be ye clean that bear the vessels of the Lord.”1

Now, you members of the Aaronic Priesthood can see that the Lord’s command includes you. Since you know that the Lord always prepares a way to keep His commandments, you can expect that He will do that for each of you.

Let me tell you of how He did it for one boy who now holds the office of priest in the Aaronic Priesthood. He is 16 years old. He lives in a country where the missionaries first arrived just a year ago. They were assigned to two cities but not to the city where the boy lives.

When he was very young, his parents brought him to Utah for safety. The family was taught and baptized by the missionaries. He was not baptized into the Church because he was not yet eight years of age.

His parents were killed in an accident. So his grandmother had him return to his home, across the ocean, back to the city where he had been born.

He was walking on the street in March just a year ago when he felt that he should speak to a woman he did not know. He spoke with her in the English he still remembered. She was a nurse sent by the mission president to his city to look for housing and medical care for the missionaries who would be assigned there soon. He and she became friends as they talked. When she got back to the mission headquarters, she told the missionaries about him.

The first two elders arrived in September of 2012. The orphan boy was their first baptism into The Church of Jesus Christ of Latter-day Saints. By March of this year he had been a member for four months. He had been ordained a priest in the Aaronic Priesthood and so could baptize the second convert to the Church. He was the first priesthood pioneer to gather other children of Heavenly Father with him to establish the Church in a city of approximately 130,000 people.

On Easter Sunday, March 31, 2013, the Church membership there had grown to the huge number of six members in that city. He was the only local member who attended the meeting that Sunday. His knee had been injured the day before, but he was determined to be there. He had prayed that he would be able to walk to church. And so he was there. He shared the sacrament with four young elders and a missionary couple—the total congregation.

That story does not seem remarkable unless you recognize in it the pattern of God’s hand in building His kingdom. I have seen it many times.

I saw it in New Mexico as a young man. For generations the prophets have told us that we must help the missionaries find and teach the honest in heart and then love those who come into the kingdom.

I have seen for myself what faithful priesthood leaders and members can do. In 1955 I became an officer in the United States Air Force. My bishop at home gave me a blessing just before I left for my first station, which was in Albuquerque, New Mexico.

In his blessing he said that my time in the air force would be missionary service. I arrived in church on my first Sunday at the Albuquerque First Branch. A man walked up to me, introduced himself as the district president, and told me that he was going to call me to serve as a district missionary.

I told him that I would be there for training for only a few weeks and then I would be assigned somewhere else in the world. He said, “I don’t know about that, but we are to call you to serve.” In the middle of my military training, by what appeared to be chance, I was chosen from hundreds of officers being trained to take the place in headquarters of an officer who had died suddenly.

So, for the two years I was there, I worked in my office. On most evenings and every weekend, I taught the gospel of Jesus Christ to people the members brought to us.

My companions and I averaged more than 40 hours a month in our missionary service without once having to knock on doors to find someone to teach. The members filled our plates so full that we often taught two families in an evening. I saw for myself the power and the blessing in the repeated call of prophets for every member to be a missionary.

On the last Sunday before I left Albuquerque, the first stake was organized in that city. There is now a sacred temple there, a house of the Lord, in a city where we once met in a single chapel with Saints who brought friends to us to be taught and to feel the witness of the Spirit. Those friends felt a welcoming home in the Lord’s true Church.

I saw it next in New England as I went to school. I was called as the counselor to a great district president who had been brought from disinterest in the Church to a man of great spiritual power. His home teacher loved him enough to ignore his cigar and see what God could see in him. The district president and I drove over the hills and along the shores to visit tiny branches that dotted Massachusetts and Rhode Island to build and bless the kingdom of God.

In the years I served with that great leader, we watched people draw friends to the Church by their example and by their invitation to listen to the missionaries. To me the growth of those branches seemed slow and faltering. But on the Sunday I left, five years later, two Apostles came to organize our district into a stake in the Longfellow Park chapel in Cambridge.

Years later I returned to conduct a stake conference there. The stake president took me to see a rocky hill in Belmont. He told me it would be a perfect place for a temple of God. One stands there now. When I gaze on it, I remember the humble members I sat with in tiny branches, the neighbors they invited, and the missionaries who were teaching them.

There is a new deacon in this meeting here tonight. I was with him on the same Easter Sunday that the priest whom I spoke of previously walked to his one-member meeting. The deacon beamed as his father said that he would be in this priesthood meeting with him tonight. This father was a great missionary in the same mission where his father had been the president. I have seen the 1937 Missionary Handbook of his great-grandfather. His heritage in bringing people to the Church runs deep.

So I spoke with that deacon’s bishop to learn what experiences the boy might expect in meeting the charge of the priesthood to work in the gathering of souls for the Lord. The bishop was enthusiastic as he described how the ward mission leader tracked the progress of investigators. He gets that information from regular contact with the missionaries.

The bishop and his ward council discuss every progressing investigator. They decide what they can do for each person and their families to help them become friends before baptism, to include them in activities, and to nurture those who are baptized. He said the missionaries on occasion have enough appointments to teach that they take Aaronic Priesthood holders as companions.

The ward mission plan includes the goals of the quorums to invite those they know to meet with the missionaries. Even the deacons quorum presidency is invited to set goals and plan for their quorum members to help bring those they know into the kingdom of God.

Now, the deacon in the strong ward and the new priest—the convert—in the tiny member group may seem to have little in common with each other or with you. And you may not see much similarity with your experiences in building up the Church with what I saw as miracles in New Mexico and in New England.

But there is one way in which we are one in our charge in the priesthood. We sanctify ourselves and fulfill our individual duties to the commandment to take the gospel to all of our Heavenly Father’s children.

We share experiences in the way in which the Lord builds His kingdom on earth. In His Church, with all the wonderful tools and organization we have been given, there is still a fundamental truth taught by prophets of how we are to fulfill our priesthood mandate of missionary work.

In the 1959 April general conference, President David O. McKay taught this principle, as have the prophets since his day, including President Thomas S. Monson. President McKay related in his closing comments that in 1923 in the British Mission, there was a general instruction sent out to the members of the Church. They were told not to spend money on advertising to combat the bad feelings of the people against the Church. President McKay said the decision was: “Throw the responsibility upon every member of the Church that in the coming year of 1923 every member will be a missionary. Every member a missionary! You may bring your mother into the Church, or it may be your father; perhaps your fellow companion in the workshop. Somebody will hear the good message of the truth through you.”

And President McKay continued: “And that is the message today. Every member—a million and a half—a missionary!”2

When it was announced in 2002 that missionary work would become the responsibility of the bishops, I marveled. I’d been one. It seemed to me they were already carrying a load close to their limits in ministering to the members and directing the organizations in the ward.

One bishop I knew saw it not as an added duty but as an opportunity to draw the ward together in a great cause where every member became a missionary. He called a ward mission leader. He met with the missionaries himself every Saturday to learn about their work, to encourage them, and to learn about the progress of their investigators. The ward council found ways for organizations and quorums to use service experiences as missionary preparation. And as a judge in Israel, he helped young people feel the blessings of the Atonement to keep them pure.

Recently I asked how he explained the surge of convert baptisms in his ward and the increase in the number of young people ready and eager to take the gospel of Jesus Christ out to the world. He said it seemed to him that it was not so much the duty anyone performed but the way they all became one in their enthusiasm to bring people into the community of Saints that had brought them such happiness.

For some it was that and more. Like the sons of Mosiah, they had felt the effects of sin in their own lives and the marvelous healing of the Atonement within the Church of God. Out of love and gratitude for the Savior’s gift to them, they wanted to help everyone they could to escape the sadness of sin, feel the joy of forgiveness, and gather with them to safety in the kingdom of God.

It was the love of God and the love for their friends and neighbors that unified them to serve the people. They desired to take the gospel to everyone in their part of the world. And they prepared their children to be worthy to be called by the Lord to teach, to testify, and to serve in other parts of His vineyard.

Whether it is in the large ward where the new deacon will perform his duty to share the gospel and build up the kingdom or in the tiny group far away where the new priest serves, they will be one in purpose. The deacon will be inspired by the love of God to reach out to a friend not yet a member. He will include his friend in some service or activity in the Church and then invite him and his family to be taught by the missionaries. To those who are baptized, he will be the friend they will need.

The priest will invite others to join with him in the tiny group of Saints where he has felt the love of God and the blessed peace of the Atonement.

If he continues faithful in his priesthood duty, he will see the group become a branch, and then a stake of Zion will come to his city. There will be a ward with a caring bishop. It could be one of his sons or grandsons who will someday take a servant of God to a nearby hill and say, “This would be a wonderful place for a temple.”

I pray that wherever we are and whatever duties we have in the priesthood of God, we will be united in the cause to bring the gospel to all the world and that we will encourage people we love to be cleansed from sin and to be happy with us in the kingdom of God. In the name of Jesus Christ, whose Church this is, amen.

# References
1. - Doctrine and Covenants 38:40–42.
2. - David O. McKay, in Conference Report, Apr. 1959, 122.