Elder Richard G. Scott
Of the Quorum of the Twelve Apostles
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/for-peace-at-home?lang=eng)

_One of the greatest blessings we can offer to the world is the power of a Christ-centered home where the gospel is taught, covenants are kept, and love abounds._

Many voices from the world in which we live tell us we should live at a frantic pace. There is always more to do and more to accomplish. Yet deep inside each of us is a need to have a place of refuge where peace and serenity prevail, a place where we can reset, regroup, and reenergize to prepare for future pressures.

The ideal place for that peace is within the walls of our own homes, where we have done all we can to make the Lord Jesus Christ the centerpiece.

Some homes have a father who is a worthy priesthood holder joined by a faithful, devoted mother who together lead in righteousness. Many homes have a different configuration. Regardless of your circumstances, you can center your home and your life on the Lord Jesus Christ, for He is the source of true peace in this life.

Be certain that every decision you make, whether temporal or spiritual, is conditioned on what the Savior would have you do. When He is the center of your home, there is peace and serenity. There is a spirit of assurance that pervades the home, and it is felt by all who dwell there.

The fulfillment of this counsel does not rest upon parents alone, although it is their role to lead. Children can be responsible for improving the Christ-centered efforts in the home. It is important for parents to teach children to recognize how their actions affect each individual who lives in the home. Children who are made to feel accountable for their actions, whether righteous or otherwise, grow to become trustworthy citizens in the kingdom of God.

I’m sure you can identify the fundamental principles that center your home on the Savior. The prophetic counsel to have daily personal and family prayer, daily personal and family scripture study, and weekly family home evening are the essential, weight-bearing beams in the construction of a Christ-centered home. Without these regular practices it will be difficult to find the desired and much-needed peace and refuge from the world.

Be obedient to the prophetic teachings Christ would have you follow. Don’t rationalize away future happiness by taking shortcuts instead of applying sound gospel principles. Remember: little things lead to big things. Seemingly insignificant indiscretions or neglect can lead to big problems. More importantly, simple, consistent, good habits lead to a life full of bountiful blessings.

You children in the Primary, you young men and women in youth programs, and you stalwart missionaries now serving are doing many things more effectively than I was able to do at your age. In the premortal life you proved to be valiant, obedient, and pure. There you worked hard to develop talents and capacities to prepare yourselves to face mortality with courage, dignity, honor, and success.

Not long ago you came to mortality with all of those magnificent capacities and endless possibilities. Yet there is real danger in the environment surrounding you. Your great potential and ability could be limited or destroyed if you yield to the devil-inspired contamination around you. However, Satan is no match for the Savior. Satan’s fate is decided. He knows he has lost, but he wants to take as many with him as he can. He will try to ruin your goodness and abilities by exploiting your weaknesses. Stay on the Lord’s side, and you will win every time.

You live in a world where technological advances occur at an astounding pace. It is difficult for many of my generation to keep up with the possibilities. Depending on how technology is used, these advances can be a blessing or a deterrent. Technology, when understood and used for righteous purposes, need not be a threat but rather an enhancement to spiritual communication.

For example, many of us have a personal electronic device that fits into our pocket. We are seldom without its company; we may refer to it many times a day. Unfortunately, these devices can be a source of filth and wasted time. But, used with discipline, this technology can be a tool of protection from the worst of society.

Who could have imagined not very many years ago that the full standard works and years of general conference messages would fit into your pocket? Just having them in your pocket will not protect you, but studying, pondering, and listening to them during quiet moments of each day will enhance communication through the Spirit.

Be wise in how you embrace technology. Mark important scriptures on your device and refer back to them frequently. If you young people would review a verse of scripture as often as some of you send text messages, you could soon have hundreds of passages of scripture memorized. Those passages would prove to be a powerful source of inspiration and guidance by the Holy Ghost in times of need.

Doing all we can to invite the gentle, guiding influence of the Holy Ghost into our lives is critical in our attempts to center our homes on the Savior. Acting obediently on those promptings strengthens us even more.

Greater peace will come as you couple your efforts to be obedient with serving those around you. So many individuals who have what they perceive to be meager talents humbly and generously use those talents to bless the lives of those around them. Selfishness is the root of great evil. The antidote for that evil is exemplified in the life of the Savior. He shows us how to focus our lives outward in unselfish service to others.

I have learned a truth that has been repeated so frequently in my life that I have come to know it as an absolute law. It defines the way obedience and service relate to the power of God. When we obey the commandments of the Lord and serve His children unselfishly, the natural consequence is power from God—power to do more than we can do by ourselves. Our insights, our talents, our abilities are expanded because we receive strength and power from the Lord. His power is a fundamental component to establishing a home filled with peace.

As you center your home on the Savior, it will naturally become a refuge not only to your own family but also to friends who live in more difficult circumstances. They will be drawn to the serenity they feel there. Welcome such friends into your home. They will blossom in that Christ-centered environment. Become friends with your children’s friends. Be a worthy example to them.

One of the greatest blessings we can offer to the world is the power of a Christ-centered home where the gospel is taught, covenants are kept, and love abounds.

Years ago, following a mission tour, my wife, Jeanene, told me about an elder she had met. Jeanene had asked him about his family. She was surprised as he responded that he had no family. He further explained that at his birth, his mother had given him to the government to raise. He spent his childhood going from one foster home to another. He was blessed as a teenager to find the gospel. A loving ward family had helped him to have the opportunity to serve a mission.

Later Jeanene asked the mission president’s wife about this fine elder. She learned that a few months earlier this elder had been in the mission home for a few days due to an illness. During that time he had joined them for a family home evening. Before he left to go back into the field, he asked the mission president if he could spend two or three days at the end of his mission in the mission home again. He wanted to observe how a Christ-centered family functions. He wanted to be able to pattern his family after theirs.

Do all you can to have just such a home. Reach out to those living in adverse circumstances. Be a true friend. This kind of enduring friendship is like asphalt that fills the potholes of life and makes the journey smoother and more pleasant. It should not be a resource used to gain personal advantage but a treasure to be appreciated and shared. Welcome into your home others who need to be strengthened by such an experience.

I offer some final thoughts for those who love a family member who is not making good choices. That can challenge our patience and endurance. We need to trust in the Lord and in His timing that a positive response to our prayers and rescue efforts can occur. We do all that we can to serve, to bless, and to submissively acknowledge God’s will in all things. We exercise faith and remember that there are some things that must be left to the Lord. He invites us to set our burdens down at His feet. With faith we can know that this straying loved one is not abandoned but is in the watchcare of a loving Savior.

Recognize the good in others, not their stains. At times a stain needs appropriate attention to be cleansed, but always build on his or her virtues.

When you feel that there is only a thin thread of hope, it is really not a thread but a massive connecting link, like a life preserver to strengthen and lift you. It will provide comfort so you can cease to fear. Strive to live worthily and place your trust in the Lord.

We need not worry if we can’t simultaneously do all of the things that the Lord has counseled us to do. He has spoken of a time and a season for all things. In response to our sincere prayers for guidance, He will direct us in what should be emphasized at each phase of our life. We can learn, grow, and become like Him one consistent step at a time.

I bear testimony that living an obedient life, firmly rooted in the gospel of Jesus Christ, provides the greatest assurance for peace and refuge in our homes. There will still be plenty of challenges or heartaches, but even in the midst of turmoil, we can enjoy inner peace and profound happiness. I testify that the Atonement of Jesus Christ is the source of that abundant peace, in the name of Jesus Christ, amen.

# References
