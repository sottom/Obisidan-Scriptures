President Henry B. Eyring
First Counselor in the First Presidency
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/come-unto-me?lang=eng)

_By His words and His example, Christ has shown us how to draw closer to Him._

I am grateful to be with you in this conference of The Church of Jesus Christ of Latter-day Saints. This is His Church. We take His name upon us as we enter His kingdom. He is God, the Creator, and perfect. We are mortals subject to death and sin. Yet in His love for us and our families, He invites us to be close to Him. Here are His words: “Draw near unto me and I will draw near unto you; seek me diligently and ye shall find me; ask, and ye shall receive; knock, and it shall be opened unto you.”1

At this Easter season we are reminded of why we love Him and of the promise He makes to His faithful disciples to become His beloved friends. The Savior made that promise and told us how, in our service to Him, He comes to us. One example is in a revelation to Oliver Cowdery as he served the Lord with the Prophet Joseph Smith in the translation of the Book of Mormon: “Behold, thou art Oliver, and I have spoken unto thee because of thy desires; therefore treasure up these words in thy heart. Be faithful and diligent in keeping the commandments of God, and I will encircle thee in the arms of my love.”2

I experienced the joy of coming closer to the Savior and of His coming closer to me most often through simple acts of obedience to the commandments.

You have had such experiences. It may have been when you chose to attend a sacrament meeting. It was for me on a Sabbath when I was very young. In those days we received the sacrament during an evening meeting. The memory of one day more than 65 years ago, when I kept the commandment to gather with my family and with the Saints, still draws me closer to the Savior.

It was dark and cold outside. I remember feeling light and warmth in the chapel that evening with my parents. We partook of the sacrament, administered by Aaronic Priesthood holders, covenanting with our Heavenly Father to always remember His Son and keep His commandments.

At the end of the meeting we sang the hymn “Abide with Me; ’Tis Eventide,” with the words in it “O Savior, stay this night with me.”3

I felt the Savior’s love and closeness that evening. And I felt the comfort of the Holy Ghost.

I wanted to rekindle once again the feelings of the love of the Savior and His closeness I felt during that sacrament meeting in my youth. So recently I kept another commandment. I searched in the scriptures. In them, I knew I could go back again to have the Holy Ghost let me feel what two disciples of the risen Lord had felt when He accepted their invitation to come into their home and to abide with them.

I read of the third day after His Crucifixion and burial. Faithful women and others found the stone rolled away from the tomb and saw that His body was not there. They had come out of love for Him to anoint His body.

Two angels stood by and asked why they were afraid, saying:

“Why seek ye the living among the dead?

“He is not here, but is risen: remember how he spake unto you when he was yet in Galilee,

“Saying, The Son of man must be delivered into the hands of sinful men, and be crucified, and the third day rise again.”4

The Gospel of Mark adds the direction from one of the angels: “But go your way, tell his disciples and Peter that he goeth before you into Galilee: there shall ye see him, as he said unto you.”5

The Apostles and disciples had gathered in Jerusalem. As we might have been, they were afraid and wondered as they spoke together about what death and reports of His being resurrected meant for them.

Two of the disciples walked that afternoon from Jerusalem on the road to Emmaus. The resurrected Christ appeared on the road and walked with them. The Lord had come to them.

The book of Luke allows us to walk with them:

“And it came to pass, that, while they communed together and reasoned, Jesus himself drew near, and went with them.

“But their eyes were holden that they should not know him.



“And he said unto them, What manner of communications are these that ye have one to another, as ye walk, and are sad?

“And the one of them, whose name was Cleopas, answering said unto him, Art thou only a stranger in Jerusalem, and hast not known the things which are come to pass there in these days?”6

They told Him of their sadness that Jesus had died when they had trusted He would be the Redeemer of Israel.

There must have been affection in the risen Lord’s voice as He spoke to these two sorrowful and mourning disciples:

“Then he said unto them, O fools, and slow of heart to believe all that the prophets have spoken:

“Ought not Christ to have suffered these things, and to enter into his glory?

“And beginning at Moses and all the prophets, he expounded unto them in all the scriptures the things concerning himself.”7

Then came a moment that has warmed my heart since I was a little boy:

“And they drew nigh unto the village, whither they went: and he made as though he would have gone further.

“But they constrained him, saying, Abide with us: for it is toward evening, and the day is far spent. And he went in to tarry with them.”8

The Savior accepted that night the invitation to enter the house of His disciples near the village of Emmaus.

He sat at meat with them. He took bread, blessed it, broke it, and gave it to them. Their eyes were opened so that they knew Him. Then He vanished out of their sight. Luke recorded for us the feelings of those blessed disciples: “And they said one to another, Did not our heart burn within us, while he talked with us by the way, and while he opened to us the scriptures?”9

At that same hour, the two disciples rushed back to Jerusalem to tell the eleven Apostles what had happened to them. In that moment the Savior appeared again.

He reviewed the prophecies of His mission to atone for the sins of all His Father’s children and to break the bands of death.

“And said unto them, Thus it is written, and thus it behoved Christ to suffer, and to rise from the dead the third day:

“And that repentance and remission of sins should be preached in his name among all nations, beginning at Jerusalem.

“And ye are witnesses of these things.”10

The Savior’s words are true as well for us as they were for His disciples then. We are witnesses of these things. And the glorious charge we accepted as we were baptized into The Church of Jesus Christ of Latter-day Saints was made plain for us by the prophet Alma centuries ago at the waters of Mormon:

“And it came to pass that he said unto them: Behold, here are the waters of Mormon (for thus were they called) and now, as ye are desirous to come into the fold of God, and to be called his people, and are willing to bear one another’s burdens, that they may be light;

“Yea, and are willing to mourn with those that mourn; yea, and comfort those that stand in need of comfort, and to stand as witnesses of God at all times and in all things, and in all places that ye may be in, even until death, that ye may be redeemed of God, and be numbered with those of the first resurrection, that ye may have eternal life—

“Now I say unto you, if this be the desire of your hearts, what have you against being baptized in the name of the Lord, as a witness before him that ye have entered into a covenant with him, that ye will serve him and keep his commandments, that he may pour out his Spirit more abundantly upon you?

“And now when the people had heard these words, they clapped their hands for joy, and exclaimed: This is the desire of our hearts.”11

We are under covenant both to lift up those in need and to be witnesses of the Savior as long as we live.

We will be able to do it without fail only as we feel love for the Savior and His love for us. As we are faithful to the promises we have made, we will feel our love for Him. It will increase because we will feel His power and His drawing near to us in His service.

President Thomas S. Monson has reminded us often of the promise of the Lord to His faithful disciples: “And whoso receiveth you, there I will be also, for I will go before your face. I will be on your right hand and on your left, and my Spirit shall be in your hearts, and mine angels round about you, to bear you up.”12

There is another way you and I have felt Him grow closer to us. As we give devoted service to Him, He draws closer to those we love in our families. Every time I have been called in the Lord’s service to move or to leave my family, I have come to see that the Lord was blessing my wife and my children. He prepared loving servants of His and opportunities to draw my family closer to Him.

You have felt that same blessing in your lives. Many of you have loved ones who are wandering off the path to eternal life. You wonder what more you can do to bring them back. You can depend on the Lord to draw closer to them as you serve Him in faith.

You remember the Lord’s promise to Joseph Smith and Sidney Rigdon when they were away from their families on His errands: “My friends Sidney and Joseph, your families are well; they are in mine hands, and I will do with them as seemeth me good; for in me there is all power.”13

Like Alma and King Mosiah, some faithful parents have served the Lord long and well yet have had children who wandered despite their parents’ sacrifice for the Lord. They have done all they could to no apparent avail, even with help from loving and faithful friends.

Alma and the Saints of his day prayed for his son and the sons of King Mosiah. An angel came. Your prayers and the prayers of those who exercise their faith will bring the Lord’s servants to help your family members. They will help them choose the way home to God, even as they are attacked by Satan and his followers, whose purpose it is to destroy families in this life and in eternity.

You remember the words spoken by the angel to Alma the Younger and the sons of Mosiah in their rebellion: “And again, the angel said: Behold, the Lord hath heard the prayers of his people, and also the prayers of his servant, Alma, who is thy father; for he has prayed with much faith concerning thee that thou mightest be brought to the knowledge of the truth; therefore, for this purpose have I come to convince thee of the power and authority of God, that the prayers of his servants might be answered according to their faith.”14

My promise to you who pray and serve the Lord cannot be that you will have every blessing you may wish for yourself and your family. But I can promise you that the Savior will draw close to you and bless you and your family with what is best. You will have the comfort of His love and feel the answer of His drawing closer as you reach out your arms in giving service to others. As you bind up the wounds of those in need and offer the cleansing of His Atonement to those who sorrow in sin, the Lord’s power will sustain you. His arms are outstretched with yours to succor and bless the children of our Heavenly Father, including those in your family.

There is a glorious homecoming prepared for us. We will then see fulfilled the promise of the Lord we have loved. It is He who welcomes us into eternal life with Him and our Heavenly Father. Jesus Christ described it this way:

“Seek to bring forth and establish my Zion. Keep my commandments in all things.

“And, if you keep my commandments and endure to the end you shall have eternal life, which gift is the greatest of all the gifts of God.”15

“For those that live shall inherit the earth, and those that die shall rest from all their labors, and their works shall follow them; and they shall receive a crown in the mansions of my Father, which I have prepared for them.”16

I testify that we can by the Spirit follow the invitation of Heavenly Father: “This is My Beloved Son. Hear Him!”17

By His words and His example, Christ has shown us how to draw closer to Him. Every child of Heavenly Father who has chosen to enter through the gate of baptism into His Church will have the opportunity in this life to be taught His gospel and to hear from His called servants His invitation, “Come unto me.”18

Every covenant servant of His within His kingdom on earth and in the spirit world will receive His guidance by the Spirit as they bless and serve others for Him. And they will feel His love and find joy in being drawn closer to Him.

I am a witness of the Resurrection of the Lord as surely as if I had been there in the evening with the two disciples in the house on Emmaus road. I know that He lives as surely as did Joseph Smith when he saw the Father and the Son in the light of a brilliant morning in a grove of trees in Palmyra.

This is the true Church of Jesus Christ. Only in the priesthood keys held by President Thomas S. Monson is the power for us to be sealed in families to live forever with our Heavenly Father and the Lord Jesus Christ. We will on the Day of Judgment stand before the Savior, face to face. It will be a time of joy for those who have drawn close to Him in His service in this life. It will be a joy to hear the words: “Well done, thou good and faithful servant.”19 I so testify as a witness of the risen Savior and our Redeemer in the name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 88:63.
2. - Doctrine and Covenants 6:20.
3. - “Abide with Me; ’Tis Eventide,” Hymns, no. 165.
4. - Luke 24:5–7.
5. - Mark 16:7.
6. - Luke 24:15–18.
7. - Luke 24:25–27.
8. - Luke 24:28–29.
9. - Luke 24:32.
10. - Luke 24:46–48.
11. - Mosiah 18:8–11.
12. - Doctrine and Covenants 84:88.
13. - Doctrine and Covenants 100:1.
14. - Mosiah 27:14.
15. - Doctrine and Covenants 14:6–7.
16. - Doctrine and Covenants 59:2.
17. - Joseph Smith—History 1:17.
18. - Matthew 11:28.
19. - Matthew 25:21.