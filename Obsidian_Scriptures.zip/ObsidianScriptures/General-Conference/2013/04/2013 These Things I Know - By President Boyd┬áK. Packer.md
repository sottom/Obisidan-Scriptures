By President Boyd K. Packer
President of the Quorum of the Twelve Apostles
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/these-things-i-know?lang=eng)

_Of all that I have read and taught and learned, the one most precious and sacred truth that I have to offer is my special witness of Jesus Christ._

In 1992, having served nine years as an Assistant to the Twelve and 22 years as a member of the Twelve, I reached the age of 68. I felt impressed to start what I called an “Unfinished Composition.” The first part of that work goes like this:





I had a thought the other night,

A thought profound and deep.

It came when I was too worn down,

Too tired to go to sleep.





I’d had a very busy day

And pondered on my fate.

The thought was this:

When I was young, I wasn’t 68!





I could walk without a limp;

I had no shoulder pain.

I could read a line through twice

And quote it back again.





I could work for endless hours

And hardly stop to breathe.

And things that now I cannot do

I mastered then with ease.





If I could now turn back the years,

If that were mine to choose,

I would not barter age for youth,

I’d have too much to lose.





I am quite content to move ahead,

To yield my youth, however grand.

The thing I’d lose if I went back

Is what I understand.





Ten years later, I decided to add a few more lines to that poem:





Ten years have flown to who knows where

And with them much of pain.

A metal hip erased my limp;

I walk quite straight again.





Another plate holds neck bones fast—

A wonderful creation!

It backed my polio away;

I’ve joined the stiff-necked generation.





The signs of aging can be seen.

Those things will not get better.

The only thing that grows in strength

With me is my forgetter.





You ask, “Do I remember you?”

Of course, you’re much the same.

Now don’t go getting all upset

If I can’t recall your name.





I would agree I’ve learned some things

I did not want to know,

But age has brought those precious truths

That make the spirit grow.





Of all the blessings that have come,

The best thing in my life

Is the companionship and comfort

I get from my dear wife.





Our children all have married well,

With families of their own,

With children and grandchildren,

How soon they all have grown.





I have not changed my mind one bit

About regaining youth.

We’re meant to age, for with it

Comes a knowledge of the truth.





You ask, “What will the future bring?

Just what will be my fate?”

I’ll go along and not complain.

Ask when I’m 88!





And last year I added these lines:





And now you see I’m 88.

The years have flown so fast.

I walked, I limped, I held a cane,

And now I ride at last.





I take a nap now and again,

But priesthood power remains.

For all the physical things I lack

There are great spiritual gains.





I have traveled the world a million miles

And another million too.

And with the help of satellites,

My journeys are not through.





I now can say with all certainty

That I know and love the Lord.

I can testify with them of old

As I preach His holy word.





I know what He felt in Gethsemane

Is too much to comprehend.

I know He did it all for us;

We have no greater Friend.







I know that He will come anew

With power and in glory.

I know I will see Him once again

At the end of my life’s story.





I’ll kneel before His wounded feet;

I’ll feel His Spirit glow.

My whispering, quivering voice will say,

“My Lord, my God, I know.”1





And I do know!

The back windows of our home overlook a small flower garden and the woods which border a small stream. One wall of the house borders on the garden and is thickly covered with English ivy. Most years this ivy has been the nesting place for house finches. The nests in the vines are safe from foxes and raccoons and cats that are about.

One day there was a great commotion in the ivy. Desperate cries of distress came as 8 or 10 finches from the surrounding woods came to join in this cry of alarm. I soon saw the source of the commotion. A snake had slid partway down out of the ivy and hung in front of the window just long enough for me to pull it out. The middle part of the snake’s body had two bulges—clear evidence convicting it of taking two fledglings from the nest. Not in the 50 years we had lived in our home had we seen anything like that. It was a once-in-a-lifetime experience—or so we thought.

A few days later there was another commotion, this time in the vines covering our dog run. We heard the same cries of alarm, the gathering of the neighborhood finches. We knew what the predator was. A grandson climbed onto the run and pulled out another snake that was still holding on tightly to the mother bird it had caught in the nest and killed.

I said to myself, “What is going on? Is the Garden of Eden being invaded again?”

There came into my mind the warnings spoken by the prophets. We will not always be safe from the adversary’s influence, even within our own homes. We need to protect our nestlings.

We live in a very dangerous world that threatens those things that are most spiritual. The family, the fundamental organization in time and eternity, is under attack from forces seen and unseen. The adversary is about. His objective is to cause injury. If he can weaken and destroy the family, he will have succeeded.

Latter-day Saints recognize the transcendent importance of the family and strive to live in such a way that the adversary cannot steal into our homes. We find safety and security for ourselves and our children in honoring the covenants we have made and living up to the ordinary acts of obedience required of the followers of Christ.

Isaiah said, “The work of righteousness shall be peace; and the effect of righteousness quietness and assurance for ever.”2

That peace is also promised in the revelations in which the Lord declares, “If ye are prepared ye shall not fear.”3

The consummate power of the priesthood has been given to protect the home and its inhabitants. The father has the authority and responsibility to teach his children and to bless and to provide for them the ordinances of the gospel and every other priesthood protection necessary. He is to demonstrate love and fidelity and honor to the mother so that their children can see that love.

I have come to know that faith is a real power, not just an expression of belief. There are few things more powerful than the faithful prayers of a righteous mother.

Teach yourself and teach your families about the gift of the Holy Ghost and the Atonement of Jesus Christ. You will do no greater eternal work than within the walls of your own home.

We know that we are spirit children of heavenly parents, here on earth to receive our mortal bodies and to be tested. We who have mortal bodies have the power over the beings who do not.4 We are free to choose what we will and to pick and choose our acts, but we are not free to choose the consequences. They come as they will come.

Agency is defined in the scriptures as “moral agency,” which means that we can choose between good and evil. The adversary seeks to tempt us to misuse our moral agency.

The scriptures teach us “that every man may act in doctrine and principle pertaining to futurity, according to the moral agency which I have given unto him, that every man may be accountable for his own sins in the day of judgment.”5

Alma taught that “the Lord cannot look upon sin with the least degree of allowance.”6 In order to understand this, we must separate the sin from the sinner.

For example, when they brought before the Savior a woman taken in adultery, obviously guilty, He dismissed the case with five words: “Go, and sin no more.”7 That is the spirit of His ministry.

Tolerance is a virtue, but like all virtues, when exaggerated, it transforms itself into a vice. We need to be careful of the “tolerance trap” so that we are not swallowed up in it. The permissiveness afforded by the weakening of the laws of the land to tolerate legalized acts of immorality does not reduce the serious spiritual consequence that is the result of the violation of God’s law of chastity.

All are born with the Light of Christ, a guiding influence which permits each person to recognize right from wrong. What we do with that light and how we respond to those promptings to live righteously is part of the test of mortality.

“For behold, the Spirit of Christ is given to every man, that he may know good from evil; wherefore, I show unto you the way to judge; for every thing which inviteth to do good, and to persuade to believe in Christ, is sent forth by the power and gift of Christ; wherefore ye may know with a perfect knowledge it is of God.”8

Each of us must stay in condition to respond to inspiration and the promptings of the Holy Ghost. The Lord has a way of pouring pure intelligence into our minds to prompt us, to guide us, to teach us, and to warn us. Each son or daughter of God can know the things they need to know instantly. Learn to receive and act on inspiration and revelation.

Of all that I have read and taught and learned, the one most precious and sacred truth that I have to offer is my special witness of Jesus Christ. He lives. I know He lives. I am His witness. And of Him I can testify. He is our Savior, our Redeemer. Of this I am certain. Of this I bear witness in the name of Jesus Christ, amen.

# References
1. - Boyd K. Packer, “Unfinished Composition,” 2012.
2. - Isaiah 32:17.
3. - Doctrine and Covenants 38:30.
4. - See Teachings of Presidents of the Church: Joseph Smith (2007), 211.
5. - Doctrine and Covenants 101:78.
6. - Alma 45:16.
7. - John 8:11.
8. - Moroni 7:16.