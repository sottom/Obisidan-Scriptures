Elder Erich W. Kopischke
Of the Seventy
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/being-accepted-of-the-lord?lang=eng)

_Seeking and receiving the acceptance of the Lord will lead to the knowledge that we are chosen and blessed by Him._

When I was a boy, I remember my father sometimes taking me with him to work on projects. We had a little garden a few kilometers from where we lived, and there was always so much to do to prepare the garden each season. We worked on the gazebo or built or repaired fences. In my memory this work always occurred in the freezing cold, heavy snow, or pouring rain. But I loved it. My father would teach me how to do things with patience and acceptance.

One day he invited me to tighten a screw and warned, “Remember, if you put it in too tight, it will break.” Proudly, I wanted to show him what I could do. I tightened with all my might, and, of course, I broke the screw. He made a funny comment, and we started over. Even when I “messed up,” I always felt his love and confidence in me. He passed away more than 10 years ago, but I can still hear his voice, sense his love, enjoy his encouragement, and feel his acceptance.

The feeling of being accepted by someone we love is a basic human need. Being accepted by good people motivates us. It increases our sense of self-worth and self-confidence. Those who cannot find acceptance from desirable sources often seek it elsewhere. They may look to people who are not interested in their well-being. They may attach themselves to false friends and do questionable things to try to receive the acknowledgment they are seeking. They may seek acceptance by wearing a particular brand of clothing to generate a feeling of belonging or status. For some, striving for a role or a position of prominence can also be a way of seeking acceptance. They may define their worth by a position they hold or status they obtain.

Even in the Church we are not always free from this type of thinking. Seeking acceptance from the wrong sources or for incorrect reasons puts us on a dangerous path—one that is likely to lead us astray and even to destruction. Instead of feeling cherished and self-confident, we will eventually feel abandoned and inferior.

Alma counseled his son Helaman, “See that ye look to God and live.”1 The ultimate source of empowerment and lasting acceptance is our Heavenly Father and His Son, Jesus Christ. They know us. They love us. They do not accept us because of our title or position. They do not look at our status. They look into our hearts. They accept us for who we are and what we are striving to become. Seeking and receiving acceptance from Them will always lift and encourage us.

I will share a simple pattern which, if applied, can help every one of us find ultimate acceptance. This pattern was given by the Lord through the Prophet Joseph Smith: “Verily I say unto you, all among them who know their hearts are honest, and are broken, and their spirits contrite, and are willing to observe their covenants by sacrifice—yea, every sacrifice which I, the Lord, shall command—they are accepted of me.”2

This pattern consists of three simple steps:





Know that our hearts are honest and broken,





Know that our spirits are contrite, and





Be willing to observe our covenants by sacrifice, as commanded by the Lord.





First, we need to know that our hearts are honest and broken. How do we know that? We begin by engaging in sincere self-reflection. The heart is the center of our feelings. As we look into our hearts, we screen ourselves. What no one around us knows, we surely know. We know our motives and desires. When we engage in sincere, honest reflection, we do not rationalize or deceive ourselves.

There is also a way to judge if our hearts are broken. A broken heart is a soft, an open, and a receptive heart. When I hear the Savior say, “Behold, I stand at the door, and knock,”3 I hear Him knocking at the door of my heart. If I open this door to Him, I am more responsive to the invitations of the Spirit, and I am more accepting of God’s will.

As we sincerely and prayerfully ponder the extent to which our hearts are honest and broken, we will be taught by the Holy Ghost. We will receive a sweet confirmation or gentle correction, inviting us to act.

Second, we have to know that our spirit is contrite. The word contrite in the Oxford dictionary is defined as “feeling or expressing remorse at the recognition that one has done wrong.”4 If we have a contrite spirit, we acknowledge our sins and shortcomings. We are teachable “concerning [all] things pertaining to righteousness.”5 We feel godly sorrow and are willing to repent. A contrite spirit is willing to listen “to the enticings of the Holy Spirit.”6

A contrite spirit is manifest by our willingness and determination to act. We are willing to humble ourselves before God, willing to repent, willing to learn, and willing to change. We are willing to pray, “Not my will, but thine, be done.”7

The third step to being accepted by the Lord is a conscious decision to observe our covenants through sacrifice, “yea, every sacrifice which I, the Lord, shall command.”8 Too often we think that the word sacrifice refers to something big or hard for us to do. In certain situations this may be true, but mostly it refers to living day-to-day as a true disciple of Christ.

One way we observe our covenants by sacrifice is worthily partaking of the sacrament each week. We consciously prepare ourselves for the sacred ordinance. We renew and confirm our sacred promises to the Lord. In this way we feel His acceptance and receive His assurance that our efforts are recognized and our sins are forgiven through the Atonement of Jesus Christ. During this ordinance, the Lord promises us that as we are willing to take upon us the name of His Son and always remember Him and keep His commandments, we will always have His Spirit to be with us. Having the Holy Ghost as our constant companion is the ultimate indicator of being accepted of God.

Other ways to observe our covenants by sacrifice are as simple as accepting a calling in the Church and faithfully serving in that calling or following the invitation of our prophet, Thomas S. Monson, to reach out to those who are standing at the wayside and need to be spiritually rescued. We observe our covenants by sacrifice by giving silent service in our neighborhood or community or by finding the names of our ancestors and doing temple work for them. We observe our covenants by sacrifice by simply striving for righteousness, being open, and listening to the promptings of the Spirit as we live our daily lives. Sometimes observing our covenants means nothing more than standing firmly and faithfully when the storms of life are raging all around us.

After explaining the pattern of how to be accepted by Him, the Lord uses a wonderful illustration to show how we profit as individuals and families as we seek His acceptance. He said, “For I, the Lord, will cause them to bring forth as a very fruitful tree which is planted in a goodly land, by a pure stream, that yieldeth much precious fruit.”9

As we are personally in tune with the Spirit of the Lord and feel His acceptance, we will be blessed above our understanding and bring forth many fruits of righteousness. We will be among those to whom He has said, “Well done, thou good and faithful servant: thou hast been faithful over a few things, I will make thee ruler over many things: enter thou into the joy of thy lord.”10

Seeking and receiving the acceptance of the Lord will lead to the knowledge that we are chosen and blessed by Him. We will gain increased confidence that He will lead us and direct us for good. His tender mercies will become evident in our hearts, in our lives, and in our families.

With all my heart I invite you to seek the Lord’s acceptance and enjoy His promised blessings. As we follow the simple pattern the Lord has laid out, we will come to know that we are accepted of Him, regardless of our position, status, or mortal limitations. His loving acceptance will motivate us, increase our faith, and help us deal with everything we face in life. Despite our challenges, we will be successful, prosper,11 and feel at peace.12 We will be among those to whom the Lord said:

“Fear not, little children, for you are mine, and I have overcome the world, and you are of them that my Father hath given me;

“And none of them that my Father hath given me shall be lost.”13

In the name of Jesus Christ, amen.

# References
1. - Alma 37:47.
2. - Doctrine and Covenants 97:8.
3. - Revelation 3:20.
4. - Oxford Dictionaries Online, “contrite,” oxforddictionaries.com.
5. - Alma 21:23.
6. - Mosiah 3:19.
7. - Luke 22:42.
8. - Doctrine and Covenants 97:8.
9. - Doctrine and Covenants 97:9.
10. - Matthew 25:21.
11. - See Mosiah 2:22.
12. - See Mosiah 2:41.
13. - Doctrine and Covenants 50:41–42.