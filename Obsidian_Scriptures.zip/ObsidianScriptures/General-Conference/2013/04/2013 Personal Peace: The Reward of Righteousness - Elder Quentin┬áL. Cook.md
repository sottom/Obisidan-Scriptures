Elder Quentin L. Cook
Of the Quorum of the Twelve Apostles
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/personal-peace-the-reward-of-righteousness?lang=eng)

_Even with the trials of life, because of the Savior’s Atonement and His grace, righteous living will be rewarded with personal peace._

Recent experiences have caused me to reflect on the doctrine of peace and especially the role of Jesus Christ in helping each of us obtain lasting personal peace.

Two events in the past few months have touched me deeply. First, I spoke at the funeral for Emilie Parker, a precious six-year-old who lost her life along with 25 others, including 19 young children, in a tragic shooting in Newtown, Connecticut. I mourned with her family and recognized that many had been deprived of peace. I found strength and faith in her parents, Robert and Alissa Parker.

Second, I met with thousands of faithful members of the Church in the Ivory Coast city of Abidjan.1 This French-speaking, West-African country has endured economic hardship, a military coup, and two recent civil wars concluding in 2011. Yet I felt a special peace in their presence.

Events often occur that rob us of peace and heighten our sense of vulnerability.

Who can forget the evil attacks of September 11, 2001, on various U.S. locations? Such events remind us how quickly our feelings of peace and safety can be destroyed.

Our oldest son and his wife, who were expecting their first child, lived three blocks from the World Trade Center in New York City when the first plane crashed into the North Tower. They went to the roof of their apartment building and were horrified as they watched what they thought was some kind of terrible accident. Then they witnessed the second plane crash into the South Tower. They immediately realized that this was no accident and believed lower Manhattan was under attack. When the South Tower collapsed, their apartment building was engulfed in the dust cloud that rained down over lower Manhattan.

Confused about what they had witnessed and concerned about further attacks, they made their way to a safer area and then to the Manhattan stake Church building at Lincoln Center. When they arrived, they found that dozens of other members in lower Manhattan had made the same decision to gather at the stake center. They called to let us know where they were. I was relieved that they were safe but not surprised at their location. Modern revelation teaches that the stakes of Zion are a defense and “a refuge from the storm, and from wrath when it shall be poured out without mixture upon the whole earth.”2

They could not return to their apartment for over a week and were devastated by the loss of innocent lives, but they suffered no permanent damage.

In contemplating these events, I have been impressed with the doctrinal difference between universal or world peace and personal peace.3

At the birth of the Savior, a multitude of the heavenly host praised God and proclaimed, “Glory to God in the highest, and on earth peace, good will toward men.”4

However, it has been poignantly noted that even in this eternally significant period following the birth of the Son of God, Herod the king carried out the slaughter of innocent infants in Bethlehem.5

Agency is essential to the plan of happiness. It allows for the love, sacrifice, personal growth, and experience necessary for our eternal progression. This agency also allows for all the pain and suffering we experience in mortality, even when caused by things we do not understand and the devastating evil choices of others. The very War in Heaven was waged over our moral agency and is essential to understanding the Savior’s earthly ministry.

As recited in the 10th chapter of Matthew, the Savior instructed the Twelve and acknowledged that His mission would not achieve universal peace in this mortal life. The Apostles were told to leave peace upon the worthy houses they visited but warned that they would be “in the midst of wolves … [and] hated of all men for my name’s sake: but he that endureth to the end shall be saved.”6 A significant pronouncement is made in verse 34: “Think not that I am come to send peace on earth.”7 It is clear that universal peace did not exist on the earth during Christ’s mortal ministry, and it does not now.

In the Lord’s preface to the Doctrine and Covenants, a number of very important principles are taught. With respect to those who do not repent, His Spirit (the Spirit of Christ), which is given to every person who comes into the world,8 “shall not always strive with man.”9 Also, “peace shall be taken from the earth.”10 Prophets have declared that peace has indeed been taken from the earth.11 Lucifer has not yet been bound and exercises power in this dominion.12

The heavenly aspiration of good people everywhere has and always will be for peace in the world. We must never give up on achieving this goal. But, President Joseph F. Smith taught, “There never can come to the world that spirit of peace and love … until mankind will receive God’s truth and God’s message … , and acknowledge his power and authority which is divine.”13

We earnestly hope and pray for universal peace, but it is as individuals and families that we achieve the kind of peace that is the promised reward of righteousness. This peace is a promised gift of the Savior’s mission and atoning sacrifice.

This principle is succinctly captured in the Doctrine and Covenants: “But learn that he who doeth the works of righteousness shall receive his reward, even peace in this world, and eternal life in the world to come.”14

President John Taylor taught that peace is not only desirable, but “it is the gift of God.”15

The peace to which I am referring is not just a temporary tranquility. It is an abiding deep happiness and spiritual contentment.16

President Heber J. Grant described the Savior’s peace this way: “His peace will ease our suffering, bind up our broken hearts, blot out our hates, engender in our breasts a love of fellow men that will suffuse our souls with calm and happiness.”17 In my meetings with Emilie Parker’s parents, I saw that the Savior’s peace has eased their suffering and is helping to bind up their broken hearts. It is notable that immediately after the shooting, Brother Parker expressed forgiveness to the perpetrator. As President Grant said, the Savior’s peace can “blot out our hates.” Judgment is the Lord’s.

The Ivory Coast Saints, during the period of civil war in their country, found peace by focusing on living the gospel of Jesus Christ, with particular emphasis on family history and temple work for their ancestors.18

We all long for peace. Peace is not just safety or lack of war, violence, conflict, and contention. Peace comes from knowing that the Savior knows who we are and knows that we have faith in Him, love Him, and keep His commandments, even and especially amid life’s devastating trials and tragedies. The Lord’s answer to the Prophet Joseph Smith in Liberty Jail brings solace to the heart:

“My son, peace be unto thy soul; thine adversity and thine afflictions shall be but a small moment;

“And then, if thou endure it well, God shall exalt thee on high.”19

Remember, “God is not the author of confusion, but [the author] of peace.”20 For those who reject God, there is no peace. We all participated in the councils of heaven that provided for moral agency, knowing that there would be mortal pain and even unspeakable tragedy because of the abuse of agency. We understood that this could leave us angry, bewildered, defenseless, and vulnerable. But we also knew that the Savior’s Atonement would overcome and compensate for all of the unfairness of mortal life and bring us peace. Elder Marion D. Hanks had a framed statement on his wall by Ugo Betti: “To believe in God is to know that all the rules will be fair, and that there will be wonderful surprises.”21

What are the sources of peace? Many search for peace in worldly ways, which never have and never will succeed. Peace is not found by attaining great wealth, power, or prominence.22 Peace is not found in the pursuit of pleasure, entertainment, or leisure. None of these can, even when attained in abundance, create any lasting happiness or peace.

Emma Lou Thayne’s beloved hymn asks the appropriate questions: “Where can I turn for peace? Where is my solace when other sources cease to make me whole?”23 The answer is the Savior, who is the source and author of peace. He is the “Prince of Peace.”24

How do we stay close to the Savior? Humbling ourselves before God, praying always, repenting of sins, entering the waters of baptism with a broken heart and contrite spirit, and becoming true disciples of Jesus Christ are profound examples of the righteousness that is rewarded by abiding peace.25 After King Benjamin delivered his stirring message concerning the Atonement of Christ, the multitude fell to the earth. “The Spirit of the Lord came upon them, and they were filled with joy, having received a remission of their sins, and having peace of conscience, because of the exceeding faith which they had in Jesus Christ.”26 Repentance and living righteously allow for peace of conscience, which is essential for contentment.27 When there has been a major transgression, confession is required to bring peace.28 Perhaps there is nothing to compare with the peace that comes from a sin-wracked soul unloading his or her burdens on the Lord and claiming the blessings of the Atonement. As another favorite Church hymn puts it, “I’ll drop my burden at his feet and bear a song away.”29

My heart rejoices when I realize that in our day tens of thousands of young men, young women, and senior missionaries have accepted the call to be emissaries of our Lord and Savior, Jesus Christ. They are taking the restored gospel of peace to the world, one person and one family at a time—a work of righteousness to bring this peace to Heavenly Father’s children.

The Church is a refuge where followers of Christ attain peace. Some young people in the world say they are spiritual but not religious. Feeling spiritual is a good first step. However, it is in the Church that we are fellowshipped, taught, and nourished by the good word of God. More importantly, it is priesthood authority in the Church that provides for sacred ordinances and covenants that bind families together and qualify each of us to return to God the Father and Jesus Christ in the celestial kingdom. These ordinances bring peace because they are covenants with the Lord.

Temples are where many of these sacred ordinances occur and are also a source of peaceful refuge from the world. Those who visit temple grounds or participate in temple open houses also feel this peace. One experience preeminent in my mind is the Suva Fiji Temple open house and dedication. There had been political upheaval resulting in rebels burning and looting downtown Suva, occupying the houses of Parliament and holding legislators hostage. The country was under martial law. The Fiji military gave the Church limited permission to assemble people for the open house and a very small group for the dedication. The members as a whole were uninvited due to concerns for their safety. It was the only temple dedication since the original Nauvoo Temple that was held under very difficult circumstances.

One person invited to the open house was a lovely Hindu woman of Indian descent, a member of Parliament who was initially held hostage but was released because she was female.

In the celestial room, free from the turmoil of the world, she dissolved in tears as she expressed feelings of peace that overwhelmed her. She felt the Holy Ghost comforting and bearing witness of the sacred nature of the temple.

The Savior is the source of true peace. Even with the trials of life, because of the Savior’s Atonement and His grace, righteous living will be rewarded with personal peace. In the intimate setting of the Passover chamber, the Savior promised His Apostles that they would be blessed with the “Comforter, which is the Holy Ghost” and then uttered these important words: “Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you.”30 Then just before His Intercessory Prayer: “These things I have spoken unto you, that in me ye might have peace. In the world ye shall have tribulation: but be of good cheer; I have overcome the world.”31

Eliza R. Snow penned this concept beautifully:





Lift up your hearts in praise to God;

Let your rejoicings never cease.

Though tribulations rage abroad,

Christ says, “In me ye shall have peace.”32





I so testify in the name of Jesus Christ, amen.

# References
1. - Two conferences were held in Abidjan on Sunday, February 10, 2013; 9,693 were in attendance—619 of whom were not yet members of the Church. Total Church membership in the Ivory Coast is approximately 19,000.
2. - Doctrine and Covenants 115:6.
3. - The word peace has different meanings. In classical Greek it refers to cessation, discontinuance, or absence of hostilities between rival forces. In Hebrew the word has a more comprehensive meaning and sometimes is just a form of greeting. Peace is also a “state of existence that comes to man only upon the terms and conditions set by God” (Howard W. Hunter, in Conference Report, Oct. 1966, 14–17).
4. - Luke 2:14; emphasis added.
5. - See Matthew 2:16; see also Ross Douthat, “The Loss of the Innocents,” New York Times, Dec. 16, 2012, 12.
6. - Matthew 10:16, 22.
7. - Matthew 10:34.
8. - See Doctrine and Covenants 84:46.
9. - Doctrine and Covenants 1:33.
10. - Doctrine and Covenants 1:35.
11. - President Woodruff declared this in 1894 and again in 1896. See The Discourses of Wilford Woodruff, ed. G. Homer Durham (1946), 251–52; see also Marion G. Romney, in Conference Report, Apr. 1967, 79–82.
12. - See Joseph Fielding Smith, The Predicted Judgments, Brigham Young University Speeches of the Year (Mar. 21, 1967), 5–6. However, as Elder Neal A. Maxwell stated, “We can have inner peace even though peace has been taken from the earth … [and] ‘all things [are] in commotion’” (“Behold, the Enemy Is Combined,” Ensign, May 1993, 79).
13. - Teachings of Presidents of the Church: Joseph F. Smith (1998), 400.
14. - Doctrine and Covenants 59:23.
15. - Teachings of Presidents of the Church: John Taylor (2001), 151.
16. - From the ancient Greeks to our own day, these words—happiness and contentment—have been parsed, dissected, and grappled with not only as to their meaning but also the guidance they give to our lives. See David Malouf, The Happy Life: The Search for Contentment in the Modern World (2011). See also a review of Mr. Malouf’s book, in R. Jay Magill Jr., “How to Live Well,” Wall Street Journal, Jan. 26–27, 2013, C6.
17. - Teachings of Presidents of the Church: Heber J. Grant (2002), 226.
18. - “Three of the five Ivory Coast stakes are among the top 25 in the Church in the percentage of adults [submitting] family names for temple ordinances,” and the Cocody Cote d’Ivoire Stake is the highest (C. Terry Warner and Susan Warner, “Apostle Visits Ivory Coast, Is ‘Impressed with Exceptional Spirit,’” Church News, Mar. 3, 2013, 4, 14). In the wake of the civil war and the closest temple being 12 hours away by bus in Accra, Ghana, this is marvelous evidence of faith and has resulted in personal and family peace.
19. - Doctrine and Covenants 121:7–8. President Harold B. Lee taught, “So, we must be refined; we must be tested in order to prove the strength and power that are in us” (Teachings of Presidents of the Church: Harold B. Lee [2000], 208).
20. - 1 Corinthians 14:33.
21. - In Marion D. Hanks, “A Loving, Communicating God,” Ensign, Nov. 1992, 63.
22. - See Jeffrey R. Holland, For Times of Trouble (2012), 79. Elder Holland teaches that “true poverty may do more to destroy the human spirit than any other condition except sin itself.” But the righteous use of money can enhance peace.
23. - “Where Can I Turn for Peace?” Hymns, no. 129.
24. - Isaiah 9:6.
25. - John Greenleaf Whittier put it simply: “Heed how thou livest. Do not act by day which from the night shall drive thy peace away” (“Conduct [From the Mahabharata],” in The Complete Poetical Works of John Greenleaf Whittier [1802], 484).
26. - Mosiah 4:3; emphasis added; see also Marion G. Romney, in Conference Report, Apr. 1967, 79–82.
27. - Conscience is a moral compass pointing us toward peace. It is activated by at least two sources: the Light of Christ, a glorious birthright from our Heavenly Father (see Doctrine and Covenants 88:6–13; 93:2), and the gift of the Holy Ghost (see Doctrine and Covenants 39:6).
28. - “Two sets of forgiveness are required to bring peace to the transgressor—one from the proper authorities of the Lord’s Church, and one from the Lord himself. [See Mosiah 26:29.]” (Teachings of Presidents of the Church: Spencer W. Kimball [2006], 41).
29. - “How Gentle God’s Commands,” Hymns, no. 125.
30. - John 14:26–27.
31. - John 16:33.
32. - “Though Deepening Trials,” Hymns, no. 122.