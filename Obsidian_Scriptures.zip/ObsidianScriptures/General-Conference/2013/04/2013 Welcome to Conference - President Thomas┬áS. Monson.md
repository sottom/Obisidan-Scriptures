President Thomas S. Monson
President of the Church
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/welcome-to-conference?lang=eng)

_I urge you to be attentive and receptive to the messages which we will hear. That we may do so is my prayer._

My beloved brothers and sisters, how pleased I am to welcome you to the 183rd Annual General Conference of the Church.

During the six months since last we met, it has been my opportunity to travel a bit and to meet with some of you in your own areas. Following general conference in October, I traveled to Germany, where it was my privilege to meet with our members at several locations in that country as well as in parts of Austria.

At the end of October, I dedicated the Calgary Alberta Temple in Canada, with the assistance of Elder and Sister M. Russell Ballard, Elder and Sister Craig C. Christensen, and Elder and Sister William R. Walker. In November, I rededicated the Boise Idaho Temple. Also traveling with me and participating in the dedication were Elder and Sister David A. Bednar, Elder and Sister Craig C. Christensen, and Elder and Sister William R. Walker.

The cultural celebrations held in conjunction with both of these dedications were outstanding. I did not personally attend the cultural celebration in Calgary, inasmuch as it was Sister Monson’s 85th birthday and I felt I should be with her. However, she and I were privileged to watch the celebration in our living room over closed-circuit television, and then I flew to Calgary the following morning for the dedication. In Boise over 9,000 youth from the temple district participated in the cultural celebration. There were so many young people involved that there was not room for family members to attend in the arena in which they performed.

Just last month President Dieter F. Uchtdorf, accompanied by Sister Uchtdorf, Elder and Sister Jeffrey R. Holland, and Elder and Sister Gregory A. Schwitzer, traveled to Tegucigalpa, Honduras, to dedicate our newly completed temple there. A magnificent youth celebration took place the evening prior to the dedication.

There are other temples which have been announced and which are at various stages in the preliminary process or which are under construction.

It is my privilege this morning to announce two additional temples, which in coming months and years will be built in the following locations: Cedar City, Utah, and Rio de Janeiro, Brazil. Brothers and sisters, temple building continues unabated.

As you know, in the October general conference I announced changes in the ages at which young men and young women might serve as full-time missionaries, with the young men now being able to serve at age 18 and the young women at 19.

The response of our young people has been remarkable and inspiring. As of April 4—two days ago—we have 65,634 full-time missionaries serving, with over 20,000 more who have received their calls but who have not yet entered a missionary training center and over 6,000 more in the interview process with their bishops and stake presidents. It has been necessary for us to create 58 new missions to accommodate the increased numbers of missionaries.

To help maintain this missionary force, and because many of our missionaries come from modest circumstances, we invite you, as you are able, to contribute generously to the General Missionary Fund of the Church.

Now, brothers and sisters, we will hear inspired messages today and tomorrow. Those who will address us have sought prayerfully to know that which the Lord would have us hear at this time.

I urge you to be attentive and receptive to the messages which we will hear. That we may do so is my prayer in the name of Jesus Christ, the Lord, amen.

# References
