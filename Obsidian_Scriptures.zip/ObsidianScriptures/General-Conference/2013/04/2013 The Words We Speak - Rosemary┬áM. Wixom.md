Rosemary M. Wixom
Primary General President
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/the-words-we-speak?lang=eng)

_How we speak to our children and the words we use can encourage and uplift them and strengthen their faith._

A young father recently learned of the passing of his extraordinary second-grade teacher. In memory of her, he wrote: “Of all the feelings and experiences I remember, the feeling most prevalent in my mind is ‘comfort.’ She may have taught me spelling, grammar, and math, but far more importantly she taught me to love being a child. In her classroom, it was OK to spell a word wrong here and there; ‘We’ll work on it,’ she’d say. It was OK to spill or tear or smudge; ‘We’ll fix it and we’ll clean it up,’ she would respond. It was OK to try, OK to stretch, OK to dream, and OK to enjoy those pleasures that come from the insignificant things that only children find exciting.”

One of the greatest influences a person can have in this world is to influence a child. Children’s beliefs and self-worth are shaped early in their lives. Everyone within the sound of my voice has the power to increase a child’s confidence in himself or herself and to increase a child’s faith in Heavenly Father and Jesus Christ through the words they speak.

In Helaman chapter 5 we read, “And now, my sons, remember, remember that it is upon the rock of our Redeemer, who is Christ, the Son of God, that ye must build your foundation.”1

These were the words Helaman taught his sons. And we read on: “And they did remember his words; and … they went forth … to teach the word of God among all the people.”2

Even though Helaman’s sons were persecuted and put in prison, those words they had heard never failed them. They were protected and encircled about with a pillar of fire. Then came a voice, saying to their captors:

“Repent ye, and seek no more to destroy my servants. …

“… It was not a voice of thunder, neither was it a voice of a great tumultuous noise, but behold, it was a still voice of perfect mildness, as if it had been a whisper, and it did pierce even to the very soul.”3

We can learn from that voice from heaven. It was not loud, scolding, or demeaning; it was a still voice of perfect mildness, giving firm direction while giving hope.

How we speak to our children and the words we use can encourage and uplift them and strengthen their faith to stay on the path back to Heavenly Father. They come to this earth ready to listen.

An example of a child listening happened in a fabric store. The store was crowded with shoppers when it became obvious to everyone that a mother was panicked because she had lost her young son. At first, she was calling his name. “Connor,” she would say as she briskly walked around the store. As time passed, her voice got louder and more frantic. Soon the store security officers were notified, and everyone in the store was involved in looking for the child. Several minutes passed with no success of finding him. Connor’s mother, understandably, was becoming more frantic by the minute and was rapidly yelling his name over and over again.

One patron, after saying a silent prayer, had the thought that Connor may be frightened as he listened to his mother scream his name. She mentioned this to another woman involved in the search, and they quickly made a plan. Together they began to walk between the tables of fabric, quietly repeating the words “Connor, if you can hear my voice, say, ‘Here I am.’” As they walked slowly toward the back of the store repeating that phrase, sure enough, they heard a timid, soft voice say, “Here I am.” Connor was hiding between the bolts of fabric under a table. It was a voice of perfect mildness that encouraged Connor to respond.





Pray to Know a Child’s Needs



To speak to a child’s heart, we must know a child’s needs. If we pray to know those needs, the very words we say may have the power to reach into their hearts. Our efforts are magnified when we seek the direction of the Holy Ghost. The Lord said:

“Speak the thoughts that I shall put into your hearts, …

“For it shall be given you in the very hour, yea, in the very moment, what ye shall say.”4







Disconnect and Listen with Love



Unfortunately, the distractions of this world prevent many children from hearing encouraging words that could shape their view of themselves.

Dr. Neal Halfon, a physician who directs the UCLA Center for Healthier Children, Families, and Communities, refers to “parental benign neglect.” One example involved an 18-month-old and his parents:

“‘Their son seemed happy, active and engaged, clearly enjoying time and pizza with his parents. … At the end of dinner, Mom got up to run an errand, handing over care to Dad.’

“Dad … started reading phone messages while the toddler struggled to get his attention by throwing bits of pizza crust. Then the dad re-engaged, facing his child and playing with him. Soon, though, he substituted watching a video on his phone with the toddler until his wife returned.

“… [Dr.] Halfon observed a dimming of the child’s internal light, a lessening of the connection between parent and child.”5

The answer to our prayer of how to meet our children’s needs may be to more often technologically disconnect. Precious moments of opportunity to interact and converse with our children dissolve when we are occupied with distractions. Why not choose a time each day to disconnect from technology and reconnect with each other? Simply turn everything off. When you do this, your home may seem quiet at first; you may even feel at a loss as to what to do or say. Then, as you give full attention to your children, a conversation will begin, and you can enjoy listening to each other.







Write to Persuade Our Children



We can also influence our children through the words we write to them. Nephi writes, “We labor diligently to write, to persuade our children … to believe in Christ, and to be reconciled to God.”6

President Thomas S. Monson shared the experience of Jay Hess, an airman who was shot down over North Vietnam in the 1960s: “For two years his family had no idea whether he was dead or alive. His captors in Hanoi eventually allowed him to write home but limited his message to less than 25 words.” President Monson asks: “What would you and I say to our families if we were in the same situation—not having seen them for over two years and not knowing if we would ever see them again? Wanting to provide something his family could recognize as having come from him and also wanting to give them valuable counsel, Brother Hess wrote [the following words]: ‘These things are important: temple marriage, mission, college. Press on, set goals, write history, take pictures twice a year.’”7

What words would you write to your children if you had 25 words or less?

The young father I spoke about earlier, who wrote about his memories of his second-grade teacher, is now raising a beautiful baby daughter. He feels the heavenly trust that has been placed in him. As she grows up, what will be her future? What will he say that will sink deep into her heart? What words will encourage her, lift her, and help her to stay on the path? Will it make a difference if he takes time to whisper, “You are a child of God”? Will she remember someday that her father often said the words, “I love everything about you”?

Isn’t that what our Heavenly Father was saying to His Son and to all of us when He said, “This is my beloved Son” and then added, “in whom I am well pleased”?8

May the words we speak and write to our children reflect the love our Heavenly Father has for His Son, Jesus Christ, and for us. And then may we pause to listen, for a child is most capable of speaking great and marvelous things in return. I say this in the name of Jesus Christ, amen.

# References
1. - Helaman 5:12.
2. - Helaman 5:14; emphasis added.
3. - Helaman 5:29–30.
4. - Doctrine and Covenants 100:5–6.
5. - Lois M. Collins, “Baby’s Development Potentially Harmed by Parents Texting,” Deseret News, June 4, 2012, deseretnews.com/article/print/865556895/Babys-development-potentially-harmed-by-parents-texting.html.
6. - 2 Nephi 25:23.
7. - Thomas S. Monson, “Finding Joy in the Journey,” Ensign or Liahona, Nov. 2008, 86.
8. - Matthew 3:17.