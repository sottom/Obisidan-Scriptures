David L. Beck
Young Men General President
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/your-sacred-duty-to-minister?lang=eng)

_You received the power, the authority, and the sacred duty to minister the moment you were ordained to the priesthood._

The Joy of Ministering



Young men of the Aaronic Priesthood, you are beloved sons of God, and He has a great work for you to do. To accomplish this work, you must fulfill your sacred duty to minister to others.1

Do you know what it means to minister? Think about this question while I tell you about a girl named Chy Johnson.

When Chy started high school last year, she became the victim of cruel and thoughtless bullying. She was mistreated, shoved, and taunted as she walked to class—some students even threw garbage at her. You have probably seen people mistreated like this in your school too.

For too many people, the teenage years are a time of loneliness and fear. It doesn’t have to be this way. Fortunately for Chy, there were young men at her school who understood what it means to minister.

Chy’s mother had asked teachers at the school to help stop the bullying, but it continued. She then contacted Carson Jones, an Aaronic Priesthood holder and the starting quarterback of the football team. She asked him to help her find out who was doing the bullying.

Carson agreed to help, but in his heart he felt that he could do much more than just identify the bullies. The Spirit whispered to him that he needed to help Chy feel loved.

Carson asked some of his teammates to join him in ministering to Chy. They invited her to sit with them during lunch. They walked her to class to make sure she was safe. Not surprisingly, with football players as her close friends, no one bullied Chy anymore.

This was an exciting season for the football team. But even with the thrill of an undefeated season, these young men did not forget about Chy. They invited her to join the team on the field after games. Chy felt loved and appreciated. She felt safe. She was happy.

The football team went on to win the state title. But something more important than a football championship happened at their school. The example of these young men has motivated other students to be more accepting, more friendly. They now treat each other with more kindness and respect.

National news media found out what these young men had done and shared their story across the country. What began as an effort to minister to one is inspiring thousands of others to do the same.

Chy’s mother calls these young men “angels in disguise.” Carson and his friends are quick to say that Chy has blessed their lives much more than they blessed hers. That’s what happens when you lose yourself in serving others—you find yourself.2 You change and grow in ways that would not be possible otherwise. These young men have experienced the joy of ministering and continue to seek opportunities to bless others. They are anxious to extend their ministering in the coming months when they serve as full-time missionaries.3







A Need and a Duty



There are thousands of Chy Johnsons throughout the world—people who need to feel Heavenly Father’s love. They are in your schools, in your quorums, and even in your family. Some come to mind quickly. Others have needs that are less obvious. Virtually everyone you know could be blessed in some way by your ministering. The Lord is counting on you to reach out to them.

You don’t have to be a star athlete to minister to others. You received the power, the authority, and the sacred duty to minister the moment you were ordained to the priesthood. President James E. Faust taught, “Priesthood is the authority delegated to man to minister in the name of God.”4 The Aaronic Priesthood holds the keys of the ministering of angels.5

As you love His children, Heavenly Father will guide you, and angels will assist you.6 You will be given power to bless lives and rescue souls.

Jesus Christ is your example. He “came not to be ministered unto, but to minister.”7 To minister means to love and care for others. It means to attend to their physical and spiritual needs. Put simply, it means to do what the Savior would do if He were here.







Your Family



Start in your own home. This is where you can do your most important ministering.8

Do you want to try an interesting experiment? The next time your mother asks for your help around the house, say something like, “Thank you for asking, Mom. I would love to help.” Then watch her reaction. Some of you might want to brush up on your first aid skills before you try this. You may send her into shock. After you revive her, you’ll find a noticeable improvement in your relationship with her and an increase of the Spirit in your home.

That’s just one way to minister to your family; there are many others. You minister as you speak kind words to family members. You minister as you treat your siblings like your best friends.

Perhaps most important, you minister as you assist your father in his duties as the spiritual leader in your home. Give your full support and encouragement to family home evening, family prayer, and family scripture study. Do your part to ensure that the Spirit is present in your home. This will strengthen your father in his role and prepare you to be a father someday. If you do not have a father in your home, your responsibility to minister to your family is even more needed.







Your Quorum



You also have a duty to minister in your quorum.

The priesthood is expanding across the world. Many of you are heeding President Monson’s call to rescue. There are more active Aaronic Priesthood holders today than ever before in the history of the Church. Yet there are still those who are not active and who need you.

Last June, when a new branch was created in Bangalore, India, the only young man in priesthood meeting was a recently ordained deacon named Gladwin.

Gladwin, along with the Young Men president and branch president, began calling the less-active young men and visiting them in their homes. Soon a second young man, Samuel, started coming to church again.

Each week Gladwin and Samuel called those who had not attended quorum meeting and shared what they had learned. They also called or visited them on their birthdays. One by one, the less-active young men became their friends and began to accept invitations to come to quorum activities, to attend quorum meetings, and eventually to do their own ministering. Today, all of the young men in the branch are active in the Church.

The scriptures teach that Aaronic Priesthood quorums are to sit in council and edify—or build up and strengthen—one another.9 You edify as you teach gospel truths, share spiritual experiences, and bear testimony. The youth curriculum encourages these kinds of interactions in quorum meetings, but this can happen only when every member of the quorum feels loved and respected. Mocking and teasing have no place in a quorum meeting—especially when feelings are openly shared. Quorum presidencies must take the lead in ensuring that quorum meetings are a safe place for everyone to participate.

The Apostle Paul admonished, “Let no corrupt communication proceed out of your mouth, but that which is good to the use of edifying, that it may minister grace unto the hearers.”10

Priesthood holders never use vulgar or filthy language. They never demean or hurt others. They always build up and strengthen others. This is a simple but powerful way to minister.







At All Times



The work of ministering is not confined to ordinances or home teaching visits or occasional service projects. We are always priesthood men—not just on Sunday and not only when we’re wearing white shirts and ties. We have a duty to minister wherever we stand. Ministering is not just something we do—it defines who we are.

Minister every day. Opportunities are all around you. Look for them. Ask the Lord to help you recognize them. You will find that most consist of small, sincere acts that help others become followers of Jesus Christ.11

As you strive to be worthy of the Spirit, you will recognize thoughts and feelings prompting you to minister. As you act on these promptings, you will receive more of them and your opportunities and ability to minister will increase and expand.

My young brethren, I testify that you have been given the authority and power of the magnificent Aaronic Priesthood to minister in God’s name.

I testify that as you do, you will be an instrument in God’s hands to help others. Your life will be richer and more meaningful. You will find greater strength to resist evil. You will find true happiness—the kind that is known only by true followers of Jesus Christ.

May you experience the joy of fulfilling your sacred duty to minister, I pray in the name of Jesus Christ, amen.

# References
1. - See Doctrine and Covenants 84:111.
2. - See Mark 8:35.
3. - See Trent Toone, “Kindness of Arizona High School QB Carson Jones and Teammates Has Gone Viral,” Deseret News, Nov. 9, 2012, deseretnews.com/article/865566351/Kindness-of-Arizona-high-school-QB-Carson-Jones-and-teammates-has-gone-viral.html.
4. - James E. Faust, “Message to My Grandsons,” Ensign or Liahona, May 2007, 54; emphasis added.
5. - See Doctrine and Covenants 13:1.
6. - See Doctrine and Covenants 84:88.
7. - See Matthew 20:27–28.
8. - See Handbook 2: Administering the Church (2010), 2.4.5.
9. - See Doctrine and Covenants 107:85.
10. - Ephesians 4:29.
11. - See Handbook 2, 3.2.3.