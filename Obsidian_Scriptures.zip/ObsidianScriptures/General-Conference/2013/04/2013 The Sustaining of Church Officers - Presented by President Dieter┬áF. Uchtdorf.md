Presented by President Dieter F. Uchtdorf
Second Counselor in the First Presidency
04-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/04/the-sustaining-of-church-officers?lang=eng)

It is proposed that we sustain Thomas Spencer Monson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Henry Bennion Eyring as First Counselor in the First Presidency; and Dieter Friedrich Uchtdorf as Second Counselor in the First Presidency.

Those in favor may manifest it.

Those opposed, if any, may manifest it.

It is proposed that we sustain Boyd Kenneth Packer as President of the Quorum of the Twelve Apostles and the following as members of that quorum: Boyd K. Packer, L. Tom Perry, Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, Richard G. Scott, Robert D. Hales, Jeffrey R. Holland, David A. Bednar, Quentin L. Cook, D. Todd Christofferson, and Neil L. Andersen.

Those in favor, please manifest it.

Any opposed may so indicate.

It is proposed that we sustain the counselors in the First Presidency and the Twelve Apostles as prophets, seers, and revelators.

All in favor, please manifest it.

Contrary, if there be any, by the same sign.

Elder Walter F. González has been released as a member of the Presidency of the Quorums of the Seventy.

Those who wish to join us in a vote of appreciation, please manifest it.

It is proposed that we sustain Elder Ulisses Soares as a member of the Presidency of the Quorums of the Seventy.

All in favor, please manifest it.

Those opposed, if any.

It is proposed that we release the following as Area Seventies, effective on May 1, 2013: Rubén V. Alliaud, Sergio M. Anaya, Nolan D. Archibald, Carlos L. Astorga, Hector Avila, M. Anthony Burns, David Cabrera, Milton Camargo, Robert E. Chambers, Victor Kah Keng Chen, Kuo Chiang Chung, Nelson D. Córdova, Gary L. Crittenden, Edward Dube, Matthew J. Eyring, Sione M. Fineanganofo, Alfredo L. Gessati, James B. Gibson, Jovencio A. Guanzon, Mario E. Guerra, Luis S. Hernandez, Hernan I. Herrera, Javier Ibañez, Paulo H. Itinose, Douglas W. Jessop, Stephen C. Kerr, Joni L. Koch, Faustino López, Richard K. Melchin, Freebody A. Mensah, Benson E. Misalucha, Abelardo Morales, W. T. David Murray, K. Brett Nattress, S. Gifford Nielsen, Satoshi Nishihara, Michael D. Pickerd, William F. Reynolds, Michael A. Roberts, Fernando A. R. Da Rocha, Manfred Schütze, Terrence C. Smith, Rubén L. Spitale, Joshua Subandriyo, Frank V. Trythall, Miguel R. Valdez, Arnulfo Valenzuela, Carlos A. C. Villanova, Terence M. Vinson, Louis Weidmann, and Richard C. Zambrano.

Those who wish to join us in expressing gratitude for their excellent service, please manifest it.

It is proposed that we release with a vote of sincere appreciation Sisters Elaine S. Dalton, Mary N. Cook, and Ann M. Dibb as the Young Women general presidency.

We likewise extend a release to all members of the Young Women general board.

All who wish to join us in expressing appreciation to these sisters for their remarkable service and devotion, please manifest it.

It is proposed that we sustain as new members of the First Quorum of the Seventy Edward Dube, S. Gifford Nielsen, and Arnulfo Valenzuela; and as new members of the Second Quorum of the Seventy Timothy J. Dyches, Randy D. Funk, Kevin S. Hamilton, Adrián Ochoa, and Terence M. Vinson.

All in favor, please manifest it.

Those opposed, by the same sign.

In view of his call as a member of the Second Quorum of the Seventy, we also release Brother Adrián Ochoa as second counselor in the Young Men general presidency.

Those who wish to extend a vote of appreciation may so manifest it.

It is proposed that we sustain the following as new Area Seventies: Ruben Acosta, Frederick O. Akinbo, Omar A. Alvarez, Sergio Antunes, Alan C. Batt, Grant C. Bennett, Fernando E. Calderón, Wilson B. Calderón, H. Marcelo Cardus, Yoke Sang (Freddie) Chan, Christopher Charles, Valeri V. Cordón, Paul R. Coward, M. T. Ben Davis, Massimo De Feo, Marion B. De Antuñano, Francisco J. Ruiz de Mendoza, Robert A. Dryden, Robert J. Dudfield, Daniel F. Dunnigan, Jeffrey D. Erekson, E. Xavier Espinoza, Meliula M. Fata, Sam M. Galvez, Claude R. Gamiette, Mervyn C. Giddey, João R. Grahl, David P. Homer, Daniel W. Jones, John A. Koranteng, Steven O. Laing, Axel H. Leimer, Gustavo Lopez, José E. Maravilla, Alfredo Miron, Hugo Montoya, Joaquim J. Moreira, Katsuyuki Otahara, José C. Pineda, Gary S. Price, Miguel A. Reyes, Gary B. Sabin, Alfredo L. Salas, Netzahualcoyotl Salinas, Ciro Schmeil, D. Zackary Smith, Michael L. Southward, G. Lawrence Spackman, Vern P. Stanfill, William H. Stoddard, Stephen E. Thompson, George J. Tobias, ‘Aisake K. Tukuafu, Jacques A. Van Reenen, Raul E. Vicencio, Raul S. Villanueva, Alan R. Walker, Keith P. Walker, and Hoi Seng Leonard Woo.

All in favor, please manifest it.

Those opposed, if any.

It is proposed that we sustain Bonnie Lee Green Oscarson as general president of the Young Women, with Carol Louise Foley McConkie as first counselor and Evelyn Neill Foote Marriott as second counselor.

Those in favor may manifest it.

Any opposed may so signify.

It is proposed that we sustain the other General Authorities, Area Seventies, and general auxiliary presidencies as presently constituted.

Those in favor, please manifest it.

Any opposed may manifest it.

Thank you, brothers and sisters, for your sustaining vote and for your continued faith and prayers in our behalf.

We invite the newly called General Authorities and Young Women general presidency to come forward and take their places on the stand.

# References
