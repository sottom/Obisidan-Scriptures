Elder Robert D. Hales
Of the Quorum of the Twelve Apostles
10-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/10/general-conference-strengthening-faith-and-testimony?lang=eng)

_Oh, how we need general conference! Through conferences our faith is fortified and our testimonies deepened._

Thank you, President Monson, for your teaching and example of Christlike service and your charge for all of us to be missionaries. We ever pray for thee.

In our dispensation, the Savior Jesus Christ referred to a gathering of Saints as “my general conference.”1

Wherever we are in this world, however we receive these proceedings, I testify that we are gathered in His conference. I also testify that we will hear His word, for He has said, “Whether by mine own voice or by the voice of my servants, it is the same.”2

Conferences have always been part of the true Church of Jesus Christ. Adam gathered his posterity and prophesied of things to come. Moses gathered the children of Israel and taught them the commandments he had received. The Savior taught multitudes gathered both in the Holy Land and on the American continent. Peter gathered believers in Jerusalem. The first general conference in these latter days was convened just two months after the Church was organized, and conferences have continued to this very day.

These conferences are always under the direction of the Lord, guided by His Spirit.3 We are not assigned specific topics. Over weeks and months, often through sleepless nights, we wait upon the Lord. Through fasting, praying, studying, and pondering, we learn the message that He wants us to give.

Some might ask, “Why doesn’t the inspiration come more easily and quickly?” The Lord taught Oliver Cowdery, “You must study it out in your mind; then you must ask me if it be right.”4 Conference messages come to us after prayerful preparation, through the Holy Ghost.

This principle is true for all members of the Church as we prepare to participate in ward, stake, and general conferences. We study out in our minds what we need and desire from Heavenly Father, and we pray to understand and apply that which we are taught. As the time for conference arrives, we sacrifice other activities, “lay[ing] aside the things of this world, [to] seek for the things of a better.”5 Then we gather our families to hear the word of the Lord, as King Benjamin’s people did.6

Children and youth love to be included. We make a serious mistake if we assume that the conference is above their intellect and spiritual sensitivity. To the young members of the Church, I promise that if you will listen, you will feel the Spirit well up within you. The Lord will tell you what He wants you to do with your life.

In conferences we can receive the word of the Lord meant just for us. One member testified: “As I listened to your address, I was astounded. … Your talk was personal revelation directly from the Lord to my family. I have never experienced such a strong manifestation of the Spirit in my life as those minutes when the Holy Ghost spoke directly to me.”

Another said, “I have never before felt so profoundly that a talk was being given to me.”

This is possible because the Holy Ghost carries the word of the Lord unto our hearts in terms we can understand.7 When I take notes at conference, I do not always write down exactly what the speaker is saying; I note the personalized direction the Spirit is giving me.

What is said is not as important as what we hear and what we feel.8 That is why we make an effort to experience conference in a setting where the still, small voice of the Spirit can be clearly heard, felt, and understood.

Oh, how we need general conference! Through conferences our faith is fortified and our testimonies deepened. And when we are converted, we strengthen each other to stand strong amid the fiery darts of these last days.9



In recent decades the Church has largely been spared the terrible misunderstandings and persecutions experienced by the early Saints. It will not always be so. The world is moving away from the Lord faster and farther than ever before. The adversary has been loosed upon the earth. We watch, hear, read, study, and share the words of prophets to be forewarned and protected. For example, “The Family: A Proclamation to the World” was given long before we experienced the challenges now facing the family. “The Living Christ: The Testimony of the Apostles” was prepared in advance of when we will need it most.

We may not know all the reasons why the prophets and conference speakers address us with certain topics in conference, but the Lord does. President Harold B. Lee taught: “The only safety we have as members of this church is to … give heed to the words and commandments that the Lord shall give through His prophet. … There will be some things that take patience and faith. You may not like what comes from the authority of the Church. It may contradict your [personal] views. It may contradict your social views. It may interfere with some of your social life. But if you listen to these things, as if from the mouth of the Lord Himself, with patience and faith, the promise is that ‘the gates of hell shall not prevail against you; … and the Lord God will disperse the powers of darkness from before you, and cause the heavens to shake for your good, and his name’s glory’ (D&C 21:6).”10

How did President Lee know what we would be facing in our day? He knew because he was a prophet, seer, and revelator. And if we listen and obey the prophets now, including those who will speak in this very conference, we will be strengthened and protected.

The greatest blessings of general conference come to us after the conference is over. Remember the pattern recorded frequently in scripture: we gather to hear the words of the Lord, and we return to our homes to live them.

After King Benjamin taught his people, “he dismissed the multitude, and they returned, every one, according to their families, to their own houses.”11 In his day, King Limhi did the same.12 After teaching and ministering to the people at the temple in Bountiful, the Savior entreated the people, “Go ye unto your homes, and ponder upon the things which I have said, and ask of the Father, in my name, that ye may understand, and prepare your minds for the morrow, and I come unto you again.”13

We accept the Savior’s invitation when we ponder and pray to understand what we have been taught and then go forward and do His will. Remember President Spencer W. Kimball’s words: “I have made up my mind that when I go home from this [general] conference … there are many, many areas in my life that I can perfect. I have made a mental list of them, and I expect to go to work as soon as we get through.”14 President Monson recently said: “I encourage you to read the talks … and to ponder the messages contained therein. I have found in my own life that I gain even more from these inspired sermons when I study them in greater depth.”15

In addition to inviting us to hold personal and family scripture study, Heavenly Father wants us to regularly study and apply what we have learned in conference. I testify that those who put their trust in the Lord and heed this counsel in faith will gain great strength to bless themselves and their families for generations to come.

Heavenly Father has provided the way. At this conference, 97 percent of the Church can hear these messages in their own language. Millions of members in 197 countries will watch this conference in 95 languages. In just two or three days the messages will appear on LDS.org in English, and within one week they will begin to be available in 52 languages. Now we receive the printed Church magazines within three weeks of the general conference. No longer do we have to wait months for the talks to arrive by mail. On a computer, phone, or other electronic device, we can read, listen to, watch, and share the teachings of the prophets. Anytime, anywhere, we can enlarge our knowledge, strengthen our faith and testimony, protect our families, and lead them safely home.

The messages of this conference will also be woven into the online youth curriculum. Parents, you may access youth lessons for yourself on LDS.org. Find out what your children are learning, and make it the subject of your own study, family discussions, family home evenings, family councils, and personal interviews with each of your children concerning what they need to be taught individually.

I encourage all members to use the resources on the Church’s websites and mobile apps. They are continually being refined so that they are easier to use and more relevant to our lives. On LDS.org you will find resources to help you study the gospel, strengthen your home and family, and serve in your calling. You can also find your ancestors who need temple ordinances and resources to support you in the work of salvation, including sharing the gospel. Parents can take the lead in preparing their children for baptism, the priesthood, full-time missions, and the temple. They can help us walk the strait and narrow path of temple ordinances and covenants and qualify for the blessing of eternal life.

In last April’s conference, in the general priesthood meeting, I told about my father drawing a picture of a knight in armor to teach me about putting on the whole armor of God and the spiritual protection it brings.

After that session was over, a father reported to his family what he had learned. Inspired, their young son Jason searched LDS.org to hear the message for himself. A few days later he appeared in family home evening to share the lesson with his brothers and sisters. Here he is.



  ImageJason



Jason in his “whole armor of God”





A simple conference message, inspired of the Lord, received by a child, was taught to a family in a personal, powerful way. I love his breastplate of righteousness. I love his shield of faith to thwart the fiery darts of the adversary. These are the blessings of conference.

My brothers and sisters, I bear my special witness that the Lord Jesus Christ lives and stands at the head of this Church. This is His general conference. I promise you in His name that if you pray with a sincere desire to hear your Heavenly Father’s voice in the messages of this conference, you will discover that He has spoken to you to help you, to strengthen you, and to lead you home into His presence. In the name of Jesus Christ, amen.

# References
1. - Doctrine and Covenants 124:88; emphasis added.
2. - Doctrine and Covenants 1:38.
3. - See Doctrine and Covenants 46:2.
4. - Doctrine and Covenants 9:8.
5. - Doctrine and Covenants 25:10.
6. - See Mosiah 2:5.
7. - See 2 Nephi 33:1.
8. - See Spencer W. Kimball, in Conference Report, Tonga Area Conference 1976, 27.
9. - See Luke 22:31–32.
10. - Teachings of Presidents of the Church: Harold B. Lee (2000), 84–85.
11. - Mosiah 6:3.
12. - See Mosiah 8:4.
13. - 3 Nephi 17:3.
14. - Spencer W. Kimball, “Spoken from Their Hearts,” Ensign, Nov. 1975, 111.
15. - Thomas S. Monson, “God Be with You Till We Meet Again,” Ensign or Liahona, Nov. 2012, 110.