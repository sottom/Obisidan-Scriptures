President Henry B. Eyring
First Counselor in the First Presidency
10-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/10/bind-up-their-wounds?lang=eng)

_I pray that we may prepare ourselves to give whatever priesthood service the Lord may set before us on our mortal journey._

All of us are blessed with responsibility for others. To hold the priesthood of God is to be held responsible by God for the eternal lives of His children. That is real, that is wonderful, and at times that can feel overwhelming.

There are elders quorum presidents listening tonight who know what I mean. Here is what happened to one of you. It has likely happened to many of you—and more than once. The details may vary, but the situation is the same.

An elder you do not know well asked for your help. He had just found out that he had to move his wife and young baby boy today from the apartment where they have been living to another one nearby.

He and his wife had already asked a friend if they could borrow a truck for the day to move their household and personal belongings. The friend loaned them the truck. The young father began to load all they owned into the truck, but in the first few minutes, he hurt his back. The friend who loaned the truck was too busy to help. The young father felt desperate. He thought of you, his elders quorum president.

By the time he asked for help, it was early afternoon. It was the day of an evening Church meeting. You had already promised to help your wife with household projects that day. Your children had asked you to do something with them, but you hadn’t gotten to it yet.

You also knew that the members of your quorum, particularly the most faithful, the ones you usually called on to help, were likely to be in the same time bind that you were in.

The Lord knew you would have such days when He called you to this position, so He gave you a story to encourage you. It is a parable for overloaded priesthood holders. We sometimes call it the story of the good Samaritan. But it is really the story for a great priesthood bearer in these busy, difficult last days.

The story is a perfect fit for the overtaxed priesthood servant. Just remember that you are the Samaritan and not the priest or the Levite who passed by the wounded man.

You may not have thought of that story when you faced such challenges. But I pray you will when such days come again, as they surely will.

We are not told in the scriptures why the Samaritan was traveling on the road from Jerusalem to Jericho. It is not likely that he was taking a stroll alone since he must have known that robbers waited for the unwary. He was on a serious journey, and as was customary, he had with him a beast of burden as well as oil and wine.

In the Lord’s words the Samaritan, when he saw the wounded man, stopped because “he had compassion.”

More than only feeling compassion, he acted. Always remember the specifics of the account:

“And [he] went to him, and bound up his wounds, pouring in oil and wine, and set him on his own beast, and brought him to an inn, and took care of him.

“And on the morrow when he departed, he took out two pence, and gave them to the host, and said unto him, Take care of him; and whatsoever thou spendest more, when I come again, I will repay thee.”1

You and the priesthood bearers you are called to lead can have at least three assurances. First, the Lord will give you, if you ask, the feelings of compassion He feels for those in need. Second, He will provide others, like the innkeeper, to join with you in your service. And third, the Lord, like the good Samaritan, will more than recompense all who join in giving help to those in need.

You quorum presidents likely have acted on those assurances more than once. You asked others of the Lord’s priesthood to help, with confidence that they would respond with compassion. You were not afraid to ask those who have responded most often in the past because you knew that they feel compassion easily. You asked them, knowing that in the past they have felt the Lord’s generosity when they chose to help. You asked some already heavily burdened, knowing that the greater the sacrifice, the greater the compensation they will receive from the Lord. Those who have helped in the past have felt the overflowing gratitude of the Savior.

You may well have been inspired not to ask someone to help load and then unload that truck. As a leader you know your quorum members and their families well. The Lord knows them perfectly.

He knows whose wife was near the breaking point because her husband was unable to find time to do what she needed done to care for her needs. He knows which children would be blessed by seeing their father go one more time to help others or if the children needed the feeling that they matter to their father enough for him to spend time with them that day. But He also knows who needs the invitation to serve but might not appear to be a likely or willing candidate.

You cannot know all your quorum members perfectly well, but God does. So, as you have done so many times, you prayed to know whom to ask to help serve others. The Lord knows who will be blessed by being asked to help and whose family will be blessed by not being asked. That is the revelation you can expect to come to you as you lead in the priesthood.

I saw that happen when I was a young man. I was the first assistant in a priests quorum. The bishop called me one day at my home. He said that he wanted me to go with him to visit a widow in great need. He said he needed me.

As I waited for him to pick me up at my home, I was troubled. I knew the bishop had strong and wise counselors. One was a famous judge. The other ran a large company and would later become a General Authority. The bishop himself would someday serve as a General Authority. Why was the bishop saying to an inexperienced priest, “I need your help”?

Well, I know better now what he might have said to me: “The Lord needs to bless you.” At the home of the widow, I saw him, to my amazement, tell the woman that she could get no help from the Church until she filled out the budget form he had left with her earlier. On the way home, as he saw how shocked I was, he chuckled at my surprise and said, “Hal, when she gets control of her spending, she will be able to help others.”

On another occasion my bishop took me with him to the home of alcoholic parents who sent two frightened little girls to meet us at the door. After he visited with the two little girls, we turned away and he said to me, “We can’t change the tragedy in their lives yet, but they can feel that the Lord loves them.”

On another evening he took me to the home of a man who hadn’t come to church in years. The bishop told him how much he loved him and how much the ward needed him. It didn’t seem to have much effect on the man. But that time, and every time the bishop took me with him, it had a great effect on me.

There is no way that I can find out whether the bishop prayed to know which priest would be blessed by going with him on those visits. He may well have taken other priests with him many times. But the Lord knew I would someday be a bishop inviting those whose faith had grown cold to come back to the warmth of the gospel. The Lord knew I would someday be charged with the priesthood responsibility for hundreds and even thousands of Heavenly Father’s children who were in desperate temporal need.

You young men cannot know what acts of priesthood service the Lord is preparing you to give. But the greater challenge for every priesthood holder is to give spiritual help. All of us have that charge. It comes with being a member of a quorum. It comes with being a member of a family. If the faith of anyone in your quorum or your family is attacked by Satan, you will feel compassion. Much like the service and mercy given by the Samaritan, you will also minister to them with healing balm for their wounds in their time of need.

In your service as a full-time missionary, you will go to thousands of people in great spiritual need. Many, until you teach them, will not even know that they have spiritual wounds that, left untreated, will bring endless misery. You will go on the Lord’s errand to rescue them. Only the Lord can bind up their spiritual wounds as they accept the ordinances that lead to eternal life.

As a quorum member, as a home teacher, and as a missionary, you cannot help people repair spiritual damage unless your own faith is vibrant. That means far more than reading the scriptures regularly and praying over them. The prayer in the moment and quick glances in the scriptures are not preparation enough. The reassurance of what you will need comes with this counsel from the 84th section of the Doctrine and Covenants: “Neither take ye thought beforehand what ye shall say; but treasure up in your minds continually the words of life, and it shall be given you in the very hour that portion that shall be meted unto every man.”2

That promise can be claimed only if we “treasure up” the words of life and do it continually. The treasuring part of that scripture has meant for me a matter of feeling something about the words. For instance, when I have gone to try to help someone wavering in his or her faith about the Prophet Joseph Smith’s divine calling, feelings come back to me.

It is not only the words from the Book of Mormon. It is a feeling of assurance of truth that comes whenever I read even a few lines from the Book of Mormon. I cannot promise that it will come to every person infected with doubt about the Prophet Joseph or the Book of Mormon. But I know Joseph Smith is the Prophet of the Restoration. I know that the Book of Mormon is the word of God because I have treasured it.

I know from experience that you can get the assurance of truth from the Spirit because it has come to me. You and I must have that assurance before the Lord puts us in the way of a traveler we love who has been wounded by the enemies of truth.

There is another preparation we must make. It is a human characteristic to become hardened to the pains of others. That is one of the reasons why the Savior went to such lengths to tell of His Atonement and of His taking upon Himself the pains and sorrows of all of our Heavenly Father’s children that He might know how to succor them.

Even the best of Heavenly Father’s mortal priesthood holders do not rise to that standard of compassion easily. Our human tendency is to be impatient with the person who cannot see the truth that is so plain to us. We must be careful that our impatience is not interpreted as condemnation or rejection.

As we prepare to give succor for the Lord as His priesthood servants, there is a scripture to guide us. It contains a gift we will need for our journey, wherever the Lord will send us. The good Samaritan had that gift. We will need it, and the Lord has told us how we can find it:

“Wherefore, my beloved brethren, if ye have not charity, ye are nothing, for charity never faileth. Wherefore, cleave unto charity, which is the greatest of all, for all things must fail—

“But charity is the pure love of Christ, and it endureth forever; and whoso is found possessed of it at the last day, it shall be well with him.

“Wherefore, my beloved brethren, pray unto the Father with all the energy of heart, that ye may be filled with this love, which he hath bestowed upon all who are true followers of his Son, Jesus Christ; that ye may become the sons of God; that when he shall appear we shall be like him, for we shall see him as he is; that we may have this hope; that we may be purified even as he is pure.”3

I pray that we may prepare ourselves to give whatever priesthood service the Lord may set before us on our mortal journey. In the sacred name of Jesus Christ, amen.

# References
1. - Luke 10:33–35.
2. - Doctrine and Covenants 84:85.
3. - Moroni 7:46–48.