President Thomas S. Monson
President of the Church
10-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/10/welcome-to-conference?lang=eng)

_It is my prayer that we may be filled with the Spirit of the Lord as we listen and learn._

How good it is, my beloved brothers and sisters, to meet together once again. It has been just over 183 years since the Church was organized by the Prophet Joseph Smith, under the direction of the Lord. At that meeting on April 6, 1830, there were six members of the Church present.1

I am happy to announce that two weeks ago, the membership of the Church reached 15 million. The Church continues to grow steadily and to change the lives of more and more people every year. It is spreading across the earth as our missionary force seeks out those who are searching for the truth.

It has scarcely been one year since I announced the lowering of the age of missionary service. Since that time the number of full-time missionaries serving has increased from 58,500 in October 2012 to 80,333 today. What a tremendous and inspiring response we have witnessed!

The holy scriptures contain no proclamation more relevant, no responsibility more binding, no instruction more direct than the injunction given by the resurrected Lord as He appeared in Galilee to the eleven disciples. Said He, “Go ye therefore, and teach all nations, baptizing them in the name of the Father, and of the Son, and of the Holy Ghost.”2 The Prophet Joseph Smith declared, “After all that has been said, the greatest and most important duty is to preach the Gospel.”3 Some of you here today will yet remember the words of President David O. McKay, who phrased the familiar “Every member a missionary!”4

To their words I add my own. Now is the time for members and missionaries to come together, to work together, to labor in the Lord’s vineyard to bring souls unto Him. He has prepared the means for us to share the gospel in a multitude of ways, and He will assist us in our labors if we will act in faith to fulfill His work.

To help maintain our ever-increasing missionary force, I have asked our members in the past to contribute, as they are able, to their ward missionary fund or to the General Missionary Fund of the Church. The response to that request has been gratifying and has helped support thousands of missionaries whose circumstances do not allow them to support themselves. I thank you for your generous contributions. The need for help is ongoing, that we might continue to assist those whose desire to serve is great but who do not, by themselves, have the means to do so.



Now, brothers and sisters, we have come here to be instructed and inspired. Many messages, covering a variety of gospel topics, will be given during the next two days. Those men and women who will speak to you have sought heaven’s help concerning the messages they will give.

It is my prayer that we may be filled with the Spirit of the Lord as we listen and learn. In the name of our Savior, Jesus Christ, amen.

# References
1. - While as many as a few dozen people were present the day the Church was organized, six were officially listed as organizing members.
2. - Matthew 28:19.
3. - Teachings of Presidents of the Church: Joseph Smith (2007), 330.
4. - David O. McKay, in Conference Report, Apr. 1959, 122.