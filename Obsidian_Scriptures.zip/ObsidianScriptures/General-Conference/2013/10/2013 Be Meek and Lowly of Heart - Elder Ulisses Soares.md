Elder Ulisses Soares
Of the Presidency of the Seventy
10-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/10/be-meek-and-lowly-of-heart?lang=eng)

_Being meek does not mean weakness, but it does mean behaving with goodness and kindness._

Mormon taught that a man “cannot have faith and hope, save he shall be meek, and lowly of heart.”1 He added that without such attributes, “faith and hope is vain, for none is acceptable before God, save the meek and lowly in heart.”2

Meekness is the quality of those who are “Godfearing, righteous, humble, teachable, and patient under suffering.”3 Those who possess this attribute are willing to follow Jesus Christ, and their temperament is calm, docile, tolerant, and submissive.

The Apostle Paul taught that meekness is a fruit of the Spirit.4 Therefore, it can most easily be attained if we “live in the Spirit.”5 And to live in the Spirit, our lifestyle must reflect righteousness before the Lord.

As we take Christ’s name upon us, it is expected that we strive to emulate His attributes and change our character to become more like Him each day. The Savior, admonishing His disciples, said, “Be ye therefore perfect, even as your Father which is in heaven is perfect.”6 If we “come unto Christ, … deny [ourselves] of all ungodliness; … and love God,” then through Christ’s grace the day will come when we may be perfect in Him.7

“Christlike attributes are gifts from God. [These attributes] come as [we] use [our] agency righteously. …With a desire to please God, [we have to] recognize [our] weaknesses and be willing and anxious to improve.”8

Meekness is vital for us to become more Christlike. Without it we won’t be able to develop other important virtues. Being meek does not mean weakness, but it does mean behaving with goodness and kindness, showing strength, serenity, healthy self-worth, and self-control.

Meekness was one of the most abundant attributes in the Savior’s life. He Himself taught His disciples, “Learn of me; for I am meek and lowly in heart.”9

We are blessed to be born with the seed of meekness in our hearts. We need to understand that it is not possible to grow and develop that seed in the twinkling of an eye but rather through the process of time. Christ asks us to “take up [our] cross daily,”10 meaning that it must be a constant focus and desire.

President Lorenzo Snow, the fifth prophet of our dispensation, taught, “It is our duty to try to be perfect, … to improve each day, and look upon our course last week and do things better this week; do things better today than we did them yesterday.”11 So the first step to becoming meek is to improve day by day. Each day we need to try to be better than the previous as we move forward through this process.

President Snow added:

“We have our little follies and our weaknesses; we should try to overcome them as fast as possible, and … should [instill] this feeling in the hearts of our children … that they may learn to [behave] properly before Him under all circumstances.

“If the husband can live with his wife one day without quarrelling or without treating anyone unkindly or without grieving the Spirit of God … he is so far perfect. Then let him try to be the same the next day. But supposing he should fail in this his next day’s attempt, that is no reason why he should not succeed in doing so the third day.”12

Upon acknowledging our dedication and perseverance, the Lord will give us that which we are not able to attain due to our imperfections and human weaknesses.

Another important step to becoming meek is learning how to control our temper. Because the natural man dwells within each one of us and because we live in a world full of pressure, controlling our temper may become one of the challenges in our lives. Think for a few seconds how you react when someone does not comply with your desires the moment you want them to. What about when people disagree with your ideas, even though you are absolutely sure that they represent the proper solution to a problem? What is your response when someone offends you, critiques your efforts, or is simply unkind because he or she is in a bad mood? At these moments and in other difficult situations, we must learn to control our temper and convey our feelings with patience and gentle persuasion. This is most important within our homes and within our relationships with our eternal companions. During the 31 years I’ve been married to my sweetheart, she has often given me gentle reminders of this as we have faced life’s unsettling challenges.

Among instructions found in his Second Epistle to Timothy, the Apostle Paul said:

“And the servant of the Lord must not strive; but be gentle unto all men, apt to teach, patient,

“In meekness instructing those that oppose themselves; if God peradventure will give them repentance to the acknowledging of the truth;

“And that they may recover themselves.”13

By controlling our reactions, being calm and temperate, and avoiding contention, we will begin to qualify for the gift of meekness. President Henry B. Eyring once said, “When we with faith control our tempers and subdue our pride, the Holy Ghost gives His approval, and sacred promises and covenants become sure.”14

Another step to attain meekness is to become humble. The Lord instructed Thomas B. Marsh through the Prophet Joseph Smith, saying, “Be thou humble; and the Lord thy God shall lead thee by the hand, and give thee answer to thy prayers.”15

I believe, brothers and sisters, that only those who are humble are able to acknowledge and understand the Lord’s answers to their prayers. The humble are teachable, recognizing how dependent they are on God and desiring to be subject to His will. The humble are meek and have the ability to influence others to be the same. God’s promise to the humble is that He will lead them by the hand. I truly believe that we will avoid detours and sadness in our lives as long as we walk hand in hand with the Lord.

One of the most beautiful modern-day examples of meekness that I am aware of is that of Brother Moses Mahlangu. His conversion began in 1964, when he received a copy of the Book of Mormon. He was fascinated as he read this book, but it was not until the early ’70s that he saw an LDS Church sign on a building in Johannesburg, South Africa, as he was walking down a street. Brother Mahlangu was intrigued and entered the building to learn more about the Church. He was kindly told that he could not attend the services or be baptized because the country’s laws did not allow it at that time.

Brother Mahlangu accepted that decision with meekness, humility, and without resentment, but he continued to have a strong desire to learn more about the Church. He asked the Church leaders if they could leave one of the meetinghouse windows open during the Sunday meetings so he could sit outside and listen to the services. For several years, Brother Mahlangu’s family and friends attended church regularly “through the window.” One day in 1980 they were told that they could attend church and also be baptized. What a glorious day it was for Brother Mahlangu.

Later the Church organized a branch in his neighborhood in Soweto. This was possible only because of the determination, courage, and faithfulness of people like Brother Mahlangu who remained faithful for so many years under difficult circumstances.

One of Brother Mahlangu’s friends, who had joined the Church at the same time, recounted this story to me when I visited the Soweto stake. At the end of our conversation, he gave me a hug. At that moment, brothers and sisters, I felt as if I was encircled in the Savior’s loving arms. Meekness emanated from this good brother’s eyes. With a heart full of goodness and deep gratitude, he asked if I could just tell President Thomas S. Monson how grateful and blessed he and many others were for having the true gospel in their lives. Brother Mahlangu and his friend’s example of meekness truly influenced many lives for good—especially mine.

Brothers and sisters, I believe the Savior Jesus Christ is the supreme example of meekness. Even during the last moments of His mortal life, being unfairly accused and condemned, painfully carrying His cross up to Golgotha, being mocked and cursed by His enemies, being abandoned by many who knew Him and had witnessed His miracles, He was nailed on the cross.

Even after the most intense physical suffering, the Lord turned to His Father and spoke from the bottom of His meek and humble heart: “Father, forgive them; for they know not what they do.”16 Christ faced extreme physical and spiritual suffering, giving us the opportunity to change our spiritual character and become meek like Him.

I bear my witness that Jesus Christ is our Savior. I testify to you that, thanks to His love, it is possible to change. It is possible to leave our weaknesses behind. It is possible to reject the evil influences in our lives, control our anger, become meek, and develop the attributes of our Savior. He showed us the way. He gave us the perfect example and commanded each one of us to become as He is. His invitation to us is to follow Him, follow His example, and become like Him. Of these truths I bear testimony in His sacred name, even Jesus Christ, amen.

# References
1. - Moroni 7:43.
2. - Moroni 7:44.
3. - Guide to the Scriptures, “Meek, Meekness”; scriptures.lds.org.
4. - See Galatians 5:22–23.
5. - Galatians 5:25.
6. - Matthew 5:48.
7. - Moroni 10:32.
8. - Preach My Gospel: A Guide to Missionary Service (2004), 115.
9. - Matthew 11:29.
10. - Luke 9:23.
11. - Lorenzo Snow, in Conference Report, Apr. 1898, 13.
12. - Teachings of Presidents of the Church: Lorenzo Snow (2012), 100, 101.
13. - 2 Timothy 2:24–26.
14. - Henry B. Eyring, “Families under Covenant,” Ensign or Liahona, May 2012, 65.
15. - Doctrine and Covenants 112:10.
16. - Luke 23:34.