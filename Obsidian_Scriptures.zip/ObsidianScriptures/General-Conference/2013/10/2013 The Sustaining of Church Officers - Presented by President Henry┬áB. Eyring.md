Presented by President Henry B. Eyring
First Counselor in the First Presidency
10-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/10/the-sustaining-of-church-officers?lang=eng)

It is proposed that we sustain Thomas Spencer Monson as prophet, seer, and revelator and President of The Church of Jesus Christ of Latter-day Saints; Henry Bennion Eyring as First Counselor in the First Presidency; and Dieter Friedrich Uchtdorf as Second Counselor in the First Presidency.

Those in favor may manifest it.

Those opposed, if any, may manifest it.

It is proposed that we sustain Boyd Kenneth Packer as President of the Quorum of the Twelve Apostles and the following as members of that quorum: Boyd K. Packer, L. Tom Perry, Russell M. Nelson, Dallin H. Oaks, M. Russell Ballard, Richard G. Scott, Robert D. Hales, Jeffrey R. Holland, David A. Bednar, Quentin L. Cook, D. Todd Christofferson, and Neil L. Andersen.

Those in favor, please manifest it.

Any opposed may so indicate.

It is proposed that we sustain the counselors in the First Presidency and the Twelve Apostles as prophets, seers, and revelators.

All in favor, please manifest it.

Contrary, if there be any, by the same sign.

It is proposed that we release Elders John B. Dickson, Paul E. Koelliker, and F. Michael Watson as members of the First Quorum of the Seventy and designate them as emeritus General Authorities.

It is also proposed that we release Elder Kent D. Watson as a member of the Second Quorum of the Seventy.

We likewise recognize and express appreciation to Elders César H. Hooker and Craig T. Wright, who have been released from their service as Area Seventies.

Those who wish to join us in expressing gratitude to these Brethren for their excellent service, please manifest it.

It is proposed that we sustain the following as new Area Seventies: Julio A. Angulo, Peter F. Evans, and Gennady N. Podvodov.

All in favor, please manifest it.

Those opposed, if any.

It is proposed that we sustain Randall L. Ridd as second counselor in the Young Men general presidency.

Those in favor may manifest it.

Any opposed may so signify.

It is proposed that we sustain the other General Authorities, Area Seventies, and general auxiliary presidencies as presently constituted.

Those in favor, please manifest it.

Any opposed may manifest it.

Thank you, brothers and sisters, for your sustaining vote and for your continued faith and prayers in our behalf.

# References
