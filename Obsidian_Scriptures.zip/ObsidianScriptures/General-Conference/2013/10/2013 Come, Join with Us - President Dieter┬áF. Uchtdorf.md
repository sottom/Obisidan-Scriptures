President Dieter F. Uchtdorf
Second Counselor in the First Presidency
10-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/10/come-join-with-us?lang=eng)

_Regardless of your circumstances, your personal history, or the strength of your testimony, there is room for you in this Church._

Once there was a man who dreamed that he was in a great hall where all the religions of the world were gathered. He realized that each religion had much that seemed desirable and worthy.

He met a nice couple who represented The Church of Jesus Christ of Latter-day Saints and asked, “What do you require of your members?”

“We do not require anything,” they replied. “But the Lord asks that we consecrate all.”

The couple went on to explain about Church callings, home and visiting teaching, full-time missions, weekly family home evenings, temple work, welfare and humanitarian service, and assignments to teach.

“Do you pay your people for all the work they do?” the man asked.

“Oh, no,” the couple explained. “They offer their time freely.”

“Also,” the couple continued, “every six months our Church members spend a weekend attending or watching 10 hours of general conference.”

“Ten hours of people giving talks?” the man wondered.

“What about your weekly church services? How long are they?”

“Three hours, every Sunday!”

“Oh, my,” the man said. “Do members of your church actually do what you have said?”

“That and more. We haven’t even mentioned family history, youth camps, devotionals, scripture study, leadership training, youth activities, early-morning seminary, maintaining Church buildings, and of course there is the Lord’s law of health, the monthly fast to help the poor, and tithing.”

The man said, “Now I’m confused. Why would anyone want to join such a church?”

The couple smiled and said, “We thought you would never ask.”





Why Would Anyone Join Such a Church?



At a time when many churches throughout the world are experiencing significant decreases in numbers, The Church of Jesus Christ of Latter-day Saints—though small in comparison with many others—is one of the fastest growing churches in the world. As of September 2013 the Church has more than 15 million members around the world.

There are many reasons for this, but may I offer a few?





The Savior’s Church



First, this Church was restored in our day by Jesus Christ Himself. Here you will find the authority to act in His name—to baptize for the remission of sins, to confer the gift of the Holy Ghost, and to seal on earth and in heaven.1

Those who join this Church love the Savior Jesus Christ and they wish to follow Him. They rejoice in the knowledge that God speaks to mankind again. When they receive sacred priesthood ordinances and make covenants with God, they can feel His power in their lives.2 When they enter the holy temple, they sense they are in His presence. When they read the holy scriptures3 and live the teachings of His prophets, they grow closer to the Savior they love so much.







An Active Faith



Another reason is because the Church provides opportunities for doing good.

Believing in God is commendable, but most people want to do more than listen to inspirational sermons or dream of their mansions above.4 They want to put their faith into practice. They want to roll up their sleeves and become engaged in this great cause.

And that is what happens when they join with us—they have many opportunities to transform their talents, compassion, and time into good works. Because we have no paid local clergy in our worldwide congregations, our members perform the work of ministry themselves. They are called by inspiration. Sometimes we volunteer; sometimes we are “volunteered.” We see assignments not as burdens but as opportunities to fulfill covenants we gladly make to serve God and His children.







Treasured Blessings



A third reason why people join the Church is because walking the path of discipleship leads to precious blessings.

We see baptism as the starting point in our journey of discipleship. Our daily walk with Jesus Christ leads to peace and purpose in this life and profound joy and eternal salvation in the world to come.

Those who follow this path faithfully avoid many of the pitfalls, sorrows, and regrets of life.

The poor in spirit and honest of heart find great treasures of knowledge here.

Those who suffer or grieve find healing here.

Those burdened with sin find forgiveness, liberty, and rest.









To Those Who Leave



The search for truth has led millions of people to The Church of Jesus Christ of Latter-day Saints. However, there are some who leave the Church they once loved.

One might ask, “If the gospel is so wonderful, why would anyone leave?”

Sometimes we assume it is because they have been offended or lazy or sinful. Actually, it is not that simple. In fact, there is not just one reason that applies to the variety of situations.

Some of our dear members struggle for years with the question whether they should separate themselves from the Church.

In this Church that honors personal agency so strongly, that was restored by a young man who asked questions and sought answers, we respect those who honestly search for truth. It may break our hearts when their journey takes them away from the Church we love and the truth we have found, but we honor their right to worship Almighty God according to the dictates of their own conscience, just as we claim that privilege for ourselves.5







Unanswered Questions



Some struggle with unanswered questions about things that have been done or said in the past. We openly acknowledge that in nearly 200 years of Church history—along with an uninterrupted line of inspired, honorable, and divine events—there have been some things said and done that could cause people to question.

Sometimes questions arise because we simply don’t have all the information and we just need a bit more patience. When the entire truth is eventually known, things that didn’t make sense to us before will be resolved to our satisfaction.

Sometimes there is a difference of opinion as to what the “facts” really mean. A question that creates doubt in some can, after careful investigation, build faith in others.







Mistakes of Imperfect People



And, to be perfectly frank, there have been times when members or leaders in the Church have simply made mistakes. There may have been things said or done that were not in harmony with our values, principles, or doctrine.

I suppose the Church would be perfect only if it were run by perfect beings. God is perfect, and His doctrine is pure. But He works through us—His imperfect children—and imperfect people make mistakes.

In the title page of the Book of Mormon we read, “And now, if there are faults they are the mistakes of men; wherefore, condemn not the things of God, that ye may be found spotless at the judgment-seat of Christ.”6

This is the way it has always been and will be until the perfect day when Christ Himself reigns personally upon the earth.

It is unfortunate that some have stumbled because of mistakes made by men. But in spite of this, the eternal truth of the restored gospel found in The Church of Jesus Christ of Latter-day Saints is not tarnished, diminished, or destroyed.

As an Apostle of the Lord Jesus Christ and as one who has seen firsthand the councils and workings of this Church, I bear solemn witness that no decision of significance affecting this Church or its members is ever made without earnestly seeking the inspiration, guidance, and approbation of our Eternal Father. This is the Church of Jesus Christ. God will not allow His Church to drift from its appointed course or fail to fulfill its divine destiny.







There Is Room for You



To those who have separated themselves from the Church, I say, my dear friends, there is yet a place for you here.

Come and add your talents, gifts, and energies to ours. We will all become better as a result.

Some might ask, “But what about my doubts?”

It’s natural to have questions—the acorn of honest inquiry has often sprouted and matured into a great oak of understanding. There are few members of the Church who, at one time or another, have not wrestled with serious or sensitive questions. One of the purposes of the Church is to nurture and cultivate the seed of faith—even in the sometimes sandy soil of doubt and uncertainty. Faith is to hope for things which are not seen but which are true.7

Therefore, my dear brothers and sisters—my dear friends—please, first doubt your doubts before you doubt your faith.8 We must never allow doubt to hold us prisoner and keep us from the divine love, peace, and gifts that come through faith in the Lord Jesus Christ.

Some might say, “I just don’t fit in with you people in the Church.”

If you could see into our hearts, you would probably find that you fit in better than you suppose. You might be surprised to find that we have yearnings and struggles and hopes similar to yours. Your background or upbringing might seem different from what you perceive in many Latter-day Saints, but that could be a blessing. Brothers and sisters, dear friends, we need your unique talents and perspectives. The diversity of persons and peoples all around the globe is a strength of this Church.

Some might say, “I don’t think I could live up to your standards.”

All the more reason to come! The Church is designed to nourish the imperfect, the struggling, and the exhausted. It is filled with people who desire with all their heart to keep the commandments, even if they haven’t mastered them yet.

Some might say, “I know a member of your Church who is a hypocrite. I could never join a church that had someone like him as a member.”

If you define hypocrite as someone who fails to live up perfectly to what he or she believes, then we are all hypocrites. None of us is quite as Christlike as we know we should be. But we earnestly desire to overcome our faults and the tendency to sin. With our heart and soul we yearn to become better with the help of the Atonement of Jesus Christ.

If these are your desires, then regardless of your circumstances, your personal history, or the strength of your testimony, there is room for you in this Church. Come, join with us!







Come, Join with Us!



In spite of our human imperfections, I am confident that you will find among the members of this Church many of the finest souls this world has to offer. The Church of Jesus Christ seems to attract the kind and the caring, the honest and the industrious.

If you expect to find perfect people here, you will be disappointed. But if you seek the pure doctrine of Christ, the word of God “which healeth the wounded soul,”9 and the sanctifying influence of the Holy Ghost, then here you will find them. In this age of waning faith—in this age when so many feel distanced from heaven’s embrace—here you will find a people who yearn to know and draw closer to their Savior by serving God and fellowmen, just like you. Come, join with us!







Will Ye Also Go Away?



I am reminded of a time in the Savior’s life when many abandoned Him.10 Jesus asked His twelve disciples:

“Will ye also go away?

“Then Simon Peter answered him, Lord, to whom shall we go? thou hast the words of eternal life.”11

There are times when we have to answer the same question. Will we also go away? Or will we, like Peter, hold fast to the words of eternal life?

If you seek truth, meaning, and a way to transform faith into action; if you are looking for a place of belonging: Come, join with us!

If you have left the faith you once embraced: Come back again. Join with us!

If you are tempted to give up: Stay yet a little longer. There is room for you here.

I plead with all who hear or read these words: Come, join with us. Come heed the call of the gentle Christ. Take up your cross and follow Him.12

Come, join with us! For here you will find what is precious beyond price.

I testify that here you will find the words of eternal life, the promise of blessed redemption, and the pathway to peace and happiness.

I earnestly pray that your own search for truth will impress upon your heart the desire to come and join with us. In the sacred name of Jesus Christ, amen.

# References
1. - See Matthew 16:18–19; Helaman 10:7.
2. - See Doctrine and Covenants 84:20.
3. - See 2 Nephi 33:10.
4. - See “Have I Done Any Good?” Hymns, no. 223.
5. - See Articles of Faith 1:11.
6. - Title page of the Book of Mormon; see Mormon 8:17.
7. - See Hebrews 11:1; Alma 32:21.
8. - See F. F. Bosworth, Christ the Healer (1924), 23.
9. - Jacob 2:8.
10. - See John 6:66.
11. - John 6:67–68.
12. - See Matthew 16:24.