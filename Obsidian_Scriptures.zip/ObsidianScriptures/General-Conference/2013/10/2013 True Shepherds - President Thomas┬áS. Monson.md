President Thomas S. Monson
President of the Church
10-2013
[Link to Talk](https://www.churchofjesuschrist.org/study/general-conference/2013/10/true-shepherds?lang=eng)

_Home teaching answers many prayers and permits us to see the transformations which can take place in people’s lives._

Tonight in the Conference Center in Salt Lake City and in locations far and near are assembled those who bear the priesthood of God. Truly you are “a royal priesthood”—even “a chosen generation,” as the Apostle Peter declared.1 I am honored to have the privilege to address you.

When I was growing up, each summer our family would drive to Provo Canyon, about 45 miles (72 km) south and a little east of Salt Lake City, where we would stay in the family cabin for several weeks. We boys were always anxious to get on the fishing stream or into the swimming hole, and we would try to push the car a little faster. In those days, the automobile my father drove was a 1928 Oldsmobile. If he went over 35 miles (56 km) an hour, my mother would say, “Keep it down! Keep it down!” I would say, “Put the accelerator down, Dad! Put it down!”

Dad would drive about 35 miles an hour all the way up to Provo Canyon or until we would come around a bend in the road and our journey would be halted by a herd of sheep. We would watch as hundreds of sheep filed past us, seemingly without a shepherd, a few dogs yapping at their heels as they moved along. Way back in the rear we could see the sheepherder on his horse—not a bridle on it but a halter. He was occasionally slouched down in the saddle dozing, since the horse knew which way to go and the yapping dogs did the work.

Contrast that to the scene which I viewed in Munich, Germany, many years ago. It was a Sunday morning, and we were en route to a missionary conference. As I looked out the window of the mission president’s automobile, I saw a shepherd with a staff in his hand, leading the sheep. They followed him wherever he went. If he moved to the left, they followed him to the left. If he moved to the right, they followed him in that direction. I made the comparison between the true shepherd who led his sheep and the sheepherder who rode casually behind his sheep.

Jesus said, “I am the good shepherd, and know my sheep.”2 He provides for us the perfect example of what a true shepherd should be.

Brethren, as the priesthood of God we have a shepherding responsibility. The wisdom of the Lord has provided guidelines whereby we might be shepherds to the families of the Church, where we can serve, we can teach, and we can testify to them. Such is called home teaching, and it is about this that I wish to speak to you tonight.

The bishop of each ward in the Church oversees the assigning of priesthood holders as home teachers to visit the homes of members every month. They go in pairs. Where possible, a young man who is a priest or a teacher in the Aaronic Priesthood accompanies an adult holding the Melchizedek Priesthood. As they go into the homes of those for whom they are responsible, the Aaronic Priesthood holder should take part in the teaching which takes place. Such an assignment will help to prepare these young men for missions as well as for a lifetime of priesthood service.

The home teaching program is a response to modern revelation commissioning those ordained to the priesthood “to teach, expound, exhort, baptize, … and visit the house of each member, and exhort them to pray vocally and in secret and attend to all family duties, … to watch over the church always, and be with and strengthen them; and see that there is no iniquity in the church, neither hardness with each other, neither lying, backbiting, nor evil speaking.”3

President David O. McKay admonished: “Home teaching is one of our most urgent and most rewarding opportunities to nurture and inspire, to counsel and direct our Father’s children. … [It] is a divine service, a divine call. It is our duty as Home Teachers to carry the … spirit into every home and heart. To love the work and do our best will bring unbounded peace, joy and satisfaction to [a noble,] dedicated [teacher] of God’s children.”4

From the Book of Mormon we read that Alma “consecrated all their priests and all their teachers; and none were consecrated except they were just men.

“Therefore they did watch over their people, and did nourish them with things pertaining to righteousness.”5

In performing our home teaching responsibilities, we are wise if we learn and understand the challenges of the members of each family, that we might be effective in teaching and in providing needed assistance.

A home teaching visit is also more likely to be successful if an appointment is made in advance. To illustrate this point, let me share with you an experience I had some years ago. At that time the Missionary Executive Committee was comprised of Spencer W. Kimball, Gordon B. Hinckley, and Thomas S. Monson. One evening Brother and Sister Hinckley hosted a dinner in their home for the committee members and our wives. We had just finished a lovely meal when there was a knock at the door. President Hinckley opened the door and found one of his home teachers standing there. The home teacher said, “I know I didn’t make an appointment to come, and I don’t have with me my companion, but I felt I should come tonight. I didn’t know you would be entertaining company.”

President Hinckley graciously invited the home teacher to come in and sit down and to instruct three Apostles and our wives concerning our duty as members. With a bit of trepidation, the home teacher did his best. President Hinckley thanked him for coming, after which he made a hurried exit.

I mention one more example of the incorrect way to accomplish home teaching. President Marion G. Romney, who was a counselor in the First Presidency some years ago, used to tell about his home teacher who once went to the Romney home on a cold winter night. He kept his hat in his hand and shifted nervously when invited to sit down and give his message. As he remained standing, he said, “Well, I’ll tell you, Brother Romney, it’s cold outside, and I left my car engine running so it wouldn’t stop. I just came by so I could tell the bishop I had made my visits.”6

President Ezra Taft Benson, after relating President Romney’s experience in a meeting of priesthood holders, then said, “We can do better than that, brethren—much better!”7 I agree.

Home teaching is more than a mechanical visit once per month. Ours is the responsibility to teach, to inspire, to motivate, and where we visit those who are not active, to bring to activity and to eventual exaltation the sons and daughters of God.

To assist in our efforts, I share this wise counsel which surely applies to home teachers. It comes from Abraham Lincoln, who said, “If you would win a man to your cause, first convince him that you are his sincere friend.”8 President Ezra Taft Benson urged: “Above all, be a genuine friend to the individuals and families you teach. … A friend makes more than a dutiful visit each month. A friend is more concerned about helping people than getting credit. A friend cares. A friend [shows love]. A friend listens, and a friend reaches out.”9

Home teaching answers many prayers and permits us to see the transformations which can take place in people’s lives.

An example of this would be Dick Hammer, who came to Utah with the Civilian Conservation Corps during the Depression. He met and married a Latter-day Saint young woman. He opened Dick’s Café in St. George, Utah, which became a popular meeting spot.

Assigned as home teacher to the Hammer family was Willard Milne, a friend of mine. Since I knew Dick Hammer as well, having printed the menus for his café, I would ask my friend Brother Milne when I visited St. George, “How is our friend Dick Hammer coming?”

The reply would generally be, “He’s coming, but slowly.”

When Willard Milne and his companion visited the Hammer home each month, they always managed to present a gospel message and to share their testimonies with Dick and the family.

The years passed by, and then one day Willard phoned me with good news. “Brother Monson,” he began, “Dick Hammer is converted and is going to be baptized. He is in his 90th year, and we have been friends all our adult lives. His decision warms my heart. I’ve been his home teacher for many years.” There was a catch in Willard’s voice as he conveyed his welcome message.

Brother Hammer was indeed baptized and a year later entered that beautiful St. George Temple and there received his endowment and sealing blessings.

I asked Willard, “Did you ever become discouraged as his home teacher for such a long time?”

He replied, “No, it was worth every effort. As I witness the joy which has come to the members of the Hammer family, my heart fills with gratitude for the blessings the gospel has brought into their lives and for the privilege I have had to help in some way. I am a happy man.”

Brethren, it will be our privilege through the years to visit and teach many individuals—those who are less active as well as those who are fully committed. If we are conscientious in our calling, we will have many opportunities to bless lives. Our visits to those who have distanced themselves from Church activity can be the key which will eventually open the doors to their return.

With this thought in mind, let us reach out to those for whom we are responsible and bring them to the table of the Lord to feast on His word and to enjoy the companionship of His Spirit and be “no more strangers and foreigners, but fellowcitizens with the saints, and of the household of God.”10

If any of you has slipped into complacency concerning your home teaching visits, may I say that there is no time like the present to rededicate yourself to fulfilling your home teaching duties. Decide now to make whatever effort is necessary to reach those for whom you have been given responsibility. There are times when a little extra prodding may be needed, as well, to help your home teaching companion find the time to go with you, but if you are persistent, you will succeed.

Brethren, our efforts in home teaching are ongoing. The work will never be concluded until our Lord and Master says, “It is enough.” There are lives to brighten. There are hearts to touch. There are souls to save. Ours is the sacred privilege to brighten, to touch, and to save those precious souls entrusted to our care. We should do so faithfully and with hearts filled with gladness.

In closing I turn to one particular example to describe the type of home teachers we should be. There is one Teacher whose life overshadows all others. He taught of life and death, of duty and destiny. He lived not to be served but to serve, not to receive but to give, not to save His life but to sacrifice it for others. He described a love more beautiful than lust, a poverty richer than treasure. It was said of this Teacher that He taught with authority and not as did the scribes.11 His laws were not inscribed upon stone but upon human hearts.

I speak of the Master Teacher, even Jesus Christ, the Son of God, the Savior and Redeemer of all mankind. The biblical account says of Him, He “went about doing good.”12 With Him as our unfailing guide and exemplar, we shall qualify for His divine help in our home teaching. Lives will be blessed. Hearts will be comforted. Souls will be saved. We will become true shepherds. That this may be so, I pray in the name of that great Shepherd, Jesus Christ, amen.

# References
1. - 1 Peter 2:9.
2. - John 10:14.
3. - Doctrine and Covenants 20:42, 47, 53–54.
4. - David O. McKay, in Priesthood Home Teaching Handbook, rev. ed. (1967), ii, iii.
5. - Mosiah 23:17–18.
6. - Quoted in Marion G. Romney, address given at a priesthood home teaching seminar, Aug. 9, 1963.
7. - Ezra Taft Benson, “To the Home Teachers of the Church,” Ensign, May 1987, 50.
8. - Abraham Lincoln, in David Decamp Thompson, Abraham Lincoln, the First American (1895), 226.
9. - Ezra Taft Benson, Ensign, May 1987, 50.
10. - Ephesians 2:19.
11. - See Matthew 7:28–29.
12. - Acts 10:38.